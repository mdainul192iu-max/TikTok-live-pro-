export type AppLanguage = 'bn' | 'en' | 'es' | 'hi' | 'ar' | 'pt' | 'ur' | 'id';

export type NavTab = 'home' | 'friends' | 'upload' | 'inbox' | 'profile';
export type TopFeedTab = 'foryou' | 'following' | 'community' | 'stem' | 'rtdb_feed';
export type ThemeMode = 'dark' | 'light';
export type GraphicQuality = 'auto' | '1080p' | '720p' | 'data_saver';

export interface AccessibilitySettings {
  autoScroll: boolean;
  fastScrollButtons: boolean;
  screenReaderDescriptions: boolean;
  largeText: boolean;
  hapticFeedback: boolean;
  highContrast: boolean;
  reducedMotion: boolean;
  playbackSpeed: number;
}

export interface Creator {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  profileVideo?: string;
  pronouns?: string;
  instagram?: string;
  youtube?: string;
  twitter?: string;
  verified: boolean;
  followers: number;
  following: number;
  likesTotal: number;
  bio: string;
  isFollowed?: boolean;
  // Account Violation / Community Guidelines Warning System
  hasWarning?: boolean;
  warningReason?: string;
  warningIssuedAt?: number;
  warningCopyLinksCount?: number;
  warningRequiredCopyLinks?: number;
  warningRecoveryStartedAt?: number;
  warningRecoveryDaysRemaining?: number;
  countryCode?: string;
  countryName?: string;
  phoneNumber?: string;
  // Automated Moderation & Shadowban AI fields
  violationCount?: number;
  isShadowbanned?: boolean;
  shadowbanReason?: string;
}

export interface UserAccount extends Creator {
  uid: string; // TikTok numeric UID e.g. 7192849204
  authMethod: 'gmail' | 'facebook' | 'twitter' | 'phone' | 'email' | 'google';
  identifier: string; // email or phone
  email?: string;
  createdAt: string;
  postedReelIds?: string[];
  likedReelIds?: string[];
  savedReelIds?: string[];
}

export type MusicSourceType = 'spotify' | 'youtube_music' | 'original' | 'trending';

export interface SoundTrack {
  id: string;
  title: string;
  artist: string;
  audioUrl: string;
  cover: string;
  duration: string;
  usesCount: number;
  category: 'trending' | 'brazilian_funk' | 'bangla' | 'lofi' | 'phonk' | 'bollywood' | 'viral';
  source?: MusicSourceType;
  youtubeVideoId?: string;
  spotifyTrackId?: string;
  waveform?: number[];
}

export interface CommentReply {
  id: string;
  commentId: string;
  user: {
    id?: string;
    name: string;
    handle: string;
    avatar: string;
    verified: boolean;
  };
  text: string;
  timestamp: string;
  likes: number;
  isLiked?: boolean;
  isCreatorReply?: boolean;
}

export interface CommentItem {
  id: string;
  user: {
    id?: string;
    name: string;
    handle: string;
    avatar: string;
    verified: boolean;
  };
  text: string;
  timestamp: string;
  likes: number;
  isLiked?: boolean;
  isCreatorLiked?: boolean;
  creatorLikedAvatar?: string;
  replies?: CommentReply[];
}

export interface InboxActivityItem {
  id: string;
  type: 'like' | 'comment' | 'reply' | 'follow';
  actor: {
    id?: string;
    name: string;
    handle: string;
    avatar: string;
    isFollowed?: boolean;
  };
  targetReelId?: string;
  targetReelThumbnail?: string;
  commentId?: string;
  text?: string;
  timestamp: string;
  createdAt: number;
  isRead?: boolean;
}

export interface PhoneNotificationBanner {
  id: string;
  title: string;
  message: string;
  avatar?: string;
  type?: 'like' | 'comment' | 'reply' | 'follow';
  reelId?: string;
  timestamp: number;
}

export interface VideoReel {
  id: string;
  videoUrl: string;
  posterUrl: string;
  caption: string;
  captionBn?: string;
  tags: string[];
  creator: Creator;
  music: SoundTrack;
  likesCount: number;
  isLiked: boolean;
  commentsCount: number;
  sharesCount: number;
  bookmarksCount: number;
  isBookmarked: boolean;
  viewsCount: number;
  category: 'foryou' | 'following' | 'friends' | 'trending';
  createdAt: string;
  location?: string;
  isAutoViral?: boolean;
  viralScore?: number;
  viralGrowthRate?: number;
  // Firestore backend schema fields for video publishing and reuse
  thumbnailUrl?: string;
  audioUrl?: string;
  originalArtistId?: string;
  audioSource?: MusicSourceType;
  audioId?: string;
  audioTitle?: string;
  audioThumbnailUrl?: string;
  // Recommendation interaction metrics
  watchTimeSec?: number;
  completionRate?: number;
  loopCount?: number;
  // TikTok Algorithm Progression Tiers (200 -> 2,000 -> 20,000 -> Viral Loop)
  algorithmTier?: 'tier_50' | 'tier_200' | 'tier_1000' | 'tier_2000' | 'tier_10000' | 'tier_20000' | 'tier_viral';
  algorithmReach?: number;
  algorithmScore?: number;
  algorithmStatusText?: string;
  isFirebaseLive?: boolean;
  // Multi-Photo Carousel mode (2, 4, or multiple pictures swipeable left-right)
  postType?: 'video' | 'photo_carousel';
  images?: string[];
  // TikTok Promoted / Boosted Sponsored Ads System
  isPromoted?: boolean;
  promotedBadge?: string;
  promotedCampaignId?: string;
  // Gemini Multimodal AI Pipeline & Safety Guardrail Fields
  subtitles?: SubtitleCue[];
  moderation?: VideoModerationResult;
  reviewStatus?: 'pending_review' | 'active' | 'rejected';
  isShadowbanned?: boolean;
  // Adaptive High Quality & 3G Low-Phone Compression
  videoQuality?: 'adaptive_hd' | '1080p' | '720p' | '480p' | 'data_saver';
  adaptiveStreamUrl?: string;
  dataSaverCompressed?: boolean;
  networkOptimized?: boolean;
}

export interface SubtitleCue {
  id: string;
  startTimeMs: number;
  endTimeMs: number;
  text: string;
  censored?: boolean;
}

export interface VideoModerationResult {
  status: 'approved' | 'rejected' | 'flagged';
  safetyScore: number; // 0 - 100
  isSafe: boolean;
  violations: string[];
  warningReason?: string;
  flaggedCategories?: string[];
  moderatedAt: number;
}

export interface CountryConfig {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  dialCode: string;
  defaultLanguage: AppLanguage;
  defaultCity: string;
  timezone: string;
}

export interface DraftReel {
  id: string;
  videoUrl: string;
  posterUrl: string;
  title: string;
  caption: string;
  location?: string;
  music?: SoundTrack;
  savedAt: string;
  filter?: string;
  textOverlays?: Array<{
    id: string;
    text: string;
    color: string;
    size: number;
    x: number;
    y: number;
  }>;
  quality?: '4k' | '1080p' | '720p' | '480p';
  musicVolume?: number;
  originalVolume?: number;
  trimStart?: number;
  trimEnd?: number;
}

export interface UserStory {
  id: string;
  videoUrl: string;
  posterUrl: string;
  createdAt: number;
  expiresAt?: number;
  creator: Creator;
  music?: SoundTrack;
  caption?: string;
  likesCount?: number;
  isLiked?: boolean;
  viewsCount?: number;
}

export interface LiveCallSession {
  id?: string;
  callerId?: string;
  callerName?: string;
  callerAvatar?: string;
  receiverId?: string;
  receiverName: string;
  receiverAvatar: string;
  receiverHandle?: string;
  type: 'video' | 'audio';
  status?: 'ringing' | 'accepted' | 'declined' | 'completed';
  startedAt?: number;
}

export interface BoostCampaign {
  id: string;
  userId: string;
  userUid: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  videoUrl: string;
  reelId?: string;
  videoCaption?: string;
  targetViews: number;
  targetLikes: number;
  totalCostDollar: number;
  paymentMethod: 'bkash' | 'nagad' | 'mastercard' | 'binance' | 'bank';
  transactionId: string;
  senderPhone?: string;
  description?: string;
  createdAt: number;
  status: 'pending' | 'active' | 'completed' | 'rejected';
  deliveredViews: number;
  deliveredLikes: number;
  paymentVerified: boolean;
}

export interface BannedUserInfo {
  id: string;
  uid: string;
  name: string;
  handle: string;
  avatar: string;
  bannedAt: number;
  reason?: string;
}

// =========================================================================
// CAPCUT VIP IN-APP PURCHASES & PAYMENT GATEWAY (ক্যাপকাট ভিআইপি ফিচার আনলক)
// =========================================================================

export interface VipCapCutPurchase {
  id: string;
  userId: string;
  userUid: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  featureKey: string; // e.g. 'all_vip_access' | '4k_hdr_export' | 'ai_clone_vfx' | 'cyberpunk_aura' | 'voice_studio'
  featureTitle: string;
  amountBDT: number;
  amountUSD: number;
  paymentMethod: 'bkash' | 'nagad' | 'binance' | 'paypal' | 'mastercard' | 'bank';
  transactionId: string;
  senderPhone: string;
  adminPhoneContact: string; // '01875328569'
  createdAt: number;
  status: 'pending' | 'verified' | 'completed';
}

// =========================================================================
// RECOMMENDATION ENGINE & COLD START USER PROFILE
// =========================================================================

export interface UserRecommendationProfile {
  videosWatchedCount: number;
  isColdStartCompleted: boolean;
  detectedInterests: string[];
  interestScores: Record<string, number>;
  totalWatchTimeSec: number;
  totalLoops: number;
  totalLikes: number;
  totalShares: number;
  lastUpdated: number;
}

export interface CapCutTemplate {
  id: string;
  title: string;
  category: string;
  previewVideoUrl: string;
  coverUrl: string;
  requiredClips: number;
  musicTitle: string;
  durationSec: number;
  usesCount: number;
  filterPreset: string;
  speedPreset: number;
  tags: string[];
}

export interface AutoSubtitleItem {
  id: string;
  text: string;
  startSec: number;
  endSec: number;
  style: 'classic_yellow' | 'neon_cyan' | 'bold_stroke' | 'bounce_pop';
}


