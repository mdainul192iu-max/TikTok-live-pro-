export function safeSetItem(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.warn(`Could not save key ${key} to localStorage`, e);
  }
}

export function safeGetItem(key: string, defaultValue: string = ''): string {
  try {
    return localStorage.getItem(key) || defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

export function sanitizeThreadsForStorage(threads: any[]): any[] {
  return threads.map((t) => ({
    id: t.id,
    name: t.name,
    handle: t.handle,
    avatar: t.avatar,
    isOnline: t.isOnline,
    unreadCount: t.unreadCount || 0,
    lastMessage: t.lastMessage || '',
    lastTime: t.lastTime || '',
    messages: (t.messages || []).slice(-30),
  }));
}
