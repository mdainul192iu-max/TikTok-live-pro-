import React, { useState, useRef, useEffect, useCallback } from 'react';
import { initialReels, mockComments, mockCreators, mockSoundTracks, initialStories, initialActivities } from './data/mockData';
import { 
  VideoReel, 
  CommentItem, 
  SoundTrack, 
  Creator, 
  UserAccount,
  NavTab, 
  TopFeedTab, 
  AppLanguage,
  ThemeMode,
  AccessibilitySettings,
  DraftReel,
  UserStory,
  CommentReply,
  InboxActivityItem,
  PhoneNotificationBanner,
  BoostCampaign
} from './types';
import { TopNavigation } from './components/TopNavigation';
import { SideActions } from './components/SideActions';
import { BottomInfo } from './components/BottomInfo';
import { BottomNavBar } from './components/BottomNavBar';
import { CommentsDrawer } from './components/CommentsDrawer';
import { ShareDrawer } from './components/ShareDrawer';
import { SoundDetailModal } from './components/SoundDetailModal';
import { UploadModal } from './components/UploadModal';
import { SearchModal } from './components/SearchModal';
import { ProfileModal } from './components/ProfileModal';
import { StoryViewerModal } from './components/StoryViewerModal';
import { AuthModal } from './components/AuthModal';
import { LiveStreamModal } from './components/LiveStreamModal';
import { InboxModal } from './components/InboxModal';
import { SettingsModal, SettingsSubView } from './components/SettingsModal';
import { SystemBackButton } from './components/SystemBackButton';
import { RecentAppsModal } from './components/RecentAppsModal';
import { UserListModal, UserListMode } from './components/UserListModal';
import { CallModal } from './components/CallModal';
import { TikTokVideoFeed } from './components/TikTokVideoFeed';
import { TikTokSnapFeed } from './components/TikTokSnapFeed';
import { AlgorithmInsightsModal } from './components/AlgorithmInsightsModal';
import { FloatingGeminiAssistant } from './components/FloatingGeminiAssistant';
import { GeminiAssistantModal } from './components/GeminiAssistantModal';
import { RewardedAdPlayerModal } from './components/RewardedAdPlayerModal';
import { admobService } from './services/admobService';
import { videoCacheManager } from './services/videoCacheManager';
import { recommendationEngine } from './services/recommendationEngine';
import { networkQualityService } from './services/networkQualityService';
import { backgroundMusicManager } from './services/musicApiService';
import { registerSoundFromReel } from './services/soundRegistryService';
import { referralWalletService } from './services/referralWalletService';
import { 
  syncReelToFirebase, 
  syncUserToFirebase, 
  syncCommentToFirebase, 
  fetchReelsFromFirebase,
  LiveCallSession,
  updateFirebaseCallSession,
  isUserBanned,
  fetchBannedUsers,
  fetchBoostCampaigns
} from './services/firebaseService';
import { safeSetItem } from './utils/storage';
import { 
  Play, 
  Heart, 
  ChevronUp, 
  ChevronDown, 
  Sparkles, 
  Flame, 
  Settings, 
  RefreshCw,
  X,
  AlertOctagon,
  Rocket,
  Zap
} from 'lucide-react';

export default function App() {
  // User Requirement: প্রত্যেক লেখা ইংরেজি ভাষা হবে (English default with multi-language selector in settings)
  const [language, setLanguage] = useState<AppLanguage>('en');
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  const [activeNavTab, setActiveNavTab] = useState<NavTab>('home');
  const [activeTopTab, setActiveTopTab] = useState<TopFeedTab>('foryou');
  const [selectedCountryForAuth, setSelectedCountryForAuth] = useState<any>(null);

  // Reels Feed State
  const [reels, setReels] = useState<VideoReel[]>(initialReels);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [activeReel, setActiveReel] = useState<VideoReel>(initialReels[0]);
  const [recommendationProfile, setRecommendationProfile] = useState(() => recommendationEngine.getProfile());

  // Dynamic recommendation feed for the 3 core tabs (For You, Following, Community, STEM)
  const activeTabReels = React.useMemo(() => {
    if (activeTopTab === 'following') {
      return recommendationEngine.getFollowingFeed(reels, ['usr-mona', 'usr-mehzabin']);
    }
    if (activeTopTab === 'community') {
      return recommendationEngine.getCommunityFeed(reels);
    }
    if (activeTopTab === 'stem') {
      const stem = reels.filter((r) =>
        r.tags.some((t) => t.includes('cyber') || t.includes('neon') || t.includes('tech') || t.includes('viral'))
      );
      return stem.length > 0 ? stem : reels;
    }
    // Default 'foryou'
    return recommendationEngine.getForYouFeed(reels);
  }, [reels, activeTopTab]);

  // Video playback & audio mute
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isHomeMuted, setIsHomeMuted] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleToggleHomeMute = () => {
    setIsHomeMuted((prev) => {
      const next = !prev;
      triggerToast(
        next
          ? (language === 'bn' ? '🔇 সাউন্ড বন্ধ (মিউট করা হয়েছে)' : '🔇 Muted')
          : (language === 'bn' ? '🔊 সাউন্ড চালু (আসল গান বাজবে)' : '🔊 Sound Unmuted')
      );
      return next;
    });
  };

  // Modals
  const [showComments, setShowComments] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showSoundModal, setShowSoundModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showLiveStreamModal, setShowLiveStreamModal] = useState(false);
  const [showInboxModal, setShowInboxModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [settingsInitialSubView, setSettingsInitialSubView] = useState<SettingsSubView>(null);
  const [showRecentAppsModal, setShowRecentAppsModal] = useState(false);
  const [showGeminiAssistantModal, setShowGeminiAssistantModal] = useState<boolean>(false);
  const [isFloatingGeminiEnabled, setIsFloatingGeminiEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_floating_gemini') !== 'false';
    } catch {
      return true;
    }
  });
  const [activeCallSession, setActiveCallSession] = useState<LiveCallSession | null>(null);
  const [showAlgorithmModal, setShowAlgorithmModal] = useState(false);
  const [selectedAlgorithmReel, setSelectedAlgorithmReel] = useState<VideoReel | null>(null);
  const [targetChatUser, setTargetChatUser] = useState<Creator | null>(null);
  const [showRewardedAdModal, setShowRewardedAdModal] = useState<boolean>(false);

  // Entities for modals
  const [activeCreator, setActiveCreator] = useState<Creator>(mockCreators.harshu);
  const [activeSound, setActiveSound] = useState<SoundTrack>(mockSoundTracks[0]);
  const [allComments, setAllComments] = useState<Record<string, CommentItem[]>>(mockComments);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const triggerToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  }, []);

  // User Requirements: ইনবক্সে লাইক, কমেন্ট, ফলো ও রিপ্লাই লম্বা অপশন
  const [activities, setActivities] = useState<InboxActivityItem[]>(() => {
    try {
      const saved = localStorage.getItem('tiktok_user_activities');
      return saved ? JSON.parse(saved) : initialActivities;
    } catch {
      return initialActivities;
    }
  });

  // User Requirements: ফোনের নোটিফিকেশন বার (Phone Notification Bar / Banner)
  const [phoneNotification, setPhoneNotification] = useState<PhoneNotificationBanner | null>(null);
  const phoneNotifTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const triggerPhoneNotification = useCallback((notif: Omit<PhoneNotificationBanner, 'id' | 'timestamp'>) => {
    const banner: PhoneNotificationBanner = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: Date.now(),
    };
    setPhoneNotification(banner);
    if (phoneNotifTimeoutRef.current) clearTimeout(phoneNotifTimeoutRef.current);
    phoneNotifTimeoutRef.current = setTimeout(() => {
      setPhoneNotification(null);
    }, 4500);
  }, []);

  // Sync activities to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tiktok_user_activities', JSON.stringify(activities));
    } catch {}
  }, [activities]);

  // Current logged in account (starts as null to show Screenshot_20261016-183446.png on Profile click)
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    try {
      const saved = localStorage.getItem('tiktok_logged_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // User Drafts & Stories (User request: ড্রাফট ও স্টোরি অপশন)
  const [drafts, setDrafts] = useState<DraftReel[]>(() => {
    try {
      const saved = localStorage.getItem('tiktok_user_drafts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [userStories, setUserStories] = useState<UserStory[]>(() => {
    try {
      const saved = localStorage.getItem('tiktok_user_stories');
      const parsed: UserStory[] = saved ? JSON.parse(saved) : [];
      // Combine with initial creator stories and filter out older than 24 hours
      const combined = [...parsed, ...initialStories.filter((init) => !parsed.some((p) => p.id === init.id))];
      const valid = combined.filter((s) => Date.now() - s.createdAt < 24 * 60 * 60 * 1000);
      return valid.length > 0 ? valid : initialStories;
    } catch {
      return initialStories;
    }
  });

  const [activeStoryQueue, setActiveStoryQueue] = useState<UserStory[]>([]);
  const [showStoryViewer, setShowStoryViewer] = useState(false);
  const [storyInitialIndex, setStoryInitialIndex] = useState(0);
  const [openProfileOnStoryClose, setOpenProfileOnStoryClose] = useState(false);

  const [editingDraft, setEditingDraft] = useState<DraftReel | null>(null);

  // User Requirement: ব্যান করলে তার আইডি বা এই এপস আর ইউজ করতে পারবে না আন ব্যান করলে সব কাজ এপসের ভিতর করতে পারবে
  const [bannedVersion, setBannedVersion] = useState(0);
  const isCurrentBanned = React.useMemo(() => {
    const handleToCheck = currentUser?.handle || (currentUser as any)?.identifier || '';
    const idToCheck = currentUser?.id || '';
    const uidToCheck = (currentUser as any)?.uid || '';
    return isUserBanned(handleToCheck) || isUserBanned(idToCheck) || isUserBanned(uidToCheck);
  }, [currentUser, bannedVersion]);

  // AI-Driven In-App Navigation (User Requirement: কেউ যদি বলে এপসের যেকোনো যায়গায় নিয়ে যেতে এআই ওই পেজে নিয়ে যাবে)
  const handleNavigateFromAI = useCallback((destination: string) => {
    setShowGeminiAssistantModal(false);

    if (destination === 'profile') {
      setShowProfileModal(true);
      triggerToast(language === 'bn' ? '👤 প্রোফাইল পেজে নিয়ে আসা হয়েছে' : '👤 Navigated to Profile');
    } else if (destination === 'upload') {
      setShowUploadModal(true);
      triggerToast(language === 'bn' ? '🎬 ক্যাপকাট ও ভিডিও এডিটর স্টুডিও খোলা হয়েছে' : '🎬 Opened Video Editor Studio');
    } else if (destination === 'inbox') {
      setShowInboxModal(true);
      triggerToast(language === 'bn' ? '💬 ইনবক্স ও মেসেজ চ্যাট খোলা হয়েছে' : '💬 Opened Inbox & Messages');
    } else if (destination === 'live') {
      setShowLiveStreamModal(true);
      triggerToast(language === 'bn' ? '🔴 লাইভ স্ট্রিম স্টুডিও শুরু হয়েছে' : '🔴 Opened Live Stream Studio');
    } else if (destination === 'settings') {
      setSettingsInitialSubView(null);
      setShowSettingsModal(true);
      triggerToast(language === 'bn' ? '⚙️ সেটিংস ও এডমিন প্যানেল খোলা হয়েছে' : '⚙️ Opened Settings & Admin');
    } else if (destination === 'search') {
      setShowSearchModal(true);
      triggerToast(language === 'bn' ? '🔍 সার্চ পেজ খোলা হয়েছে' : '🔍 Opened Search');
    } else if (destination === 'sound') {
      setShowSoundModal(true);
      triggerToast(language === 'bn' ? '🎵 সাউন্ড ও ব্যাকগ্রাউন্ড মিউজিক খোলা হয়েছে' : '🎵 Opened Sound Library');
    } else if (destination === 'algorithm') {
      setSelectedAlgorithmReel(activeReel);
      setShowAlgorithmModal(true);
      triggerToast(language === 'bn' ? '📊 ৪-টিয়ার ভাইরাল অ্যালগরিদম ইনসাইটস' : '📊 4-Tier Viral Algorithm Insights');
    } else if (destination === 'boost') {
      setSettingsInitialSubView('tiktok_boost');
      setShowSettingsModal(true);
      triggerToast(language === 'bn' ? '💎 বিকাশ, নগদ ও রেফারেল ওয়ালেট ভিডিও বুস্ট' : '💎 Video Boost Studio');
    } else if (destination === 'refer' || destination === 'wallet') {
      setSettingsInitialSubView('refer_and_earn');
      setShowSettingsModal(true);
      triggerToast(language === 'bn' ? '🎁 রেফার ও আর্ন ওয়ালেট (৳৪৯৯ বোনাস)' : '🎁 Refer & Earn Wallet (৳499 Bonus)');
    } else if (destination === 'home') {
      setActiveNavTab('home');
      setActiveTopTab('foryou');
      triggerToast(language === 'bn' ? '🏠 হোমপেজ ফর ইউ ফিডে নিয়ে আসা হয়েছে' : '🏠 Navigated to For You Feed');
    } else if (destination === 'friends') {
      setActiveNavTab('friends');
      setActiveTopTab('following');
      triggerToast(language === 'bn' ? '👥 ফ্রেন্ডস ফিডে নিয়ে আসা হয়েছে' : '👥 Navigated to Friends Feed');
    } else if (destination === 'auth') {
      setShowAuthModal(true);
      triggerToast(language === 'bn' ? '🔑 লগইন / রেজিস্ট্রেশন পেজ' : '🔑 Opened Auth Portal');
    }
  }, [language, activeReel, triggerToast]);

  // Boost Campaign Activation on For You feed
  const handleActivateBoost = (campaign: BoostCampaign) => {
    setReels((prev) => {
      const targetIdx = prev.findIndex((r) => r.videoUrl === campaign.videoUrl || r.id === campaign.reelId);
      if (targetIdx !== -1) {
        const targetReel = prev[targetIdx];
        const boosted: VideoReel = {
          ...targetReel,
          isPromoted: true,
          promotedBadge: 'Sponsored • Promoted 🚀',
          viewsCount: (targetReel.viewsCount || 0) + campaign.targetViews,
          likesCount: (targetReel.likesCount || 0) + campaign.targetLikes,
        };
        const rest = prev.filter((_, i) => i !== targetIdx);
        return [boosted, ...rest];
      } else {
        const customReel: VideoReel = {
          id: `promoted-${campaign.id}`,
          videoUrl: campaign.videoUrl || 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-light-futuristic-concept-42209-large.mp4',
          posterUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400',
          caption: `[Sponsored 🚀] ${campaign.description || campaign.videoCaption || 'Special offer & business promotion'} 🔥`,
          tags: ['#promoted', '#sponsored', '#foryou', '#viral'],
          creator: {
            id: campaign.userId,
            name: campaign.userName,
            handle: campaign.userHandle,
            avatar: campaign.userAvatar,
            verified: true,
            followers: 25000,
            following: 10,
            likesTotal: campaign.targetLikes,
            bio: campaign.description || 'Verified Business Campaign',
          },
          music: mockSoundTracks[0],
          likesCount: campaign.targetLikes,
          isLiked: false,
          commentsCount: 88,
          sharesCount: 140,
          bookmarksCount: 95,
          isBookmarked: false,
          viewsCount: campaign.targetViews,
          category: 'foryou',
          createdAt: 'Just now',
          isPromoted: true,
          promotedBadge: 'Sponsored • Promoted 🚀',
          promotedCampaignId: campaign.id,
        };
        return [customReel, ...prev];
      }
    });

    triggerToast(`🚀 Video Boost Active! Delivering ${campaign.targetViews.toLocaleString()} views to For You feed.`);
  };

  // Sync drafts and stories to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tiktok_user_drafts', JSON.stringify(drafts));
    } catch {}
  }, [drafts]);

  useEffect(() => {
    try {
      localStorage.setItem('tiktok_user_stories', JSON.stringify(userStories));
    } catch {}
  }, [userStories]);

  // Periodic 24-hour story auto-deletion cleanup
  useEffect(() => {
    const cleanup = () => {
      setUserStories((prev) => {
        const active = prev.filter((s) => Date.now() - s.createdAt < 24 * 60 * 60 * 1000);
        if (active.length !== prev.length) {
          try {
            localStorage.setItem('tiktok_user_stories', JSON.stringify(active));
          } catch {}
          return active;
        }
        return prev;
      });
    };
    const interval = setInterval(cleanup, 60000);
    return () => clearInterval(interval);
  }, []);

  // Referral URL link detector
  // User Requirement: মানুষ এই লিংকে ক্লিক করে একাউন্ট অপশনে আসবে এবং 499 টাকা আনলক হয়ে যাবে এবং নিচে লেখা আসবে 600 টাকা উইথড্র করতে পারবেন হলে এবং এই টাকা দিয়ে ভিডিও বুস্ট করতে পারবে
  useEffect(() => {
    try {
      let refCode: string | null = null;
      if (typeof window !== 'undefined') {
        if (window.location.search) {
          const params = new URLSearchParams(window.location.search);
          refCode = params.get('ref') || params.get('referral');
        }
        if (!refCode && window.location.hash) {
          const hash = window.location.hash.replace(/^#/, '');
          const hashParams = new URLSearchParams(hash);
          refCode = hashParams.get('ref') || hashParams.get('referral');
        }
      }
      if (refCode) {
        referralWalletService.claimReferralBonus(refCode);
        triggerToast(
          language === 'bn'
            ? '🎉 রেফারেল বোনাস ৳৪৯৯ আনলক হয়েছে! ন্যূনতম ৳৬০০ হলে নগদ/বিকাশ উইথড্র করতে পারবেন অথবা এখনই ভিডিও বুস্ট করতে পারবেন।'
            : '🎉 ৳499 Referral Bonus unlocked! Minimum withdrawal is ৳600, or boost videos right now.'
        );
        setSettingsInitialSubView('refer_and_earn');
        setShowSettingsModal(true);
      }
    } catch {}
  }, [language, triggerToast]);

  // Pull-to-refresh on Home feed
  const [isFeedRefreshing, setIsFeedRefreshing] = useState(false);

  // Format numbers
  const formatCount = (count: number) => {
    if (count >= 1000000) return (count / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (count >= 1000) return (count / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    return count.toString();
  };

  // Next and Previous reel
  const goToNextReel = useCallback(() => {
    setCurrentIndex((prev) => (prev < reels.length - 1 ? prev + 1 : 0));
  }, [reels.length]);

  const goToPrevReel = useCallback(() => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : 0));
  }, []);

  // Handle Home Feed Pull-to-Refresh
  const handleHomeFeedRefresh = () => {
    setIsFeedRefreshing(true);
    setTimeout(() => {
      setReels((prev) => [...prev.slice(1), prev[0]]);
      setIsFeedRefreshing(false);
      triggerToast(language === 'bn' ? '✓ নতুন ভিডিও ফিডে লোড হয়েছে!' : '✓ Fresh feed loaded!');
    }, 700);
  };

  // Double tap to like with floating heart

  // Require account before allowing like, comment, share, follow, upload, inbox
  const requireAuth = (actionName: string) => {
    if (!currentUser) {
      triggerToast(
        language === 'bn' 
          ? `⚠️ ${actionName} করতে আগে টিকটক আইডি খুলুন!` 
          : `⚠️ Please log in to ${actionName}!`
      );
      setActiveCreator({
        id: 'self',
        name: 'Profile',
        handle: 'guest',
        avatar: '',
        verified: false,
        followers: 0,
        following: 0,
        likesTotal: 0,
        bio: '',
      });
      setShowProfileModal(true);
      return false;
    }
    return true;
  };

  // Toggle Like with TikTok Algorithm Progression Response & Inbox Activity sync
  const handleToggleLike = (reelId: string) => {
    if (!requireAuth(language === 'bn' ? 'লাইক দিতে' : 'like videos')) return;
    setReels((prev) =>
      prev.map((r) => {
        if (r.id === reelId) {
          const nextLiked = !r.isLiked;
          const nextLikes = nextLiked ? r.likesCount + 1 : Math.max(0, r.likesCount - 1);
          recommendationEngine.trackLike(r, nextLiked);

          let updatedReel: VideoReel = {
            ...r,
            isLiked: nextLiked,
            likesCount: nextLikes,
          };

          // Record to Inbox Activity list when liked
          if (nextLiked) {
            const newAct: InboxActivityItem = {
              id: `act-like-${Date.now()}`,
              type: 'like',
              actor: {
                id: currentUser?.id,
                name: currentUser ? currentUser.name : 'আমার অ্যাকাউন্ট',
                handle: currentUser ? currentUser.handle : 'user_bangla',
                avatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
              },
              targetReelId: r.id,
              targetReelThumbnail: r.posterUrl,
              text: 'আপনার ভিডিও পছন্দ করেছেন ❤️',
              timestamp: 'এইমাত্র',
              createdAt: Date.now(),
            };
            setActivities((acts) => [newAct, ...acts]);
          }

          // If video is in active algorithm testing tiers, positive likes trigger promotion!
          if (nextLiked && r.algorithmTier) {
            if (r.algorithmTier === 'tier_50') {
              const res = recommendationEngine.advanceReelTier(updatedReel);
              updatedReel = res.updatedReel;
              triggerToast(
                language === 'bn'
                  ? '🚀 ইতিবাচক রেসপন্স! ভিডিওটি ১,০০০ জনের ফর ইউ পেজে পৌঁছেছে!'
                  : '🚀 Promoted to 1,000 users on For You page!'
              );
            } else if (r.algorithmTier === 'tier_1000' && nextLikes >= 200) {
              const res = recommendationEngine.advanceReelTier(updatedReel);
              updatedReel = res.updatedReel;
              triggerToast(
                language === 'bn'
                  ? '🔥 উচ্চ লাইক রেসপন্স! ভিডিওটি ১০,০০০ জনের ফর ইউ পেজে ভাইরাল হয়েছে!'
                  : '🔥 High engagement pushed video to 10,000+ users on FYP!'
              );
            }
          }

          syncReelToFirebase(updatedReel);
          if (selectedAlgorithmReel?.id === r.id) {
            setSelectedAlgorithmReel(updatedReel);
          }
          return updatedReel;
        }
        return r;
      })
    );
  };

  // Explicit Manual or Accelerated Algorithm Tier Advance
  const handleAdvanceAlgorithmTier = (targetReel: VideoReel) => {
    const { updatedReel, message } = recommendationEngine.advanceReelTier(targetReel);
    setReels((prev) => prev.map((r) => (r.id === targetReel.id ? updatedReel : r)));
    setSelectedAlgorithmReel(updatedReel);
    syncReelToFirebase(updatedReel);
    triggerToast(message);
  };

  // Toggle Bookmark
  const handleToggleBookmark = (reelId: string) => {
    if (!requireAuth(language === 'bn' ? 'বুকমার্ক করতে' : 'bookmark videos')) return;
    setReels((prev) =>
      prev.map((r) => {
        if (r.id === reelId) {
          const nextSaved = !r.isBookmarked;
          return {
            ...r,
            isBookmarked: nextSaved,
            bookmarksCount: nextSaved ? r.bookmarksCount + 1 : r.bookmarksCount - 1,
          };
        }
        return r;
      })
    );
    triggerToast(
      !activeReel?.isBookmarked
        ? (language === 'bn' ? '✓ বুকমার্কে সংরক্ষিত হয়েছে' : '✓ Saved to bookmarks')
        : (language === 'bn' ? 'বুকমার্ক সরানো হয়েছে' : 'Removed from bookmarks')
    );
  };

  // User Requirement: প্রত্যেক ভিডিও তে আনলিমিটেড কপি লিংক করতে পারবে এবং বেশি বেশি কপি লিংক করলে ওয়ারনিং চলে যাবে ৩ দিন এর ভিতর
  const handleCopyLink = (reel: VideoReel) => {
    try {
      navigator.clipboard?.writeText(window.location.origin + '/video/' + reel.id);
    } catch {}

    if (reel.creator.hasWarning) {
      setReels((prev) =>
        prev.map((r) => {
          if (r.creator.id === reel.creator.id) {
            const nextCount = (r.creator.warningCopyLinksCount || 4) + 1;
            return {
              ...r,
              creator: {
                ...r.creator,
                warningCopyLinksCount: nextCount,
              },
            };
          }
          return r;
        })
      );
    }

    triggerToast(
      language === 'bn'
        ? '✓ ভিডিওর লিংক আনলিমিটেড কপি করা হয়েছে!'
        : '✓ Unlimited video link copied!'
    );
  };

  // Toggle Follow (User Requirement: প্রত্যেক মানুষ একটা আইডিতে একটাই ফলো করতে পারবে এবং ফলো/আনফলো বাটন থাকবে)
  const handleToggleFollow = (creatorId: string) => {
    if (!requireAuth(language === 'bn' ? 'ফলো করতে' : 'follow creators')) return;
    setReels((prev) =>
      prev.map((r) => {
        if (r.creator.id === creatorId) {
          const nextFollow = !r.creator.isFollowed;
          if (nextFollow) {
            const newAct: InboxActivityItem = {
              id: `act-fol-${Date.now()}`,
              type: 'follow',
              actor: {
                id: currentUser ? currentUser.id : 'usr-me',
                name: currentUser ? currentUser.name : 'আমার অ্যাকাউন্ট',
                handle: currentUser ? currentUser.handle : 'user_bangla',
                avatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
                isFollowed: true,
              },
              text: 'আপনাকে ফলো করা শুরু করেছেন 👤',
              timestamp: 'এইমাত্র',
              createdAt: Date.now(),
            };
            setActivities((acts) => [newAct, ...acts]);
            triggerPhoneNotification({
              title: `${r.creator.name} কে ফলো করছেন`,
              message: language === 'bn' ? 'আপনার ফলো সফলভাবে সম্পন্ন হয়েছে' : 'You followed this creator',
              avatar: r.creator.avatar,
              type: 'follow',
            });
          }
          return {
            ...r,
            creator: {
              ...r.creator,
              isFollowed: nextFollow,
              followers: nextFollow ? r.creator.followers + 1 : Math.max(0, r.creator.followers - 1),
            },
          };
        }
        return r;
      })
    );
    triggerToast(language === 'bn' ? '✓ লাইভ ফলো আপডেট হয়েছে' : '✓ Following updated');
  };

  // Add Comment (User Requirement: ১০ করে কমেন্ট করতে পারবে এবং কমেন্ট এর রিপ্লাই অন্য কেউ করলে নোটিফিকেশন বার চলে যাবে)
  const handleAddComment = (text: string, targetReelId?: string) => {
    const reelId = targetReelId || activeReel?.id;
    if (!reelId) return;
    const targetReel = reels.find((r) => r.id === reelId) || activeReel;

    const newComment: CommentItem = {
      id: `c-${Date.now()}`,
      user: {
        id: currentUser?.id,
        name: currentUser ? currentUser.name : 'আমার অ্যাকাউন্ট',
        handle: currentUser ? currentUser.handle : 'user_bangla',
        avatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
        verified: true,
      },
      text,
      timestamp: 'এইমাত্র',
      likes: 0,
      replies: [],
    };

    setAllComments((prev) => ({
      ...prev,
      [reelId]: [newComment, ...(prev[reelId] || [])],
    }));

    setReels((prev) =>
      prev.map((r) =>
        r.id === reelId ? { ...r, commentsCount: r.commentsCount + 1 } : r
      )
    );

    // Record to Inbox Activity list
    const newAct: InboxActivityItem = {
      id: `act-com-${Date.now()}`,
      type: 'comment',
      actor: {
        id: currentUser?.id,
        name: currentUser ? currentUser.name : 'আমার অ্যাকাউন্ট',
        handle: currentUser ? currentUser.handle : 'user_bangla',
        avatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      },
      targetReelId: reelId,
      targetReelThumbnail: targetReel?.posterUrl,
      commentId: newComment.id,
      text,
      timestamp: 'এইমাত্র',
      createdAt: Date.now(),
    };
    setActivities((prev) => [newAct, ...prev]);

    syncCommentToFirebase(reelId, newComment);
    triggerToast(language === 'bn' ? '✓ মন্তব্য পোস্ট করা হয়েছে' : '✓ Comment posted');

    // User Requirement: হোম পেজে শুধু ওই আইডির নির্দিষ্ট ওই ভিডিও তে কমেন্ট করলে তার কোমেনট এর রিপ্লাই অন্য কেউ করলে তার নোটিফিকেশন বার চলে যাবে
    // Realistic simulation: creator or fellow user replies to this comment after 3 seconds, triggering the notification bar!
    setTimeout(() => {
      const replier = targetReel?.creator || mockCreators.harshu;
      const replyText = language === 'bn' 
        ? 'অনেক ধন্যবাদ ভাই, সবসময় সাথে থাকবেন! ❤️🔥' 
        : 'Thank you so much! Always keep supporting ❤️🔥';
      
      const autoReply: CommentReply = {
        id: `rep-${Date.now()}`,
        commentId: newComment.id,
        user: {
          id: replier.id,
          name: replier.name,
          handle: replier.handle,
          avatar: replier.avatar,
          verified: replier.verified,
        },
        text: replyText,
        timestamp: 'এইমাত্র',
        likes: 1,
        isCreatorReply: true,
      };

      setAllComments((prev) => {
        const currentList = prev[reelId] || [];
        const updated = currentList.map((c) =>
          c.id === newComment.id ? { ...c, replies: [...(c.replies || []), autoReply] } : c
        );
        return { ...prev, [reelId]: updated };
      });

      // Add reply to inbox activity
      const replyAct: InboxActivityItem = {
        id: `act-rep-${Date.now()}`,
        type: 'reply',
        actor: {
          id: replier.id,
          name: replier.name,
          handle: replier.handle,
          avatar: replier.avatar,
        },
        targetReelId: reelId,
        targetReelThumbnail: targetReel?.posterUrl,
        commentId: newComment.id,
        text: replyText,
        timestamp: 'এইমাত্র',
        createdAt: Date.now(),
      };
      setActivities((prev) => [replyAct, ...prev]);

      // Trigger the Phone Notification Bar across top of screen!
      triggerPhoneNotification({
        title: replier.name,
        message: language === 'bn' ? `আপনার কমেন্টে রিপ্লাই দিয়েছেন: "${replyText}"` : `replied to your comment: "${replyText}"`,
        avatar: replier.avatar,
        type: 'reply',
        reelId,
      });
    }, 3200);
  };

  // Add Comment Reply manually from user
  const handleAddReply = (commentId: string, text: string, targetReelId?: string) => {
    const reelId = targetReelId || activeReel?.id;
    if (!reelId) return;
    const targetReel = reels.find((r) => r.id === reelId) || activeReel;
    const isUploader = currentUser && targetReel?.creator.handle === currentUser.handle;

    const newReply: CommentReply = {
      id: `rep-${Date.now()}`,
      commentId,
      user: {
        id: currentUser?.id,
        name: currentUser ? currentUser.name : 'আমার অ্যাকাউন্ট',
        handle: currentUser ? currentUser.handle : 'user_bangla',
        avatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
        verified: true,
      },
      text,
      timestamp: 'এইমাত্র',
      likes: 0,
      isCreatorReply: !!isUploader,
    };

    setAllComments((prev) => {
      const currentList = prev[reelId] || [];
      const updated = currentList.map((c) =>
        c.id === commentId ? { ...c, replies: [...(c.replies || []), newReply] } : c
      );
      return { ...prev, [reelId]: updated };
    });

    const replyAct: InboxActivityItem = {
      id: `act-rep-${Date.now()}`,
      type: 'reply',
      actor: {
        id: currentUser?.id,
        name: currentUser ? currentUser.name : 'আমার অ্যাকাউন্ট',
        handle: currentUser ? currentUser.handle : 'user_bangla',
        avatar: currentUser ? currentUser.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      },
      targetReelId: reelId,
      targetReelThumbnail: targetReel?.posterUrl,
      commentId,
      text,
      timestamp: 'এইমাত্র',
      createdAt: Date.now(),
    };
    setActivities((prev) => [replyAct, ...prev]);

    triggerToast(language === 'bn' ? '✓ রিপ্লাই সফলভাবে যোগ করা হয়েছে' : '✓ Reply added');
  };

  // Toggle Like on Comment or Reply (User Requirement: যে ভিডিও আপলোড করছে সে কমেন্ট লাইক দিলে তার প্রোফাইল ছবি ছোট আইকনে সো করবে)
  const handleToggleLikeComment = (commentId: string, replyId?: string, targetReelId?: string) => {
    const reelId = targetReelId || activeReel?.id;
    if (!reelId) return;
    const targetReel = reels.find((r) => r.id === reelId) || activeReel;
    const isUploader = currentUser && targetReel?.creator.handle === currentUser.handle;

    setAllComments((prev) => {
      const currentList = prev[reelId] || [];
      const updated = currentList.map((c) => {
        if (c.id === commentId) {
          if (replyId) {
            const nextReplies = (c.replies || []).map((rep) =>
              rep.id === replyId ? { ...rep, isLiked: !rep.isLiked, likes: rep.isLiked ? rep.likes - 1 : rep.likes + 1 } : rep
            );
            return { ...c, replies: nextReplies };
          }
          const nextLiked = !c.isLiked;
          return {
            ...c,
            isLiked: nextLiked,
            likes: nextLiked ? c.likes + 1 : Math.max(0, c.likes - 1),
            // Video creator like badge: shows small creator avatar badge over the heart
            isCreatorLiked: isUploader ? nextLiked : (c.isCreatorLiked ?? true),
            creatorLikedAvatar: isUploader ? currentUser?.avatar : targetReel?.creator.avatar,
          };
        }
        return c;
      });
      return { ...prev, [reelId]: updated };
    });
  };

  // User Requirement: হোমপেজ থেকে কেউ যদি তার প্রোফাইলে ক্লিক করে যদি তার স্টোরি তার প্রোফাইলে থাকে প্রথমে স্টোরি দেখাবে উপরে কাটা চিহ্ন থাকবে কেটে দিয়ে তার প্রোফাইলে সোজা ঢুকে যাবে সে লাইভ ফলো করতে পারবে এবং তার মতোই সম্পূর্ণ প্রোফাইল ওপেন হবে
  const handleOpenCreator = (creator: Creator) => {
    setActiveCreator(creator);
    const creatorStories = userStories.filter(
      (s) =>
        (s.creator.id === creator.id || s.creator.handle === creator.handle) &&
        Date.now() - s.createdAt < 24 * 60 * 60 * 1000
    );

    if (creatorStories.length > 0) {
      // Put this creator's stories first, then other creators' stories to allow continuous next progression
      const otherStories = userStories.filter(
        (s) =>
          s.creator.id !== creator.id &&
          s.creator.handle !== creator.handle &&
          Date.now() - s.createdAt < 24 * 60 * 60 * 1000
      );
      setActiveStoryQueue([...creatorStories, ...otherStories]);
      setStoryInitialIndex(0);
      setOpenProfileOnStoryClose(true);
      setShowStoryViewer(true);
    } else {
      setShowProfileModal(true);
    }
  };

  // System Back handler
  const handleSystemBack = () => {
    if (showRecentAppsModal) {
      setShowRecentAppsModal(false);
      return;
    }
    if (showAuthModal) {
      setShowAuthModal(false);
      return;
    }
    if (showSettingsModal) {
      setShowSettingsModal(false);
      return;
    }
    if (showLiveStreamModal) {
      setShowLiveStreamModal(false);
      return;
    }
    if (showComments) {
      setShowComments(false);
      return;
    }
    if (showShare) {
      setShowShare(false);
      return;
    }
    if (showUploadModal) {
      setShowUploadModal(false);
      return;
    }
    if (showSearchModal) {
      setShowSearchModal(false);
      return;
    }
    if (showSoundModal) {
      setShowSoundModal(false);
      return;
    }
    if (showProfileModal) {
      setShowProfileModal(false);
      return;
    }
    if (showInboxModal) {
      setShowInboxModal(false);
      return;
    }
    if (activeNavTab !== 'home') {
      setActiveNavTab('home');
      return;
    }
    goToPrevReel();
  };

  return (
    <div className="relative w-screen h-screen bg-black flex items-center justify-center overflow-hidden font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-16 z-70 bg-zinc-900/95 border border-white/20 text-white px-4 py-2 rounded-full text-xs font-bold shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-200">
          {toastMessage}
        </div>
      )}

      {/* Main TikTok Mobile Frame Container */}
      <div className="relative w-full max-w-[430px] h-full sm:h-[95vh] bg-black sm:rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl flex flex-col select-none">

        {/* TOP NAVIGATION (Immersive Status Bar with 2s auto-hide + Tabs + Mute button) */}
        <TopNavigation
          activeTab={activeTopTab}
          onTabChange={(t) => setActiveTopTab(t)}
          onOpenSearch={() => setShowSearchModal(true)}
          onOpenLive={() => setShowLiveStreamModal(true)}
          language={language}
          onSystemBack={handleSystemBack}
          canGoBack={false}
          isAudioMuted={isHomeMuted}
          onToggleAudioMute={handleToggleHomeMute}
        />

        {/* FLOATING QUICK SETTINGS & AI COLD START / PERSONALIZED FEED PILL */}
        <div className="absolute top-14 left-3 z-30 flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setShowSettingsModal(true)}
            className="w-8 h-8 rounded-full bg-black/45 hover:bg-black/70 backdrop-blur-md flex items-center justify-center text-white/90 hover:text-white border border-white/10 shadow-lg active:scale-90 transition-transform cursor-pointer"
            title="সেটিংস"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* AI Cold Start & 100% Personalized Feed Indicator */}
          <button
            type="button"
            onClick={() => {
              setSelectedAlgorithmReel(activeReel);
              setShowAlgorithmModal(true);
            }}
            className="px-2.5 py-1 rounded-full bg-black/55 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white shadow-lg flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="TikTok এআই অ্যালগরিদম ও পারসোনালাইজড রিপোর্ট"
          >
            <div className="w-2 h-2 rounded-full bg-[#25f4ee] animate-ping" />
            <span className="text-[10px] font-black tracking-tight text-white/95">
              {!recommendationProfile.isColdStartCompleted
                ? `🎯 কোল্ড স্টার্ট: ${recommendationProfile.videosWatchedCount}/৫`
                : `✨ এআই ফিড: ${(recommendationProfile.detectedInterests[0] || 'Personalized').toUpperCase()}`}
            </span>
          </button>
        </div>

        {/* STEEM UNLIMITED REWARDED AD BUTTON (User Requirement: Steem Page - Unlimited Rewarded Ad ID: ca-app-pub-3964151806897298/7585516907) */}
        {activeTopTab === 'stem' && (
          <div className="absolute top-14 right-3 z-30 flex items-center gap-1.5 pointer-events-auto">
            <button
              type="button"
              onClick={() => setShowRewardedAdModal(true)}
              className="px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 text-white shadow-xl flex items-center gap-1.5 border border-amber-300/40 text-[11px] font-black cursor-pointer active:scale-95 transition-all animate-pulse"
              title="Watch Unlimited AdMob Rewarded Ads (+5 Coins Each)"
            >
              <Zap className="w-3.5 h-3.5 fill-current text-amber-200" />
              <span>Watch Ad (+5 🪙)</span>
            </button>
          </div>
        )}

        {/* User Requirement: ফোনের নোটিফিকেশন বার (Top Phone Notification Bar / Push Banner) */}
        {phoneNotification && (
          <div
            onClick={() => {
              if (phoneNotification.reelId) {
                const idx = reels.findIndex((r) => r.id === phoneNotification.reelId);
                if (idx !== -1) {
                  setCurrentIndex(idx);
                  setActiveNavTab('home');
                  setActiveTopTab('foryou');
                }
              }
              if (phoneNotification.type === 'reply' || phoneNotification.type === 'comment') {
                setShowComments(true);
              } else if (phoneNotification.type === 'follow') {
                setShowInboxModal(true);
              }
              setPhoneNotification(null);
            }}
            className="absolute top-3 left-3 right-3 z-60 bg-zinc-900/95 hover:bg-zinc-900 text-white p-3 rounded-2xl border border-white/20 shadow-2xl backdrop-blur-xl flex items-start gap-3 cursor-pointer animate-in slide-in-from-top-6 duration-300"
          >
            {/* App / Notification Icon */}
            <div className="relative shrink-0">
              <div className="w-9 h-9 rounded-full overflow-hidden border border-zinc-700">
                <img
                  src={phoneNotification.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80'}
                  alt=""
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-tr from-[#fe2c55] to-[#25f4ee] flex items-center justify-center text-[8px] text-white font-black shadow-xs">
                {phoneNotification.type === 'like' ? '❤️' : phoneNotification.type === 'reply' ? '↩️' : phoneNotification.type === 'follow' ? '👤' : '💬'}
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider text-zinc-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#fe2c55] animate-ping" />
                  TikTok • এইমাত্র
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setPhoneNotification(null);
                  }}
                  className="text-zinc-500 hover:text-white p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <h5 className="text-xs font-black text-white mt-0.5 truncate">
                {phoneNotification.title}
              </h5>
              <p className="text-[11px] text-zinc-300 line-clamp-2 mt-0.5">
                {phoneNotification.message}
              </p>
            </div>
          </div>
        )}

        {/* VIDEO DISPLAY AREA: High-Performance TikTok Vertical Snapping Engine with Autoplay & Video Caching */}
        {activeTopTab === 'rtdb_feed' ? (
          <div className="absolute inset-0 z-0 bg-black">
            <TikTokVideoFeed
              onBack={() => setActiveTopTab('foryou')}
              onUseSound={(sound) => {
                setActiveSound(sound);
                setShowUploadModal(true);
                triggerToast(language === 'bn' ? `✓ '${sound.title}' গানটি সিলেক্ট করা হয়েছে` : 'Sound selected!');
              }}
              onOpenComment={() => {
                if (!requireAuth(language === 'bn' ? 'কমেন্ট করতে' : 'comment')) return;
                setShowComments(true);
              }}
              onShareVideo={() => {
                if (!requireAuth(language === 'bn' ? 'ভিডিও শেয়ার করতে' : 'share videos')) return;
                setShowShare(true);
              }}
            />
          </div>
        ) : (
          <div className="absolute inset-0 z-0 bg-black">
            <TikTokSnapFeed
              reels={activeTabReels}
              activeTopTab={activeTopTab}
              onOpenCreator={handleOpenCreator}
              onOpenSound={(sound) => {
                setActiveSound(sound);
                setShowSoundModal(true);
              }}
              onOpenComments={(reel) => {
                if (!requireAuth(language === 'bn' ? 'কমেন্ট করতে' : 'comment')) return;
                setActiveReel(reel);
                setShowComments(true);
              }}
              onOpenShare={(reel) => {
                if (!requireAuth(language === 'bn' ? 'ভিডিও শেয়ার করতে' : 'share videos')) return;
                setActiveReel(reel);
                setShowShare(true);
              }}
              onToggleLike={handleToggleLike}
              onToggleBookmark={handleToggleBookmark}
              onUseSound={(sound) => {
                setActiveSound(sound);
                setShowUploadModal(true);
                triggerToast(
                  language === 'bn'
                    ? `✓ '${sound.title}' গানটি দিয়ে ভিডিও রেকর্ডিং স্টুডিও চালু হয়েছে 🎬`
                    : `✓ Audio synced for recording: ${sound.title}`
                );
              }}
              onOpenAlgorithmInsights={(reel) => {
                setSelectedAlgorithmReel(reel);
                setShowAlgorithmModal(true);
              }}
              onCopyLink={handleCopyLink}
              language={language}
              formatCount={formatCount}
              onRefreshFeed={handleHomeFeedRefresh}
              isRefreshing={isFeedRefreshing}
              isGlobalAudioMuted={isHomeMuted}
              onToggleAudioMute={handleToggleHomeMute}
              onToast={triggerToast}
            />
          </div>
        )}

        {/* BOTTOM NAV BAR (5 Buttons with Active White Background) */}
        <BottomNavBar
          activeTab={activeNavTab}
          onTabChange={(tab) => {
            if (tab === 'home' && activeNavTab === 'home') {
              handleHomeFeedRefresh();
              return;
            }
            setActiveNavTab(tab);
            if (tab === 'profile') {
              if (currentUser) {
                setActiveCreator(currentUser);
              } else {
                setActiveCreator({
                  id: 'self',
                  name: 'Profile',
                  handle: 'guest',
                  avatar: '',
                  verified: false,
                  followers: 0,
                  following: 0,
                  likesTotal: 0,
                  bio: '',
                });
              }
              setShowProfileModal(true);
            } else if (tab === 'inbox') {
              if (!requireAuth(language === 'bn' ? 'ইনবক্স ব্যবহার করতে' : 'use Inbox')) return;
              setShowInboxModal(true);
            } else if (tab === 'friends') {
              setActiveTopTab('following');
            }
          }}
          onOpenUpload={() => {
            if (!requireAuth(language === 'bn' ? 'ভিডিও পোস্ট করতে' : 'post videos')) return;
            setShowUploadModal(true);
          }}
          onHomeRefresh={handleHomeFeedRefresh}
          isHomeRefreshing={isFeedRefreshing}
          language={language}
          userAvatar={currentUser?.avatar}
          hasStory={userStories.length > 0}
        />

        {/* SYSTEM 3-BUTTON ANDROID NAVIGATION BAR (◁ Back, ○ Home, ▢ Recents) */}
        <SystemBackButton
          onBack={handleSystemBack}
          onHome={() => {
            setShowRecentAppsModal(false);
            setShowSearchModal(false);
            setShowProfileModal(false);
            setShowInboxModal(false);
            setShowUploadModal(false);
            setShowSettingsModal(false);
            setShowComments(false);
            setShowShare(false);
            setShowLiveStreamModal(false);
            setShowAuthModal(false);
            setShowSoundModal(false);
            setActiveNavTab('home');
            setActiveTopTab('foryou');
            setCurrentIndex(0);
          }}
          onOverview={() => setShowRecentAppsModal(true)}
          language={language}
          showBar={true}
          themeMode={themeMode}
        />

        {/* ======================================================== */}
        {/* MODALS & DRAWERS */}
        {/* ======================================================== */}

        {/* 1. Comments Drawer */}
        <CommentsDrawer
          isOpen={showComments}
          onClose={() => setShowComments(false)}
          reel={activeReel}
          comments={activeReel ? allComments[activeReel.id] || [] : []}
          totalCount={activeReel ? activeReel.commentsCount : 0}
          onAddComment={handleAddComment}
          onAddReply={handleAddReply}
          onToggleLikeComment={handleToggleLikeComment}
          currentUser={currentUser}
          language={language}
          onToast={triggerToast}
          onOpenProfile={handleOpenCreator}
        />

        {/* 2. Share Drawer */}
        {activeReel && (
          <ShareDrawer
            isOpen={showShare}
            onClose={() => setShowShare(false)}
            reel={activeReel}
            language={language}
            onRepost={() => {
              setReels((prev) =>
                prev.map((r) =>
                  r.id === activeReel.id ? { ...r, sharesCount: r.sharesCount + 1 } : r
                )
              );
              triggerToast(language === 'bn' ? '✓ রিপোস্ট সম্পন্ন হয়েছে!' : '✓ Reposted!');
            }}
            onToast={triggerToast}
          />
        )}

        {/* 3. Audio & Sound Detail Modal (Dual Tabs: Spotify & YouTube Music v3) */}
        <SoundDetailModal
          isOpen={showSoundModal}
          onClose={() => setShowSoundModal(false)}
          sound={activeSound}
          reels={reels}
          onUseSound={(sound) => {
            setActiveSound(sound);
            setShowUploadModal(true);
            setShowSoundModal(false);
            triggerToast(
              language === 'bn'
                ? `✓ '${sound.title}' মিউজিক ব্যাকগ্রাউন্ডে সিলেক্ট করা হয়েছে! এবার ভিডিও বানান 🎬`
                : '✓ Sound selected for video recording!'
            );
          }}
          language={language}
          onToast={triggerToast}
        />

        {/* 4. Upload & Recording Studio Modal (With CapCut Editor, Post Screen, Story, Drafts) */}
        <UploadModal
          isOpen={showUploadModal}
          onClose={() => {
            setShowUploadModal(false);
            setEditingDraft(null);
          }}
          onPublish={(newReel) => {
            setReels((prev) => [newReel, ...prev]);
            setCurrentIndex(0);
            setActiveNavTab('home');
            setActiveTopTab('foryou');
            syncReelToFirebase(newReel);
            if (editingDraft) {
              setDrafts((prev) => prev.filter((d) => d.id !== editingDraft.id));
              setEditingDraft(null);
            }
          }}
          onPostStory={(story) => {
            setUserStories((prev) => [story, ...prev]);
            if (editingDraft) {
              setDrafts((prev) => prev.filter((d) => d.id !== editingDraft.id));
              setEditingDraft(null);
            }
          }}
          onSaveDraft={(draft) => {
            setDrafts((prev) => [draft, ...prev.filter((d) => d.id !== draft.id)]);
            setEditingDraft(null);
          }}
          editingDraft={editingDraft}
          selectedSound={activeSound}
          onOpenSoundPicker={() => setShowSoundModal(true)}
          currentCreator={currentUser || activeCreator}
          currentUser={currentUser}
          language={language}
          onToast={triggerToast}
        />

        {/* 5. Search Modal */}
        <SearchModal
          isOpen={showSearchModal}
          onClose={() => setShowSearchModal(false)}
          reels={reels}
          onSelectReel={(id) => {
            const idx = reels.findIndex((r) => r.id === id);
            if (idx !== -1) {
              setCurrentIndex(idx);
              setActiveTopTab('foryou');
            }
          }}
          onSelectCreator={(selectedCreator) => {
            setActiveCreator(selectedCreator);
            setShowProfileModal(true);
          }}
          onSelectSoundForVideo={(sound) => {
            setActiveSound(sound);
            setShowUploadModal(true);
            triggerToast(
              language === 'bn'
                ? `✓ '${sound.title}' গানটি রেকর্ড স্টুডিওতে সিলেক্ট করা হয়েছে`
                : `✓ Selected sound: ${sound.title}`
            );
          }}
          language={language}
        />

        {/* 6. Profile Modal (With Eye Icon 👁️ 16 -> Viewers List, Hamburger ☰ -> Side Sheet, UID Create/Login, Story Ring & Drafts) */}
        <ProfileModal
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          creator={activeCreator}
          allReels={reels}
          drafts={drafts}
          userStories={userStories}
          onOpenDraft={(draft) => {
            setEditingDraft(draft);
            setShowProfileModal(false);
            setShowUploadModal(true);
          }}
          onSelectReel={(id) => {
            const idx = reels.findIndex((r) => r.id === id);
            if (idx !== -1) {
              setCurrentIndex(idx);
              setActiveTopTab('foryou');
            }
          }}
          onToggleFollow={handleToggleFollow}
          onToggleLikeReel={handleToggleLike}
          onToggleBookmarkReel={handleToggleBookmark}
          onAddCommentReel={(reelId, text) => handleAddComment(text, reelId)}
          onRepostReel={(reel) => {
            setReels((prev) =>
              prev.map((r) =>
                r.id === reel.id ? { ...r, sharesCount: r.sharesCount + 1 } : r
              )
            );
            triggerToast(language === 'bn' ? '✓ ভিডিওটি বন্ধুদের কাছে রিপোস্ট করা হয়েছে!' : '✓ Reposted video!');
          }}
          allComments={allComments}
          onUpdateProfile={(name, bio, handle, avatar) => {
            if (currentUser) {
              const updated = {
                ...currentUser,
                name,
                bio,
                handle,
                avatar: avatar || currentUser.avatar,
              };
              setCurrentUser(updated);
              setActiveCreator(updated);
              syncUserToFirebase(updated);
            }
          }}
          onOpenSettings={() => {
            setSettingsInitialSubView(null);
            setShowSettingsModal(true);
          }}
          onOpenReferAndEarn={() => {
            setSettingsInitialSubView('wallet_and_earnings');
            setShowSettingsModal(true);
          }}
          onStartChat={(creator) => {
            setShowProfileModal(false);
            setTargetChatUser(creator);
            setShowInboxModal(true);
          }}
          onOpenHome={() => {
            setShowProfileModal(false);
            setActiveNavTab('home');
            setActiveTopTab('foryou');
          }}
          onOpenFriends={() => {
            setShowProfileModal(false);
            setActiveNavTab('friends');
            setActiveTopTab('following');
          }}
          onOpenUpload={() => {
            setShowProfileModal(false);
            setShowUploadModal(true);
          }}
          onOpenInbox={() => {
            setShowProfileModal(false);
            setShowInboxModal(true);
          }}
          currentUser={currentUser}
          onLoginUser={(user) => {
            setCurrentUser(user);
            setActiveCreator(user);
            try {
              localStorage.setItem('tiktok_logged_user', JSON.stringify(user));
            } catch {}
            syncUserToFirebase(user);
          }}
          language={language}
          onToast={triggerToast}
          onLogout={() => {
            setCurrentUser(null);
            try {
              localStorage.removeItem('tiktok_logged_user');
            } catch {}
            setActiveCreator({
              id: 'self',
              name: 'Profile',
              handle: 'guest',
              avatar: '',
              verified: false,
              followers: 0,
              following: 0,
              likesTotal: 0,
              bio: '',
            });
            setShowProfileModal(false);
            triggerToast(language === 'bn' ? 'লগ আউট সম্পন্ন' : 'Logged out');
          }}
        />

        {/* 7. Settings & Privacy Modal */}
        <SettingsModal
          isOpen={showSettingsModal}
          onClose={() => setShowSettingsModal(false)}
          language={language}
          onLanguageChange={(l) => setLanguage(l)}
          themeMode={themeMode}
          onToggleTheme={() => setThemeMode((m) => (m === 'dark' ? 'light' : 'dark'))}
          accessibility={{
            autoScroll: false,
            fastScrollButtons: true,
            screenReaderDescriptions: false,
            largeText: false,
            hapticFeedback: true,
            highContrast: false,
            reducedMotion: false,
            playbackSpeed: 1,
          }}
          onUpdateAccessibility={() => {}}
          onLogout={() => {
            setCurrentUser(null);
            setShowSettingsModal(false);
            triggerToast(language === 'bn' ? 'লগআউট সম্পন্ন' : 'Logged out successfully');
          }}
          onToast={triggerToast}
          onOpenAuthForCountry={(country) => {
            setSelectedCountryForAuth(country);
            setShowAuthModal(true);
          }}
          currentUser={currentUser || activeCreator}
          reels={reels}
          onDeleteReel={(reelId) => {
            setReels((prev) => prev.filter((r) => r.id !== reelId));
            triggerToast(language === 'bn' ? '✓ পোস্ট সফলভাবে ডিলিট করা হয়েছে' : '✓ Post deleted successfully');
          }}
          onOpenLive={() => {
            setShowSettingsModal(false);
            setShowLiveStreamModal(true);
          }}
          onOpenAuth={() => {
            setShowSettingsModal(false);
            setShowAuthModal(true);
          }}
          onActivateBoost={handleActivateBoost}
          onOpenGeminiAssistant={() => {
            setShowSettingsModal(false);
            setShowGeminiAssistantModal(true);
          }}
          isFloatingGeminiEnabled={isFloatingGeminiEnabled}
          onToggleFloatingGemini={(val) => {
            setIsFloatingGeminiEnabled(val);
            try {
              localStorage.setItem('tiktok_floating_gemini', String(val));
            } catch {}
          }}
          initialSubView={settingsInitialSubView}
          onOpenRewardedAds={() => setShowRewardedAdModal(true)}
        />

        {/* 8. Recent Apps Android Switcher (চার কোন বাটন ▢) */}
        <RecentAppsModal
          isOpen={showRecentAppsModal}
          onClose={() => setShowRecentAppsModal(false)}
          language={language}
          activeReel={activeReel}
          onResumeTikTok={() => setShowRecentAppsModal(false)}
          onToast={triggerToast}
        />

        {/* 9. Live Stream Modal */}
        <LiveStreamModal
          isOpen={showLiveStreamModal}
          onClose={() => setShowLiveStreamModal(false)}
          language={language}
          onToast={triggerToast}
        />

        {/* 10. Inbox Modal (Matching Screenshot Dashboard) */}
        <InboxModal
          isOpen={showInboxModal}
          onClose={() => {
            setShowInboxModal(false);
            setTargetChatUser(null);
          }}
          language={language}
          currentUser={currentUser || activeCreator}
          userStories={userStories}
          initialTargetChat={targetChatUser}
          activities={activities}
          onSelectReelFromActivity={(targetReelId) => {
            const idx = reels.findIndex((r) => r.id === targetReelId);
            if (idx !== -1) {
              setCurrentIndex(idx);
              setActiveNavTab('home');
              setActiveTopTab('foryou');
            }
          }}
          onToggleFollow={handleToggleFollow}
          onAddStory={(videoUrl) => {
            const newStory: UserStory = {
              id: `story-${Date.now()}`,
              videoUrl,
              posterUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&auto=format&fit=crop&q=80',
              createdAt: Date.now(),
              creator: currentUser || activeCreator,
            };
            setUserStories((prev) => [newStory, ...prev]);
            triggerToast(
              language === 'bn'
                ? '✓ সম্পূর্ণ ভিডিও স্টোরি সফলভাবে যুক্ত হয়েছে এবং প্রোফাইলে রঙিন বর্ডার ঘুরছে!'
                : '✓ Full video story added with rainbow animated ring!'
            );
          }}
          onOpenProfile={(creator) => {
            if (creator) setActiveCreator(creator);
            setShowProfileModal(true);
            setShowInboxModal(false);
          }}
          onStartCall={(target, type) => {
            setActiveCallSession({
              receiverName: target.name,
              receiverAvatar: target.avatar,
              receiverHandle: target.handle || 'user',
              type,
              status: 'ringing',
              startedAt: Date.now(),
            });
          }}
          onOpenHome={() => {
            setShowInboxModal(false);
            setActiveNavTab('home');
          }}
          onOpenFriends={() => {
            setShowInboxModal(false);
            setActiveNavTab('friends');
            setActiveTopTab('following');
          }}
          onOpenUpload={() => {
            setShowInboxModal(false);
            setShowUploadModal(true);
          }}
          onToast={triggerToast}
        />

        {/* 11. Auth Modal */}
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          initialCountry={selectedCountryForAuth}
          onSuccess={(user) => {
            setCurrentUser(user);
            setActiveCreator(user);
            syncUserToFirebase(user);
            triggerToast(language === 'bn' ? `স্বাগতম ${user.name}!` : `Welcome ${user.name}!`);
          }}
          language={language}
        />

        {/* 12. TikTok Recommendation Algorithm Insights Modal */}
        {selectedAlgorithmReel && (
          <AlgorithmInsightsModal
            isOpen={showAlgorithmModal}
            onClose={() => setShowAlgorithmModal(false)}
            reel={selectedAlgorithmReel}
            onAdvanceTier={handleAdvanceAlgorithmTier}
            language={language}
          />
        )}

        {/* 13. Home Feed Story-First Viewer (User Requirement: হোমপেজ থেকে কেউ যদি কারো প্রোফাইলে ক্লিক করে যদি তার স্টোরি থাকে প্রথমে স্টোরি দেখাবে উপরে কাটা চিহ্ন কেটে দিলে তার প্রোফাইলে সোজা ঢুকে যাবে) */}
        {showStoryViewer && activeStoryQueue.length > 0 && (
          <StoryViewerModal
            isOpen={showStoryViewer}
            onClose={() => {
              setShowStoryViewer(false);
              if (openProfileOnStoryClose) {
                setShowProfileModal(true);
                setOpenProfileOnStoryClose(false);
              }
            }}
            stories={activeStoryQueue}
            initialIndex={storyInitialIndex}
            openProfileOnClose={openProfileOnStoryClose}
            onOpenProfile={(creator) => {
              setActiveCreator(creator);
              setShowStoryViewer(false);
              setShowProfileModal(true);
              setOpenProfileOnStoryClose(false);
            }}
            onToggleFollow={handleToggleFollow}
            language={language}
            onToast={triggerToast}
          />
        )}

        {/* 14. BANNED ACCOUNT RESTRICTION OVERLAY (User Requirement: ব্যান করলে তার আইডি বা এই এপস আর ইউজ করতে পারবে না আন ব্যান করলে সব কাজ এপসের ভিতর করতে পারবে) */}
        {isCurrentBanned && (
          <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
            <div className="w-full max-w-sm bg-zinc-900 border-2 border-rose-600/50 rounded-3xl p-6 text-center shadow-2xl text-white animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-rose-500/20 text-[#fe2c55] flex items-center justify-center mx-auto mb-3.5 border border-rose-500/40">
                <AlertOctagon className="w-9 h-9 stroke-[2.4]" />
              </div>

              <span className="px-3 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black uppercase tracking-wider">
                ACCOUNT SUSPENDED / BANNED 🚫
              </span>

              <h3 className="text-base font-black mt-2.5 text-white">
                {language === 'bn' ? 'আপনার অ্যাকাউন্ট ব্যান করা হয়েছে' : 'Your Account Has Been Banned'}
              </h3>
              
              <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                {language === 'bn'
                  ? 'কমিউনিটি নীতিমালা লঙ্ঘনের কারণে অ্যাডমিন কর্তৃক এই অ্যাকাউন্ট সাময়িকভাবে বন্ধ করা হয়েছে।'
                  : 'This account has been restricted by TikTok Administration due to community guidelines violation.'}
              </p>

              <div className="my-4 p-3 rounded-2xl bg-zinc-800/80 border border-zinc-700/60 text-left text-xs space-y-1.5">
                <div className="flex justify-between py-1 border-b border-zinc-700/40 text-[11px]">
                  <span className="text-zinc-400">Account:</span>
                  <span className="font-mono font-bold text-white">@{currentUser?.handle || activeCreator?.handle}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-zinc-700/40 text-[11px]">
                  <span className="text-zinc-400">Status:</span>
                  <span className="font-bold text-rose-500">Access Restricted ⛔</span>
                </div>
                <div className="flex justify-between py-1 text-[11px]">
                  <span className="text-zinc-400">Admin Contact:</span>
                  <span className="font-mono font-bold text-emerald-400">01875328569</span>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setCurrentUser(null);
                    setBannedVersion((v) => v + 1);
                    triggerToast('Switched to guest mode');
                  }}
                  className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-extrabold text-xs transition-colors cursor-pointer"
                >
                  Switch / Log in to Another Account
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowSettingsModal(true);
                  }}
                  className="w-full py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 font-bold text-xs border border-rose-500/30 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Admin Settings & Unban Portal</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 15. Draggable Floating Gemini AI Assistant Widget */}
        <FloatingGeminiAssistant
          isVisible={isFloatingGeminiEnabled && !showGeminiAssistantModal}
          onOpenAssistant={() => setShowGeminiAssistantModal(true)}
          language={language}
        />

        {/* 16. Fullscreen Gemini AI Assistant Modal / Sheet */}
        <GeminiAssistantModal
          isOpen={showGeminiAssistantModal}
          onClose={() => setShowGeminiAssistantModal(false)}
          language={language}
          onToast={triggerToast}
          onNavigate={handleNavigateFromAI}
        />

        {/* 17. Unlimited AdMob Rewarded Video Ad Modal (Steem Page & Wallet) */}
        <RewardedAdPlayerModal
          isOpen={showRewardedAdModal}
          onClose={() => setShowRewardedAdModal(false)}
          language={language}
          onRewardClaimed={(coins) => {
            triggerToast(
              language === 'bn'
                ? `🎉 সফল! +${coins} কয়েন আপনার ওয়ালেটে জমা হয়েছে!`
                : `🎉 Reward Claimed: +${coins} Gold Coins added to your wallet!`
            );
          }}
          onToast={triggerToast}
        />
      </div>
    </div>
  );
}
