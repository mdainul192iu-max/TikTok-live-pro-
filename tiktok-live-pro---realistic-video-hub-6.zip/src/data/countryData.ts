import { CountryConfig } from '../types';

export const ALL_COUNTRIES: CountryConfig[] = [
  {
    code: 'BD',
    name: 'Bangladesh',
    nativeName: 'বাংলাদেশ',
    flag: '🇧🇩',
    dialCode: '+880',
    defaultLanguage: 'bn',
    defaultCity: 'Dhaka',
    timezone: 'Asia/Dhaka',
  },
  {
    code: 'US',
    name: 'United States',
    nativeName: 'United States',
    flag: '🇺🇸',
    dialCode: '+1',
    defaultLanguage: 'en',
    defaultCity: 'New York',
    timezone: 'America/New_York',
  },
  {
    code: 'GB',
    name: 'United Kingdom',
    nativeName: 'United Kingdom',
    flag: '🇬🇧',
    dialCode: '+44',
    defaultLanguage: 'en',
    defaultCity: 'London',
    timezone: 'Europe/London',
  },
  {
    code: 'IN',
    name: 'India',
    nativeName: 'भारत',
    flag: '🇮🇳',
    dialCode: '+91',
    defaultLanguage: 'en',
    defaultCity: 'Mumbai',
    timezone: 'Asia/Kolkata',
  },
  {
    code: 'SA',
    name: 'Saudi Arabia',
    nativeName: 'المملكة العربية السعودية',
    flag: '🇸🇦',
    dialCode: '+966',
    defaultLanguage: 'ar',
    defaultCity: 'Riyadh',
    timezone: 'Asia/Riyadh',
  },
  {
    code: 'AE',
    name: 'United Arab Emirates',
    nativeName: 'الإمارات العربية المتحدة',
    flag: '🇦🇪',
    dialCode: '+971',
    defaultLanguage: 'ar',
    defaultCity: 'Dubai',
    timezone: 'Asia/Dubai',
  },
  {
    code: 'CA',
    name: 'Canada',
    nativeName: 'Canada',
    flag: '🇨🇦',
    dialCode: '+1',
    defaultLanguage: 'en',
    defaultCity: 'Toronto',
    timezone: 'America/Toronto',
  },
  {
    code: 'MY',
    name: 'Malaysia',
    nativeName: 'Malaysia',
    flag: '🇲🇾',
    dialCode: '+60',
    defaultLanguage: 'en',
    defaultCity: 'Kuala Lumpur',
    timezone: 'Asia/Kuala_Lumpur',
  },
  {
    code: 'PK',
    name: 'Pakistan',
    nativeName: 'پاکستان',
    flag: '🇵🇰',
    dialCode: '+92',
    defaultLanguage: 'ur',
    defaultCity: 'Karachi',
    timezone: 'Asia/Karachi',
  },
  {
    code: 'ID',
    name: 'Indonesia',
    nativeName: 'Indonesia',
    flag: '🇮🇩',
    dialCode: '+62',
    defaultLanguage: 'id',
    defaultCity: 'Jakarta',
    timezone: 'Asia/Jakarta',
  },
  {
    code: 'AU',
    name: 'Australia',
    nativeName: 'Australia',
    flag: '🇦🇺',
    dialCode: '+61',
    defaultLanguage: 'en',
    defaultCity: 'Sydney',
    timezone: 'Australia/Sydney',
  },
  {
    code: 'SG',
    name: 'Singapore',
    nativeName: 'Singapore',
    flag: '🇸🇬',
    dialCode: '+65',
    defaultLanguage: 'en',
    defaultCity: 'Singapore',
    timezone: 'Asia/Singapore',
  },
  {
    code: 'QA',
    name: 'Qatar',
    nativeName: 'قطر',
    flag: '🇶🇦',
    dialCode: '+974',
    defaultLanguage: 'ar',
    defaultCity: 'Doha',
    timezone: 'Asia/Qatar',
  },
  {
    code: 'KW',
    name: 'Kuwait',
    nativeName: 'الكويت',
    flag: '🇰🇼',
    dialCode: '+965',
    defaultLanguage: 'ar',
    defaultCity: 'Kuwait City',
    timezone: 'Asia/Kuwait',
  },
  {
    code: 'DE',
    name: 'Germany',
    nativeName: 'Deutschland',
    flag: '🇩🇪',
    dialCode: '+49',
    defaultLanguage: 'en',
    defaultCity: 'Berlin',
    timezone: 'Europe/Berlin',
  },
  {
    code: 'FR',
    name: 'France',
    nativeName: 'France',
    flag: '🇫🇷',
    dialCode: '+33',
    defaultLanguage: 'en',
    defaultCity: 'Paris',
    timezone: 'Europe/Paris',
  },
  {
    code: 'JP',
    name: 'Japan',
    nativeName: '日本',
    flag: '🇯🇵',
    dialCode: '+81',
    defaultLanguage: 'en',
    defaultCity: 'Tokyo',
    timezone: 'Asia/Tokyo',
  },
  {
    code: 'ES',
    name: 'Spain',
    nativeName: 'España',
    flag: '🇪🇸',
    dialCode: '+34',
    defaultLanguage: 'es',
    defaultCity: 'Madrid',
    timezone: 'Europe/Madrid',
  },
  {
    code: 'BR',
    name: 'Brazil',
    nativeName: 'Brasil',
    flag: '🇧🇷',
    dialCode: '+55',
    defaultLanguage: 'pt',
    defaultCity: 'São Paulo',
    timezone: 'America/Sao_Paulo',
  },
];

/**
 * Automatically detects the user's country based on browser timezone and locale
 */
export function detectUserCountry(): CountryConfig {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (tz) {
      const matchByTz = ALL_COUNTRIES.find(
        (c) => c.timezone.toLowerCase() === tz.toLowerCase() || tz.toLowerCase().includes(c.defaultCity.toLowerCase().replace(/\s+/g, '_'))
      );
      if (matchByTz) return matchByTz;

      if (tz.includes('Dhaka')) return ALL_COUNTRIES.find((c) => c.code === 'BD')!;
      if (tz.includes('Calcutta') || tz.includes('Kolkata')) return ALL_COUNTRIES.find((c) => c.code === 'IN')!;
      if (tz.includes('New_York') || tz.includes('Los_Angeles') || tz.includes('Chicago')) return ALL_COUNTRIES.find((c) => c.code === 'US')!;
      if (tz.includes('London')) return ALL_COUNTRIES.find((c) => c.code === 'GB')!;
      if (tz.includes('Riyadh')) return ALL_COUNTRIES.find((c) => c.code === 'SA')!;
      if (tz.includes('Dubai')) return ALL_COUNTRIES.find((c) => c.code === 'AE')!;
      if (tz.includes('Karachi')) return ALL_COUNTRIES.find((c) => c.code === 'PK')!;
      if (tz.includes('Jakarta')) return ALL_COUNTRIES.find((c) => c.code === 'ID')!;
    }

    const lang = (navigator.language || '').toLowerCase();
    if (lang.includes('bn')) return ALL_COUNTRIES.find((c) => c.code === 'BD')!;
    if (lang.includes('hi')) return ALL_COUNTRIES.find((c) => c.code === 'IN')!;
    if (lang.includes('ar')) return ALL_COUNTRIES.find((c) => c.code === 'SA')!;
    if (lang.includes('es')) return ALL_COUNTRIES.find((c) => c.code === 'ES')!;
    if (lang.includes('pt')) return ALL_COUNTRIES.find((c) => c.code === 'BR')!;
    if (lang.includes('id')) return ALL_COUNTRIES.find((c) => c.code === 'ID')!;
  } catch {}

  // Default to US (English)
  return ALL_COUNTRIES[1];
}
