import { securityArchitectureService } from './securityArchitectureService';
import { COUNTRIES_200, CountryLanguageItem } from '../data/languages200';

export interface DailyEarningBreakdown {
  videoAdsCount: number;
  videoAdsCoins: number;
  bannerAdsCount: number;
  bannerAdsCoins: number;
  referralCount: number;
  referralCoins: number;
  watchEarnCount: number;
  watchEarnCoins: number;
}

export type WithdrawalMethod = 'binance' | 'bkash' | 'nagad' | 'bank' | 'paypal';

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  method: WithdrawalMethod;
  accountNumber: string; // Phone number for bkash/nagad, Binance Pay ID / USDT BEP-20 address, or Bank Account details
  bankName?: string;
  transferId: string;
  amountCoins: number;
  amountFiat: number;
  currencyCode: string;
  currencySymbol: string;
  status: 'pending' | 'completed' | 'rejected';
  createdAt: number;
  approvedAt?: number;
  adminNote?: string;
}

export interface MobileRechargeRequest {
  id: string;
  userId: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  recipientPhone: string;
  countryCode: string;
  countryName: string;
  operatorName: string;
  rechargeType: 'prepaid' | 'postpaid';
  amountCoins: number;
  amountFiat: number;
  currencyCode: string;
  currencySymbol: string;
  status: 'pending' | 'completed' | 'rejected';
  createdAt: number;
  approvedAt?: number;
  adminNote?: string;
}

export interface UserWalletState {
  totalCoins: number;
  selectedCurrencyCode: string; // e.g. BDT, USD, INR, etc.
  dailyEarnings: DailyEarningBreakdown;
  lastDailyResetDate: string; // YYYY-MM-DD
}

const STORAGE_WALLET_KEY = 'tiktok_user_wallet_state_v2';
const STORAGE_WITHDRAWALS_KEY = 'tiktok_wallet_withdrawals_v2';
const STORAGE_RECHARGES_KEY = 'tiktok_wallet_recharges_v2';

const DEFAULT_INITIAL_WALLET: UserWalletState = {
  totalCoins: 52480, // Default balance equivalent to ~৳524.80 BDT or ~$4.72 USD
  selectedCurrencyCode: 'BDT',
  dailyEarnings: {
    videoAdsCount: 18,
    videoAdsCoins: 3600,
    bannerAdsCount: 6,
    bannerAdsCoins: 1200,
    referralCount: 2,
    referralCoins: 9980,
    watchEarnCount: 42,
    watchEarnCoins: 2100,
  },
  lastDailyResetDate: new Date().toISOString().split('T')[0],
};

const SEED_WITHDRAWALS: WithdrawalRequest[] = [
  {
    id: 'WTH-881920',
    userId: 'usr-self',
    userName: 'Tanvir Hossain',
    userHandle: 'tanvir_creator',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    method: 'bkash',
    accountNumber: '01875328569',
    transferId: 'TRX-BK-91827401',
    amountCoins: 10000,
    amountFiat: 100,
    currencyCode: 'BDT',
    currencySymbol: '৳',
    status: 'pending',
    createdAt: Date.now() - 3600000 * 2,
  },
  {
    id: 'WTH-773912',
    userId: 'usr-mona',
    userName: 'Mona Lisa',
    userHandle: 'monalisa_live',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    method: 'binance',
    accountNumber: 'Binance Pay ID: 849201948',
    transferId: 'BINANCE-USDT-94812',
    amountCoins: 33000,
    amountFiat: 3.00,
    currencyCode: 'USD',
    currencySymbol: '$',
    status: 'pending',
    createdAt: Date.now() - 3600000 * 5,
  },
  {
    id: 'WTH-662810',
    userId: 'usr-arman',
    userName: 'Arman Khan',
    userHandle: 'armankhan_bd',
    userAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150',
    method: 'nagad',
    accountNumber: '01712984530',
    transferId: 'TRX-NGD-389104',
    amountCoins: 25000,
    amountFiat: 250,
    currencyCode: 'BDT',
    currencySymbol: '৳',
    status: 'completed',
    createdAt: Date.now() - 86400000,
    approvedAt: Date.now() - 72000000,
  }
];

const SEED_RECHARGES: MobileRechargeRequest[] = [
  {
    id: 'RCH-109284',
    userId: 'usr-self',
    userName: 'Tanvir Hossain',
    userHandle: 'tanvir_creator',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    recipientPhone: '01875328569',
    countryCode: 'BD',
    countryName: 'Bangladesh',
    operatorName: 'Grameenphone (GP)',
    rechargeType: 'prepaid',
    amountCoins: 5000,
    amountFiat: 50,
    currencyCode: 'BDT',
    currencySymbol: '৳',
    status: 'pending',
    createdAt: Date.now() - 1800000,
  },
  {
    id: 'RCH-109285',
    userId: 'usr-rohit',
    userName: 'Rohit Sharma',
    userHandle: 'rohit_vids',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    recipientPhone: '+919876543210',
    countryCode: 'IN',
    countryName: 'India',
    operatorName: 'Reliance Jio',
    rechargeType: 'prepaid',
    amountCoins: 6000,
    amountFiat: 50,
    currencyCode: 'INR',
    currencySymbol: '₹',
    status: 'pending',
    createdAt: Date.now() - 5400000,
  }
];

class WalletEarningsService {
  private wallet: UserWalletState;
  private withdrawals: WithdrawalRequest[];
  private recharges: MobileRechargeRequest[];
  private listeners: Array<() => void> = [];

  constructor() {
    this.wallet = this.loadWallet();
    this.withdrawals = this.loadWithdrawals();
    this.recharges = this.loadRecharges();
  }

  private loadWallet(): UserWalletState {
    try {
      const saved = localStorage.getItem(STORAGE_WALLET_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const today = new Date().toISOString().split('T')[0];
        // Reset daily counters if a new day has arrived
        if (parsed.lastDailyResetDate !== today) {
          parsed.dailyEarnings = {
            videoAdsCount: 0,
            videoAdsCoins: 0,
            bannerAdsCount: 0,
            bannerAdsCoins: 0,
            referralCount: 0,
            referralCoins: 0,
            watchEarnCount: 0,
            watchEarnCoins: 0,
          };
          parsed.lastDailyResetDate = today;
          localStorage.setItem(STORAGE_WALLET_KEY, JSON.stringify(parsed));
        }
        return parsed;
      }
    } catch {}
    return { ...DEFAULT_INITIAL_WALLET };
  }

  private loadWithdrawals(): WithdrawalRequest[] {
    try {
      const saved = localStorage.getItem(STORAGE_WITHDRAWALS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [...SEED_WITHDRAWALS];
  }

  private loadRecharges(): MobileRechargeRequest[] {
    try {
      const saved = localStorage.getItem(STORAGE_RECHARGES_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [...SEED_RECHARGES];
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_WALLET_KEY, JSON.stringify(this.wallet));
      localStorage.setItem(STORAGE_WITHDRAWALS_KEY, JSON.stringify(this.withdrawals));
      localStorage.setItem(STORAGE_RECHARGES_KEY, JSON.stringify(this.recharges));
    } catch {}
    this.notify();
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter(l => l !== cb);
    };
  }

  private notify() {
    this.listeners.forEach(cb => cb());
  }

  public getWallet(): UserWalletState {
    return { ...this.wallet };
  }

  public setCurrency(currencyCode: string) {
    this.wallet.selectedCurrencyCode = currencyCode;
    this.save();
  }

  public getCountryByCode(code: string): CountryLanguageItem {
    const found = COUNTRIES_200.find(c => c.code.toUpperCase() === code.toUpperCase() || c.currencyCode.toUpperCase() === code.toUpperCase());
    return found || COUNTRIES_200[0];
  }

  /**
   * Convert coins to local fiat currency
   */
  public convertCoinsToFiat(coins: number, currencyCode?: string): { amount: number; symbol: string; formatted: string } {
    const targetCode = currencyCode || this.wallet.selectedCurrencyCode || 'BDT';
    const country = COUNTRIES_200.find(c => c.currencyCode.toUpperCase() === targetCode.toUpperCase()) || COUNTRIES_200[0];
    const rate = country.coinsPerUnit || 100;
    const fiatAmount = Number((coins / rate).toFixed(2));
    return {
      amount: fiatAmount,
      symbol: country.currencySymbol,
      formatted: `${country.currencySymbol} ${fiatAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${country.currencyCode}`,
    };
  }

  /**
   * Calculate how many coins are needed for a given fiat amount
   */
  public convertFiatToCoins(fiatAmount: number, currencyCode?: string): number {
    const targetCode = currencyCode || this.wallet.selectedCurrencyCode || 'BDT';
    const country = COUNTRIES_200.find(c => c.currencyCode.toUpperCase() === targetCode.toUpperCase()) || COUNTRIES_200[0];
    const rate = country.coinsPerUnit || 100;
    return Math.ceil(fiatAmount * rate);
  }

  /**
   * Add coins with military-grade HMAC signing validation
   */
  public async addCoinsWithSignature(
    type: 'video_ad' | 'banner_ad' | 'referral' | 'watch_earn',
    amount: number
  ): Promise<{ success: boolean; newBalance: number; error?: string }> {
    const signed = await securityArchitectureService.signRewardPayload({
      type,
      amount,
      currentBalance: this.wallet.totalCoins,
      timestamp: Date.now(),
    });

    const verify = await securityArchitectureService.verifySignedReward(signed);
    if (!verify.valid) {
      return { success: false, newBalance: this.wallet.totalCoins, error: verify.error };
    }

    this.wallet.totalCoins += amount;

    if (type === 'video_ad') {
      this.wallet.dailyEarnings.videoAdsCount += 1;
      this.wallet.dailyEarnings.videoAdsCoins += amount;
    } else if (type === 'banner_ad') {
      this.wallet.dailyEarnings.bannerAdsCount += 1;
      this.wallet.dailyEarnings.bannerAdsCoins += amount;
    } else if (type === 'referral') {
      this.wallet.dailyEarnings.referralCount += 1;
      this.wallet.dailyEarnings.referralCoins += amount;
    } else if (type === 'watch_earn') {
      this.wallet.dailyEarnings.watchEarnCount += 1;
      this.wallet.dailyEarnings.watchEarnCoins += amount;
    }

    this.save();
    return { success: true, newBalance: this.wallet.totalCoins };
  }

  /**
   * Submit Withdrawal Request
   */
  public async submitWithdrawal(data: {
    userId: string;
    userName: string;
    userHandle: string;
    userAvatar: string;
    method: WithdrawalMethod;
    accountNumber: string;
    bankName?: string;
    amountCoins: number;
    currencyCode: string;
  }): Promise<{ success: boolean; request?: WithdrawalRequest; error?: string }> {
    if (this.wallet.totalCoins < data.amountCoins) {
      return { success: false, error: 'Insufficient coins in wallet balance.' };
    }

    const fiat = this.convertCoinsToFiat(data.amountCoins, data.currencyCode);
    const transferId = `TRX-${data.method.toUpperCase().slice(0, 3)}-${Math.floor(10000000 + Math.random() * 90000000)}`;

    const newRequest: WithdrawalRequest = {
      id: `WTH-${Date.now()}`,
      userId: data.userId,
      userName: data.userName,
      userHandle: data.userHandle,
      userAvatar: data.userAvatar,
      method: data.method,
      accountNumber: data.accountNumber,
      bankName: data.bankName,
      transferId,
      amountCoins: data.amountCoins,
      amountFiat: fiat.amount,
      currencyCode: data.currencyCode,
      currencySymbol: fiat.symbol,
      status: 'pending',
      createdAt: Date.now(),
    };

    // Deduct coins from active balance
    this.wallet.totalCoins -= data.amountCoins;
    this.withdrawals.unshift(newRequest);
    this.save();

    return { success: true, request: newRequest };
  }

  /**
   * Submit Worldwide Mobile Operator Recharge Request
   */
  public async submitMobileRecharge(data: {
    userId: string;
    userName: string;
    userHandle: string;
    userAvatar: string;
    recipientPhone: string;
    countryCode: string;
    countryName: string;
    operatorName: string;
    amountFiat: number;
    currencyCode: string;
  }): Promise<{ success: boolean; request?: MobileRechargeRequest; error?: string }> {
    const requiredCoins = this.convertFiatToCoins(data.amountFiat, data.currencyCode);
    if (this.wallet.totalCoins < requiredCoins) {
      return { success: false, error: `Insufficient coins. Required ${requiredCoins.toLocaleString()} coins for ${data.currencyCode} ${data.amountFiat}.` };
    }

    const country = COUNTRIES_200.find(c => c.code === data.countryCode) || COUNTRIES_200[0];

    const newRequest: MobileRechargeRequest = {
      id: `RCH-${Date.now()}`,
      userId: data.userId,
      userName: data.userName,
      userHandle: data.userHandle,
      userAvatar: data.userAvatar,
      recipientPhone: data.recipientPhone,
      countryCode: data.countryCode,
      countryName: data.countryName,
      operatorName: data.operatorName,
      rechargeType: 'prepaid',
      amountCoins: requiredCoins,
      amountFiat: data.amountFiat,
      currencyCode: data.currencyCode,
      currencySymbol: country.currencySymbol,
      status: 'pending',
      createdAt: Date.now(),
    };

    this.wallet.totalCoins -= requiredCoins;
    this.recharges.unshift(newRequest);
    this.save();

    return { success: true, request: newRequest };
  }

  /**
   * ADMIN APPROVE WITHDRAWAL
   */
  public approveWithdrawal(requestId: string): boolean {
    const item = this.withdrawals.find(w => w.id === requestId);
    if (item) {
      item.status = 'completed';
      item.approvedAt = Date.now();
      item.adminNote = 'Transferred successfully via Admin gateway';
      this.save();
      return true;
    }
    return false;
  }

  /**
   * ADMIN REJECT WITHDRAWAL (Refunds coins back to user)
   */
  public rejectWithdrawal(requestId: string, reason?: string): boolean {
    const item = this.withdrawals.find(w => w.id === requestId);
    if (item && item.status === 'pending') {
      item.status = 'rejected';
      item.adminNote = reason || 'Rejected by Admin';
      this.wallet.totalCoins += item.amountCoins;
      this.save();
      return true;
    }
    return false;
  }

  /**
   * ADMIN APPROVE MOBILE RECHARGE
   */
  public approveRecharge(requestId: string): boolean {
    const item = this.recharges.find(r => r.id === requestId);
    if (item) {
      item.status = 'completed';
      item.approvedAt = Date.now();
      item.adminNote = 'Recharge dispatched successfully via Telecom API';
      this.save();
      return true;
    }
    return false;
  }

  /**
   * ADMIN REJECT MOBILE RECHARGE (Refunds coins back)
   */
  public rejectRecharge(requestId: string, reason?: string): boolean {
    const item = this.recharges.find(r => r.id === requestId);
    if (item && item.status === 'pending') {
      item.status = 'rejected';
      item.adminNote = reason || 'Rejected by Admin';
      this.wallet.totalCoins += item.amountCoins;
      this.save();
      return true;
    }
    return false;
  }

  public getWithdrawals(): WithdrawalRequest[] {
    return [...this.withdrawals];
  }

  public getRecharges(): MobileRechargeRequest[] {
    return [...this.recharges];
  }

  public getPendingWithdrawalsCount(): number {
    return this.withdrawals.filter(w => w.status === 'pending').length;
  }

  public getPendingRechargesCount(): number {
    return this.recharges.filter(r => r.status === 'pending').length;
  }
}

export const walletEarningsService = new WalletEarningsService();
