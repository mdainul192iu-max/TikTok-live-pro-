import { GraphicQuality } from '../types';

export interface NetworkStatus {
  effectiveType: '4g' | '3g' | '2g' | 'slow-2g' | 'unknown';
  downlink: number; // Mbps
  rtt: number; // ms
  saveData: boolean;
  recommendedQuality: GraphicQuality;
}

class NetworkQualityService {
  private currentQuality: GraphicQuality = 'auto';

  constructor() {
    this.detectNetwork();
  }

  public getNetworkStatus(): NetworkStatus {
    const nav = typeof navigator !== 'undefined' ? (navigator as any) : null;
    const conn = nav?.connection || nav?.mozConnection || nav?.webkitConnection;

    if (!conn) {
      return {
        effectiveType: '4g',
        downlink: 10,
        rtt: 50,
        saveData: false,
        recommendedQuality: '1080p',
      };
    }

    const effectiveType = conn.effectiveType || '4g';
    const downlink = conn.downlink || 5;
    const rtt = conn.rtt || 100;
    const saveData = conn.saveData || false;

    let recommendedQuality: GraphicQuality = '1080p';
    if (saveData) {
      recommendedQuality = 'data_saver';
    } else if (effectiveType === '2g' || effectiveType === 'slow-2g' || downlink < 1.0) {
      recommendedQuality = 'data_saver';
    } else if (effectiveType === '3g' || downlink < 3.0) {
      recommendedQuality = '720p';
    } else {
      recommendedQuality = '1080p';
    }

    return {
      effectiveType,
      downlink,
      rtt,
      saveData,
      recommendedQuality,
    };
  }

  public getEffectiveQuality(): GraphicQuality {
    if (this.currentQuality !== 'auto') {
      return this.currentQuality;
    }
    if (this.isDataSaver3GEnabled()) {
      return 'data_saver';
    }
    return this.getNetworkStatus().recommendedQuality;
  }

  public setQuality(quality: GraphicQuality) {
    this.currentQuality = quality;
  }

  // Battery Optimizer / Saver
  public isBatterySaverEnabled(): boolean {
    try {
      return localStorage.getItem('tiktok_battery_saver') === 'true';
    } catch {
      return false;
    }
  }

  public setBatterySaver(enabled: boolean): void {
    try {
      localStorage.setItem('tiktok_battery_saver', enabled ? 'true' : 'false');
    } catch {}
  }

  // 3G Network / Data Saver
  public isDataSaver3GEnabled(): boolean {
    try {
      return localStorage.getItem('tiktok_3g_data_saver') === 'true';
    } catch {
      return false;
    }
  }

  public setDataSaver3G(enabled: boolean): void {
    try {
      localStorage.setItem('tiktok_3g_data_saver', enabled ? 'true' : 'false');
    } catch {}
  }

  // Low-End Phone Smooth Mode (Hardware / FPS Optimizer)
  public isLowEndSmoothModeEnabled(): boolean {
    try {
      return localStorage.getItem('tiktok_low_end_smooth_mode') === 'true';
    } catch {
      return false;
    }
  }

  public setLowEndSmoothMode(enabled: boolean): void {
    try {
      localStorage.setItem('tiktok_low_end_smooth_mode', enabled ? 'true' : 'false');
    } catch {}
  }

  // Background Audio Playback
  public isBackgroundAudioEnabled(): boolean {
    try {
      return localStorage.getItem('tiktok_background_audio') === 'true';
    } catch {
      return false;
    }
  }

  public setBackgroundAudio(enabled: boolean): void {
    try {
      localStorage.setItem('tiktok_background_audio', enabled ? 'true' : 'false');
    } catch {}
  }

  // Auto Scroll
  public isAutoScrollEnabled(): boolean {
    try {
      return localStorage.getItem('tiktok_auto_scroll') === 'true';
    } catch {
      return false;
    }
  }

  public setAutoScroll(enabled: boolean): void {
    try {
      localStorage.setItem('tiktok_auto_scroll', enabled ? 'true' : 'false');
    } catch {}
  }

  private detectNetwork() {
    if (typeof window === 'undefined') return;
    const nav = navigator as any;
    const conn = nav?.connection || nav?.mozConnection || nav?.webkitConnection;
    if (conn) {
      conn.addEventListener('change', () => {
        // Auto-adapts quality
      });
    }
  }
}

export const networkQualityService = new NetworkQualityService();
