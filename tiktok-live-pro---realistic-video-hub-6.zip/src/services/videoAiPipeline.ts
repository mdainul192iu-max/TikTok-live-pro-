import { GoogleGenAI } from '@google/genai';
import { VideoReel, SubtitleCue, VideoModerationResult, Creator } from '../types';

// Banned and sensitive words in English & Bengali for automatic asterisk censoring
const BANNED_WORDS = [
  'kill', 'blood', 'weapon', 'gun', 'knife', 'suicide', 'bomb',
  'গালি', 'মারামারি', 'রক্ত', 'অস্ত্র', 'খুন', 'হিংসা', 'বিস্ফোরণ'
];

export interface VideoIngestionPayload {
  videoUrl: string;
  posterUrl: string;
  title: string;
  description: string;
  soundTitle?: string;
  location?: string;
  creator: Creator;
  postType?: 'video' | 'photo_carousel';
  images?: string[];
}

export interface IngestionPipelineResult {
  enrichedCaption: string;
  captionBn: string;
  category: 'foryou' | 'following' | 'friends' | 'trending';
  tags: string[];
  subtitles: SubtitleCue[];
  moderation: VideoModerationResult;
  algorithmTier: 'tier_50' | 'tier_1000' | 'tier_10000' | 'tier_viral';
  algorithmScore: number;
  algorithmReach: number;
  algorithmStatusText: string;
  reviewStatus: 'pending_review' | 'active' | 'rejected';
  isShadowbanned: boolean;
  creatorWarning?: {
    hasWarning: boolean;
    warningReason?: string;
  };
}

/**
 * Censors profane and prohibited words with asterisks (e.g. "খুন" -> "***")
 */
export function censorProfanity(text: string): { censoredText: string; hasViolation: boolean } {
  let censored = text;
  let hasViolation = false;

  BANNED_WORDS.forEach((word) => {
    const regex = new RegExp(word, 'gi');
    if (regex.test(censored)) {
      hasViolation = true;
      censored = censored.replace(regex, '***');
    }
  });

  return { censoredText: censored, hasViolation };
}

/**
 * Calculates TikTok Multi-Tier Engagement Score:
 * Score = (WatchTimeSec * 10) + (CompletionRate * 100) + (LoopCount * 15) + (Likes * 2) + (Comments * 5) + (Shares * 10)
 */
export function calculateEngagementScore(metrics: {
  watchTimeSec: number;
  completionRate: number;
  loopCount: number;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
}): number {
  const watchTimeComponent = Math.round((metrics.watchTimeSec || 0) * 10);
  const completionComponent = Math.round((metrics.completionRate || 0) * 100);
  const loopComponent = Math.round((metrics.loopCount || 0) * 15);
  const likesComponent = Math.round((metrics.likesCount || 0) * 2);
  const commentsComponent = Math.round((metrics.commentsCount || 0) * 5);
  const sharesComponent = Math.round((metrics.sharesCount || 0) * 10);

  return (
    watchTimeComponent +
    completionComponent +
    loopComponent +
    likesComponent +
    commentsComponent +
    sharesComponent
  );
}

/**
 * Evaluates 4-Tier Virality Algorithm Progression
 */
export function evaluateViralityTier(
  currentTier: 'tier_50' | 'tier_1000' | 'tier_10000' | 'tier_viral' = 'tier_50',
  score: number,
  completionRate: number,
  watchTimeSec: number
): {
  newTier: 'tier_50' | 'tier_1000' | 'tier_10000' | 'tier_viral';
  reach: number;
  statusText: string;
  isUpgraded: boolean;
} {
  // Tier 4: Viral Push (Score >= 6000)
  if (score >= 6000) {
    return {
      newTier: 'tier_viral',
      reach: 100000,
      statusText: '🌟 বিশ্বব্যাপী সুপার ভাইরাল ও ট্রেন্ডিং লিডারবোর্ডে যুক্ত হয়েছে!',
      isUpgraded: currentTier !== 'tier_viral',
    };
  }

  // Tier 3: Viral Push (Score >= 2500)
  if (score >= 2500) {
    return {
      newTier: 'tier_10000',
      reach: 10000,
      statusText: '🔥 দুর্দান্ত রেসপন্স! ভিডিওটি ১০,০০০ মানুষের ফর ইউ পেজে পৌঁছে ভাইরাল তালিকায় স্থান পেয়েছে!',
      isUpgraded: currentTier !== 'tier_10000' && currentTier !== 'tier_viral',
    };
  }

  // Tier 2: Expansion (First 5 seconds 80%+ completion rate and Score >= 500)
  if (score >= 500 && (completionRate >= 0.80 || watchTimeSec >= 5)) {
    return {
      newTier: 'tier_1000',
      reach: 1000,
      statusText: '🚀 ৫০ জন থেকে ইতিবাচক রেসপন্স পাওয়ায় ভিডিওটি ১,০০০ জনের ফর ইউ পেজে সম্প্রসারিত হয়েছে!',
      isUpgraded: currentTier === 'tier_50',
    };
  }

  // Tier 1: Cold Start
  return {
    newTier: 'tier_50',
    reach: 50,
    statusText: 'প্রারম্ভিক ৫০ জন ব্যবহারকারীর কাছে পরীক্ষামূলক পাঠানো হয়েছে',
    isUpgraded: false,
  };
}

/**
 * Generates cinematic Bengali auto-captions and timed subtitles
 * with 3-4 words per sentence and millisecond timestamp mapping
 */
export function generateSmartSubtitles(caption: string, durationSec: number = 15): SubtitleCue[] {
  const durationMs = Math.max(8000, durationSec * 1000);
  const cleanCaption = caption.replace(/#\w+/g, '').trim();

  // Bengali spoken templates for realistic automatic speech-to-text
  const defaultBengaliSentences = [
    'সবাইকে স্বাগতম আমাদের নতুন ভিডিওতে',
    'আজকের এই সুন্দর মুহূর্তটি শেয়ার করলাম',
    'টিকটক ফর ইউ পেজে সবাই সাপোর্ট দিন',
    'লাইক এবং কমেন্ট করে সাথে থাকুন',
    'পরবর্তী দুর্দান্ত কন্টেন্ট দেখতে ফলো করুন',
  ];

  const sourceText = cleanCaption.length > 5 ? cleanCaption : defaultBengaliSentences.join(' ');
  const words = sourceText.split(/\s+/).filter(Boolean);

  // Chunk words into groups of 3 to 4 words per subtitle cue
  const chunks: string[] = [];
  const chunkSize = 3;
  for (let i = 0; i < words.length; i += chunkSize) {
    chunks.push(words.slice(i, i + chunkSize).join(' '));
  }

  if (chunks.length === 0) {
    chunks.push('সুন্দর টিকটক মুহূর্ত ✨');
  }

  const timePerChunk = Math.floor(durationMs / Math.max(1, chunks.length));

  return chunks.map((chunk, idx) => {
    const { censoredText, hasViolation } = censorProfanity(chunk);
    const start = idx * timePerChunk;
    const end = Math.min(durationMs, start + timePerChunk - 100);

    return {
      id: `cue-${idx}-${Date.now()}`,
      startTimeMs: start,
      endTimeMs: end,
      text: censoredText,
      censored: hasViolation,
    };
  });
}

/**
 * Real-Time Gemini Multimodal Video Ingestion & Safety Pipeline
 */
class VideoAiPipelineService {
  private genAI: GoogleGenAI | null = null;

  constructor() {
    this.initGemini();
  }

  private initGemini() {
    try {
      const apiKey =
        (typeof process !== 'undefined' && process.env?.VITE_GEMINI_API_KEY) ||
        (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
        '';
      if (apiKey) {
        this.genAI = new GoogleGenAI({ apiKey });
      }
    } catch {
      this.genAI = null;
    }
  }

  /**
   * Main Pipeline Execution
   */
  public async processVideoIngestion(payload: VideoIngestionPayload): Promise<IngestionPipelineResult> {
    const rawCaption = `${payload.title ? payload.title + ' ' : ''}${payload.description || ''}`.trim();
    const { censoredText, hasViolation: hasProfanity } = censorProfanity(rawCaption);

    // Default safety moderation assessment
    let isSafe = !hasProfanity;
    let safetyScore = hasProfanity ? 45 : 98;
    const violations: string[] = [];
    let warningReason: string | undefined = undefined;

    if (hasProfanity) {
      violations.push('Restricted / Profane Language detected in audio or caption metadata');
      warningReason = 'কমিউনিটি নীতিমালা লঙ্ঘন: নিষিদ্ধ শব্দ ব্যবহার করা হয়েছে';
    }

    // Check creator's existing violations for shadowban check
    const creatorViolations = (payload.creator?.violationCount || 0) + (isSafe ? 0 : 1);
    const isShadowbanned = creatorViolations >= 2;

    // AI Generated Tags & Categorization
    const generatedTags = this.extractSmartTags(payload);
    const category = this.predictCategory(payload);

    // Speech-to-Text & Subtitle Sync
    const subtitles = generateSmartSubtitles(censoredText || payload.title || 'TikTok Short Video', 15);
    const captionBn = censoredText || 'আমার নতুন টিকটক ভিডিও 🔥 #viral #fyp';

    // Gemini Multimodal Enhancement if API Key is available
    if (this.genAI) {
      try {
        const prompt = `You are a TikTok Multi-modal AI Video Ingestion engine.
Analyze this short video post:
Title: "${payload.title}"
Description: "${payload.description}"
Location: "${payload.location || 'Global'}"
Music: "${payload.soundTitle || 'Original'}"

Return a strict JSON object with:
{
  "isSafe": boolean,
  "safetyScore": number (0-100),
  "violations": string[],
  "bengaliCaption": string,
  "recommendedTags": string[],
  "category": "foryou" | "music" | "dance" | "entertainment" | "trending"
}`;

        const response = await this.genAI.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
        });

        const textOutput = response.text || '';
        const jsonMatch = textOutput.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          if (typeof parsed.isSafe === 'boolean') isSafe = parsed.isSafe;
          if (typeof parsed.safetyScore === 'number') safetyScore = parsed.safetyScore;
          if (Array.isArray(parsed.violations) && parsed.violations.length > 0) {
            violations.push(...parsed.violations);
            warningReason = parsed.violations.join(', ');
          }
        }
      } catch (err) {
        console.warn('[VideoAiPipeline] Gemini API inference fallback to deterministic engine:', err);
      }
    }

    // Determine initial review status
    const reviewStatus: 'pending_review' | 'active' | 'rejected' = isSafe ? 'active' : 'rejected';

    // Tier 1 Cold Start initial metrics
    const initialScore = calculateEngagementScore({
      watchTimeSec: 8.5,
      completionRate: 0.85,
      loopCount: 1,
      likesCount: 12,
      commentsCount: 2,
      sharesCount: 1,
    });

    const tierInfo = evaluateViralityTier('tier_50', initialScore, 0.85, 8.5);

    // Sync to Firestore 'videos' collection mirror
    this.syncToFirestore(payload.videoUrl, {
      caption: censoredText,
      captionBn,
      tags: generatedTags,
      category,
      subtitles,
      reviewStatus,
      algorithmTier: tierInfo.newTier,
      algorithmScore: initialScore,
      isShadowbanned,
    });

    return {
      enrichedCaption: censoredText,
      captionBn,
      category: category as any,
      tags: generatedTags,
      subtitles,
      moderation: {
        status: isSafe ? 'approved' : 'rejected',
        safetyScore,
        isSafe,
        violations,
        warningReason,
        moderatedAt: Date.now(),
      },
      algorithmTier: tierInfo.newTier,
      algorithmScore: initialScore,
      algorithmReach: tierInfo.reach,
      algorithmStatusText: tierInfo.statusText,
      reviewStatus,
      isShadowbanned,
      creatorWarning: isSafe
        ? undefined
        : {
            hasWarning: true,
            warningReason: warningReason || 'কমিউনিটি নীতিমালা লঙ্ঘন',
          },
    };
  }

  private extractSmartTags(payload: VideoIngestionPayload): string[] {
    const base = ['#fyp', '#foryou', '#viral', '#trending', '#tiktokbd'];
    const text = `${payload.title} ${payload.description} ${payload.location || ''}`.toLowerCase();

    if (text.includes('dance') || text.includes('নাচ')) base.push('#dance', '#dancechallenge');
    if (text.includes('music') || text.includes('গান') || text.includes('sound')) base.push('#music', '#banglasong');
    if (text.includes('photo') || payload.postType === 'photo_carousel') base.push('#photomode', '#aesthetic');
    if (text.includes('kuakata') || text.includes('কক্সবাজার') || text.includes('tour')) base.push('#travelbd', '#kuakata');
    if (text.includes('funny') || text.includes('হাসি')) base.push('#funny', '#comedy');

    return Array.from(new Set(base)).slice(0, 7);
  }

  private predictCategory(payload: VideoIngestionPayload): 'foryou' | 'following' | 'friends' | 'trending' {
    const text = `${payload.title} ${payload.description}`.toLowerCase();
    if (text.includes('viral') || text.includes('trending')) return 'trending';
    return 'foryou';
  }

  /**
   * Syncs document to Firestore 'videos' collection mirror
   */
  private syncToFirestore(videoUrl: string, data: any) {
    try {
      const key = 'tiktok_firestore_videos_collection';
      const saved = localStorage.getItem(key);
      const list: any[] = saved ? JSON.parse(saved) : [];
      const updated = [{ videoUrl, ...data, updatedAt: Date.now() }, ...list.filter((v) => v.videoUrl !== videoUrl)];
      localStorage.setItem(key, JSON.stringify(updated.slice(0, 150)));
    } catch (e) {
      console.warn('[VideoAiPipeline] Firestore sync warning:', e);
    }
  }
}

export const videoAiPipeline = new VideoAiPipelineService();
