import { SoundTrack, VideoReel } from '../types';

const registeredSounds: Map<string, SoundTrack> = new Map();

export function registerSoundFromReel(reel: VideoReel): SoundTrack {
  const sound: SoundTrack = {
    ...reel.music,
    id: reel.audioId || reel.music.id,
    title: reel.audioTitle || reel.music.title,
    cover: reel.audioThumbnailUrl || reel.music.cover,
    source: reel.audioSource || reel.music.source || 'trending',
  };
  registeredSounds.set(sound.id, sound);
  return sound;
}

export function getRegisteredSound(id: string): SoundTrack | undefined {
  return registeredSounds.get(id);
}
