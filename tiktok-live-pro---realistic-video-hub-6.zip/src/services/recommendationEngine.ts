import { VideoReel, UserRecommendationProfile } from '../types';
import { safeSetItem } from '../utils/storage';

const PROFILE_KEY = 'tiktok_ai_recommendation_profile';

export const INITIAL_RECOMMENDATION_PROFILE: UserRecommendationProfile = {
  videosWatchedCount: 0,
  isColdStartCompleted: false,
  detectedInterests: ['trending', 'entertainment'],
  interestScores: {
    foryou: 5,
    trending: 5,
    entertainment: 4,
    music: 4,
    comedy: 3,
    dance: 3,
    tech: 2,
    islamic: 2,
    lifestyle: 2,
  },
  totalWatchTimeSec: 0,
  totalLoops: 0,
  totalLikes: 0,
  totalShares: 0,
  lastUpdated: Date.now(),
};

export function getRecommendationProfile(): UserRecommendationProfile {
  try {
    const saved = localStorage.getItem(PROFILE_KEY);
    if (saved) return JSON.parse(saved);
  } catch {}
  return { ...INITIAL_RECOMMENDATION_PROFILE };
}

export function saveRecommendationProfile(profile: UserRecommendationProfile): void {
  safeSetItem(PROFILE_KEY, JSON.stringify(profile));
}

export interface VideoInteractionEvent {
  reelId: string;
  category: string;
  tags: string[];
  watchTimeSec: number;
  durationSec: number;
  loopCount: number;
  isLiked: boolean;
  isCommented: boolean;
  isShared: boolean;
  isBookmarked: boolean;
}

export interface InteractionResult {
  profile: UserRecommendationProfile;
  justCompletedColdStart: boolean;
  detectedCategory?: string;
  completionRate: number;
  reWatchScore: number;
}

/**
 * Record user interactions in real-time:
 * - Completion Rate (কত শতাংশ দেখেছে)
 * - Re-watch Rate (লুপ / পুনরায় দেখছে কি না)
 * - Likes, Comments, Shares, Bookmarks
 * - Early Skip Penalty (<2.5s)
 * - Cold Start Engine (Detects taste within first 5 videos)
 */
export function recordUserInteraction(event: VideoInteractionEvent): InteractionResult {
  const profile = getRecommendationProfile();
  const dur = Math.max(1, event.durationSec || 15);
  const completionRate = Math.min(2.0, event.watchTimeSec / dur);
  const isEarlySkip = event.watchTimeSec < 2.5 && completionRate < 0.25;
  const isRewatched = event.loopCount > 1;

  // Calculate algorithmic engagement weight
  let scoreDelta = 0;
  if (isEarlySkip) {
    scoreDelta = -2.5; // Negative signal for fast skip
  } else {
    // High completion rate is strong positive signal (>80% gives heavy boost)
    scoreDelta += completionRate * 4.0;
    if (isRewatched) scoreDelta += 3.5; // Rewatch rate (re-looping)
    if (event.isLiked) scoreDelta += 2.5;
    if (event.isCommented) scoreDelta += 2.0;
    if (event.isShared) scoreDelta += 4.0; // Shares are highest organic signal
    if (event.isBookmarked) scoreDelta += 2.5;
  }

  // Update category and tag affinities
  const cat = event.category?.toLowerCase() || 'entertainment';
  const scores = { ...profile.interestScores };
  scores[cat] = Math.max(0, (scores[cat] || 2) + scoreDelta);

  event.tags?.forEach((t) => {
    const cleanTag = t.replace('#', '').toLowerCase();
    if (cleanTag.length > 2) {
      scores[cleanTag] = Math.max(0, (scores[cleanTag] || 1) + scoreDelta * 0.5);
    }
  });

  // Track counts
  profile.videosWatchedCount += 1;
  profile.totalWatchTimeSec += event.watchTimeSec;
  profile.totalLoops += Math.max(0, event.loopCount - 1);
  if (event.isLiked) profile.totalLikes += 1;
  if (event.isShared) profile.totalShares += 1;
  profile.lastUpdated = Date.now();
  profile.interestScores = scores;

  let justCompletedColdStart = false;
  let topCategory: string | undefined;

  // Cold Start Detection: First 5 videos
  if (!profile.isColdStartCompleted && profile.videosWatchedCount >= 5) {
    profile.isColdStartCompleted = true;
    justCompletedColdStart = true;

    // Pick top scoring categories
    const sortedCats = Object.entries(scores)
      .sort((a, b) => b[1] - a[1])
      .map(([k]) => k)
      .slice(0, 4);

    profile.detectedInterests = sortedCats.length > 0 ? sortedCats : ['trending', 'entertainment'];
    topCategory = profile.detectedInterests[0];
  } else if (profile.isColdStartCompleted) {
    const sortedCats = Object.entries(scores)
      .sort((a, b) => b[1] - a[1])
      .map(([k]) => k)
      .slice(0, 4);
    profile.detectedInterests = sortedCats;
    topCategory = sortedCats[0];
  }

  saveRecommendationProfile(profile);

  return {
    profile,
    justCompletedColdStart,
    detectedCategory: topCategory,
    completionRate,
    reWatchScore: isRewatched ? event.loopCount : 1,
  };
}

/**
 * Ranks and personalizes the For You feed reels according to user interest vectors
 */
export function rankReelsForUser(reels: VideoReel[]): VideoReel[] {
  const profile = getRecommendationProfile();
  const scores = profile.interestScores;

  // Always keep sponsored/promoted videos at prime slots
  const sponsored = reels.filter((r) => r.isPromoted);
  const organic = reels.filter((r) => !r.isPromoted);

  // Score organic reels
  const scored = organic.map((r) => {
    let affinity = scores[r.category?.toLowerCase()] || 2;
    r.tags?.forEach((tag) => {
      const clean = tag.replace('#', '').toLowerCase();
      if (scores[clean]) affinity += scores[clean] * 0.4;
    });

    // Viral tier weight
    const tierBonus =
      r.algorithmTier === 'tier_viral'
        ? 15
        : r.algorithmTier === 'tier_20000' || r.algorithmTier === 'tier_10000'
        ? 8
        : r.algorithmTier === 'tier_2000' || r.algorithmTier === 'tier_1000'
        ? 4
        : 1;

    return {
      reel: r,
      score: affinity * 2 + (r.likesCount / 1000) * 0.5 + tierBonus,
    };
  });

  scored.sort((a, b) => b.score - a.score);

  // Interleave sponsored if present
  if (sponsored.length > 0) {
    const result: VideoReel[] = [];
    let spIdx = 0;
    scored.forEach((item, index) => {
      // Place first sponsored at position 0, next every 4 videos
      if (index === 0 && spIdx < sponsored.length) {
        result.push(sponsored[spIdx++]);
      }
      result.push(item.reel);
      if (index > 0 && index % 4 === 0 && spIdx < sponsored.length) {
        result.push(sponsored[spIdx++]);
      }
    });
    return result;
  }

  return scored.map((s) => s.reel);
}

/**
 * CREATOR VIRAL LOOP (Creator Push Mechanism):
 * - Phase 1: Test Cohort (২০০ জন টেস্ট গ্রুপ)
 * - Phase 2: Engagement Spike (২,০০০ জন সম্প্রসারণ)
 * - Phase 3: National Trending (২০,০০০ জন ভাইরাল পুশ)
 * - Phase 4: Global Mega Viral Loop (১,০০,০০০+ অডিয়েন্স)
 */
export function evaluateCreatorViralPush(reel: VideoReel): VideoReel {
  const currentTier = reel.algorithmTier || 'tier_200';
  let reach = reel.algorithmReach || 200;
  let newTier = currentTier;
  let statusText = reel.algorithmStatusText || '';

  const completionRate = reel.completionRate || 0.82;
  const likesToViewsRatio = reel.viewsCount > 0 ? reel.likesCount / reel.viewsCount : 0.2;

  if (currentTier === 'tier_50' || currentTier === 'tier_200') {
    // If completion rate > 60% and good like ratio, push from 200 to 2,000 users
    if (completionRate >= 0.6 || likesToViewsRatio > 0.12 || reel.likesCount > 40) {
      newTier = 'tier_2000';
      reach = 2000;
      statusText = '🔥 টেস্ট গ্রুপে ৬০%+ ওয়াচ-টাইম আসায় অ্যালগরিদম ভিডিওটি ২,০০০ জন অডিয়েন্সের ফর ইউ পেজে সম্প্রসারণ করেছে!';
    } else {
      reach = 200;
      statusText = '🎯 ১ম ধাপ: ২০০ জনের টেস্ট গ্রুপে ওয়াচ-টাইম ও লাইক রেসপন্স পর্যবেক্ষণ করা হচ্ছে।';
    }
  } else if (currentTier === 'tier_1000' || currentTier === 'tier_2000') {
    if (reel.likesCount > 300 || reel.sharesCount > 25) {
      newTier = 'tier_20000';
      reach = 20000;
      statusText = '🚀 ব্যাপক শেয়ার ও লাইকের কারণে ভিডিওটি ২০,০০০ জনের ন্যাশনাল ট্রেন্ডিং ফিডে পুশ করা হয়েছে!';
    }
  } else if (currentTier === 'tier_10000' || currentTier === 'tier_20000') {
    if (reel.likesCount > 2500 || reel.sharesCount > 100) {
      newTier = 'tier_viral';
      reach = 150000;
      statusText = '🌟 গ্লোবাল মেগা ভাইরাল লুপ: দেশজুড়ে শীর্ষে স্থান পেয়েছে!';
    }
  }

  return {
    ...reel,
    algorithmTier: newTier,
    algorithmReach: reach,
    algorithmStatusText: statusText,
  };
}

export function manuallyAdvanceViralStage(reel: VideoReel): VideoReel {
  const currentTier = reel.algorithmTier || 'tier_200';
  let nextTier: VideoReel['algorithmTier'] = 'tier_2000';
  let reach = 2000;
  let text = '';
  let addLikes = 150;
  let addViews = 1800;

  if (currentTier === 'tier_50' || currentTier === 'tier_200') {
    nextTier = 'tier_2000';
    reach = 2000;
    text = '🔥 টেস্ট গ্রুপে ৬০%+ ওয়াচ-টাইম রেসপন্স আসায় ভিডিওটি ২,০০০ জনের কাছে সম্প্রসারণ করা হয়েছে!';
    addLikes = 220;
    addViews = 2000;
  } else if (currentTier === 'tier_1000' || currentTier === 'tier_2000') {
    nextTier = 'tier_20000';
    reach = 20000;
    text = '🚀 উচ্চ শেয়ার ও ফুল ভিউ রেসপন্সে ভিডিওটি ২০,০০০ মানুষের ফর ইউ পেজে ভাইরাল পুশ পেয়েছে!';
    addLikes = 1200;
    addViews = 18000;
  } else if (currentTier === 'tier_10000' || currentTier === 'tier_20000') {
    nextTier = 'tier_viral';
    reach = 150000;
    text = '🌟 গ্লোবাল ভাইরাল লুপ সক্রিয়! মিলিয়ন ভিউয়ার্স ট্রেন্ডিংয়ে সবার উপরে স্থান পেয়েছে।';
    addLikes = 8500;
    addViews = 120000;
  }

  return {
    ...reel,
    algorithmTier: nextTier,
    algorithmReach: reach,
    algorithmStatusText: text,
    viewsCount: reel.viewsCount + addViews,
    likesCount: reel.likesCount + addLikes,
    sharesCount: reel.sharesCount + Math.floor(addLikes * 0.15),
  };
}

export const recommendationEngine = {
  getProfile: getRecommendationProfile,
  saveProfile: saveRecommendationProfile,
  recordUserInteraction,
  rankReelsForUser,
  evaluateCreatorViralPush,
  manuallyAdvanceViralStage,
  trackLike: (reel: VideoReel, isLiked: boolean) => {
    return recordUserInteraction({
      reelId: reel.id,
      category: reel.category || 'entertainment',
      tags: reel.tags || [],
      watchTimeSec: 8,
      durationSec: 15,
      loopCount: 1,
      isLiked,
      isCommented: false,
      isShared: false,
      isBookmarked: false,
    });
  },
  trackWatch: (reel: VideoReel, watchTimeSec: number, durationSec: number, loopCount: number) => {
    return recordUserInteraction({
      reelId: reel.id,
      category: reel.category || 'entertainment',
      tags: reel.tags || [],
      watchTimeSec,
      durationSec,
      loopCount,
      isLiked: reel.isLiked,
      isCommented: false,
      isShared: false,
      isBookmarked: reel.isBookmarked,
    });
  },
  advanceReelTier: (targetReel: VideoReel) => {
    const updated = manuallyAdvanceViralStage(targetReel);
    let msg = '🚀 ভিডিওটি পরবর্তী ভাইরাল ধাপে পুশ করা হয়েছে!';
    if (updated.algorithmTier === 'tier_2000' || updated.algorithmTier === 'tier_1000') {
      msg = '🚀 ওয়াচ-টাইম ৬০%+ হওয়ায় ভিডিওটি ২,০০০ জনের কাছে পৌঁছেছে!';
    } else if (updated.algorithmTier === 'tier_20000' || updated.algorithmTier === 'tier_10000') {
      msg = '🔥 উচ্চ শেয়ার ও লাইক রেসপন্সে ভিডিওটি ২০,০০০ জনের ন্যাশনাল ট্রেন্ডিংয়ে পৌঁছেছে!';
    } else if (updated.algorithmTier === 'tier_viral') {
      msg = '🌟 ভিডিওটি গ্লোবাল মেগা ভাইরাল লুপে সবার উপরে পৌঁছে গেছে!';
    }
    return { updatedReel: updated, message: msg };
  },
  getForYouFeed: (reels: VideoReel[]) => {
    return rankReelsForUser(reels);
  },
  getFollowingFeed: (reels: VideoReel[], followingIds: string[] = []) => {
    const followed = reels.filter((r) => followingIds.includes(r.creator.id) || r.creator.isFollowed);
    return followed.length > 0 ? followed : reels;
  },
  getCommunityFeed: (reels: VideoReel[]) => {
    return [...reels].sort((a, b) => b.likesCount - a.likesCount);
  },
  trackShare: (reel: VideoReel) => {
    return recordUserInteraction({
      reelId: reel.id,
      category: reel.category || 'entertainment',
      tags: reel.tags || [],
      watchTimeSec: 15,
      durationSec: 15,
      loopCount: 2,
      isLiked: true,
      isCommented: false,
      isShared: true,
      isBookmarked: false,
    });
  },
  trackWatchSession: (reelId: string, watchDurationSec: number, durationSec: number = 15, tags: string[] = [], creatorId?: string) => {
    return recordUserInteraction({
      reelId,
      category: tags[0] || 'entertainment',
      tags,
      watchTimeSec: watchDurationSec,
      durationSec,
      loopCount: Math.max(1, Math.floor(watchDurationSec / durationSec)),
      isLiked: false,
      isCommented: false,
      isShared: false,
      isBookmarked: false,
    });
  },
};

