import { VideoReel, UserAccount, SoundTrack, CommentItem, LiveCallSession, BoostCampaign, BannedUserInfo, Creator, VipCapCutPurchase } from '../types';
import { safeSetItem } from '../utils/storage';
import { mockCreators } from '../data/mockData';

export type { LiveCallSession };

export interface FirebaseUserDirectoryItem {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  verified: boolean;
  isOnline?: boolean;
}

export function isFirebaseConnected(): boolean {
  return true;
}

export function isFirebaseLiveConnected(): boolean {
  return true;
}

export function getFireLiveMetrics() {
  return {
    status: 'online',
    connected: true,
    server: 'asia-southeast1-firebase-live',
    edgeServer: 'asia-southeast1 (Dhaka Node)',
    latencyMs: 24,
    activeViewers: 12480,
    syncEngine: 'FireLive-v2-Realtime',
    syncEngines: ['reels', 'hearts', 'gifts', 'video_calls', 'gemini_moderation'],
    bandwidthMbps: 48.6,
    packetLoss: '0.01%',
    fireLiveConnected: true,
  };
}

export async function syncReelToFirebase(reel: VideoReel): Promise<boolean> {
  try {
    const saved = localStorage.getItem('tiktok_firestore_reels_v1');
    const list: VideoReel[] = saved ? JSON.parse(saved) : [];
    
    // Firestore schema normalization under 'videos' collection
    const firestoreDocument: VideoReel = {
      ...reel,
      videoUrl: reel.videoUrl,
      thumbnailUrl: reel.thumbnailUrl || reel.posterUrl,
      audioUrl: reel.audioUrl || reel.music?.audioUrl || '',
      audioTitle: reel.audioTitle || reel.music?.title || 'Original Sound',
      audioId: reel.audioId || reel.music?.id || `snd_${reel.id}`,
      originalArtistId: reel.originalArtistId || reel.creator?.id || 'artist_default',
      audioSource: reel.audioSource || reel.music?.source || 'youtube_music',
    };

    const updated = [firestoreDocument, ...list.filter((r) => r.id !== reel.id)];
    safeSetItem('tiktok_firestore_reels_v1', JSON.stringify(updated));
    return true;
  } catch (e) {
    console.warn('syncReelToFirebase err:', e);
    return false;
  }
}

export async function fetchReelsFromFirebase(): Promise<VideoReel[]> {
  try {
    const saved = localStorage.getItem('tiktok_firestore_reels_v1');
    return saved ? JSON.parse(saved) : [];
  } catch (e) {
    return [];
  }
}

export async function syncUserToFirebase(user: UserAccount): Promise<boolean> {
  try {
    const saved = localStorage.getItem('tiktok_registered_accounts');
    let list: UserAccount[] = saved ? JSON.parse(saved) : [];
    const idx = list.findIndex((u) => u.id === user.id);
    if (idx !== -1) {
      list[idx] = user;
    } else {
      list.push(user);
    }
    safeSetItem('tiktok_registered_accounts', JSON.stringify(list));
    return true;
  } catch (e) {
    return false;
  }
}

export async function syncSoundToFirebase(sound: SoundTrack): Promise<boolean> {
  return true;
}

export async function syncCommentToFirebase(reelId: string, comment: CommentItem): Promise<boolean> {
  try {
    const saved = localStorage.getItem(`tiktok_comments_${reelId}`);
    const list: CommentItem[] = saved ? JSON.parse(saved) : [];
    safeSetItem(`tiktok_comments_${reelId}`, JSON.stringify([comment, ...list]));
    return true;
  } catch (e) {
    return false;
  }
}

export async function updateFirebaseCallSession(session: LiveCallSession): Promise<void> {
  safeSetItem('tiktok_live_call_session', JSON.stringify(session));
}

export async function logCallEventToFirebaseChat(threadId: string, eventData: any): Promise<void> {
  // Chat logging
}

// =========================================================================
// ADMIN SEARCH, BAN & UNBAN ENGINE (ব্যবহারকারী অনুসন্ধান ও ব্যান/আনব্যান)
// =========================================================================

export function fetchBannedUsers(): BannedUserInfo[] {
  try {
    const saved = localStorage.getItem('tiktok_banned_users');
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

export function isUserBanned(identifier: string): boolean {
  if (!identifier) return false;
  const banned = fetchBannedUsers();
  const clean = identifier.toLowerCase().replace('@', '').trim();
  return banned.some(
    (b) =>
      b.id.toLowerCase() === clean ||
      b.uid.toLowerCase() === clean ||
      b.handle.toLowerCase().replace('@', '') === clean
  );
}

export function banUser(
  user: { id: string; uid?: string; name: string; handle: string; avatar?: string },
  reason: string = 'Violation of community guidelines and illegal content distribution'
): boolean {
  try {
    const banned = fetchBannedUsers();
    const uid = user.uid || (user.id.startsWith('usr-') ? user.id.replace('usr-', '') : `uid_${user.id}`);
    const newBan: BannedUserInfo = {
      id: user.id,
      uid,
      name: user.name,
      handle: user.handle.replace('@', ''),
      avatar: user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      bannedAt: Date.now(),
      reason,
    };
    const updated = [newBan, ...banned.filter((b) => b.id !== user.id && b.handle !== user.handle)];
    safeSetItem('tiktok_banned_users', JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('banUser error:', e);
    return false;
  }
}

export function unbanUser(identifier: string): boolean {
  try {
    const banned = fetchBannedUsers();
    const clean = identifier.toLowerCase().replace('@', '').trim();
    const updated = banned.filter(
      (b) =>
        b.id.toLowerCase() !== clean &&
        b.uid.toLowerCase() !== clean &&
        b.handle.toLowerCase().replace('@', '') !== clean
    );
    safeSetItem('tiktok_banned_users', JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('unbanUser error:', e);
    return false;
  }
}

export interface AppDirectoryUser {
  id: string;
  uid: string;
  name: string;
  handle: string;
  avatar: string;
  followers: number;
  verified: boolean;
  country?: string;
  isBanned: boolean;
  bannedAt?: number;
  bio?: string;
}

export function getAllAppUsers(): AppDirectoryUser[] {
  const directory: Map<string, AppDirectoryUser> = new Map();
  const bannedList = fetchBannedUsers();
  const isBannedMap = new Map(bannedList.map((b) => [b.handle.toLowerCase().replace('@', ''), b]));

  // 1. Ingest Mock Creators
  Object.values(mockCreators).forEach((c, idx) => {
    const handleClean = c.handle.toLowerCase().replace('@', '');
    const banInfo = isBannedMap.get(handleClean);
    directory.set(c.id, {
      id: c.id,
      uid: `7192${849200 + idx}`,
      name: c.name,
      handle: c.handle,
      avatar: c.avatar,
      followers: c.followers,
      verified: c.verified,
      country: c.countryName || 'Bangladesh',
      isBanned: Boolean(banInfo),
      bannedAt: banInfo?.bannedAt,
      bio: c.bio,
    });
  });

  // 2. Ingest Registered Accounts
  try {
    const saved = localStorage.getItem('tiktok_registered_accounts');
    if (saved) {
      const list: UserAccount[] = JSON.parse(saved);
      list.forEach((u) => {
        const handleClean = u.handle.toLowerCase().replace('@', '');
        const banInfo = isBannedMap.get(handleClean);
        directory.set(u.id, {
          id: u.id,
          uid: u.uid || `8402${Math.floor(Math.random() * 900000)}`,
          name: u.name,
          handle: u.handle,
          avatar: u.avatar,
          followers: u.followers || 0,
          verified: u.verified || false,
          country: u.countryName || 'Bangladesh',
          isBanned: Boolean(banInfo),
          bannedAt: banInfo?.bannedAt,
          bio: u.bio,
        });
      });
    }
  } catch {}

  return Array.from(directory.values());
}

// =========================================================================
// TIKTOK BOOST & PROMOTED ADS ENGINE (ভিডিও বুস্ট ও স্পন্সর ক্যাম্পেইন)
// =========================================================================

export function fetchBoostCampaigns(): BoostCampaign[] {
  try {
    const saved = localStorage.getItem('tiktok_boost_campaigns');
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

export function saveBoostCampaign(campaign: BoostCampaign): boolean {
  try {
    const list = fetchBoostCampaigns();
    const updated = [campaign, ...list.filter((c) => c.id !== campaign.id)];
    safeSetItem('tiktok_boost_campaigns', JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('saveBoostCampaign error:', e);
    return false;
  }
}

export function updateBoostCampaign(campaignId: string, updates: Partial<BoostCampaign>): boolean {
  try {
    const list = fetchBoostCampaigns();
    const updated = list.map((c) => (c.id === campaignId ? { ...c, ...updates } : c));
    safeSetItem('tiktok_boost_campaigns', JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('updateBoostCampaign error:', e);
    return false;
  }
}

// =========================================================================
// CAPCUT VIP PURCHASES & IN-APP PURCHASE ENGINE (ক্যাপকাট ভিআইপি ফিচার আনলক)
// =========================================================================

export function fetchVipPurchases(): VipCapCutPurchase[] {
  try {
    const saved = localStorage.getItem('tiktok_capcut_vip_purchases');
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

export function saveVipPurchase(purchase: VipCapCutPurchase): boolean {
  try {
    const list = fetchVipPurchases();
    const updated = [purchase, ...list.filter((p) => p.id !== purchase.id)];
    safeSetItem('tiktok_capcut_vip_purchases', JSON.stringify(updated));
    
    // Also unlock locally for this user
    unlockVipFeatureLocally(purchase.featureKey);
    return true;
  } catch (e) {
    console.error('saveVipPurchase error:', e);
    return false;
  }
}

export function updateVipPurchase(purchaseId: string, updates: Partial<VipCapCutPurchase>): boolean {
  try {
    const list = fetchVipPurchases();
    const updated = list.map((p) => (p.id === purchaseId ? { ...p, ...updates } : p));
    safeSetItem('tiktok_capcut_vip_purchases', JSON.stringify(updated));
    return true;
  } catch (e) {
    console.error('updateVipPurchase error:', e);
    return false;
  }
}

export function fetchUnlockedVipFeatures(): string[] {
  try {
    const saved = localStorage.getItem('tiktok_unlocked_vip_features');
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

export function unlockVipFeatureLocally(featureKey: string): void {
  try {
    const current = fetchUnlockedVipFeatures();
    if (!current.includes(featureKey)) {
      const updated = [...current, featureKey];
      safeSetItem('tiktok_unlocked_vip_features', JSON.stringify(updated));
    }
  } catch {}
}

export function isFeatureVipUnlocked(featureKey: string): boolean {
  // If user bought all-in-one VIP access, all features are unlocked
  const unlocked = fetchUnlockedVipFeatures();
  return unlocked.includes('all_vip_access') || unlocked.includes(featureKey);
}



