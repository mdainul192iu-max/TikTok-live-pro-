export interface WalletTransaction {
  id: string;
  type: 'referral_bonus' | 'boost_spend' | 'withdraw';
  amountBDT: number;
  title: string;
  timestamp: number;
  status: 'completed' | 'pending';
}

export interface UserWallet {
  balanceBDT: number;
  referralCode: string;
  referralLink: string;
  hasClaimedWelcomeBonus: boolean;
  referredUsersCount: number;
  totalEarnedBDT: number;
  minWithdrawalBDT: number; // 600 BDT
  transactions: WalletTransaction[];
}

const WALLET_KEY = 'tiktok_user_wallet_data';

export class ReferralWalletService {
  private getStorageWallet(): UserWallet {
    try {
      const saved = localStorage.getItem(WALLET_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}

    // Initial state: automatically has ৳499 welcome bonus available or claimed
    const initialWallet: UserWallet = {
      balanceBDT: 499,
      referralCode: 'TK-7192849204',
      referralLink: typeof window !== 'undefined' 
        ? `${window.location.origin}/#ref=TK-7192849204`
        : 'https://tiktok.live/#ref=TK-7192849204',
      hasClaimedWelcomeBonus: true,
      referredUsersCount: 1,
      totalEarnedBDT: 499,
      minWithdrawalBDT: 600,
      transactions: [
        {
          id: `tx-init-${Date.now()}`,
          type: 'referral_bonus',
          amountBDT: 499,
          title: 'রেফারেন্স আইডি ওয়েলকাম বোনাস আনলক (৳৪৯৯)',
          timestamp: Date.now() - 3600000,
          status: 'completed',
        },
      ],
    };

    try {
      localStorage.setItem(WALLET_KEY, JSON.stringify(initialWallet));
    } catch {}

    return initialWallet;
  }

  private saveWallet(wallet: UserWallet): void {
    try {
      localStorage.setItem(WALLET_KEY, JSON.stringify(wallet));
    } catch {}
  }

  public getWallet(customUid?: string): UserWallet {
    const wallet = this.getStorageWallet();
    if (customUid && customUid !== '7192849204') {
      wallet.referralCode = `TK-${customUid}`;
      if (typeof window !== 'undefined') {
        wallet.referralLink = `${window.location.origin}/#ref=TK-${customUid}`;
      }
    }
    return wallet;
  }

  /**
   * Claim referral bonus (৳499) for new account or friend reference
   */
  public claimReferralBonus(code?: string): { success: boolean; message: string; wallet: UserWallet } {
    const wallet = this.getStorageWallet();
    if (wallet.hasClaimedWelcomeBonus && wallet.balanceBDT >= 499) {
      return {
        success: true,
        message: '✓ আপনার একাউন্টে ইতিমধ্যে ৳৪৯৯ টাকা আনলক রয়েছে!',
        wallet,
      };
    }

    wallet.hasClaimedWelcomeBonus = true;
    wallet.balanceBDT += 499;
    wallet.totalEarnedBDT += 499;
    wallet.referredUsersCount += 1;
    wallet.transactions.unshift({
      id: `tx-${Date.now()}`,
      type: 'referral_bonus',
      amountBDT: 499,
      title: code ? `রেফার কোড [${code}] বোনাস আনলক (৳৪৯৯)` : 'রেফারেন্স আইডি ওয়েলকাম বোনাস (৳৪৯৯)',
      timestamp: Date.now(),
      status: 'completed',
    });

    this.saveWallet(wallet);
    return {
      success: true,
      message: '🎉 অভিনন্দন! রেফারেন্স বোনাস হিসেবে ৳৪৯৯ টাকা সফলভাবে আনলক হয়েছে!',
      wallet,
    };
  }

  /**
   * Spend balance to boost video in For You feed
   */
  public spendBalanceForBoost(amountBDT: number, videoCaption: string): { success: boolean; message: string; wallet: UserWallet } {
    const wallet = this.getStorageWallet();
    if (wallet.balanceBDT < amountBDT) {
      return {
        success: false,
        message: `⚠️ অপর্যাপ্ত ব্যালেন্স! আপনার ওয়ালেটে ৳${wallet.balanceBDT} আছে, প্রয়োজন ৳${amountBDT}।`,
        wallet,
      };
    }

    wallet.balanceBDT -= amountBDT;
    wallet.transactions.unshift({
      id: `tx-${Date.now()}`,
      type: 'boost_spend',
      amountBDT,
      title: `ভিডিও বুস্টে খরচ: ${videoCaption.slice(0, 24)}... (৳${amountBDT})`,
      timestamp: Date.now(),
      status: 'completed',
    });

    this.saveWallet(wallet);
    return {
      success: true,
      message: `🎉 ৳${amountBDT} টাকা রেফারেল ব্যালেন্স কেটে ভিডিওটি ফর ইউ পেজে ৪-টিয়ার বুস্টে পাঠানো হয়েছে!`,
      wallet,
    };
  }

  /**
   * Request withdrawal (requires at least ৳600)
   */
  public requestWithdrawal(amountBDT: number, method: 'bkash' | 'nagad', phone: string): { success: boolean; message: string; wallet: UserWallet } {
    const wallet = this.getStorageWallet();
    if (wallet.balanceBDT < 600) {
      const remaining = 600 - wallet.balanceBDT;
      return {
        success: false,
        message: `⚠️ উইথড্র করতে ন্যূনতম ৬০০ টাকা ব্যালেন্স প্রয়োজন! আপনার ব্যালেন্স ৳${wallet.balanceBDT}। আরও ৳${remaining} আয় করুন।`,
        wallet,
      };
    }

    if (amountBDT > wallet.balanceBDT) {
      return {
        success: false,
        message: `⚠️ আপনার সর্বোচ্চ উত্তোলনযোগ্য ব্যালেন্স ৳${wallet.balanceBDT}।`,
        wallet,
      };
    }

    wallet.balanceBDT -= amountBDT;
    wallet.transactions.unshift({
      id: `tx-${Date.now()}`,
      type: 'withdraw',
      amountBDT,
      title: `${method === 'bkash' ? 'বিকাশ' : 'নগদ'} উইথড্র রিকোয়েস্ট (${phone})`,
      timestamp: Date.now(),
      status: 'pending',
    });

    this.saveWallet(wallet);
    return {
      success: true,
      message: `✓ ৳${amountBDT} টাকা ${method === 'bkash' ? 'বিকাশ' : 'নগদ'} নম্বরে (${phone}) উইথড্র প্রসেসিংয়ে জমা হয়েছে! এডমিন zenx 1 ফোনে যাচাই করবেন।`,
      wallet,
    };
  }
}

export const referralWalletService = new ReferralWalletService();
