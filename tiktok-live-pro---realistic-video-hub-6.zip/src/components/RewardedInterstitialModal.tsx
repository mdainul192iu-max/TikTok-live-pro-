import React, { useState, useEffect } from 'react';
import { 
  Loader2, 
  Sparkles, 
  ShieldCheck, 
  Coins, 
  X, 
  ExternalLink, 
  DollarSign,
  CheckCircle2
} from 'lucide-react';
import { admobService, OFFICIAL_ADMOB_CONFIG } from '../services/admobService';

interface RewardedInterstitialModalProps {
  isOpen: boolean;
  onAdCompleted: () => void;
  onClose: () => void;
  amountFiat: number;
  currencyCode: string;
}

export const RewardedInterstitialModal: React.FC<RewardedInterstitialModalProps> = ({
  isOpen,
  onAdCompleted,
  onClose,
  amountFiat,
  currencyCode,
}) => {
  const [stage, setStage] = useState<'loading' | 'playing' | 'completed'>('loading');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(6);

  useEffect(() => {
    if (!isOpen) return;

    // Stage 1: Transition Loading Spinner (Simulates high-yield SDK ad buffering)
    setStage('loading');
    setSecondsRemaining(6);

    const loadTimer = setTimeout(() => {
      setStage('playing');
    }, 1200);

    return () => clearTimeout(loadTimer);
  }, [isOpen]);

  useEffect(() => {
    if (stage !== 'playing') return;

    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setStage('completed');
          admobService.grantRewardedInterstitialReward();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [stage]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-80 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 select-none">
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-3xl p-6 text-white shadow-2xl flex flex-col items-center text-center space-y-4 animate-in zoom-in-95 duration-200">
        
        {/* STAGE 1: LOADING SPINNER */}
        {stage === 'loading' && (
          <div className="py-12 flex flex-col items-center space-y-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-amber-500/20 border-t-amber-400 animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <DollarSign className="w-7 h-7 text-amber-400" />
              </div>
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                Loading High-Paying Rewarded Interstitial
              </h3>
              <p className="text-xs text-zinc-400 mt-1 font-mono">
                Ad Unit: {OFFICIAL_ADMOB_CONFIG.rewardedInterstitialAdId}
              </p>
            </div>
            <span className="text-[11px] font-bold text-emerald-400 px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30">
              Securing Transfer Gateway for {currencyCode} {amountFiat}...
            </span>
          </div>
        )}

        {/* STAGE 2: PLAYING REWARDED INTERSTITIAL AD */}
        {stage === 'playing' && (
          <div className="w-full space-y-4">
            {/* Top Header */}
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <div className="flex items-center gap-1.5 text-left">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider">
                  AdMob High-Paying Rewarded Ad
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-zinc-300 bg-zinc-800 px-2.5 py-1 rounded-full border border-zinc-700">
                Reward in {secondsRemaining}s
              </span>
            </div>

            {/* Video / Creative Showcase */}
            <div className="relative w-full h-56 rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800 flex items-center justify-center shadow-inner">
              <img
                src="https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?w=800"
                alt="Ad"
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent p-4 flex flex-col justify-end text-left">
                <div className="flex items-center gap-1.5 text-[10px] font-black text-amber-300 uppercase tracking-widest">
                  <Sparkles className="w-3.5 h-3.5 fill-current" />
                  <span>Verified Official Partner</span>
                </div>
                <h4 className="text-base font-black text-white mt-0.5">
                  Binance Pay 0% Transfer Fee
                </h4>
                <p className="text-xs text-zinc-300 mt-1 line-clamp-2">
                  Instantly receive global micro-earnings in USDT, BDT, INR, and 200+ local currencies.
                </p>
              </div>
            </div>

            {/* Bottom Progress */}
            <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 via-[#fe2c55] to-emerald-400 transition-all duration-1000"
                style={{ width: `${((6 - secondsRemaining) / 6) * 100}%` }}
              />
            </div>

            <p className="text-[11px] text-zinc-400">
              Please watch this sponsored ad to complete your verified withdrawal transaction.
            </p>
          </div>
        )}

        {/* STAGE 3: COMPLETED & CONFIRMED */}
        {stage === 'completed' && (
          <div className="py-6 space-y-4 w-full">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
            </div>

            <div>
              <h3 className="text-base font-black text-white">
                Rewarded Ad Completed!
              </h3>
              <p className="text-xs text-zinc-300 mt-1">
                Your withdrawal request for <strong className="text-emerald-400">{currencyCode} {amountFiat}</strong> is now authenticated and ready for submission to the Admin Panel.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-zinc-800/60 border border-zinc-700 text-xs font-mono text-amber-300 flex items-center justify-between">
              <span>High-Paying Bonus:</span>
              <span className="font-bold">+5 Free Gold Coins Added</span>
            </div>

            <button
              type="button"
              onClick={onAdCompleted}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm shadow-xl transition-all cursor-pointer active:scale-95"
            >
              Proceed & Confirm Withdrawal (পেনডিং সম্পন্ন)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
