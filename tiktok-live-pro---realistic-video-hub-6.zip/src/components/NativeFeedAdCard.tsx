import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Heart, 
  MessageCircle, 
  Share2, 
  ExternalLink, 
  Sparkles, 
  ShieldCheck, 
  Coins, 
  Star 
} from 'lucide-react';
import { NativeAdData, admobService } from '../services/admobService';
import { walletEarningsService } from '../services/walletEarningsService';
import { AppLanguage } from '../types';

interface NativeFeedAdCardProps {
  ad: NativeAdData;
  isActive: boolean;
  language: AppLanguage;
  onToast?: (msg: string) => void;
}

export const NativeFeedAdCard: React.FC<NativeFeedAdCardProps> = ({
  ad,
  isActive,
  language,
  onToast,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [likesCount, setLikesCount] = useState<number>(1420);
  const [hasAwardedCoins, setHasAwardedCoins] = useState<boolean>(false);
  const [watchProgress, setWatchProgress] = useState<number>(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (isActive) {
      admobService.recordNativeAdImpression();
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    } else {
      if (videoRef.current) {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  }, [isActive]);

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const { currentTime, duration } = videoRef.current;
    if (duration > 0) {
      const progress = (currentTime / duration) * 100;
      setWatchProgress(progress);

      // When user watches at least 80% of the native video ad, automatically award 5 Coins!
      if (progress >= 80 && !hasAwardedCoins) {
        setHasAwardedCoins(true);
        admobService.grantRewardedAdReward();
        onToast?.('🎉 +5 Gold Coins added to your Wallet for viewing Sponsored Ad!');
      }
    }
  };

  const handleTogglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  return (
    <div className="relative w-full h-full bg-black select-none overflow-hidden flex items-center justify-center">
      {/* Video Content */}
      <video
        ref={videoRef}
        src={ad.mediaVideoUrl}
        poster={ad.mediaPosterUrl}
        loop
        playsInline
        muted={isMuted}
        onTimeUpdate={handleTimeUpdate}
        onClick={handleTogglePlay}
        className="w-full h-full object-cover cursor-pointer"
      />

      {/* Play/Pause Center Indicator */}
      {!isPlaying && (
        <div 
          onClick={handleTogglePlay}
          className="absolute inset-0 z-10 flex items-center justify-center bg-black/30 cursor-pointer"
        >
          <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white">
            <Play className="w-8 h-8 fill-current ml-1" />
          </div>
        </div>
      )}

      {/* Top Overlay: Sponsored Native Ad Identification */}
      <div className="absolute top-14 left-4 z-20 flex items-center gap-2 pointer-events-none">
        <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase tracking-wider flex items-center gap-1 shadow-lg">
          <Sparkles className="w-3 h-3 text-amber-300 fill-current" />
          <span>Sponsored Ad</span>
        </span>
        <span className="px-2 py-0.5 rounded-full bg-black/40 backdrop-blur-md text-zinc-300 text-[9px] font-mono border border-white/10">
          Native ca-app-pub...5487509167
        </span>
      </div>

      {/* Mute Button */}
      <button
        onClick={() => setIsMuted(!isMuted)}
        className="absolute top-14 right-4 z-20 w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white border border-white/20 cursor-pointer shadow-md"
      >
        {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
      </button>

      {/* Bottom Info: Advertiser, Headline, Rating, and CTA Button */}
      <div className="absolute bottom-16 left-3 right-16 z-20 space-y-2 pointer-events-auto">
        {/* Advertiser Header */}
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-amber-400 shadow-md shrink-0">
            <img src={ad.iconUrl} alt="" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-black text-white drop-shadow-md">
                {ad.advertiser}
              </span>
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 fill-current" />
            </div>
            <div className="flex items-center gap-1 text-[10px] text-amber-300">
              <div className="flex items-center">
                <Star className="w-3 h-3 fill-current text-amber-400" />
                <span className="font-bold ml-0.5">{ad.rating}</span>
              </div>
              <span>• {ad.sponsorName}</span>
            </div>
          </div>
        </div>

        {/* Headline & Body */}
        <div>
          <h4 className="text-xs font-bold text-white line-clamp-1 drop-shadow-md">
            {ad.headline}
          </h4>
          <p className="text-[11px] text-zinc-200 line-clamp-2 mt-0.5 drop-shadow-md">
            {ad.body}
          </p>
        </div>

        {/* Prominent Call to Action Button */}
        <div className="pt-1 flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              onToast?.(`✓ Opening advertiser link: ${ad.title}`);
              window.open('https://google.com', '_blank');
            }}
            className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-[#fe2c55] to-amber-400 hover:brightness-110 text-white font-black text-xs shadow-xl flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer border border-white/20"
          >
            <span>{ad.callToAction}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          {/* Reward pill indicator */}
          <div className="px-2.5 py-2 rounded-xl bg-black/60 backdrop-blur-md border border-amber-400/50 flex items-center gap-1 text-[11px] font-mono font-black text-amber-300 shadow-md">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span>+5 COINS</span>
          </div>
        </div>

        {/* Watch Progress bar */}
        <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden mt-1">
          <div 
            className="h-full bg-gradient-to-r from-amber-400 to-[#fe2c55] transition-all duration-300"
            style={{ width: `${watchProgress}%` }}
          />
        </div>
      </div>

      {/* Right Side Engagement Icons */}
      <div className="absolute bottom-20 right-2 z-20 flex flex-col items-center gap-4 pointer-events-auto">
        {/* Like Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => {
              setIsLiked(!isLiked);
              setLikesCount(prev => isLiked ? prev - 1 : prev + 1);
            }}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white active:scale-75 transition-transform"
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : 'text-white'}`} />
          </button>
          <span className="text-[10px] font-bold text-white mt-1">{likesCount}</span>
        </div>

        {/* Comment Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => onToast?.('Comments for this sponsored ad')}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white active:scale-75 transition-transform"
          >
            <MessageCircle className="w-5 h-5 text-white" />
          </button>
          <span className="text-[10px] font-bold text-white mt-1">84</span>
        </div>

        {/* Share Button */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => {
              navigator.clipboard?.writeText(window.location.href);
              onToast?.('Sponsored ad link copied!');
            }}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white active:scale-75 transition-transform"
          >
            <Share2 className="w-5 h-5 text-white" />
          </button>
          <span className="text-[10px] font-bold text-white mt-1">Share</span>
        </div>
      </div>
    </div>
  );
};
