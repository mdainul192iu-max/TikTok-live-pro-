import React, { useState, useEffect } from 'react';
import { 
  X, 
  Mail, 
  ChevronDown, 
  Check, 
  Search,
  HelpCircle,
  ArrowLeft,
  Shield,
  Lock,
  Globe,
  Bell,
  Camera,
  Mic,
  Folder,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { UserAccount, AppLanguage } from '../types';

interface CountryItem {
  name: string;
  code: string;
  flag: string;
  iso: string;
}

const COUNTRIES: CountryItem[] = [
  { name: 'Bangladesh', code: '+880', flag: '🇧🇩', iso: 'BD' },
  { name: 'United States', code: '+1', flag: '🇺🇸', iso: 'US' },
  { name: 'India', code: '+91', flag: '🇮🇳', iso: 'IN' },
  { name: 'Pakistan', code: '+92', flag: '🇵🇰', iso: 'PK' },
  { name: 'United Kingdom', code: '+44', flag: '🇬🇧', iso: 'GB' },
  { name: 'Saudi Arabia', code: '+966', flag: '🇸🇦', iso: 'SA' },
  { name: 'United Arab Emirates', code: '+971', flag: '🇦🇪', iso: 'AE' },
  { name: 'Malaysia', code: '+60', flag: '🇲🇾', iso: 'MY' },
  { name: 'Canada', code: '+1', flag: '🇨🇦', iso: 'CA' },
  { name: 'Australia', code: '+61', flag: '🇦🇺', iso: 'AU' },
  { name: 'Germany', code: '+49', flag: '🇩🇪', iso: 'DE' },
  { name: 'France', code: '+33', flag: '🇫🇷', iso: 'FR' },
  { name: 'Italy', code: '+39', flag: '🇮🇹', iso: 'IT' },
  { name: 'Brazil', code: '+55', flag: '🇧🇷', iso: 'BR' },
  { name: 'Singapore', code: '+65', flag: '🇸🇬', iso: 'SG' },
  { name: 'Qatar', code: '+974', flag: '🇶🇦', iso: 'QA' },
  { name: 'Kuwait', code: '+965', flag: '🇰🇼', iso: 'KW' },
  { name: 'Oman', code: '+968', flag: '🇴🇲', iso: 'OM' },
  { name: 'Indonesia', code: '+62', flag: '🇮🇩', iso: 'ID' },
  { name: 'Turkey', code: '+90', flag: '🇹🇷', iso: 'TR' },
];

export type AuthStep = 
  | 'main' 
  | 'facebook_auth' 
  | 'google_auth' 
  | 'phone_otp' 
  | 'email_input' 
  | 'email_otp' 
  | 'permissions';

export const detectUserCountry = (): CountryItem => {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (tz.includes('Dhaka')) return COUNTRIES.find(c => c.iso === 'BD') || COUNTRIES[0];
    if (tz.includes('New_York') || tz.includes('Los_Angeles') || tz.includes('Chicago')) return COUNTRIES.find(c => c.iso === 'US') || COUNTRIES[1];
    if (tz.includes('Kolkata') || tz.includes('Calcutta')) return COUNTRIES.find(c => c.iso === 'IN') || COUNTRIES[2];
    if (tz.includes('Karachi')) return COUNTRIES.find(c => c.iso === 'PK') || COUNTRIES[3];
    if (tz.includes('London')) return COUNTRIES.find(c => c.iso === 'GB') || COUNTRIES[4];
    if (tz.includes('Riyadh')) return COUNTRIES.find(c => c.iso === 'SA') || COUNTRIES[5];
    if (tz.includes('Dubai')) return COUNTRIES.find(c => c.iso === 'AE') || COUNTRIES[6];
    if (tz.includes('Kuala_Lumpur')) return COUNTRIES.find(c => c.iso === 'MY') || COUNTRIES[7];
    if (tz.includes('Toronto') || tz.includes('Vancouver')) return COUNTRIES.find(c => c.iso === 'CA') || COUNTRIES[8];
    if (tz.includes('Sydney') || tz.includes('Melbourne')) return COUNTRIES.find(c => c.iso === 'AU') || COUNTRIES[9];
    if (tz.includes('Berlin')) return COUNTRIES.find(c => c.iso === 'DE') || COUNTRIES[10];
    if (tz.includes('Paris')) return COUNTRIES.find(c => c.iso === 'FR') || COUNTRIES[11];
    if (tz.includes('Rome')) return COUNTRIES.find(c => c.iso === 'IT') || COUNTRIES[12];
    if (tz.includes('Sao_Paulo')) return COUNTRIES.find(c => c.iso === 'BR') || COUNTRIES[13];
    if (tz.includes('Singapore')) return COUNTRIES.find(c => c.iso === 'SG') || COUNTRIES[14];
    if (tz.includes('Qatar')) return COUNTRIES.find(c => c.iso === 'QA') || COUNTRIES[15];
    if (tz.includes('Kuwait')) return COUNTRIES.find(c => c.iso === 'KW') || COUNTRIES[16];
    if (tz.includes('Muscat')) return COUNTRIES.find(c => c.iso === 'OM') || COUNTRIES[17];
    if (tz.includes('Jakarta')) return COUNTRIES.find(c => c.iso === 'ID') || COUNTRIES[18];
    if (tz.includes('Istanbul')) return COUNTRIES.find(c => c.iso === 'TR') || COUNTRIES[19];
    const navLang = navigator.language || '';
    if (navLang.includes('BD') || navLang.includes('bn')) return COUNTRIES.find(c => c.iso === 'BD') || COUNTRIES[0];
    if (navLang.includes('US')) return COUNTRIES.find(c => c.iso === 'US') || COUNTRIES[1];
    if (navLang.includes('IN') || navLang.includes('hi')) return COUNTRIES.find(c => c.iso === 'IN') || COUNTRIES[2];
    if (navLang.includes('GB')) return COUNTRIES.find(c => c.iso === 'GB') || COUNTRIES[4];
  } catch {}
  return COUNTRIES[0];
};

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserAccount) => void;
  language: AppLanguage;
  initialMode?: 'signup' | 'login';
  initialCountry?: CountryItem;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  language,
  initialMode = 'signup',
  initialCountry,
}) => {
  const [authMode, setAuthMode] = useState<'signup' | 'login'>(initialMode);
  const [step, setStep] = useState<AuthStep>('main');
  
  // Country & phone state with automatic country detection
  const [selectedCountry, setSelectedCountry] = useState<CountryItem>(() => initialCountry || detectUserCountry());
  const [showCountryPicker, setShowCountryPicker] = useState<boolean>(false);
  const [countrySearch, setCountrySearch] = useState<string>('');
  const [phoneNumber, setPhoneNumber] = useState<string>('');

  // Email & username signup state
  const [emailUsername, setEmailUsername] = useState<string>('');
  const [emailAddress, setEmailAddress] = useState<string>('');

  // OTP state
  const [phoneOtp, setPhoneOtp] = useState<string[]>(['', '', '', '', '', '']);
  const [emailOtp, setEmailOtp] = useState<string[]>(['', '', '', '', '', '']);
  const [otpTimer, setOtpTimer] = useState<number>(59);
  const [showSmsBanner, setShowSmsBanner] = useState<boolean>(false);
  const [showMailBanner, setShowMailBanner] = useState<boolean>(false);

  // Staged User pending permissions
  const [pendingUser, setPendingUser] = useState<UserAccount | null>(null);

  // Reset state when opening & auto-detect country if not manually provided
  useEffect(() => {
    if (isOpen) {
      setStep('main');
      setPhoneOtp(['', '', '', '', '', '']);
      setEmailOtp(['', '', '', '', '', '']);
      setShowSmsBanner(false);
      setShowMailBanner(false);

      if (initialCountry) {
        setSelectedCountry(initialCountry);
      } else {
        try {
          const saved = localStorage.getItem('tiktok_selected_country');
          if (saved) {
            const found = COUNTRIES.find((c) => c.iso === saved || c.code === saved);
            if (found) {
              setSelectedCountry(found);
              return;
            }
          }
        } catch {}
        setSelectedCountry(detectUserCountry());
      }
    }
  }, [isOpen, initialCountry]);

  // Countdown timer for OTP
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if ((step === 'phone_otp' || step === 'email_otp') && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [step, otpTimer]);

  if (!isOpen) return null;

  // 1. Submit Phone -> Go to Phone OTP
  const handleStartPhoneAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim()) return;

    const fullPhone = `${selectedCountry.code} ${phoneNumber.trim()}`;
    const randomUid = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      uid: randomUid,
      name: `User_${phoneNumber.slice(-4)}`,
      handle: `user_${phoneNumber.slice(-4)}`,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      authMethod: 'phone',
      identifier: fullPhone,
      countryCode: selectedCountry.iso,
      countryName: selectedCountry.name,
      phoneNumber: fullPhone,
      verified: true,
      followers: 142,
      following: 3,
      likesTotal: 840,
      bio: `TikTok Creator from ${selectedCountry.name} ${selectedCountry.flag}\nWelcome to my profile!`,
      createdAt: 'আজকে',
    };

    setPendingUser(newUser);
    setStep('phone_otp');
    setOtpTimer(59);

    // Trigger realistic SMS notification banner after 1.2 seconds
    setTimeout(() => {
      setShowSmsBanner(true);
    }, 1200);
  };

  // Auto-fill or type Phone OTP
  const handleFillPhoneOtp = (code: string) => {
    const digits = code.split('').slice(0, 6);
    setPhoneOtp(digits);
    setShowSmsBanner(false);
    // Proceed to permissions after short realistic verification delay
    setTimeout(() => {
      setStep('permissions');
    }, 600);
  };

  // 2. Submit Email & Username -> Go to Email OTP
  const handleStartEmailAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailAddress.trim()) return;

    const cleanUsername = (emailUsername.trim() || emailAddress.split('@')[0]).replace(/[^a-zA-Z0-9_]/g, '');
    const randomUid = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      uid: randomUid,
      name: cleanUsername.toUpperCase(),
      handle: cleanUsername.toLowerCase(),
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      authMethod: 'email',
      identifier: emailAddress.trim(),
      email: emailAddress.trim(),
      verified: true,
      followers: 210,
      following: 5,
      likesTotal: 1420,
      bio: `TikTok Star ✨ @${cleanUsername.toLowerCase()}\nMusic Lover & Content Creator`,
      createdAt: 'আজকে',
    };

    setPendingUser(newUser);
    setStep('email_otp');
    setOtpTimer(59);

    // Trigger realistic Gmail notification banner after 1.2 seconds
    setTimeout(() => {
      setShowMailBanner(true);
    }, 1200);
  };

  // Auto-fill or type Email OTP
  const handleFillEmailOtp = (code: string) => {
    const digits = code.split('').slice(0, 6);
    setEmailOtp(digits);
    setShowMailBanner(false);
    setTimeout(() => {
      setStep('permissions');
    }, 600);
  };

  // 3. Facebook Flow
  const handleStartFacebook = () => {
    const randomUid = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const fbUser: UserAccount = {
      id: `usr-fb-${Date.now()}`,
      uid: randomUid,
      name: 'Ainul Good',
      handle: 'ainul_good_fb',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      authMethod: 'facebook',
      identifier: 'facebook.ainulgood',
      email: 'ainulgood12345@gmail.com',
      verified: true,
      followers: 520,
      following: 12,
      likesTotal: 12800,
      bio: 'Facebook Verified Creator 🌟\nTikTok Live & Reels Official',
      createdAt: 'আজকে',
    };
    setPendingUser(fbUser);
    setStep('facebook_auth');
  };

  // 4. Google Flow
  const handleStartGoogle = () => {
    const randomUid = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const googleUser: UserAccount = {
      id: `usr-gg-${Date.now()}`,
      uid: randomUid,
      name: 'AINUL GOOD',
      handle: 'ainulgood',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      authMethod: 'google',
      identifier: 'ainulgood12345@gmail.com',
      email: 'ainulgood12345@gmail.com',
      verified: true,
      followers: 840,
      following: 8,
      likesTotal: 24500,
      bio: 'Google Verified Account 🚀\nMusic Producer & Video Artist\n> dhaka <',
      createdAt: 'আজকে',
    };
    setPendingUser(googleUser);
    setStep('google_auth');
  };

  // Final Step: Grant Permissions and Save User for Life
  const handleGrantPermissions = (type: 'always' | 'allowed') => {
    if (!pendingUser) return;
    try {
      localStorage.setItem('tiktok_logged_user', JSON.stringify(pendingUser));
      // Save to directory of all registered accounts
      const existing = localStorage.getItem('tiktok_all_users_db');
      const list = existing ? JSON.parse(existing) : [];
      if (!list.find((u: any) => u.id === pendingUser.id)) {
        localStorage.setItem('tiktok_all_users_db', JSON.stringify([pendingUser, ...list]));
      }
    } catch {}

    onSuccess(pendingUser);
    onClose();
  };

  const filteredCountries = COUNTRIES.filter((c) =>
    c.name.toLowerCase().includes(countrySearch.toLowerCase()) ||
    c.code.includes(countrySearch)
  );

  return (
    <div className="fixed inset-0 z-60 flex items-end justify-center bg-black/75 backdrop-blur-xs select-none pointer-events-auto animate-in fade-in duration-200">
      
      {/* 95% Height TikTok Bottom Sheet (User Request: ৯৫ পারসেন্ট সিট নিচ থেকে ওপেন হবে) */}
      <div className="relative w-full max-w-[460px] h-[95vh] bg-white text-zinc-900 rounded-t-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300">
        
        {/* ========================================================================= */}
        {/* VIEW 1: MAIN SIGN UP / LOG IN SCREEN (Screenshot_20261016-183513.png)     */}
        {/* ========================================================================= */}
        {step === 'main' && (
          <div className="flex-1 flex flex-col overflow-hidden bg-white">
            
            {/* Top Navigation Bar: Help (?) on Left, Close [X] on Right matching screenshot */}
            <div className="px-5 py-3.5 flex items-center justify-between border-b border-zinc-100 bg-white sticky top-0 z-20">
              <button
                type="button"
                onClick={() => {}}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800 transition-colors cursor-pointer"
                title="Help"
              >
                <HelpCircle className="w-5 h-5 stroke-[2]" />
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800 transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5 stroke-[2.4]" />
              </button>
            </div>

            {/* Scrollable Sheet Content */}
            <div className="flex-1 overflow-y-auto px-6 pt-2 pb-6 no-scrollbar">
              
              {/* Main Title (Screenshot: Sign up for TikTok) */}
              <div className="text-center my-6">
                <h2 className="text-2xl sm:text-3xl font-black text-zinc-900 tracking-tight">
                  {authMode === 'signup' ? 'Sign up for TikTok' : 'Log in to TikTok'}
                </h2>
              </div>

              {/* 1. Phone Number Input Option with All Country selector */}
              <form onSubmit={handleStartPhoneAuth} className="space-y-4 mb-4">
                <div className="flex items-center bg-[#f1f1f2] rounded-xl overflow-hidden px-3.5 py-1">
                  
                  {/* Left: Country Selector Dropdown */}
                  <button
                    type="button"
                    onClick={() => setShowCountryPicker(true)}
                    className="py-2.5 flex items-center gap-1.5 hover:opacity-80 transition-opacity cursor-pointer text-xs sm:text-sm font-bold text-zinc-900 shrink-0 pr-3 border-r border-zinc-300"
                  >
                    <span className="font-mono">{selectedCountry.iso} {selectedCountry.code}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-zinc-600 stroke-[2.5]" />
                  </button>

                  {/* Right: Phone Number Input */}
                  <input
                    type="tel"
                    autoFocus
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                    placeholder="Phone number"
                    className="flex-1 px-3 py-2.5 text-sm font-semibold text-zinc-900 placeholder-zinc-400 outline-none bg-transparent"
                  />
                </div>

                {/* Continue Button (Screenshot: red rounded-full) */}
                <button
                  type="submit"
                  disabled={phoneNumber.length < 5}
                  className="w-full py-3.5 bg-[#fe2c55] disabled:bg-[#fe2c55]/40 text-white font-extrabold text-sm sm:text-base rounded-full shadow-md hover:brightness-105 active:scale-98 transition-all cursor-pointer"
                >
                  Continue
                </button>
              </form>

              {/* Divider: ── or ── */}
              <div className="relative my-4 flex items-center justify-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-zinc-200" />
                </div>
                <span className="relative bg-white px-4 text-xs font-bold text-zinc-400">
                  or
                </span>
              </div>

              {/* Vertical Continue Buttons with light grey background bg-[#f1f1f2] */}
              <div className="space-y-3">
                
                {/* 1. Continue with Email */}
                <button
                  type="button"
                  onClick={() => setStep('email_input')}
                  className="w-full py-3.5 px-4 bg-[#f1f1f2] hover:bg-zinc-200/70 rounded-xl active:scale-98 flex items-center justify-center relative text-xs sm:text-sm font-bold text-zinc-900 transition-all cursor-pointer"
                >
                  <Mail className="w-5 h-5 text-zinc-800 stroke-[2] absolute left-4" />
                  <span>Continue with Email</span>
                </button>

                {/* 2. Continue with Facebook */}
                <button
                  type="button"
                  onClick={handleStartFacebook}
                  className="w-full py-3.5 px-4 bg-[#f1f1f2] hover:bg-zinc-200/70 rounded-xl active:scale-98 flex items-center justify-center relative text-xs sm:text-sm font-bold text-zinc-900 transition-all cursor-pointer"
                >
                  <div className="w-5 h-5 rounded-full bg-[#1877f2] text-white flex items-center justify-center font-black text-xs absolute left-4">
                    f
                  </div>
                  <span>Continue with Facebook</span>
                </button>

                {/* 3. Continue with Google */}
                <button
                  type="button"
                  onClick={handleStartGoogle}
                  className="w-full py-3.5 px-4 bg-[#f1f1f2] hover:bg-zinc-200/70 rounded-xl active:scale-98 flex items-center justify-center relative text-xs sm:text-sm font-bold text-zinc-900 transition-all cursor-pointer"
                >
                  <svg className="w-5 h-5 absolute left-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Continue with Google</span>
                </button>
              </div>

              {/* Legal Disclaimer Text exactly as in Screenshot_20261016-183513.png */}
              <div className="mt-8 text-center px-2">
                <p className="text-[11px] text-zinc-500 font-normal leading-relaxed">
                  By continuing with an account located in <span className="text-blue-600 font-medium">Bangladesh</span>, you agree to our <span className="text-blue-600 font-medium">Terms of Service</span> and acknowledge that you have read our <span className="text-blue-600 font-medium">Privacy Policy</span>.
                </p>
              </div>
            </div>

            {/* Persistent Bottom Bar (Screenshot: Already have an account? Log in) */}
            <div className="p-4 bg-[#f8f8f9] border-t border-zinc-200 text-center">
              {authMode === 'signup' ? (
                <p className="text-xs sm:text-sm text-zinc-700 font-medium">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setAuthMode('login')}
                    className="font-bold text-[#fe2c55] hover:underline cursor-pointer ml-1"
                  >
                    Log in
                  </button>
                </p>
              ) : (
                <p className="text-xs sm:text-sm text-zinc-700 font-medium">
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setAuthMode('signup')}
                    className="font-bold text-[#fe2c55] hover:underline cursor-pointer ml-1"
                  >
                    Sign up
                  </button>
                </p>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: FACEBOOK IN-BROWSER / CHROME AUTHORIZATION SCREEN                 */}
        {/* ========================================================================= */}
        {step === 'facebook_auth' && (
          <div className="flex-1 flex flex-col bg-white overflow-hidden animate-in fade-in duration-200">
            {/* Chrome In-App Browser Header */}
            <div className="px-4 py-2.5 bg-[#f0f2f5] border-b border-zinc-200 flex items-center justify-between text-xs text-zinc-700">
              <div className="flex items-center gap-2">
                <button 
                  type="button" 
                  onClick={() => setStep('main')}
                  className="hover:bg-zinc-200 p-1 rounded-full text-zinc-600"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                </button>
                <div className="flex items-center gap-1.5 px-3 py-1 bg-white border border-zinc-200 rounded-full font-mono text-[11px] text-zinc-600">
                  <Lock className="w-3 h-3 text-emerald-600" />
                  <span>m.facebook.com/dialog/oauth</span>
                </div>
              </div>
              <button onClick={() => setStep('main')} className="text-zinc-500 hover:text-black">
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* Facebook Content */}
            <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center justify-center text-center">
              <div className="w-14 h-14 rounded-full bg-[#1877f2] text-white flex items-center justify-center font-black text-3xl shadow-md mb-4">
                f
              </div>

              <h3 className="font-extrabold text-lg text-zinc-900 mb-1">
                Log in with Facebook
              </h3>
              <p className="text-xs text-zinc-500 mb-6 max-w-xs">
                TikTok is requesting access to your name, profile picture, and email address.
              </p>

              {/* User Account Card */}
              <div className="w-full max-w-sm p-4 rounded-2xl border border-zinc-200 bg-zinc-50 flex items-center gap-3.5 mb-6 text-left">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
                  alt=""
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#1877f2]"
                />
                <div>
                  <h4 className="font-black text-sm text-zinc-900">Ainul Good</h4>
                  <p className="text-xs text-zinc-500">ainulgood12345@gmail.com</p>
                  <span className="text-[10px] text-emerald-600 font-bold">Active on Facebook</span>
                </div>
              </div>

              {/* Continue Button as Ainul */}
              <button
                type="button"
                onClick={() => setStep('permissions')}
                className="w-full max-w-sm py-3.5 rounded-xl bg-[#1877f2] hover:bg-[#166fe5] text-white font-extrabold text-sm shadow-md active:scale-98 transition-all cursor-pointer mb-3"
              >
                Continue as Ainul
              </button>

              <button
                type="button"
                onClick={() => setStep('main')}
                className="w-full max-w-sm py-2.5 text-xs font-bold text-zinc-500 hover:text-zinc-900"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: GOOGLE / GMAIL ACCOUNT CHOOSER SCREEN                            */}
        {/* ========================================================================= */}
        {step === 'google_auth' && (
          <div className="flex-1 flex flex-col bg-white overflow-hidden animate-in fade-in duration-200">
            {/* Google Header */}
            <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span className="font-bold text-sm text-zinc-700">Sign in with Google</span>
              </div>
              <button onClick={() => setStep('main')} className="text-zinc-400 hover:text-black">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-between">
              <div>
                <h3 className="font-black text-xl text-zinc-900 mb-1">
                  Choose an account
                </h3>
                <p className="text-xs text-zinc-500 mb-6">
                  to continue to <span className="font-bold text-zinc-800">TikTok</span>
                </p>

                {/* Google Account Row */}
                <div 
                  onClick={() => setStep('permissions')}
                  className="p-3.5 rounded-2xl border border-zinc-200 hover:border-blue-400 hover:bg-blue-50/30 flex items-center justify-between cursor-pointer transition-all shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
                      alt=""
                      className="w-10 h-10 rounded-full object-cover border border-zinc-200"
                    />
                    <div>
                      <h4 className="font-extrabold text-sm text-zinc-900">AINUL GOOD</h4>
                      <p className="text-xs text-zinc-500">ainulgood12345@gmail.com</p>
                    </div>
                  </div>
                  <Check className="w-5 h-5 text-blue-600 stroke-[2.5]" />
                </div>

                <div className="mt-6 text-xs text-zinc-500 leading-relaxed">
                  To continue, Google will share your name, email address, language preference, and profile picture with TikTok.
                </div>
              </div>

              {/* Google Blue Continue Button */}
              <div className="space-y-2 pt-6">
                <button
                  type="button"
                  onClick={() => setStep('permissions')}
                  className="w-full py-3.5 rounded-full bg-[#1a73e8] hover:bg-[#1557b0] text-white font-extrabold text-sm shadow-md active:scale-98 transition-all cursor-pointer"
                >
                  Continue
                </button>
                <button
                  type="button"
                  onClick={() => setStep('main')}
                  className="w-full py-2.5 text-xs font-bold text-zinc-500 hover:text-zinc-900"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: PHONE NUMBER 6-DIGIT OTP VERIFICATION SCREEN                     */}
        {/* ========================================================================= */}
        {step === 'phone_otp' && (
          <div className="flex-1 flex flex-col bg-white overflow-hidden relative">
            
            {/* Simulated Incoming SMS Notification Banner at Top */}
            {showSmsBanner && (
              <div className="absolute top-2 inset-x-3 z-50 bg-zinc-900/95 text-white p-3 rounded-2xl shadow-2xl flex items-center justify-between animate-in slide-in-from-top-4 duration-300 border border-white/20">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white shrink-0 font-bold text-xs">
                    SMS
                  </div>
                  <div className="min-w-0 flex-1 text-left">
                    <p className="text-[11px] font-bold text-zinc-200">Messages • Just now</p>
                    <p className="text-xs font-black truncate text-white">TikTok: 482910 is your code.</p>
                  </div>
                </div>

                {/* Auto-fill Button */}
                <button
                  type="button"
                  onClick={() => handleFillPhoneOtp('482910')}
                  className="px-3 py-1.5 bg-[#fe2c55] hover:bg-rose-600 text-white font-black text-xs rounded-full shadow-md active:scale-95 transition-transform cursor-pointer shrink-0 ml-2"
                >
                  ⚡ Auto-fill
                </button>
              </div>
            )}

            {/* Header */}
            <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100">
              <button 
                type="button"
                onClick={() => setStep('main')}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
              </button>
              <h3 className="font-extrabold text-sm text-zinc-900">Phone Verification</h3>
              <button className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-600">
                <HelpCircle className="w-5 h-5" />
              </button>
            </div>

            {/* OTP Content in English */}
            <div className="flex-1 overflow-y-auto px-6 pt-6 pb-4 flex flex-col justify-between">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 mb-2">
                  Enter 6-digit code
                </h2>
                <p className="text-xs text-zinc-500 font-medium leading-relaxed">
                  Your verification code was sent to <span className="font-bold text-zinc-900">{selectedCountry.code} {phoneNumber}</span>.
                </p>

                {/* 6 Digit Input Boxes */}
                <div className="grid grid-cols-6 gap-2 my-8">
                  {phoneOtp.map((digit, idx) => (
                    <input
                      key={idx}
                      type="text"
                      maxLength={1}
                      autoFocus={idx === 0}
                      value={digit}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        const copy = [...phoneOtp];
                        copy[idx] = val;
                        setPhoneOtp(copy);
                        if (val && idx < 5) {
                          const nextInput = document.getElementById(`phone-otp-${idx + 1}`);
                          nextInput?.focus();
                        }
                        if (copy.every((d) => d !== '')) {
                          handleFillPhoneOtp(copy.join(''));
                        }
                      }}
                      id={`phone-otp-${idx}`}
                      className="w-full aspect-square text-center text-2xl font-black bg-[#f1f1f2] rounded-xl outline-none focus:ring-2 focus:ring-[#fe2c55] text-zinc-900"
                    />
                  ))}
                </div>

                {/* Simulated Auto-Fill trigger chip */}
                <div className="flex justify-center mb-6">
                  <button
                    type="button"
                    onClick={() => handleFillPhoneOtp('482910')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-rose-50 border border-rose-200 text-[#fe2c55] text-xs font-bold hover:bg-rose-100 cursor-pointer shadow-xs active:scale-95 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-detect code (482910)</span>
                  </button>
                </div>
              </div>

              {/* Resend Code Timer */}
              <div className="text-center pb-4">
                <p className="text-xs text-zinc-400 font-medium">
                  {otpTimer > 0 ? (
                    `Resend code in ${otpTimer}s`
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setOtpTimer(59);
                        setShowSmsBanner(true);
                      }}
                      className="font-bold text-[#fe2c55] hover:underline cursor-pointer"
                    >
                      Resend code
                    </button>
                  )}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 5: EMAIL & USERNAME SIGNUP SCREEN                                    */}
        {/* ========================================================================= */}
        {step === 'email_input' && (
          <div className="flex-1 flex flex-col bg-white overflow-hidden">
            <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100">
              <button 
                type="button"
                onClick={() => setStep('main')}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
              </button>
              <h3 className="font-extrabold text-sm text-zinc-900">Email Sign up</h3>
              <div className="w-8" />
            </div>

            <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-between">
              <form onSubmit={handleStartEmailAuth} className="space-y-4">
                <div className="mb-2">
                  <h2 className="text-2xl font-black text-zinc-900 mb-1">
                    Sign up with Email
                  </h2>
                  <p className="text-xs text-zinc-500">
                    Create your unique TikTok username and provide your email.
                  </p>
                </div>

                {/* 1. Username field */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-zinc-700">Username</label>
                  <div className="flex items-center bg-[#f1f1f2] rounded-xl px-3.5 py-3">
                    <span className="text-zinc-400 font-bold mr-1">@</span>
                    <input
                      type="text"
                      autoFocus
                      value={emailUsername}
                      onChange={(e) => setEmailUsername(e.target.value)}
                      placeholder="e.g. star_creator"
                      className="w-full text-sm font-semibold text-zinc-900 placeholder-zinc-400 outline-none bg-transparent"
                    />
                  </div>
                </div>

                {/* 2. Email field */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-zinc-700">Email Address</label>
                  <div className="flex items-center bg-[#f1f1f2] rounded-xl px-3.5 py-3">
                    <Mail className="w-4 h-4 text-zinc-400 mr-2 shrink-0" />
                    <input
                      type="email"
                      value={emailAddress}
                      onChange={(e) => setEmailAddress(e.target.value)}
                      placeholder="e.g. ainulgood12345@gmail.com"
                      className="w-full text-sm font-semibold text-zinc-900 placeholder-zinc-400 outline-none bg-transparent"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={!emailAddress.includes('@')}
                  className="w-full py-3.5 rounded-full bg-[#fe2c55] disabled:bg-[#fe2c55]/40 text-white font-extrabold text-sm shadow-md hover:brightness-105 active:scale-98 transition-all cursor-pointer mt-4"
                >
                  Continue
                </button>
              </form>

              <div className="text-center text-[11px] text-zinc-400 pb-2">
                We'll send a 6-digit verification code to your email.
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 6: EMAIL 6-DIGIT OTP SCREEN                                          */}
        {/* ========================================================================= */}
        {step === 'email_otp' && (
          <div className="flex-1 flex flex-col bg-white overflow-hidden relative">
            {/* Simulated Email Notification Banner */}
            {showMailBanner && (
              <div className="absolute top-2 inset-x-3 z-50 bg-zinc-900/95 text-white p-3 rounded-2xl shadow-2xl flex items-center justify-between animate-in slide-in-from-top-4 duration-300 border border-white/20">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-8 h-8 rounded-full bg-rose-600 flex items-center justify-center text-white shrink-0 font-bold text-xs">
                    M
                  </div>
                  <div className="min-w-0 flex-1 text-left">
                    <p className="text-[11px] font-bold text-zinc-200">Gmail • Just now</p>
                    <p className="text-xs font-black truncate text-white">TikTok: 739214 is your email code.</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleFillEmailOtp('739214')}
                  className="px-3 py-1.5 bg-[#fe2c55] hover:bg-rose-600 text-white font-black text-xs rounded-full shadow-md active:scale-95 transition-transform cursor-pointer shrink-0 ml-2"
                >
                  ⚡ Auto-fill
                </button>
              </div>
            )}

            <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100">
              <button 
                type="button"
                onClick={() => setStep('email_input')}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
              </button>
              <h3 className="font-extrabold text-sm text-zinc-900">Email Verification</h3>
              <div className="w-8" />
            </div>

            <div className="flex-1 overflow-y-auto px-6 pt-6 pb-4 flex flex-col justify-between">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 mb-2">
                  Enter 6-digit code
                </h2>
                <p className="text-xs text-zinc-500 font-medium leading-relaxed">
                  Enter the code sent to <span className="font-bold text-zinc-900">{emailAddress}</span>.
                </p>

                {/* 6 Digit Input Boxes */}
                <div className="grid grid-cols-6 gap-2 my-8">
                  {emailOtp.map((digit, idx) => (
                    <input
                      key={idx}
                      type="text"
                      maxLength={1}
                      autoFocus={idx === 0}
                      value={digit}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        const copy = [...emailOtp];
                        copy[idx] = val;
                        setEmailOtp(copy);
                        if (val && idx < 5) {
                          const nextInput = document.getElementById(`email-otp-${idx + 1}`);
                          nextInput?.focus();
                        }
                        if (copy.every((d) => d !== '')) {
                          handleFillEmailOtp(copy.join(''));
                        }
                      }}
                      id={`email-otp-${idx}`}
                      className="w-full aspect-square text-center text-2xl font-black bg-[#f1f1f2] rounded-xl outline-none focus:ring-2 focus:ring-[#fe2c55] text-zinc-900"
                    />
                  ))}
                </div>

                {/* Auto-fill trigger chip */}
                <div className="flex justify-center mb-6">
                  <button
                    type="button"
                    onClick={() => handleFillEmailOtp('739214')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-rose-50 border border-rose-200 text-[#fe2c55] text-xs font-bold hover:bg-rose-100 cursor-pointer shadow-xs active:scale-95 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-fill email code (739214)</span>
                  </button>
                </div>
              </div>

              <div className="text-center pb-4">
                <p className="text-xs text-zinc-400 font-medium">
                  {otpTimer > 0 ? (
                    `Resend code in ${otpTimer}s`
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setOtpTimer(59);
                        setShowMailBanner(true);
                      }}
                      className="font-bold text-[#fe2c55] hover:underline cursor-pointer"
                    >
                      Resend code
                    </button>
                  )}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 7: ANDROID SYSTEM PERMISSIONS DIALOG (Allowed / Always allowed)       */}
        {/* ========================================================================= */}
        {step === 'permissions' && (
          <div className="flex-1 flex flex-col items-center justify-center p-6 bg-zinc-900/40 backdrop-blur-md animate-in fade-in duration-200">
            <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-zinc-200 flex flex-col items-center text-center">
              
              {/* App Icon */}
              <div className="w-14 h-14 rounded-2xl bg-black text-white flex items-center justify-center shadow-lg mb-4 relative">
                <span className="text-2xl font-black tracking-tighter">TikTok</span>
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#25f4ee]" />
              </div>

              {/* Permission Title */}
              <h3 className="font-black text-base text-zinc-900 mb-2">
                Allow TikTok to access photos, media, files, camera and microphone on your device?
              </h3>
              <p className="text-xs text-zinc-500 mb-6">
                This enables uploading reels, camera live streaming, video calling, and saving offline video files.
              </p>

              {/* Android Permission Options: Allowed / Always allowed / Don't allow */}
              <div className="w-full space-y-2.5">
                
                {/* 1. Always allowed */}
                <button
                  type="button"
                  onClick={() => handleGrantPermissions('always')}
                  className="w-full py-3.5 rounded-2xl bg-[#fe2c55] hover:brightness-110 text-white font-extrabold text-sm shadow-md active:scale-98 transition-all cursor-pointer"
                >
                  Always allowed
                </button>

                {/* 2. Allowed */}
                <button
                  type="button"
                  onClick={() => handleGrantPermissions('allowed')}
                  className="w-full py-3.5 rounded-2xl bg-zinc-100 hover:bg-zinc-200 text-zinc-900 font-extrabold text-sm active:scale-98 transition-all cursor-pointer"
                >
                  Allowed
                </button>

                {/* 3. Don't allow */}
                <button
                  type="button"
                  onClick={() => setStep('main')}
                  className="w-full py-2.5 text-xs font-bold text-zinc-400 hover:text-zinc-700 cursor-pointer"
                >
                  Don't allow
                </button>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Country Select Dropdown Picker Sheet */}
      {showCountryPicker && (
        <div className="fixed inset-0 z-70 bg-black/60 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-sm h-[70vh] bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="p-4 border-b border-zinc-200 flex items-center justify-between">
              <h3 className="font-black text-sm text-zinc-900">Select Country / Region</h3>
              <button
                type="button"
                onClick={() => setShowCountryPicker(false)}
                className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Country search input */}
            <div className="p-3 border-b border-zinc-100">
              <div className="relative">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={countrySearch}
                  onChange={(e) => setCountrySearch(e.target.value)}
                  placeholder="Search country or code..."
                  className="w-full pl-9 pr-3 py-2 bg-zinc-100 rounded-xl text-xs font-semibold outline-none"
                />
              </div>
            </div>

            {/* Countries list */}
            <div className="flex-1 overflow-y-auto divide-y divide-zinc-100 p-2 no-scrollbar">
              {filteredCountries.map((c) => (
                <button
                  key={`${c.iso}-${c.code}`}
                  type="button"
                  onClick={() => {
                    setSelectedCountry(c);
                    setShowCountryPicker(false);
                    setCountrySearch('');
                  }}
                  className="w-full p-3 rounded-xl hover:bg-zinc-50 flex items-center justify-between text-xs font-bold text-zinc-900 cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{c.flag}</span>
                    <span>{c.name}</span>
                  </div>
                  <span className="font-mono text-zinc-500 font-bold">{c.code}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
