import React from 'react';
import { 
  X, 
  Flame, 
  Sparkles, 
  TrendingUp, 
  Users, 
  Eye, 
  Heart, 
  Repeat, 
  Share2, 
  ShieldCheck, 
  ChevronRight, 
  Zap,
  Activity,
  Layers,
  Clock,
  BarChart2
} from 'lucide-react';
import { VideoReel, AppLanguage } from '../types';

interface AlgorithmInsightsModalProps {
  isOpen: boolean;
  onClose: () => void;
  reel: VideoReel;
  onAdvanceTier?: (reel: VideoReel) => void;
  language: AppLanguage;
}

export const AlgorithmInsightsModal: React.FC<AlgorithmInsightsModalProps> = ({
  isOpen,
  onClose,
  reel,
  onAdvanceTier,
  language,
}) => {
  if (!isOpen) return null;

  const tier = reel.algorithmTier || 'tier_200';
  const reach = reel.algorithmReach || (tier === 'tier_200' || tier === 'tier_50' ? 200 : tier === 'tier_2000' || tier === 'tier_1000' ? 2000 : 20000);

  const getTierStepNumber = () => {
    switch (tier) {
      case 'tier_50':
      case 'tier_200': 
        return 1;
      case 'tier_1000':
      case 'tier_2000': 
        return 2;
      case 'tier_10000':
      case 'tier_20000': 
        return 3;
      case 'tier_viral': 
        return 4;
      default: 
        return 1;
    }
  };

  const step = getTierStepNumber();
  const completionRate = reel.completionRate ? Math.round(reel.completionRate * 100) : 82;
  const loopRate = reel.loopCount || 1.8;

  return (
    <div className="fixed inset-0 z-[80] bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl text-white space-y-4 max-h-[90vh] overflow-y-auto no-scrollbar animate-in slide-in-from-bottom duration-250">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-850 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#fe2c55] via-amber-400 to-[#25f4ee] flex items-center justify-center text-black shadow-lg">
              <Zap className="w-5 h-5 fill-black stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base leading-tight">
                {language === 'bn' ? 'TikTok এআই অ্যালগরিদম ও ভাইরাল লুপ' : 'TikTok AI Algorithm Viral Loop'}
              </h3>
              <p className="text-[10px] text-zinc-400 font-medium">
                {language === 'bn' ? '২০০ জন ➔ ২,০০০ জন ➔ ২০,০০০ জন ➔ ভাইরাল ফিড' : '200 ➔ 2K ➔ 20K ➔ Global Viral Loop'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* Current Active Stage Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 border border-zinc-800 space-y-2 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black text-[#25f4ee] flex items-center gap-1.5 uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#25f4ee] animate-ping" />
              {language === 'bn' ? 'বর্তমান পর্যায়' : 'Current Stage'}: Phase {step}
            </span>
            <span className="text-xs font-black text-white px-2.5 py-0.5 rounded-lg bg-black/60 border border-white/10 font-mono">
              {reach.toLocaleString()} {language === 'bn' ? 'জন দর্শক' : 'Reach'}
            </span>
          </div>

          <h4 className="font-black text-base text-white">
            {step === 1 && (language === 'bn' ? '🎯 ১ম ধাপ: ২০০ জন প্রাথমিক টেস্ট গ্রুপ' : 'Stage 1: 200 Users Test Cohort')}
            {step === 2 && (language === 'bn' ? '🚀 ২য় ধাপ: ২,০০০ জন অডিয়েন্স সম্প্রসারণ' : 'Stage 2: 2,000 Users Expanded Batch')}
            {step === 3 && (language === 'bn' ? '🔥 ৩য় ধাপ: ২০,০০০ জন ভাইরাল ফর ইউ পুশ' : 'Stage 3: 20,000 Users National Trending')}
            {step === 4 && (language === 'bn' ? '🌟 ৪র্থ ধাপ: গ্লোবাল মেগা ভাইরাল লুপ' : 'Stage 4: Global Mega Viral Loop')}
          </h4>

          <p className="text-xs text-zinc-300 leading-relaxed font-medium">
            {reel.algorithmStatusText || (
              step === 1
                ? 'ভিডিওটি আপলোড করার পর অ্যালগরিদম প্রথমে ২০০ জনের একটি অ্যাক্টিভ টেস্ট গ্রুপের কাছে পাঠিয়েছে। এখানে ওয়াচ-টাইম ৬০% এর বেশি আসলে ভিডিও স্বয়ংক্রিয়ভাবে পরবর্তী ধাপে পুশ হবে।'
                : step === 2
                ? 'টেস্ট গ্রুপে ওয়াচ-টাইম ৬০%+ এবং উচ্চ লাইক রেসপন্স আসায় অ্যালগরিদম ভিডিওটি ২,০০০ জন অডিয়েন্সের ফর ইউ পেজে পুশ করেছে।'
                : step === 3
                ? 'উচ্চ রি-ওয়াচ রেট এবং ব্যাপক শেয়ারের কারণে ভিডিওটি ২০,০০০ মানুষের ন্যাশনাল ট্রেন্ডিং ফিডে শীর্ষে স্থান করে নিয়েছে।'
                : 'গ্লোবাল ভাইরাল লুপ সক্রিয়! মিলিয়ন দর্শকের কাছে ভিডিওটি বিশ্বমানের টিকটক অ্যালগরিদমের মাধ্যমে পৌঁছে যাচ্ছে।'
            )}
          </p>
        </div>

        {/* 4-Step Pipeline Visualizer */}
        <div className="space-y-2 pt-1">
          <span className="text-[11px] font-black text-zinc-400 uppercase tracking-wider block">
            {language === 'bn' ? 'ক্রিয়েটর ভাইরাল লুপ মেকানিজম' : 'Creator Viral Loop Mechanism'}
          </span>

          <div className="space-y-2">
            {[
              { 
                lvl: 1, 
                title: language === 'bn' ? '১. ২০০ জন টেস্ট গ্রুপ (Test Cohort)' : '1. 200 Users Test Group',
                desc: language === 'bn' ? 'নতুন ক্রিয়েটরের ভিডিও প্রাথমিক ২০০ জনের কাছে পরিবেশন ও ওয়াচ-টাইম পর্যবেক্ষণ' : 'Initial 200 audience cohort to measure retention and watch-time',
                status: step >= 1 ? 'completed' : 'pending',
                badge: '২০০ জন',
              },
              { 
                lvl: 2, 
                title: language === 'bn' ? '২. ২,০০০ জন পুশ (Engagement Spike)' : '2. 2,000 Users Cohort Push',
                desc: language === 'bn' ? 'ওয়াচ-টাইম > ৬০% ও শেয়ার/লাইক রেট > ১৫% হলে ২,০০০ জনের ফিডে পুশ' : 'Triggered when watch-time > 60% and share/like ratio > 15%',
                status: step >= 2 ? 'completed' : step === 1 ? 'current' : 'pending',
                badge: '২,০০০ জন',
              },
              { 
                lvl: 3, 
                title: language === 'bn' ? '৩. ২০,০০০ জন পুশ (National Trending)' : '3. 20,000 Users Viral Push',
                desc: language === 'bn' ? 'উচ্চ কমপ্লিশন ও রি-লুপিংয়ে ২০,০০০ মানুষের ফর ইউ পেজে ট্রেন্ডিং' : 'High retention & completion rate unlocks 20K users FYP reach',
                status: step >= 3 ? 'completed' : step === 2 ? 'next' : 'pending',
                badge: '২০,০০০ জন',
              },
              { 
                lvl: 4, 
                title: language === 'bn' ? '৪. গ্লোবাল মেগা ভাইরাল লুপ (Viral Loop)' : '4. Global Mega Viral Loop',
                desc: language === 'bn' ? 'আন্তর্জাতিক ফর ইউ ফিডে সুপার ভাইরাল ও আনলিমিটেড অর্গানিক রিচ' : 'Global multi-regional viral explosion across all FYP feeds',
                status: step >= 4 ? 'completed' : 'locked',
                badge: 'সুপার ভাইরাল',
              },
            ].map((item) => (
              <div 
                key={item.lvl}
                className={`p-3 rounded-2xl border transition-all flex items-center justify-between ${
                  step === item.lvl 
                    ? 'bg-[#fe2c55]/15 border-[#fe2c55]/60 shadow-md shadow-rose-950/40' 
                    : step > item.lvl 
                    ? 'bg-zinc-900/60 border-emerald-500/30' 
                    : 'bg-zinc-900/30 border-zinc-800/50 opacity-60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${
                    step > item.lvl 
                      ? 'bg-emerald-500 text-black' 
                      : step === item.lvl 
                      ? 'bg-[#fe2c55] text-white shadow-md' 
                      : 'bg-zinc-800 text-zinc-500'
                  }`}>
                    {step > item.lvl ? '✓' : item.lvl}
                  </div>
                  <div>
                    <h5 className="font-extrabold text-xs text-white leading-tight">{item.title}</h5>
                    <p className="text-[10px] text-zinc-400">{item.desc}</p>
                  </div>
                </div>

                <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                  step === item.lvl 
                    ? 'bg-[#fe2c55] text-white' 
                    : step > item.lvl 
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-zinc-800 text-zinc-400'
                }`}>
                  {item.badge}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Live Engagement Signals Metrics */}
        <div className="grid grid-cols-4 gap-2 pt-1 text-center">
          <div className="p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800">
            <Eye className="w-3.5 h-3.5 text-sky-400 mx-auto mb-1" />
            <span className="text-xs font-black text-white block">{reel.viewsCount.toLocaleString()}</span>
            <span className="text-[9px] text-zinc-400 font-medium">ভিউয়ারস</span>
          </div>

          <div className="p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800">
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 mx-auto mb-1" />
            <span className="text-xs font-black text-white block">{reel.likesCount.toLocaleString()}</span>
            <span className="text-[9px] text-zinc-400 font-medium">লাইক</span>
          </div>

          <div className="p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800">
            <Clock className="w-3.5 h-3.5 text-emerald-400 mx-auto mb-1" />
            <span className="text-xs font-black text-emerald-400 block">{completionRate}%</span>
            <span className="text-[9px] text-zinc-400 font-medium">কমপ্লিশন রেট</span>
          </div>

          <div className="p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800">
            <Repeat className="w-3.5 h-3.5 text-amber-400 mx-auto mb-1" />
            <span className="text-xs font-black text-amber-400 block">{loopRate}x</span>
            <span className="text-[9px] text-zinc-400 font-medium">রি-ওয়াচ লুপ</span>
          </div>
        </div>

        {/* Real-Time Personalized Engine Tag */}
        <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-[#25f4ee]" />
            <span className="font-bold text-zinc-300">১০০% পারসোনালাইজড এআই টেস্ট ডিটেকশন</span>
          </div>
          <span className="text-[10px] font-black text-[#25f4ee] bg-cyan-950/80 px-2.5 py-0.5 rounded-full border border-cyan-500/30">
            ● সক্রিয়
          </span>
        </div>

        {/* Interactive Advance/Test Button */}
        {step < 4 && onAdvanceTier && (
          <button
            type="button"
            onClick={() => {
              onAdvanceTier(reel);
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#fe2c55] via-amber-500 to-[#25f4ee] hover:brightness-110 active:scale-98 text-black font-black text-xs sm:text-sm shadow-xl shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Sparkles className="w-4 h-4 fill-current" />
            <span>
              {step === 1 && (language === 'bn' ? '২০০ জনের ওয়াচ-টাইম রেসপন্স দিন (২,০০০ জনে পুশ)' : 'Trigger Good Watch-Time (Advance to 2,000)')}
              {step === 2 && (language === 'bn' ? 'উচ্চ শেয়ার রেসপন্স দিন (২০,০০০ জনে পুশ)' : 'Trigger Viral Response (Advance to 20,000)')}
              {step === 3 && (language === 'bn' ? 'গ্লোবাল মেগা ভাইরাল লুপে পুশ করুন' : 'Push to Global Mega Viral Loop')}
            </span>
            <ChevronRight className="w-4 h-4 stroke-[3]" />
          </button>
        )}
      </div>
    </div>
  );
};
