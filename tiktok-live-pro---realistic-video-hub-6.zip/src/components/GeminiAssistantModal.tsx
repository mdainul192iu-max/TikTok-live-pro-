import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  X, 
  Search, 
  Image as ImageIcon, 
  Video as VideoIcon, 
  Mic, 
  MicOff, 
  Send, 
  Volume2, 
  VolumeX, 
  Bot, 
  HelpCircle, 
  Wand2, 
  Film, 
  Scissors, 
  RefreshCw, 
  Check, 
  Zap,
  Globe,
  ArrowRight,
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { 
  geminiAssistantService, 
  AssistantMessage, 
  AppNavigationDestination 
} from '../services/geminiAssistantService';
import { AppLanguage } from '../types';

interface GeminiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onToast?: (msg: string) => void;
  onNavigate?: (destination: AppNavigationDestination) => void;
}

const SUPPORTED_VOICE_LANGS = [
  { code: 'bn-BD', label: 'বাংলা (BD)', flag: '🇧🇩' },
  { code: 'en-US', label: 'English (US)', flag: '🇺🇸' },
  { code: 'hi-IN', label: 'हिन्दी (IN)', flag: '🇮🇳' },
  { code: 'ar-SA', label: 'العربية (SA)', flag: '🇸🇦' },
  { code: 'ur-PK', label: 'اردو (PK)', flag: '🇵🇰' },
  { code: 'es-ES', label: 'Español (ES)', flag: '🇪🇸' },
  { code: 'fr-FR', label: 'Français (FR)', flag: '🇫🇷' },
];

export const GeminiAssistantModal: React.FC<GeminiAssistantModalProps> = ({
  isOpen,
  onClose,
  language,
  onToast,
  onNavigate,
}) => {
  const [messages, setMessages] = useState<AssistantMessage[]>([
    {
      id: 'init-1',
      sender: 'gemini',
      text: language === 'bn'
        ? '👋 **স্বাগতম! আমি পৃথিবীর ১ নম্বর জিমিনি সুপার এআই (Gemini World #1 AI Assistant)।**\n\nআপনি আমাকে বিশ্বের **যেকোনো দেশের ভাষায়** লিখুন বা মুখে বলুন—আমি তাৎক্ষণিক গুগল-মানের বিস্তারিত সঠিক উত্তর দেব।\n\n• **অ্যাপ নেভিগেশন**: *"আমাকে প্রোফাইলে নিয়ে যাও"*, *"ভিডিও এডিটর খোলো"*, *"ইনবক্স দেখাও"*, *"লাইভে চলো"*, *"সেটিংস খোলো"* বললে আমি সরাসরি সেই পেজে নিয়ে যাব!\n• **ভিডিও/ছবি এডিট**: নিচে ছবি বা ভিডিও যুক্ত করে এডিটিং পরামর্শ বা ক্যাপকাট ফর্মুলা নিন।\n• **সার্বজনীন জ্ঞান**: বিজ্ঞান, কোডিং, গণিত, ব্যবসা ও জীবনের যেকোনো প্রশ্ন করতে পারেন!'
        : '👋 **Welcome! I am the World\'s #1 Gemini Super AI Assistant.**\n\nWrite or speak to me in **ANY world language**—I will provide comprehensive, Google-grade answers.\n\n• **In-App Navigation**: Say *"Take me to profile"*, *"Open video editor"*, *"Go to inbox"*, *"Start live stream"*, or *"Open settings"* and I will navigate you immediately!\n• **Media & CapCut Studio**: Attach photos/videos below for viral scripts, color grading, and hooks.\n• **Universal Knowledge**: Ask anything about science, coding, math, virality, or general knowledge!',
      timestamp: Date.now(),
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceLang, setVoiceLang] = useState<string>(language === 'bn' ? 'bn-BD' : 'en-US');
  const [showVoiceLangMenu, setShowVoiceLangMenu] = useState(false);

  const [attachedMedia, setAttachedMedia] = useState<{
    url: string;
    type: 'image' | 'video';
    base64?: string;
    mimeType?: string;
  } | null>(null);

  const [activeSpeechId, setActiveSpeechId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const speechRecognitionRef = useRef<any>(null);

  // Auto scroll to latest message
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isLoading]);

  // Handle Speech Recognition in selected world language
  const toggleVoiceRecognition = () => {
    if (isListening) {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      onToast?.(language === 'bn' ? '⚠️ আপনার ডিভাইসে ভয়েস রিকগনিশন সক্রিয় নেই' : 'Speech recognition not supported in browser');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      speechRecognitionRef.current = recognition;
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = voiceLang;

      recognition.onstart = () => {
        setIsListening(true);
        const langObj = SUPPORTED_VOICE_LANGS.find((l) => l.code === voiceLang);
        onToast?.(
          language === 'bn'
            ? `🎙️ শুনছি (${langObj?.label || voiceLang})... আপনার প্রশ্ন বলুন`
            : `Listening (${langObj?.label || voiceLang})... Speak now`
        );
      };

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        setInputText(transcript);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  // Multilingual Text to Speech playback matching detected response language
  const handleSpeakText = (msgId: string, text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    if (activeSpeechId === msgId) {
      window.speechSynthesis.cancel();
      setActiveSpeechId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#_`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Dynamic accent detection
    if (/[\u0980-\u09FF]/.test(cleanText)) {
      utterance.lang = 'bn-BD';
    } else if (/[\u0900-\u097F]/.test(cleanText)) {
      utterance.lang = 'hi-IN';
    } else if (/[\u0600-\u06FF]/.test(cleanText)) {
      utterance.lang = 'ar-SA';
    } else if (/[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/.test(cleanText)) {
      utterance.lang = 'ja-JP';
    } else if (/\b(cómo|está|gracias|hola|dónde|por qué|amigo)\b/i.test(cleanText)) {
      utterance.lang = 'es-ES';
    } else if (/\b(bonjour|merci|avec|vous|comment)\b/i.test(cleanText)) {
      utterance.lang = 'fr-FR';
    } else {
      utterance.lang = 'en-US';
    }

    utterance.rate = 1.0;

    utterance.onend = () => {
      setActiveSpeechId(null);
    };

    utterance.onerror = () => {
      setActiveSpeechId(null);
    };

    setActiveSpeechId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Attach Image
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setAttachedMedia({
        url: URL.createObjectURL(file),
        type: 'image',
        base64,
        mimeType: file.type || 'image/jpeg',
      });
      onToast?.(language === 'bn' ? '✓ ছবি যুক্ত হয়েছে! এবার প্রম্পট লিখে পাঠান' : 'Photo attached!');
    };
    reader.readAsDataURL(file);
  };

  // Attach Video
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setAttachedMedia({
        url: URL.createObjectURL(file),
        type: 'video',
        base64,
        mimeType: file.type || 'video/mp4',
      });
      onToast?.(language === 'bn' ? '✓ ভিডিও ক্লিপ যুক্ত হয়েছে!' : 'Video attached!');
    };
    reader.readAsDataURL(file);
  };

  // Send Prompt to Gemini
  const handleSendMessage = async (customPrompt?: string) => {
    const promptToSend = (customPrompt || inputText).trim();
    if (!promptToSend && !attachedMedia) return;

    const currentMedia = attachedMedia;
    setAttachedMedia(null);
    setInputText('');

    // Add User Message
    const userMsg: AssistantMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: promptToSend || (currentMedia?.type === 'image' ? '📸 এই ছবিটি এডিট ও বিশ্লেষণ করে দাও' : '🎥 এই ভিডিওটি এডিট ও হুক তৈরি করে দাও'),
      timestamp: Date.now(),
      mediaUrl: currentMedia?.url,
      mediaType: currentMedia?.type,
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const result = await geminiAssistantService.askGemini({
        prompt: promptToSend || 'Analyze attached media and give TikTok creative edit guide',
        mediaBase64: currentMedia?.base64,
        mediaMimeType: currentMedia?.mimeType,
        language,
      });

      const geminiMsg: AssistantMessage = {
        id: `gem-${Date.now()}`,
        sender: 'gemini',
        text: result.text,
        timestamp: Date.now(),
        navDestination: result.navDestination,
        navLabel: result.navLabel,
      };

      setMessages((prev) => [...prev, geminiMsg]);

      // If navigation action returned and requested explicitly, auto-navigate option
      if (result.navDestination) {
        onToast?.(
          language === 'bn'
            ? `📍 নেভিগেশন প্রস্তুত: ${result.navLabel || result.navDestination}`
            : `📍 Navigation Ready: ${result.navLabel || result.navDestination}`
        );
      }
    } catch (err) {
      const errorMsg: AssistantMessage = {
        id: `err-${Date.now()}`,
        sender: 'gemini',
        text: language === 'bn'
          ? 'দুঃখিত, সংযোগে সাময়িক সমস্যা হয়েছে। আপনি আবার চেষ্টা করতে পারেন।'
          : 'Sorry, temporary connection issue. Please try again.',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick prompt chips
  const quickChips = [
    { label: language === 'bn' ? '👤 প্রোফাইলে নিয়ে যাও' : '👤 Take me to Profile', prompt: 'আমাকে প্রোফাইলে নিয়ে যাও' },
    { label: language === 'bn' ? '🎬 ভিডিও এডিটর খোলো' : '🎬 Open Video Editor', prompt: 'ভিডিও এডিটর খোলো' },
    { label: language === 'bn' ? '💬 ইনবক্স মেসেজ দেখাও' : '💬 Open Inbox', prompt: 'ইনবক্সে মেসেজ দেখাও' },
    { label: language === 'bn' ? '🔴 লাইভ স্ট্রিমে চলো' : '🔴 Go Live', prompt: 'লাইভ স্ট্রিমে চলো' },
    { label: language === 'bn' ? '⚙️ সেটিংস ও এডমিন' : '⚙️ Open Settings', prompt: 'সেটিংস পেজ খোলো' },
    { label: language === 'bn' ? '💎 বিকাশ/নগদ পেমেন্ট' : '💎 bKash/Nagad VIP', prompt: 'বিকাশ ও নগদ পেমেন্ট কিভাবে করে?' },
    { label: language === 'bn' ? '🔥 ভাইরাল গ্রোথ ট্রিক' : '🔥 Viral Growth Tips', prompt: 'টিকটকে ১ম ৩ সেকেন্ডের হুক ফর্মুলা কি?' },
  ];

  // Helper to render rich markdown cleanly like Google Search cards
  const renderFormattedText = (text: string) => {
    const lines = text.split('\n');
    return (
      <div className="space-y-1.5 text-xs leading-relaxed">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (!trimmed) return <div key={idx} className="h-1" />;

          // Heading 3
          if (trimmed.startsWith('### ')) {
            return (
              <h4 key={idx} className="text-sm font-black text-cyan-300 mt-2 mb-1 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                {trimmed.replace('### ', '')}
              </h4>
            );
          }

          // Heading 2 / 1
          if (trimmed.startsWith('## ') || trimmed.startsWith('# ')) {
            return (
              <h3 key={idx} className="text-base font-black text-white mt-2.5 mb-1 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-300">
                {trimmed.replace(/^#+\s*/, '')}
              </h3>
            );
          }

          // Bullet points
          if (trimmed.startsWith('• ') || trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
            const content = trimmed.replace(/^[•\-*]\s*/, '');
            return (
              <div key={idx} className="flex items-start gap-2 pl-1 text-zinc-200">
                <span className="text-cyan-400 font-bold shrink-0 mt-0.5">•</span>
                <span>{renderInlineFormatting(content)}</span>
              </div>
            );
          }

          // Numbered lists
          if (/^\d+\.\s/.test(trimmed)) {
            const num = trimmed.match(/^(\d+\.)\s/)?.[1] || '1.';
            const content = trimmed.replace(/^\d+\.\s/, '');
            return (
              <div key={idx} className="flex items-start gap-2 pl-1 text-zinc-200">
                <span className="font-mono font-bold text-amber-400 shrink-0">{num}</span>
                <span>{renderInlineFormatting(content)}</span>
              </div>
            );
          }

          return (
            <p key={idx} className="text-zinc-200">
              {renderInlineFormatting(trimmed)}
            </p>
          );
        })}
      </div>
    );
  };

  // Inline formatting helper for **bold**
  const renderInlineFormatting = (str: string) => {
    const parts = str.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-extrabold text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[95] bg-black/90 backdrop-blur-xl flex flex-col justify-between animate-in fade-in duration-200 select-none">
      
      {/* 1. TOP HEADER & ROTATING GLOWING AI LOADER */}
      <div className="px-4 py-3 bg-zinc-950/95 border-b border-zinc-800/80 flex items-center justify-between z-20 shrink-0">
        
        {/* Gemini Branding & Live Indicator */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-fuchsia-500 p-0.5 shadow-lg shadow-indigo-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-[#25f4ee] animate-pulse" />
              </div>
            </div>
            {/* Live 24/7 Online Beacon */}
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-zinc-950 shadow-xs" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-black text-white tracking-tight">
                Gemini Super AI 3.8
              </h2>
              <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-600 text-white text-[9px] font-black uppercase shadow-xs">
                World #1
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 font-medium">
              {language === 'bn' ? '২৪ ঘণ্টা লাইভ সহকারী • গুগল মানের উত্তর • অ্যাপ নেভিগেশন' : '24/7 Live Assistant • Google Grade • Full Navigation'}
            </p>
          </div>
        </div>

        {/* Top Loading Indicator & Close Button */}
        <div className="flex items-center gap-2">
          {isLoading && (
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-cyan-500/40 text-cyan-300 text-[11px] font-bold shadow-lg shadow-cyan-500/20 animate-pulse">
              <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <span className="hidden sm:inline">
                {language === 'bn' ? 'জিমিনি ভাবছে...' : 'Thinking...'}
              </span>
            </div>
          )}

          {/* Spoken Voice Language Selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowVoiceLangMenu(!showVoiceLangMenu)}
              className="px-2 py-1 rounded-xl bg-zinc-900 border border-zinc-750 hover:border-zinc-600 text-[11px] font-bold text-zinc-300 flex items-center gap-1 cursor-pointer transition-colors"
              title="ভয়েসের ভাষা নির্বাচন"
            >
              <Globe className="w-3 h-3 text-cyan-400" />
              <span>{SUPPORTED_VOICE_LANGS.find((l) => l.code === voiceLang)?.flag || '🌐'}</span>
              <ChevronDown className="w-2.5 h-2.5 text-zinc-400" />
            </button>

            {showVoiceLangMenu && (
              <div className="absolute right-0 top-full mt-1.5 w-40 bg-zinc-900 border border-zinc-700 rounded-2xl p-1.5 shadow-2xl z-30 space-y-0.5 animate-in fade-in zoom-in-95">
                <span className="text-[9px] font-black uppercase text-zinc-500 px-2 py-0.5 block">
                  Select Language
                </span>
                {SUPPORTED_VOICE_LANGS.map((item) => (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => {
                      setVoiceLang(item.code);
                      setShowVoiceLangMenu(false);
                      onToast?.(`Voice set to: ${item.label}`);
                    }}
                    className={`w-full px-2 py-1.5 rounded-xl text-left text-xs font-bold flex items-center justify-between cursor-pointer transition-colors ${
                      voiceLang === item.code ? 'bg-cyan-500/20 text-cyan-300' : 'text-zinc-300 hover:bg-zinc-800'
                    }`}
                  >
                    <span>{item.flag} {item.label}</span>
                    {voiceLang === item.code && <Check className="w-3 h-3 text-cyan-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. CHAT STREAM & ACTION CARDS CONTAINER */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        
        {/* Quick Suggestion Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {quickChips.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(chip.prompt)}
              className="px-3 py-1.5 rounded-full bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 hover:border-cyan-500/50 text-[11px] font-bold text-zinc-300 hover:text-white shrink-0 transition-all cursor-pointer active:scale-95 shadow-xs"
            >
              {chip.label}
            </button>
          ))}
        </div>

        {/* Message Bubbles */}
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1.5 animate-in fade-in duration-150`}
            >
              <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 font-mono">
                {isUser ? (
                  <span>আপনি</span>
                ) : (
                  <span className="flex items-center gap-1 text-[#25f4ee] font-bold">
                    <Sparkles className="w-3 h-3" />
                    Gemini AI
                  </span>
                )}
                <span>• {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>

              {/* Media Preview if attached */}
              {msg.mediaUrl && (
                <div className="max-w-[240px] rounded-2xl overflow-hidden border border-zinc-700 bg-black shadow-lg mb-1">
                  {msg.mediaType === 'image' ? (
                    <img src={msg.mediaUrl} alt="" className="w-full h-auto object-cover max-h-48" />
                  ) : (
                    <video src={msg.mediaUrl} controls className="w-full h-auto max-h-48 object-cover" />
                  )}
                </div>
              )}

              {/* Message Bubble Body */}
              <div
                className={`max-w-[92%] sm:max-w-[82%] p-3.5 rounded-2xl ${
                  isUser
                    ? 'bg-gradient-to-r from-[#fe2c55] to-rose-600 text-white font-medium rounded-tr-xs shadow-md text-xs'
                    : 'bg-zinc-900/95 text-zinc-100 border border-zinc-800/80 rounded-tl-xs shadow-xl'
                }`}
              >
                {/* Render markdown / formatted text for Gemini, plain for user */}
                {isUser ? (
                  <div className="whitespace-pre-wrap">{msg.text}</div>
                ) : (
                  renderFormattedText(msg.text)
                )}

                {/* Direct Interactive In-App Navigation Action Button */}
                {!isUser && msg.navDestination && (
                  <div className="mt-3 p-3 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-indigo-950/70 to-purple-950/70 border border-cyan-500/40 shadow-lg flex items-center justify-between gap-2 animate-in zoom-in-95">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-[#25f4ee] flex items-center justify-center font-bold shrink-0 border border-cyan-500/40">
                        <ExternalLink className="w-4.5 h-4.5" />
                      </div>
                      <div>
                        <span className="text-xs font-black text-white block">
                          {msg.navLabel || `Go to ${msg.navDestination}`}
                        </span>
                        <span className="text-[10px] text-cyan-300 font-medium">
                          {language === 'bn' ? 'সরাসরি এই পেজে যেতে এখানে ট্যাপ করুন' : 'Tap to navigate directly'}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (msg.navDestination) {
                          onNavigate?.(msg.navDestination);
                          onClose();
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-xs shadow-md shadow-cyan-500/30 flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer shrink-0"
                    >
                      <span>{language === 'bn' ? 'এখনই যান' : 'Go Now'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Gemini Read Aloud Voice Button */}
                {!isUser && (
                  <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => handleSpeakText(msg.id, msg.text)}
                      className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      {activeSpeechId === msg.id ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                          <span className="text-rose-400">{language === 'bn' ? 'ভয়েস বন্ধ' : 'Stop Audio'}</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'ভয়েস শুনুন (Read Aloud)' : 'Read Aloud'}</span>
                        </>
                      )}
                    </button>
                    <span className="text-[9px] text-zinc-500 font-mono">World #1 Super AI</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Indicator in Chat Stream */}
        {isLoading && (
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-zinc-900/80 border border-cyan-500/30 text-cyan-300 text-xs w-fit animate-pulse shadow-lg">
            <Sparkles className="w-4 h-4 text-[#25f4ee] animate-spin" />
            <span>
              {language === 'bn' 
                ? 'জিমিনি ৩.৮ ফ্ল্যাশ অনুসন্ধান করছে ও উত্তর তৈরি করছে...' 
                : 'Gemini 3.8 Flash researching & generating response...'}
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 3. ATTACHED MEDIA PREVIEW PILL (Above Search Bar) */}
      {attachedMedia && (
        <div className="px-4 py-2 bg-zinc-950 border-t border-zinc-850 flex items-center justify-between animate-in slide-in-from-bottom-2 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-cyan-500/40 bg-black shrink-0">
              {attachedMedia.type === 'image' ? (
                <img src={attachedMedia.url} alt="" className="w-full h-full object-cover" />
              ) : (
                <video src={attachedMedia.url} className="w-full h-full object-cover" />
              )}
            </div>
            <div>
              <span className="text-xs font-black text-white block">
                {attachedMedia.type === 'image' ? '📸 ছবি সিলেক্টেড' : '🎥 ভিডিও ক্লিপ সিলেক্টেড'}
              </span>
              <span className="text-[10px] text-cyan-400">এআইকে এডিট করতে বা প্রশ্ন করতে সেন্ড করুন</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setAttachedMedia(null)}
            className="w-7 h-7 rounded-full bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 4. GOOGLE-STYLE SEARCH BAR AT BOTTOM */}
      <div className="p-3 sm:p-4 bg-zinc-950 border-t border-zinc-850 z-20 shrink-0">
        <div className="relative w-full max-w-2xl mx-auto flex items-center bg-zinc-900/95 hover:bg-zinc-900 border border-zinc-700/80 rounded-full px-3.5 py-1.5 shadow-2xl transition-all focus-within:border-cyan-400 focus-within:ring-2 focus-within:ring-cyan-500/20">
          
          {/* Google Search Lens Icon */}
          <div className="text-zinc-400 pl-1 pr-2">
            <Search className="w-4 h-4 text-cyan-400" />
          </div>

          {/* Search / Prompt Input */}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSendMessage();
              }
            }}
            placeholder={
              isListening
                ? (language === 'bn' ? '🎙️ শুনছি... যেকোনো ভাষায় আপনার প্রশ্ন বলুন...' : 'Listening... Speak now...')
                : (language === 'bn' ? 'গুগলের মতো যেকোনো প্রশ্ন করুন বা বলুন কোন পেজে নিয়ে যাব...' : 'Ask Google-style question or tell AI where to go...')
            }
            className="flex-1 bg-transparent text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none py-1.5 min-w-0"
          />

          {/* Media Attachments & Voice Controls */}
          <div className="flex items-center gap-1.5 pl-2">
            
            {/* Hidden File Inputs */}
            <input
              type="file"
              ref={imageInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
            <input
              type="file"
              ref={videoInputRef}
              onChange={handleVideoUpload}
              accept="video/*"
              className="hidden"
            />

            {/* 1. Photo Attach Button */}
            <button
              type="button"
              onClick={() => imageInputRef.current?.click()}
              className="p-1.5 rounded-full text-zinc-400 hover:text-cyan-400 hover:bg-zinc-800 transition-colors cursor-pointer active:scale-90"
              title="ছবি আপলোড করুন (Upload Photo)"
            >
              <ImageIcon className="w-4 h-4" />
            </button>

            {/* 2. Video Attach Button */}
            <button
              type="button"
              onClick={() => videoInputRef.current?.click()}
              className="p-1.5 rounded-full text-zinc-400 hover:text-[#fe2c55] hover:bg-zinc-800 transition-colors cursor-pointer active:scale-90"
              title="ভিডিও আপলোড করুন (Upload Video)"
            >
              <VideoIcon className="w-4 h-4" />
            </button>

            {/* 3. Voice / Mic Button */}
            <button
              type="button"
              onClick={toggleVoiceRecognition}
              className={`p-1.5 rounded-full transition-all cursor-pointer active:scale-90 ${
                isListening
                  ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/50 animate-pulse'
                  : 'text-zinc-400 hover:text-amber-400 hover:bg-zinc-800'
              }`}
              title={isListening ? 'ভয়েস বন্ধ করুন' : 'ভয়েসে কথা বলুন (Speak in any language)'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* 4. Send Button */}
            <button
              type="button"
              disabled={!inputText.trim() && !attachedMedia}
              onClick={() => handleSendMessage()}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer active:scale-90 ${
                inputText.trim() || attachedMedia
                  ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-md shadow-cyan-500/30'
                  : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
              }`}
              title="পাঠান"
            >
              <Send className="w-3.5 h-3.5 ml-0.5" />
            </button>
          </div>
        </div>

        {/* Footer info */}
        <p className="text-center text-[10px] text-zinc-500 mt-2">
          Gemini Super AI 3.8 • সর্বজনীন বহুভাষিক বুদ্ধিমত্তা ও স্বয়ংক্রিয় অ্যাপ নেভিগেশন
        </p>
      </div>

    </div>
  );
};
