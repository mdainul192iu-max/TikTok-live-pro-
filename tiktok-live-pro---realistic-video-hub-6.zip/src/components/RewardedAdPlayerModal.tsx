import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Coins, 
  Sparkles, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  FastForward, 
  ExternalLink 
} from 'lucide-react';
import { admobService, OFFICIAL_ADMOB_CONFIG } from '../services/admobService';
import { AppLanguage } from '../types';

interface RewardedAdPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onRewardClaimed: (coins: number) => void;
  onToast?: (msg: string) => void;
}

const REWARDED_SAMPLE_VIDEOS = [
  {
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    title: 'Supercell Clash of Clans: Clan Wars Epic Raid',
    advertiser: 'Supercell Studios',
  },
  {
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    title: 'Binance Pay: Send Crypto Instantly Across 200 Countries',
    advertiser: 'Binance Global',
  },
  {
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    title: 'Top Speed Racing Rivals 2026',
    advertiser: 'Speed Rivals Mobile',
  },
];

export const RewardedAdPlayerModal: React.FC<RewardedAdPlayerModalProps> = ({
  isOpen,
  onClose,
  language,
  onRewardClaimed,
  onToast,
}) => {
  const [adIndex, setAdIndex] = useState<number>(0);
  const [countdown, setCountdown] = useState<number>(10);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [coinsGranted, setCoinsGranted] = useState<number>(5);
  const [isClaiming, setIsClaiming] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const currentAd = REWARDED_SAMPLE_VIDEOS[adIndex % REWARDED_SAMPLE_VIDEOS.length];

  // Start countdown and video on open
  useEffect(() => {
    if (!isOpen) return;

    setCountdown(10);
    setIsCompleted(false);
    setIsClaiming(false);

    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleAdFinished();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, adIndex]);

  const handleAdFinished = async () => {
    setIsCompleted(true);
    setIsClaiming(true);

    const res = await admobService.grantRewardedAdReward();
    setIsClaiming(false);

    if (res.success) {
      setCoinsGranted(res.coinsAwarded);
      onRewardClaimed(res.coinsAwarded);
      onToast?.('🎉 +5 Gold Coins Earned! Cryptographic HMAC Signature Verified.');
    } else {
      onToast?.(res.error || 'Failed to claim coins');
    }
  };

  const handleWatchNextAd = () => {
    // Instantly switch to next ad with 0 delay since next ad is pre-loaded!
    setAdIndex((prev) => prev + 1);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-70 bg-black/90 backdrop-blur-md flex items-center justify-center p-0 sm:p-4 select-none">
      <div className="relative w-full max-w-[430px] h-full sm:h-[92vh] bg-black sm:rounded-3xl overflow-hidden flex flex-col justify-between shadow-2xl border border-zinc-800">
        
        {/* Top Header Bar */}
        <div className="absolute top-4 left-4 right-4 z-30 flex items-center justify-between text-white pointer-events-auto">
          {/* AdMob Official ID Pill */}
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase tracking-wider flex items-center gap-1 shadow-md">
              <Sparkles className="w-3.5 h-3.5 fill-current" />
              <span>Unlimited Rewarded Ad</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white border border-white/20"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>

            {/* Countdown / Close Button */}
            {isCompleted ? (
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center cursor-pointer transition-colors border border-white/20"
              >
                <X className="w-5 h-5 stroke-[2.5]" />
              </button>
            ) : (
              <div className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-xs font-mono font-bold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#fe2c55] animate-ping" />
                <span>Reward in {countdown}s</span>
              </div>
            )}
          </div>
        </div>

        {/* Video Player */}
        <div className="relative w-full h-full flex items-center justify-center bg-black overflow-hidden">
          <video
            ref={videoRef}
            src={currentAd.url}
            autoPlay
            playsInline
            muted={isMuted}
            className="w-full h-full object-cover"
          />

          {/* Ad Unit Details Overlay */}
          <div className="absolute top-16 left-4 z-20 pointer-events-none">
            <span className="text-[9px] font-mono text-zinc-400 bg-black/40 px-2 py-0.5 rounded-full border border-white/10">
              Unit: ca-app-pub-3964151806897298/7585516907
            </span>
          </div>
        </div>

        {/* Bottom Card: Advertiser & Rewards */}
        <div className="absolute bottom-4 left-4 right-4 z-30 p-4 bg-zinc-900/90 backdrop-blur-md rounded-2xl border border-zinc-700 shadow-2xl space-y-3 pointer-events-auto">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                {currentAd.advertiser}
              </span>
              <h4 className="text-xs font-black text-white line-clamp-1">
                {currentAd.title}
              </h4>
            </div>

            {/* Reward Badge */}
            <div className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-zinc-950 font-black font-mono text-xs shadow-md flex items-center gap-1">
              <Coins className="w-4 h-4 fill-current" />
              <span>+5 COINS</span>
            </div>
          </div>

          {/* If completed: Congratulations and "Watch Next Ad Instantly" Button */}
          {isCompleted ? (
            <div className="space-y-2 pt-1 border-t border-zinc-800 animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>5 Gold Coins Added to Wallet!</span>
                </div>
                <span className="text-[10px] text-zinc-400 font-mono">
                  HMAC Signed ✓
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleWatchNextAd}
                  className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 via-[#fe2c55] to-amber-400 hover:brightness-110 text-white font-black text-xs shadow-lg flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                >
                  <FastForward className="w-4 h-4 fill-current" />
                  <span>Watch Next (+5 Coins)</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="py-2.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs cursor-pointer transition-colors"
                >
                  Close & View Wallet
                </button>
              </div>
            </div>
          ) : (
            <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-amber-400 via-rose-500 to-emerald-400 transition-all duration-1000"
                style={{ width: `${((10 - countdown) / 10) * 100}%` }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
