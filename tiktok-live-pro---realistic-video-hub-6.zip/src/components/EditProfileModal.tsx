import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Camera, 
  Copy, 
  Check, 
  ChevronRight, 
  Sparkles, 
  X, 
  Instagram, 
  Youtube, 
  Twitter 
} from 'lucide-react';
import { Creator, UserAccount, AppLanguage } from '../types';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  creator: Creator;
  userAccount?: UserAccount | null;
  language: AppLanguage;
  onSave: (
    name: string,
    bio: string,
    handle: string,
    avatar?: string,
    otherFields?: { pronouns?: string; instagram?: string; youtube?: string; twitter?: string; profileVideo?: string }
  ) => void;
  onOpenGallery?: () => void;
  onToast?: (msg: string) => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  creator,
  userAccount,
  language,
  onSave,
  onOpenGallery,
  onToast,
}) => {
  const [name, setName] = useState(creator.name);
  const [handle, setHandle] = useState(creator.handle);
  const [bio, setBio] = useState(creator.bio || '');
  const [pronouns, setPronouns] = useState(creator.pronouns || 'he/him');
  const [instagram, setInstagram] = useState(creator.instagram || '');
  const [youtube, setYoutube] = useState(creator.youtube || '');
  const [twitter, setTwitter] = useState(creator.twitter || '');
  const [avatarUrl, setAvatarUrl] = useState(creator.avatar);

  if (!isOpen) return null;

  const handleCopyHandle = () => {
    try {
      navigator.clipboard?.writeText(`@${handle}`);
    } catch {}
    onToast?.(language === 'bn' ? `✓ ইউজারনেম @${handle} কপি করা হয়েছে!` : `✓ Copied @${handle}!`);
  };

  const handleSave = () => {
    onSave(name, bio, handle, avatarUrl, {
      pronouns,
      instagram,
      youtube,
      twitter,
    });
    onToast?.(language === 'bn' ? '✓ প্রোফাইল সফলভাবে আপডেট হয়েছে!' : '✓ Profile updated!');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md select-none pointer-events-auto">
      <div className="relative w-full max-w-[480px] h-full sm:h-[92vh] bg-white text-zinc-900 sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100 bg-white">
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-700 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
          </button>
          <h3 className="font-extrabold text-base text-zinc-900">
            {language === 'bn' ? 'প্রোফাইল এডিট' : 'Edit profile'}
          </h3>
          <button
            onClick={handleSave}
            className="text-xs font-black text-[#fe2c55] hover:opacity-80 px-2 py-1 cursor-pointer"
          >
            {language === 'bn' ? 'সেভ' : 'Save'}
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
          {/* Change Photo / Video Avatar */}
          <div className="flex items-center justify-center gap-8 py-2">
            <div 
              onClick={onOpenGallery}
              className="flex flex-col items-center gap-1.5 cursor-pointer group"
            >
              <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-zinc-200 shadow-md group-hover:opacity-90">
                <img src={avatarUrl} alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/35 flex items-center justify-center text-white">
                  <Camera className="w-6 h-6" />
                </div>
              </div>
              <span className="text-xs font-bold text-zinc-700">ছবি পরিবর্তন</span>
            </div>
          </div>

          {/* Section: About You */}
          <div>
            <h4 className="text-[11px] font-black text-zinc-400 uppercase tracking-wider mb-2">
              আপনার সম্পর্কে (About you)
            </h4>
            <div className="divide-y divide-zinc-100 border-y border-zinc-100">
              {/* Name */}
              <div className="py-3 flex items-center justify-between">
                <span className="text-xs font-bold text-zinc-500 w-24">নাম</span>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="flex-1 text-right text-xs font-bold text-zinc-900 outline-none"
                />
              </div>

              {/* Username with Copy Button */}
              <div className="py-3 flex items-center justify-between">
                <span className="text-xs font-bold text-zinc-500 w-24">ইউজারনেম</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-zinc-400 font-mono">@</span>
                  <input
                    type="text"
                    value={handle}
                    onChange={(e) => setHandle(e.target.value.replace(/[^a-zA-Z0-9_.]/g, ''))}
                    className="text-right text-xs font-bold text-zinc-900 outline-none w-32 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleCopyHandle}
                    className="p-1 rounded-md hover:bg-zinc-100 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                    title="Copy username"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Pronouns */}
              <div className="py-3 flex items-center justify-between">
                <span className="text-xs font-bold text-zinc-500 w-24">সর্বনাম</span>
                <input
                  type="text"
                  value={pronouns}
                  onChange={(e) => setPronouns(e.target.value)}
                  placeholder="he/him, she/her"
                  className="flex-1 text-right text-xs font-semibold text-zinc-900 outline-none"
                />
              </div>

              {/* Bio */}
              <div className="py-3 flex flex-col gap-1.5">
                <span className="text-xs font-bold text-zinc-500">বায়ো (Bio)</span>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={3}
                  placeholder="আপনার সম্পর্কে লিখুন..."
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl p-2.5 text-xs text-zinc-900 outline-none focus:border-zinc-400"
                />
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div>
            <h4 className="text-[11px] font-black text-zinc-400 uppercase tracking-wider mb-2">
              সোশ্যাল লিংক (Social)
            </h4>
            <div className="divide-y divide-zinc-100 border-y border-zinc-100">
              <div className="py-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Instagram className="w-4 h-4 text-pink-500" />
                  <span className="text-xs font-bold text-zinc-600">Instagram</span>
                </div>
                <input
                  type="text"
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  placeholder="Add Instagram..."
                  className="text-right text-xs text-zinc-900 outline-none"
                />
              </div>

              <div className="py-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Youtube className="w-4 h-4 text-red-500" />
                  <span className="text-xs font-bold text-zinc-600">YouTube</span>
                </div>
                <input
                  type="text"
                  value={youtube}
                  onChange={(e) => setYoutube(e.target.value)}
                  placeholder="Add YouTube..."
                  className="text-right text-xs text-zinc-900 outline-none"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
