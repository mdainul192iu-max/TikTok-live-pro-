import React, { useState } from 'react';
import { X, Send, Heart, CheckCircle2, CornerDownRight, ShieldCheck, Flame } from 'lucide-react';
import { CommentItem, CommentReply, AppLanguage, VideoReel, UserAccount, Creator } from '../types';

interface CommentsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  reel?: VideoReel | null;
  comments: CommentItem[];
  totalCount: number;
  onAddComment: (text: string) => void;
  onAddReply?: (commentId: string, text: string) => void;
  onToggleLikeComment?: (commentId: string, replyId?: string) => void;
  currentUser?: UserAccount | Creator | null;
  language: AppLanguage;
  searchSuggestion?: string;
  themeMode?: 'dark' | 'light';
  onToast?: (msg: string) => void;
  onOpenProfile?: (creator: any) => void;
}

export const CommentsDrawer: React.FC<CommentsDrawerProps> = ({
  isOpen,
  onClose,
  reel,
  comments,
  totalCount,
  onAddComment,
  onAddReply,
  onToggleLikeComment,
  currentUser,
  language,
  onToast,
  onOpenProfile,
}) => {
  const [commentText, setCommentText] = useState('');
  const [replyingTo, setReplyingTo] = useState<{
    commentId: string;
    userName: string;
    userHandle?: string;
  } | null>(null);

  if (!isOpen) return null;

  // Count user's comments on this video (Requirement: 10 করে কমেন্ট করতে পারবে)
  const myCommentCount = comments.filter(
    (c) =>
      c.user.handle === currentUser?.handle ||
      c.user.name === currentUser?.name ||
      (currentUser && c.user.id === currentUser.id)
  ).length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    if (myCommentCount >= 10 && !replyingTo) {
      onToast?.(
        language === 'bn'
          ? '⚠️ এই ভিডিওতে আপনার সর্বোচ্চ ১০টি মন্তব্য করা সম্পন্ন হয়েছে!'
          : '⚠️ Maximum 10 comments reached on this video!'
      );
      return;
    }

    if (replyingTo && onAddReply) {
      onAddReply(replyingTo.commentId, commentText.trim());
      setReplyingTo(null);
    } else {
      onAddComment(commentText.trim());
    }
    setCommentText('');
  };

  const creatorAvatar = reel?.creator.avatar;
  const creatorHandle = reel?.creator.handle;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs select-none pointer-events-auto">
      <div className="relative w-full max-w-[480px] h-[72vh] bg-zinc-950 text-white rounded-t-3xl border-t border-zinc-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300">
        
        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-800/80 bg-zinc-950">
          <div className="flex items-center gap-1.5 text-xs text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-[#fe2c55] animate-pulse" />
            <span className="font-mono text-[11px]">
              {language === 'bn' ? `আপনার কমেন্ট: ${myCommentCount}/১০` : `Your comments: ${myCommentCount}/10`}
            </span>
          </div>

          <h4 className="font-black text-sm text-center text-zinc-100 flex items-center gap-1">
            <span>{totalCount}</span>
            <span>{language === 'bn' ? 'টি মন্তব্য' : 'comments'}</span>
          </h4>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white cursor-pointer active:scale-90 transition-transform"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video Creator Pin Banner */}
        {reel && (
          <div className="px-4 py-2 bg-zinc-900/50 border-b border-zinc-800/50 flex items-center justify-between text-xs">
            <div 
              onClick={() => onOpenProfile?.(reel.creator)}
              className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
            >
              <div className="relative w-6 h-6 rounded-full p-[1px] bg-gradient-to-tr from-[#fe2c55] to-[#25f4ee]">
                <img src={reel.creator.avatar} alt="" className="w-full h-full rounded-full object-cover" />
              </div>
              <span className="text-[11px] font-bold text-zinc-300 truncate max-w-[180px]">
                {reel.creator.name}
              </span>
              <span className="px-1.5 py-0.2 rounded-full bg-zinc-800 text-[#25f4ee] text-[9px] font-extrabold border border-zinc-700">
                {language === 'bn' ? 'ভিডিও আপলোডার' : 'Creator'}
              </span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">
              {language === 'bn' ? 'সর্বোচ্চ ১০ কমেন্ট' : 'Max 10 / user'}
            </span>
          </div>
        )}

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {comments.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-zinc-500">
              <div className="w-12 h-12 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-600 mb-2">
                <Flame className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-zinc-400">
                {language === 'bn' ? 'এখনও কোনো মন্তব্য করা হয়নি' : 'No comments yet'}
              </p>
              <p className="text-[11px] text-zinc-600 mt-1">
                {language === 'bn' ? 'সুন্দর একটি কমেন্ট লিখে আলোচনা শুরু করুন!' : 'Be the first to share your thoughts!'}
              </p>
            </div>
          ) : (
            comments.map((c) => {
              const isUploader = creatorHandle && c.user.handle === creatorHandle;
              return (
                <div key={c.id} className="space-y-2.5">
                  <div className="flex items-start gap-3">
                    {/* User Avatar with Profile Click */}
                    <div
                      onClick={() => onOpenProfile?.(c.user)}
                      className="relative w-9 h-9 rounded-full flex items-center justify-center p-[1px] shrink-0 cursor-pointer hover:scale-105 active:scale-95 transition-transform"
                    >
                      <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-xs" />
                      <img src={c.user.avatar} alt="" className="relative z-1 w-full h-full rounded-full object-cover border border-zinc-900" />
                    </div>

                    {/* Comment Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span 
                          onClick={() => onOpenProfile?.(c.user)}
                          className="text-xs font-bold text-zinc-200 cursor-pointer hover:underline"
                        >
                          {c.user.name}
                        </span>
                        {c.user.verified && <CheckCircle2 className="w-3 h-3 fill-cyan-400 text-black shrink-0" />}
                        
                        {/* Creator Tag if the commenter is the video uploader */}
                        {isUploader && (
                          <span className="px-1.5 py-0.2 rounded-full bg-[#fe2c55]/20 text-[#fe2c55] border border-[#fe2c55]/40 text-[9px] font-black">
                            {language === 'bn' ? 'ক্রিয়েটর' : 'Creator'}
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-white mt-1 leading-relaxed break-words">{c.text}</p>
                      
                      {/* Meta actions: timestamp, reply button */}
                      <div className="flex items-center gap-3 text-[10px] text-zinc-500 font-semibold mt-1.5">
                        <span>{c.timestamp}</span>
                        <button
                          type="button"
                          onClick={() => {
                            setReplyingTo({
                              commentId: c.id,
                              userName: c.user.name,
                              userHandle: c.user.handle,
                            });
                          }}
                          className="text-zinc-400 hover:text-[#25f4ee] active:scale-95 transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <CornerDownRight className="w-3 h-3" />
                          <span>{language === 'bn' ? 'উত্তর দিন' : 'Reply'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Like Action & Video Uploader Like Avatar Badge */}
                    {/* User Requirement: যে ওই ভিডিও টা আপলোড করছে সে কমেন্ট পাশের লাইক বা কমেন্ট রিপ্লাই দিলে শুধু তার প্রোফাইল ছবি ছোট আইকনে সো করবে */}
                    <div className="flex flex-col items-center gap-1 shrink-0 pt-1">
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => onToggleLikeComment?.(c.id)}
                          className="p-1 text-zinc-500 hover:text-rose-500 active:scale-125 transition-transform cursor-pointer"
                          title="লাইক দিন"
                        >
                          <Heart className={`w-4 h-4 ${c.isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : ''}`} />
                        </button>

                        {/* Creator Mini Avatar Badge on Like if uploader liked this comment! */}
                        {(c.isCreatorLiked || c.creatorLikedAvatar) && (
                          <div 
                            className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full p-[0.5px] bg-[#fe2c55] shadow-md border border-black flex items-center justify-center cursor-pointer"
                            title="ভিডিও ক্রিয়েটর এই কমেন্টটি লাইক করেছেন"
                            onClick={() => onToast?.(language === 'bn' ? '❤️ ক্রিয়েটর এই মন্তব্যটি পছন্দ করেছেন' : '❤️ Creator liked this comment')}
                          >
                            <img
                              src={c.creatorLikedAvatar || creatorAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80'}
                              alt=""
                              className="w-full h-full rounded-full object-cover"
                            />
                          </div>
                        )}
                      </div>

                      <span className="text-[10px] font-mono text-zinc-400">{c.likes || 0}</span>
                    </div>
                  </div>

                  {/* Comment Replies (Indented under comment) */}
                  {c.replies && c.replies.length > 0 && (
                    <div className="pl-10 space-y-2 border-l border-zinc-800 ml-4.5 mt-2">
                      {c.replies.map((reply: CommentReply) => {
                        const isReplyFromCreator =
                          (creatorHandle && reply.user.handle === creatorHandle) ||
                          reply.isCreatorReply;
                        return (
                          <div key={reply.id} className="flex items-start gap-2.5 pt-1">
                            {/* Reply Avatar */}
                            <div 
                              onClick={() => onOpenProfile?.(reply.user)}
                              className="relative w-6 h-6 rounded-full shrink-0 overflow-hidden border border-zinc-700 cursor-pointer"
                            >
                              <img src={reply.user.avatar} alt="" className="w-full h-full object-cover" />
                            </div>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span 
                                  onClick={() => onOpenProfile?.(reply.user)}
                                  className="text-[11px] font-bold text-zinc-300 cursor-pointer hover:underline"
                                >
                                  {reply.user.name}
                                </span>
                                
                                {/* Video Creator Badge when uploader replies */}
                                {isReplyFromCreator && (
                                  <div className="flex items-center gap-1 px-1.5 py-0.2 rounded-full bg-[#fe2c55]/20 text-[#fe2c55] border border-[#fe2c55]/40 text-[8px] font-black">
                                    <img 
                                      src={reply.user.avatar} 
                                      alt="" 
                                      className="w-2.5 h-2.5 rounded-full object-cover" 
                                    />
                                    <span>{language === 'bn' ? 'ক্রিয়েটর' : 'Creator'}</span>
                                  </div>
                                )}
                              </div>

                              <p className="text-[11px] text-zinc-200 mt-0.5 leading-relaxed break-words">
                                {reply.text}
                              </p>
                              <span className="text-[9px] text-zinc-500 font-mono mt-0.5 block">
                                {reply.timestamp}
                              </span>
                            </div>

                            {/* Reply like */}
                            <button
                              type="button"
                              onClick={() => onToggleLikeComment?.(c.id, reply.id)}
                              className="p-1 text-zinc-500 hover:text-rose-500 active:scale-125 transition-transform cursor-pointer"
                            >
                              <Heart className={`w-3.5 h-3.5 ${reply.isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : ''}`} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Replying banner */}
        {replyingTo && (
          <div className="px-4 py-1.5 bg-zinc-900 border-t border-zinc-800 flex items-center justify-between text-xs animate-in slide-in-from-bottom-2">
            <div className="flex items-center gap-1.5 text-zinc-300 font-medium">
              <CornerDownRight className="w-3.5 h-3.5 text-[#25f4ee]" />
              <span>
                {language === 'bn' ? `${replyingTo.userName} কে উত্তর দিচ্ছেন...` : `Replying to @${replyingTo.userName}`}
              </span>
            </div>
            <button
              onClick={() => setReplyingTo(null)}
              className="text-zinc-500 hover:text-white p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Comment Input */}
        <form onSubmit={handleSubmit} className="p-3 bg-zinc-900 border-t border-zinc-800 flex items-center gap-2">
          {currentUser && (
            <div className="w-7 h-7 rounded-full overflow-hidden border border-zinc-700 shrink-0">
              <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
            </div>
          )}
          <input
            type="text"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder={
              replyingTo
                ? (language === 'bn' ? `@${replyingTo.userName} এর উত্তর লিখুন...` : `Reply to @${replyingTo.userName}...`)
                : (language === 'bn' ? 'সুন্দর একটি মন্তব্য লিখুন (১০টি পর্যন্ত)...' : 'Add comment (up to 10)...')
            }
            className="flex-1 bg-zinc-950 border border-zinc-800 rounded-full px-4 py-2 text-xs text-white placeholder-zinc-500 outline-none focus:border-[#fe2c55]"
          />
          <button
            type="submit"
            disabled={!commentText.trim()}
            className="w-8 h-8 rounded-full bg-[#fe2c55] disabled:opacity-40 flex items-center justify-center text-white cursor-pointer active:scale-90 transition-transform"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
