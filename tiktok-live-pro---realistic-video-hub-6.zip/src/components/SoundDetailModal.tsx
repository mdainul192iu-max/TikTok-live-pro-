import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  Bookmark, 
  Search, 
  Music, 
  Youtube, 
  Sparkles, 
  Check, 
  TrendingUp,
  Volume2,
  Sliders,
  Radio,
  Flame,
  Globe2,
  Disc3,
  Scissors
} from 'lucide-react';
import { SoundTrack, VideoReel, AppLanguage } from '../types';
import { searchUnifiedMusic, backgroundMusicManager } from '../services/musicApiService';

interface SoundDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  sound?: SoundTrack;
  reels?: VideoReel[];
  onUseSound: (sound: SoundTrack) => void;
  language: AppLanguage;
  onToast?: (msg: string) => void;
}

export const SoundDetailModal: React.FC<SoundDetailModalProps> = ({
  isOpen,
  onClose,
  sound,
  onUseSound,
  language,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'youtube_music' | 'spotify' | 'trending' | 'bangla' | 'phonk'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [spotifyList, setSpotifyList] = useState<SoundTrack[]>([]);
  const [youtubeList, setYoutubeList] = useState<SoundTrack[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<SoundTrack | null>(sound || null);
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [musicVolume, setMusicVolume] = useState<number>(85);
  const [showVolumeSlider, setShowVolumeSlider] = useState<boolean>(false);

  useEffect(() => {
    if (sound) {
      setSelectedTrack(sound);
    }
  }, [sound]);

  // Initial load of tracks
  useEffect(() => {
    if (isOpen) {
      handleSearch('');
    }
  }, [isOpen]);

  const handleSearch = async (query: string) => {
    setIsSearching(true);
    try {
      const { spotifyTracks, youtubeTracks } = await searchUnifiedMusic(query);
      setSpotifyList(spotifyTracks);
      setYoutubeList(youtubeTracks);
      if (!selectedTrack && (youtubeTracks[0] || spotifyTracks[0])) {
        setSelectedTrack(youtubeTracks[0] || spotifyTracks[0]);
      }
    } catch (e) {
      console.warn('Search error:', e);
    } finally {
      setIsSearching(false);
    }
  };

  const togglePreview = (track: SoundTrack) => {
    if (playingTrackId === track.id) {
      backgroundMusicManager.pause();
      setPlayingTrackId(null);
    } else {
      setSelectedTrack(track);
      setPlayingTrackId(track.id);
      backgroundMusicManager.playTrack(track, musicVolume / 100);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setMusicVolume(newVol);
    backgroundMusicManager.setVolume(newVol / 100);
  };

  const handleSelectSound = (track: SoundTrack) => {
    setSelectedTrack(track);
    backgroundMusicManager.stop();
    setPlayingTrackId(null);
    onUseSound(track);
    onClose();
    onToast?.(
      language === 'bn'
        ? `✓ '${track.title}' ভিডিওর সাউন্ড হিসেবে সেট করা হয়েছে!`
        : `✓ '${track.title}' selected as video sound!`
    );
  };

  const handleClose = () => {
    backgroundMusicManager.pause();
    setPlayingTrackId(null);
    onClose();
  };

  if (!isOpen) return null;

  // Filter lists based on active tab
  let displayList: SoundTrack[] = [];
  if (activeTab === 'all') {
    const maxLen = Math.max(youtubeList.length, spotifyList.length);
    for (let i = 0; i < maxLen; i++) {
      if (youtubeList[i]) displayList.push(youtubeList[i]);
      if (spotifyList[i]) displayList.push(spotifyList[i]);
    }
  } else if (activeTab === 'youtube_music') {
    displayList = youtubeList;
  } else if (activeTab === 'spotify') {
    displayList = spotifyList;
  } else if (activeTab === 'trending') {
    displayList = [...youtubeList, ...spotifyList].filter(
      (t) => t.category === 'trending' || t.category === 'brazilian_funk'
    );
  } else if (activeTab === 'bangla') {
    displayList = [...youtubeList, ...spotifyList].filter(
      (t) => t.category === 'bangla' || t.title.toLowerCase().includes('bangla') || t.title.toLowerCase().includes('bashori')
    );
    if (displayList.length === 0) displayList = spotifyList;
  } else if (activeTab === 'phonk') {
    displayList = [...youtubeList, ...spotifyList].filter(
      (t) => t.category === 'brazilian_funk' || t.title.toLowerCase().includes('phonk') || t.title.toLowerCase().includes('automotivo')
    );
  }

  const currentTrack = selectedTrack || displayList[0] || sound;

  return (
    // FULL-SCREEN SHEET (User Request: প্লাস বাটনে উপরের মেনুতে মিউজিক অপশন ওখানে ক্লিক করলে ফুল স্ক্রিন জুড়ে একটি সিট ওপেন হবে)
    <div className="fixed inset-0 z-[70] bg-black text-white flex flex-col overflow-hidden select-none animate-in fade-in duration-200">
      
      {/* 1. TOP HEADER WITH BACK BUTTON (<) */}
      <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-800 bg-black/95 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleClose}
            className="w-9 h-9 rounded-full bg-zinc-900 hover:bg-zinc-800 flex items-center justify-center text-zinc-200 hover:text-white transition-all cursor-pointer shadow-md"
            title="Back to camera"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          </button>
          <div>
            <h3 className="font-black text-base sm:text-lg tracking-tight text-white flex items-center gap-2">
              <Music className="w-4 h-4 text-[#fe2c55]" />
              <span>{language === 'bn' ? 'বিশ্বের সব গানের লাইব্রেরি' : 'Global Music & Sounds'}</span>
            </h3>
            <p className="text-[10px] text-zinc-400 font-medium">
              {language === 'bn' ? 'ইউটিউব ও স্পোটিফাই আসল সাউন্ড সিঙ্ক' : 'YouTube & Spotify Real Sound Sync'}
            </p>
          </div>
        </div>

        {/* Selected Track Pill */}
        {currentTrack && (
          <button
            type="button"
            onClick={() => handleSelectSound(currentTrack)}
            className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#fe2c55] to-amber-500 hover:brightness-110 text-white font-black text-xs shadow-lg active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
            <span>{language === 'bn' ? 'ব্যবহার করুন' : 'Use Sound'}</span>
          </button>
        )}
      </div>

      {/* 2. SEARCH BAR (Search ANY song from anywhere in the world) */}
      <div className="p-3 bg-zinc-950 border-b border-zinc-800/80">
        <div className="relative flex items-center max-w-xl mx-auto">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              handleSearch(e.target.value);
            }}
            placeholder={
              language === 'bn'
                ? 'পৃথিবীর যেকোনো গান, শিল্পী বা মিউজিক লিখে সার্চ করুন...'
                : 'Search any song or artist from YouTube & Spotify globally...'
            }
            className="w-full pl-10 pr-16 py-2.5 bg-zinc-900/90 rounded-2xl text-xs font-semibold text-white placeholder-zinc-500 border border-zinc-800 outline-none focus:border-[#fe2c55] transition-colors"
          />
          {isSearching ? (
            <span className="absolute right-3.5 text-[10px] text-[#25f4ee] font-mono animate-pulse">
              খোঁজা হচ্ছে...
            </span>
          ) : searchQuery ? (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                handleSearch('');
              }}
              className="absolute right-3.5 text-xs text-zinc-400 hover:text-white"
            >
              মুছুন
            </button>
          ) : null}
        </div>
      </div>

      {/* 3. CATEGORY TABS */}
      <div className="flex border-b border-zinc-800/80 bg-zinc-950/90 overflow-x-auto no-scrollbar px-2 py-1 max-w-xl mx-auto w-full">
        <button
          type="button"
          onClick={() => setActiveTab('all')}
          className={`px-3 py-2 flex items-center gap-1.5 text-xs font-black shrink-0 rounded-xl transition-all cursor-pointer ${
            activeTab === 'all'
              ? 'bg-white text-black shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Globe2 className="w-3.5 h-3.5 text-[#25f4ee]" />
          <span>{language === 'bn' ? 'সকল গান' : 'All Tracks'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('trending')}
          className={`px-3 py-2 flex items-center gap-1.5 text-xs font-black shrink-0 rounded-xl transition-all cursor-pointer ${
            activeTab === 'trending'
              ? 'bg-amber-500 text-black shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Flame className="w-3.5 h-3.5 text-amber-300" />
          <span>{language === 'bn' ? 'ভাইরাল টিকটক' : 'Viral'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('youtube_music')}
          className={`px-3 py-2 flex items-center gap-1.5 text-xs font-black shrink-0 rounded-xl transition-all cursor-pointer ${
            activeTab === 'youtube_music'
              ? 'bg-red-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Youtube className="w-3.5 h-3.5 text-red-500" />
          <span>YouTube Music</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('spotify')}
          className={`px-3 py-2 flex items-center gap-1.5 text-xs font-black shrink-0 rounded-xl transition-all cursor-pointer ${
            activeTab === 'spotify'
              ? 'bg-emerald-500 text-black shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Music className="w-3.5 h-3.5 text-emerald-400" />
          <span>Spotify</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('bangla')}
          className={`px-3 py-2 flex items-center gap-1.5 text-xs font-black shrink-0 rounded-xl transition-all cursor-pointer ${
            activeTab === 'bangla'
              ? 'bg-[#25f4ee] text-black shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Radio className="w-3.5 h-3.5 text-[#25f4ee]" />
          <span>{language === 'bn' ? 'বাংলা হিটস' : 'Bangla Hits'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('phonk')}
          className={`px-3 py-2 flex items-center gap-1.5 text-xs font-black shrink-0 rounded-xl transition-all cursor-pointer ${
            activeTab === 'phonk'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-300" />
          <span>Brazilian Phonk</span>
        </button>
      </div>

      {/* 4. ACTIVE PLAYING BANNER WITH VOLUME & TRIM CONTROLLER */}
      {currentTrack && (
        <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-black border-b border-zinc-800/80 px-4 py-3 max-w-xl mx-auto w-full">
          <div className="flex items-center gap-3">
            <div className="relative w-14 h-14 rounded-2xl overflow-hidden shrink-0 border border-white/15 shadow-xl group">
              <img src={currentTrack.cover} alt="" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => togglePreview(currentTrack)}
                className="absolute inset-0 bg-black/45 flex items-center justify-center text-white hover:bg-black/30 transition-all cursor-pointer"
                title="Play Real Sound"
              >
                {playingTrackId === currentTrack.id ? (
                  <Pause className="w-6 h-6 fill-white" />
                ) : (
                  <Play className="w-6 h-6 fill-white ml-0.5" />
                )}
              </button>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                  currentTrack.source === 'spotify' 
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-red-950 text-red-400 border border-red-500/30'
                }`}>
                  {currentTrack.source === 'spotify' ? '🟢 Spotify Live' : '🔴 YouTube Music'}
                </span>
                {playingTrackId === currentTrack.id && (
                  <span className="flex items-center gap-1 text-[10px] text-[#25f4ee] font-black animate-pulse">
                    <Volume2 className="w-3 h-3" /> আসল গান বাজছে... 🎵
                  </span>
                )}
              </div>
              <h4 className="font-black text-xs sm:text-sm text-white truncate mt-1">
                {currentTrack.title}
              </h4>
              <p className="text-[11px] text-zinc-400 truncate">
                {currentTrack.artist} • {currentTrack.duration}
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Volume Slider Toggle */}
              <button
                type="button"
                onClick={() => setShowVolumeSlider(!showVolumeSlider)}
                className={`p-2.5 rounded-2xl transition-all cursor-pointer ${
                  showVolumeSlider ? 'bg-[#fe2c55] text-white' : 'bg-zinc-800 text-zinc-300 hover:text-white'
                }`}
                title="সাউন্ড ভলিউম নিয়ন্ত্রণ"
              >
                <Sliders className="w-4 h-4" />
              </button>

              {/* Bookmark Sound */}
              <button
                type="button"
                onClick={() => {
                  setIsBookmarked(!isBookmarked);
                  onToast?.(
                    !isBookmarked
                      ? (language === 'bn' ? '✓ গান ফেভারিটে যোগ করা হয়েছে' : '✓ Added to favorites')
                      : (language === 'bn' ? 'ফেভারিট থেকে সরানো হয়েছে' : 'Removed from favorites')
                  );
                }}
                className="p-2.5 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-[#fe2c55] text-[#fe2c55]' : ''}`} />
              </button>
            </div>
          </div>

          {/* Expandable Volume Adjuster */}
          {showVolumeSlider && (
            <div className="mt-3 p-3 rounded-2xl bg-black/80 border border-zinc-800 flex items-center gap-3 animate-in fade-in duration-200">
              <Volume2 className="w-4 h-4 text-[#fe2c55] shrink-0" />
              <span className="text-[11px] font-bold text-zinc-300 shrink-0">
                {language === 'bn' ? 'মিউজিক ভলিউম:' : 'Sound Volume:'} {musicVolume}%
              </span>
              <input
                type="range"
                min="0"
                max="100"
                value={musicVolume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="flex-1 accent-[#fe2c55] h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
              />
            </div>
          )}
        </div>
      )}

      {/* 5. GLOBAL SONGS LIST */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2.5 max-w-xl mx-auto w-full no-scrollbar">
        {displayList.length === 0 ? (
          <div className="p-12 text-center text-zinc-500">
            <Music className="w-12 h-12 mx-auto mb-3 opacity-40 animate-bounce" />
            <p className="text-sm font-bold text-zinc-400">কোনো গান পাওয়া যায়নি</p>
            <p className="text-xs text-zinc-500 mt-1">অন্য কোনো নাম লিখে সার্চ করুন</p>
          </div>
        ) : (
          displayList.map((track) => {
            const isCurrent = currentTrack?.id === track.id;
            const isPlaying = playingTrackId === track.id;

            return (
              <div
                key={track.id}
                onClick={() => togglePreview(track)}
                className={`p-3 rounded-2xl flex items-center justify-between gap-3.5 transition-all cursor-pointer border ${
                  isCurrent
                    ? 'bg-zinc-900 border-[#fe2c55] shadow-xl ring-1 ring-[#fe2c55]/40'
                    : 'bg-zinc-900/60 border-zinc-800/80 hover:bg-zinc-900 hover:border-zinc-700'
                }`}
              >
                {/* Left: Artwork with Play Button (tap plays real sound immediately) */}
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  <div className="relative w-13 h-13 rounded-2xl overflow-hidden shrink-0 border border-white/10 group shadow-md">
                    <img src={track.cover} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePreview(track);
                      }}
                      className="absolute inset-0 bg-black/45 flex items-center justify-center text-white hover:bg-black/25 transition-all cursor-pointer"
                      title="Play Preview"
                    >
                      {isPlaying ? (
                        <Pause className="w-5 h-5 fill-white" />
                      ) : (
                        <Play className="w-5 h-5 fill-white ml-0.5" />
                      )}
                    </button>
                  </div>

                  {/* Middle Info: Song Title & Artist */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${
                        track.source === 'spotify' 
                          ? 'bg-emerald-950 text-emerald-400' 
                          : 'bg-red-950 text-red-400'
                      }`}>
                        {track.source === 'spotify' ? 'Spotify' : 'YouTube'}
                      </span>
                      {isPlaying && (
                        <span className="text-[9px] text-[#25f4ee] font-black flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-[#25f4ee] animate-ping" />
                          বাজছে
                        </span>
                      )}
                    </div>
                    <h5 className="font-black text-xs sm:text-sm text-white truncate mt-1">
                      {track.title}
                    </h5>
                    <p className="text-[11px] text-zinc-400 truncate">
                      {track.artist}
                    </p>
                    <span className="text-[9px] text-zinc-500 font-mono">
                      {track.duration} • {(track.usesCount / 1000).toFixed(0)}K ভিডিও তৈরি
                    </span>
                  </div>
                </div>

                {/* Right: Red Select / Use Button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelectSound(track);
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 ${
                    isCurrent
                      ? 'bg-gradient-to-r from-[#fe2c55] to-rose-600 text-white shadow-lg active:scale-95'
                      : 'bg-zinc-800 hover:bg-[#fe2c55] hover:text-white text-zinc-300'
                  }`}
                >
                  {language === 'bn' ? 'ব্যবহার করুন' : 'Use'}
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* 6. BOTTOM USE BUTTON (Direct full width action) */}
      {currentTrack && (
        <div className="p-3.5 border-t border-zinc-800 bg-black/95 max-w-xl mx-auto w-full flex items-center gap-3">
          <button
            type="button"
            onClick={() => handleSelectSound(currentTrack)}
            className="flex-1 py-3.5 bg-gradient-to-r from-[#fe2c55] via-rose-600 to-amber-500 hover:brightness-110 active:scale-98 text-white font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-rose-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Check className="w-5 h-5 stroke-[3]" />
            <span className="truncate">
              {language === 'bn' 
                ? `এই মিউজিক ব্যবহার করুন (${currentTrack.title.substring(0, 26)}...)` 
                : `Use Sound for Video (${currentTrack.title.substring(0, 26)}...)`}
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
