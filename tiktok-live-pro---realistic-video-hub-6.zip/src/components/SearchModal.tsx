import React, { useState, useEffect } from 'react';
import { 
  Search, 
  X, 
  TrendingUp, 
  Music, 
  Play, 
  Pause,
  User, 
  Flame, 
  CheckCircle2, 
  Plus, 
  UserCheck, 
  ChevronRight,
  Sparkles,
  Video,
  Share2
} from 'lucide-react';
import { VideoReel, SoundTrack, Creator, AppLanguage } from '../types';
import { mockCreators, mockSoundTracks } from '../data/mockData';
import { searchUnifiedMusic, backgroundMusicManager } from '../services/musicApiService';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  reels: VideoReel[];
  initialQuery?: string;
  onSelectReel: (id: string) => void;
  onSelectSoundForVideo?: (sound: SoundTrack) => void;
  onSelectCreator?: (creator: Creator) => void;
  language: AppLanguage;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  reels,
  initialQuery = '',
  onSelectReel,
  onSelectSoundForVideo,
  onSelectCreator,
  language,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<'all' | 'accounts' | 'sounds' | 'videos'>('all');
  const [onlineMusicResults, setOnlineMusicResults] = useState<SoundTrack[]>([]);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [followedIds, setFollowedIds] = useState<string[]>(['usr-mona']);

  // Fetch online music matches (YouTube API + Spotify) on search query
  useEffect(() => {
    let isCancelled = false;
    if (query.trim().length > 1) {
      searchUnifiedMusic(query.trim()).then(({ spotifyTracks, youtubeTracks }) => {
        if (!isCancelled) {
          setOnlineMusicResults([...spotifyTracks.slice(0, 4), ...youtubeTracks.slice(0, 4)]);
        }
      });
    } else {
      setOnlineMusicResults([]);
    }
    return () => {
      isCancelled = true;
    };
  }, [query]);

  // Clean audio on close
  useEffect(() => {
    if (!isOpen) {
      backgroundMusicManager.pause();
      setPlayingAudioId(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const cleanQuery = query.toLowerCase().trim();

  // 1. Matched Creators: verified / authentic accounts prioritized
  const allKnownCreators: Creator[] = Object.values(mockCreators);
  const matchedCreators = cleanQuery
    ? allKnownCreators.filter(
        (c) =>
          c.name.toLowerCase().includes(cleanQuery) ||
          c.handle.toLowerCase().includes(cleanQuery) ||
          c.bio.toLowerCase().includes(cleanQuery)
      )
    : [];

  // Sort: Exact handle/name match & verified at the very top (আসল আইডি সবার উপরে থাকবে)
  matchedCreators.sort((a, b) => {
    const aExact =
      a.handle.toLowerCase() === cleanQuery || a.name.toLowerCase() === cleanQuery;
    const bExact =
      b.handle.toLowerCase() === cleanQuery || b.name.toLowerCase() === cleanQuery;
    if (aExact && !bExact) return -1;
    if (!aExact && bExact) return 1;
    if (a.verified && !b.verified) return -1;
    if (!a.verified && b.verified) return 1;
    return b.followers - a.followers;
  });

  const authenticTopCreator = matchedCreators.length > 0 ? matchedCreators[0] : null;
  const secondaryCreators = matchedCreators.slice(1);

  // 2. Matched Sounds & Songs (from mock and online search)
  const matchedLocalSounds = cleanQuery
    ? mockSoundTracks.filter(
        (s) =>
          s.title.toLowerCase().includes(cleanQuery) ||
          s.artist.toLowerCase().includes(cleanQuery) ||
          s.category.toLowerCase().includes(cleanQuery)
      )
    : [];

  const combinedSounds = [
    ...matchedLocalSounds,
    ...onlineMusicResults.filter((os) => !matchedLocalSounds.some((ms) => ms.id === os.id)),
  ];

  // 3. Matched Reels (by song, caption, tags, creator handle/name)
  const matchedReels = cleanQuery
    ? reels.filter((r) => {
        const matchesSong =
          r.music.title.toLowerCase().includes(cleanQuery) ||
          (r.audioTitle && r.audioTitle.toLowerCase().includes(cleanQuery)) ||
          r.music.artist.toLowerCase().includes(cleanQuery);
        const matchesCreator =
          r.creator.name.toLowerCase().includes(cleanQuery) ||
          r.creator.handle.toLowerCase().includes(cleanQuery);
        const matchesCaption =
          r.caption.toLowerCase().includes(cleanQuery) ||
          r.tags.some((t) => t.toLowerCase().includes(cleanQuery));

        return matchesSong || matchesCreator || matchesCaption;
      })
    : [];

  // Videos specifically using the searched sound
  const videosWithThisSound = cleanQuery
    ? reels.filter(
        (r) =>
          r.music.title.toLowerCase().includes(cleanQuery) ||
          (r.audioTitle && r.audioTitle.toLowerCase().includes(cleanQuery)) ||
          (r.creator.handle.toLowerCase().includes(cleanQuery) && r.audioTitle)
      )
    : [];

  // User Request: গানে ক্লিক করে ভিডিও সহ গান প্লে হবে
  const handlePlaySoundWithVideo = (sound: SoundTrack) => {
    backgroundMusicManager.pause();
    setPlayingAudioId(null);
    const sTitle = sound.title.toLowerCase();
    const matchingReel = reels.find(
      (r) =>
        r.music.id === sound.id ||
        (r.audioId && r.audioId === sound.id) ||
        r.music.title.toLowerCase().includes(sTitle) ||
        (r.audioTitle && r.audioTitle.toLowerCase().includes(sTitle))
    );

    if (matchingReel) {
      onSelectReel(matchingReel.id);
      onClose();
    } else if (reels.length > 0) {
      onSelectReel(reels[0].id);
      onClose();
    }
  };

  const handleToggleAudioPreview = (sound: SoundTrack) => {
    if (playingAudioId === sound.id) {
      backgroundMusicManager.pause();
      setPlayingAudioId(null);
    } else {
      backgroundMusicManager.playTrack(sound);
      setPlayingAudioId(sound.id);
    }
  };

  const handleToggleFollow = (creatorId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFollowedIds((prev) =>
      prev.includes(creatorId) ? prev.filter((id) => id !== creatorId) : [...prev, creatorId]
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950 text-white flex flex-col p-0 select-none animate-in fade-in duration-200">
      {/* Top Search Bar */}
      <div className="px-4 pt-3 pb-2 border-b border-zinc-800 bg-zinc-950/95 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="flex-1 relative flex items-center">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={query}
              autoFocus
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                language === 'bn'
                  ? 'যেকোনো গান, শিল্পী বা আইডির নাম খুঁজুন...'
                  : 'Search any song, artist, username...'
              }
              className="w-full pl-10 pr-9 py-2.5 bg-zinc-900 border border-zinc-700/80 rounded-full text-xs sm:text-sm text-white placeholder-zinc-500 outline-none focus:border-[#fe2c55] shadow-inner"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3 w-4 h-4 rounded-full bg-zinc-700 flex items-center justify-center text-zinc-300 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
          <button
            onClick={() => {
              backgroundMusicManager.pause();
              onClose();
            }}
            className="text-xs font-black text-[#fe2c55] hover:brightness-125 px-2 py-1 cursor-pointer transition-all"
          >
            {language === 'bn' ? 'বাতিল' : 'Cancel'}
          </button>
        </div>

        {/* Filter Navigation Tabs */}
        {cleanQuery && (
          <div className="flex items-center gap-4 mt-3 pt-1 border-t border-zinc-800/60 text-xs font-bold text-zinc-400">
            <button
              onClick={() => setActiveTab('all')}
              className={`pb-1.5 transition-all cursor-pointer ${
                activeTab === 'all'
                  ? 'text-white border-b-2 border-[#fe2c55] font-black'
                  : 'hover:text-zinc-200'
              }`}
            >
              {language === 'bn' ? 'সব (Top)' : 'Top'}
            </button>
            <button
              onClick={() => setActiveTab('accounts')}
              className={`pb-1.5 transition-all cursor-pointer ${
                activeTab === 'accounts'
                  ? 'text-white border-b-2 border-[#fe2c55] font-black'
                  : 'hover:text-zinc-200'
              }`}
            >
              {language === 'bn' ? 'আইডি ও ইউজার' : 'Accounts'} ({matchedCreators.length})
            </button>
            <button
              onClick={() => setActiveTab('sounds')}
              className={`pb-1.5 transition-all cursor-pointer ${
                activeTab === 'sounds'
                  ? 'text-white border-b-2 border-[#fe2c55] font-black'
                  : 'hover:text-zinc-200'
              }`}
            >
              {language === 'bn' ? 'গান ও সাউন্ড' : 'Sounds'} ({combinedSounds.length})
            </button>
            <button
              onClick={() => setActiveTab('videos')}
              className={`pb-1.5 transition-all cursor-pointer ${
                activeTab === 'videos'
                  ? 'text-white border-b-2 border-[#fe2c55] font-black'
                  : 'hover:text-zinc-200'
              }`}
            >
              {language === 'bn' ? 'ভিডিও' : 'Videos'} ({matchedReels.length})
            </button>
          </div>
        )}
      </div>

      {/* Main Search Results Area */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-5 no-scrollbar">
        {cleanQuery ? (
          <>
            {/* ========================================================================= */}
            {/* 1. AUTHENTIC USER CARD (User request: আসল আইডি সবার উপরে থাকবে) */}
            {/* ========================================================================= */}
            {(activeTab === 'all' || activeTab === 'accounts') && authenticTopCreator && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-black tracking-wider uppercase text-emerald-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    {language === 'bn' ? 'আসল আইডি (Official Account)' : 'Official Account'}
                  </span>
                </div>

                <div
                  onClick={() => {
                    onSelectCreator?.(authenticTopCreator);
                    onClose();
                  }}
                  className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-700/80 rounded-2xl p-4 shadow-xl hover:border-zinc-500 transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={authenticTopCreator.avatar}
                          alt=""
                          className="w-14 h-14 rounded-full object-cover border-2 border-[#fe2c55] shadow-md"
                        />
                        {authenticTopCreator.verified && (
                          <CheckCircle2 className="w-4 h-4 fill-cyan-400 text-black absolute -bottom-0.5 -right-0.5 shadow-sm" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-black text-sm text-white">
                            {authenticTopCreator.name}
                          </h4>
                          <span className="bg-[#fe2c55]/20 text-[#fe2c55] text-[9px] font-extrabold px-1.5 py-0.2 rounded-full border border-[#fe2c55]/30">
                            VERIFIED
                          </span>
                        </div>
                        <p className="text-xs text-zinc-400 font-semibold">
                          @{authenticTopCreator.handle}
                        </p>
                        <p className="text-[11px] text-zinc-300 mt-1 line-clamp-1">
                          {authenticTopCreator.bio}
                        </p>
                      </div>
                    </div>

                    {/* Follow button */}
                    <button
                      onClick={(e) => handleToggleFollow(authenticTopCreator.id, e)}
                      className={`px-4 py-1.5 rounded-full text-xs font-black transition-all cursor-pointer shadow-md ${
                        followedIds.includes(authenticTopCreator.id)
                          ? 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                          : 'bg-[#fe2c55] hover:bg-[#fe2c55]/90 text-white'
                      }`}
                    >
                      {followedIds.includes(authenticTopCreator.id)
                        ? (language === 'bn' ? 'ফলোয়িং' : 'Following')
                        : (language === 'bn' ? 'ফলো' : 'Follow')}
                    </button>
                  </div>

                  {/* Creator Stats */}
                  <div className="flex items-center gap-4 mt-3 pt-2.5 border-t border-zinc-800/80 text-[11px] text-zinc-400 font-bold">
                    <span>
                      <strong className="text-white font-mono">
                        {(authenticTopCreator.followers / 1000).toFixed(1)}K
                      </strong>{' '}
                      {language === 'bn' ? 'ফলোয়ার' : 'Followers'}
                    </span>
                    <span>
                      <strong className="text-white font-mono">
                        {(authenticTopCreator.likesTotal / 1000).toFixed(0)}K
                      </strong>{' '}
                      {language === 'bn' ? 'লাইক' : 'Likes'}
                    </span>
                    <span className="text-[#25f4ee] ml-auto flex items-center gap-0.5">
                      {language === 'bn' ? 'প্রোফাইল ও ভিডিও দেখুন' : 'View Profile'}
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 2. MATCHING ACCOUNTS LIST (User request: এর পর নিচে লাইন হয়ে ওই নামের আইডি সব সোউ করবে) */}
            {/* ========================================================================= */}
            {(activeTab === 'all' || activeTab === 'accounts') && secondaryCreators.length > 0 && (
              <div>
                <h5 className="text-[11px] font-black uppercase text-zinc-400 tracking-wider mb-2">
                  {language === 'bn' ? 'অনুরূপ আইডি ও প্রোফাইল' : 'Other Matching Accounts'}
                </h5>
                <div className="bg-zinc-900/80 rounded-2xl border border-zinc-800 divide-y divide-zinc-800/60 overflow-hidden">
                  {secondaryCreators.map((creator) => (
                    <div
                      key={creator.id}
                      onClick={() => {
                        onSelectCreator?.(creator);
                        onClose();
                      }}
                      className="p-3 flex items-center justify-between hover:bg-zinc-800/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={creator.avatar}
                          alt=""
                          className="w-10 h-10 rounded-full object-cover border border-zinc-700"
                        />
                        <div>
                          <span className="font-bold text-xs text-white block">
                            {creator.name}
                          </span>
                          <span className="text-[11px] text-zinc-400">@{creator.handle}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-zinc-400">
                          {(creator.followers / 1000).toFixed(0)}K
                        </span>
                        <button
                          onClick={(e) => handleToggleFollow(creator.id, e)}
                          className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer ${
                            followedIds.includes(creator.id)
                              ? 'bg-zinc-800 text-zinc-400'
                              : 'bg-white text-black font-black'
                          }`}
                        >
                          {followedIds.includes(creator.id)
                            ? (language === 'bn' ? 'ফলোয়িং' : 'Following')
                            : (language === 'bn' ? 'ফলো' : 'Follow')}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 3. SOUND CARD & VIDEOS WITH THIS SONG (User request: গান সার্চ করলে ওই গান সহ ভিডিও আসবে, ক্লিক করে ভিডিও সহ গান প্লে হবে) */}
            {/* ========================================================================= */}
            {(activeTab === 'all' || activeTab === 'sounds') && combinedSounds.length > 0 && (
              <div>
                <h5 className="text-[11px] font-black uppercase text-zinc-400 tracking-wider mb-2 flex items-center gap-1.5">
                  <Music className="w-3.5 h-3.5 text-[#25f4ee]" />
                  {language === 'bn' ? 'গান ও সাউন্ড ট্র্যাক (Music & Sounds)' : 'Music & Sounds'}
                </h5>

                <div className="space-y-2.5">
                  {combinedSounds.slice(0, 4).map((sound) => (
                    <div
                      key={sound.id}
                      className="bg-zinc-900 border border-zinc-800 rounded-2xl p-3 flex items-center justify-between gap-3 shadow-md hover:border-zinc-600 transition-all cursor-pointer group"
                      onClick={() => handlePlaySoundWithVideo(sound)}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        {/* Album Cover with Play/Pause button for audio preview */}
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleAudioPreview(sound);
                          }}
                          className="relative w-12 h-12 rounded-xl overflow-hidden shrink-0 cursor-pointer group/cover shadow-inner"
                          title="অডিও প্রিভিউ শুনুন"
                        >
                          <img src={sound.cover} alt="" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover/cover:bg-black/60 transition-colors">
                            {playingAudioId === sound.id ? (
                              <Pause className="w-5 h-5 text-[#fe2c55] fill-[#fe2c55]" />
                            ) : (
                              <Play className="w-5 h-5 text-white fill-white ml-0.5" />
                            )}
                          </div>
                        </div>

                        {/* Song Details - Click to play video with this song */}
                        <div className="overflow-hidden">
                          <h4 className="font-extrabold text-xs text-white truncate group-hover:text-[#25f4ee] transition-colors flex items-center gap-1">
                            <span>{sound.title}</span>
                          </h4>
                          <p className="text-[11px] text-zinc-400 truncate">{sound.artist}</p>
                          <div className="flex items-center gap-2 text-[9px] text-zinc-500 font-mono mt-0.5">
                            <span className="text-[#25f4ee] font-bold">ভিডিওতে বাজবে ▶</span>
                            <span>•</span>
                            <span className="text-zinc-300">
                              {(sound.usesCount / 1000).toFixed(0)}K ভিডিও তৈরি
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right Action Buttons */}
                      <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                        {/* Play Video with Song button */}
                        <button
                          type="button"
                          onClick={() => handlePlaySoundWithVideo(sound)}
                          className="px-2.5 py-1.5 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-[11px] font-bold rounded-xl flex items-center gap-1 cursor-pointer transition-colors border border-white/10"
                          title="গানের ভিডিও প্লে করুন"
                        >
                          <Play className="w-3 h-3 fill-white" />
                          <span>ভিডিও</span>
                        </button>

                        {/* Use Sound Button */}
                        <button
                          type="button"
                          onClick={() => {
                            onSelectSoundForVideo?.(sound);
                            onClose();
                          }}
                          className="px-2.5 py-1.5 bg-[#fe2c55] hover:bg-[#fe2c55]/90 active:scale-95 text-white text-[11px] font-black rounded-xl cursor-pointer shadow-md transition-all"
                          title="এই গান দিয়ে নতুন ভিডিও বানান"
                        >
                          {language === 'bn' ? 'ব্যবহার' : 'Use'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* 4. VIDEOS PLAYLIST (User request: ওই গান সহ ভিডিও আসবে, ক্লিক করে ভিডিও সহ গান প্লে হবে) */}
            {/* ========================================================================= */}
            {(activeTab === 'all' || activeTab === 'videos') && matchedReels.length > 0 && (
              <div>
                <h5 className="text-[11px] font-black uppercase text-zinc-400 tracking-wider mb-2 flex items-center gap-1.5">
                  <Video className="w-3.5 h-3.5 text-[#fe2c55]" />
                  {language === 'bn' ? 'এই গানের ও বিষয়ের ভিডিওসমূহ' : 'Videos with this sound & topic'} ({matchedReels.length})
                </h5>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {matchedReels.map((reel) => (
                    <div
                      key={reel.id}
                      onClick={() => {
                        backgroundMusicManager.pause();
                        onSelectReel(reel.id);
                        onClose();
                      }}
                      className="relative aspect-[9/16] rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 cursor-pointer group shadow-lg hover:border-zinc-600 transition-all"
                    >
                      <img
                        src={reel.posterUrl}
                        alt=""
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent flex flex-col justify-end p-2.5">
                        <div className="flex items-center gap-1 mb-0.5">
                          <span className="text-[11px] font-black text-white truncate">
                            @{reel.creator.handle}
                          </span>
                          {reel.creator.verified && (
                            <CheckCircle2 className="w-3 h-3 fill-cyan-400 text-black shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-zinc-200 line-clamp-1 font-medium">
                          {reel.caption}
                        </p>
                        <div className="flex items-center gap-1 text-[9px] text-[#25f4ee] font-mono mt-1">
                          <Music className="w-2.5 h-2.5 shrink-0 animate-pulse" />
                          <span className="truncate">{reel.audioTitle || reel.music.title}</span>
                        </div>
                      </div>

                      {/* Play overlay badge */}
                      <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 backdrop-blur-xs flex items-center justify-center">
                        <Play className="w-3 h-3 fill-white text-white ml-0.5" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Empty state if nothing matches */}
            {matchedCreators.length === 0 &&
              combinedSounds.length === 0 &&
              matchedReels.length === 0 && (
                <div className="text-center py-16 text-zinc-500">
                  <p className="text-sm font-bold">
                    {language === 'bn'
                      ? `'${query}' দিয়ে কোনো ফলাফল পাওয়া যায়নি`
                      : `No results found for '${query}'`}
                  </p>
                  <span className="text-xs text-zinc-600 mt-1 block">
                    অন্য গান, হ্যাশট্যাগ বা ইউজারনেম দিয়ে আবার সার্চ করুন
                  </span>
                </div>
              )}
          </>
        ) : (
          /* Default Trending Searches & Suggested Topics */
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-black text-white mb-2.5">
                <Flame className="w-4 h-4 text-[#fe2c55]" />
                <span>{language === 'bn' ? 'জনপ্রিয় সার্চ টপিক' : 'Trending Searches'}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  'BAD boy HARSHU',
                  'Mehzabin..',
                  'Automotivo Bibi Fogosa',
                  'Bangla Viral Folk Flute',
                  'Mtg Ensurdecência Estelar',
                  'Brazilian Phonk Remix',
                  'TANI EDITZ',
                  'Mona_yours',
                ].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="px-3.5 py-1.5 rounded-full bg-zinc-900 hover:bg-zinc-800 text-xs text-zinc-300 font-semibold border border-zinc-800 transition-colors cursor-pointer"
                  >
                    🔍 {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Suggested Creators */}
            <div>
              <h5 className="text-[11px] font-black uppercase text-zinc-400 tracking-wider mb-2.5">
                {language === 'bn' ? 'জনপ্রিয় ক্রিয়েটর আইডি' : 'Popular Creators'}
              </h5>
              <div className="grid grid-cols-2 gap-2">
                {allKnownCreators.slice(0, 4).map((c) => (
                  <div
                    key={c.id}
                    onClick={() => {
                      onSelectCreator?.(c);
                      onClose();
                    }}
                    className="bg-zinc-900 p-2.5 rounded-2xl border border-zinc-800 flex items-center gap-2.5 cursor-pointer hover:border-zinc-700"
                  >
                    <img src={c.avatar} alt="" className="w-9 h-9 rounded-full object-cover" />
                    <div className="overflow-hidden">
                      <span className="font-bold text-xs text-white truncate block">
                        {c.name}
                      </span>
                      <span className="text-[10px] text-zinc-400 truncate block">
                        @{c.handle}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
