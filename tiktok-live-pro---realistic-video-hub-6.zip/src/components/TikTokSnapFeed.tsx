import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Heart, 
  MessageCircle, 
  Bookmark, 
  Share2, 
  Music, 
  Volume2, 
  VolumeX, 
  Plus, 
  CheckCircle2, 
  MapPin, 
  RefreshCw,
  Download,
  EyeOff,
  Eye,
  Sliders,
  Flag,
  ArrowDownCircle,
  Subtitles,
  ExternalLink,
  Headphones,
  HelpCircle,
  X,
  Sparkles,
  Zap,
  Copy,
  ChevronLeft,
  ChevronRight,
  Image as ImageIcon,
  Battery,
  BatteryCharging,
  Wifi,
  Gauge,
  Smartphone,
  Radio,
  Check
} from 'lucide-react';
import { VideoReel, SoundTrack, Creator, AppLanguage, TopFeedTab } from '../types';
import { videoCacheManager } from '../services/videoCacheManager';
import { recommendationEngine } from '../services/recommendationEngine';
import { generateSmartSubtitles, calculateEngagementScore, evaluateViralityTier } from '../services/videoAiPipeline';
import { networkQualityService } from '../services/networkQualityService';
import { backgroundMusicManager } from '../services/musicApiService';
import { admobService } from '../services/admobService';
import { NativeFeedAdCard } from './NativeFeedAdCard';

export interface FeedItem {
  id: string;
  type: 'reel' | 'native_ad';
  reel?: VideoReel;
  adIndex?: number;
}

interface TikTokSnapFeedProps {
  reels: VideoReel[];
  activeTopTab: TopFeedTab;
  onOpenCreator: (creator: Creator) => void;
  onOpenSound: (sound: SoundTrack) => void;
  onOpenComments: (reel: VideoReel) => void;
  onOpenShare: (reel: VideoReel) => void;
  onToggleLike: (reelId: string) => void;
  onToggleBookmark: (reelId: string) => void;
  onUseSound: (sound: SoundTrack) => void;
  onCopyLink?: (reel: VideoReel) => void;
  onOpenAlgorithmInsights?: (reel: VideoReel) => void;
  language: AppLanguage;
  formatCount: (num: number) => string;
  onRefreshFeed?: () => void;
  isRefreshing?: boolean;
  isGlobalAudioMuted?: boolean;
  onToggleAudioMute?: () => void;
  onToast?: (msg: string) => void;
}

export const TikTokSnapFeed: React.FC<TikTokSnapFeedProps> = ({
  reels,
  activeTopTab,
  onOpenCreator,
  onOpenSound,
  onOpenComments,
  onOpenShare,
  onToggleLike,
  onToggleBookmark,
  onUseSound,
  onCopyLink,
  onOpenAlgorithmInsights,
  language,
  formatCount,
  onRefreshFeed,
  isRefreshing = false,
  isGlobalAudioMuted = false,
  onToggleAudioMute,
  onToast,
}) => {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [cachedUrls, setCachedUrls] = useState<Record<string, string>>({});
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(isGlobalAudioMuted);
  const [isPlayingMap, setIsPlayingMap] = useState<Record<number, boolean>>({});
  const [floatingHearts, setFloatingHearts] = useState<{ id: string; x: number; y: number }[]>([]);
  const [pullDistance, setPullDistance] = useState<number>(0);

  // Photo Carousel State (User Requirement: চার টা, দুই টা বা একাধিক ছবি ডান থেকে বামে চেপে নিয়ে গেলে পরের ছবি)
  const [photoIndexMap, setPhotoIndexMap] = useState<Record<string, number>>({});
  const photoAudioRefs = useRef<(HTMLAudioElement | null)[]>([]);
  const photoTouchStartX = useRef<number | null>(null);

  // TikTok Half-Sheet & Video Controls State (User Request)
  const [showActionSheet, setShowActionSheet] = useState<boolean>(false);
  const [selectedSpeed, setSelectedSpeed] = useState<number>(1.0);
  const [isClearDisplay, setIsClearDisplay] = useState<boolean>(false);
  const [isAutoScroll, setIsAutoScroll] = useState<boolean>(() => networkQualityService.isAutoScrollEnabled());
  const [showCaptions, setShowCaptions] = useState<boolean>(true); // Default true for cinematic subtitles
  const [isBackgroundAudio, setIsBackgroundAudio] = useState<boolean>(() => networkQualityService.isBackgroundAudioEnabled());
  const [isBatterySaver, setIsBatterySaver] = useState<boolean>(() => networkQualityService.isBatterySaverEnabled());
  const [isDataSaver3G, setIsDataSaver3G] = useState<boolean>(() => networkQualityService.isDataSaver3GEnabled());
  const [isLowEndSmoothMode, setIsLowEndSmoothMode] = useState<boolean>(() => networkQualityService.isLowEndSmoothModeEnabled());
  const [selectedQuality, setSelectedQuality] = useState<'auto' | '1080p' | '480p'>('auto');
  const [networkStatus, setNetworkStatus] = useState<any>(() => networkQualityService.getNetworkStatus());
  const [showWhyThisPostModal, setShowWhyThisPostModal] = useState<boolean>(false);
  const hasTriggeredLongPressRef = useRef<boolean>(false);

  // AdMob Feed Interleaving State (Configurable from Admin Panel: Every N videos)
  const [admobConfig, setAdmobConfig] = useState(() => admobService.getConfig());

  useEffect(() => {
    return admobService.subscribe(() => {
      setAdmobConfig(admobService.getConfig());
    });
  }, []);

  // Interleave reels with Native Ads based on Admin frequency setting (every 4 or 5 videos)
  const feedItems: FeedItem[] = React.useMemo(() => {
    const items: FeedItem[] = [];
    const freq = admobConfig.videosPerNativeAd || 4;
    let adCount = 0;

    reels.forEach((reel, idx) => {
      items.push({ id: reel.id, type: 'reel', reel });
      // In For You feed, inject a Native Ad after every freq videos
      if (activeTopTab === 'foryou' && (idx + 1) % freq === 0) {
        items.push({
          id: `native_ad_slot_${idx}_${adCount}`,
          type: 'native_ad',
          adIndex: adCount,
        });
        adCount++;
      }
    });

    return items;
  }, [reels, activeTopTab, admobConfig.videosPerNativeAd]);

  const activeFeedItem = feedItems[activeIndex] || feedItems[0];
  const activeReel = activeFeedItem?.reel || reels[0] || null;

  // Subtitles & Playback Time Tracking (Gemini Speech-to-Text Synchronizer)
  const [playbackTimeMs, setPlaybackTimeMs] = useState<number>(0);
  const [activeTierToast, setActiveTierToast] = useState<{
    tier: string;
    text: string;
  } | null>(null);

  // Compute current subtitles with 3-4 words per cue
  const currentSubtitles = React.useMemo(() => {
    const currentReel = activeReel;
    if (!currentReel) return [];
    if (currentReel.subtitles && currentReel.subtitles.length > 0) {
      return currentReel.subtitles;
    }
    return generateSmartSubtitles(currentReel.captionBn || currentReel.caption, 15);
  }, [activeReel]);

  const activeCue = React.useMemo(() => {
    if (!currentSubtitles || currentSubtitles.length === 0) return null;
    const found = currentSubtitles.find(
      (c) => playbackTimeMs >= c.startTimeMs && playbackTimeMs <= c.endTimeMs
    );
    return found || currentSubtitles[0];
  }, [currentSubtitles, playbackTimeMs]);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const lastTapRef = useRef<number>(0);
  const singleTapTimerRef = useRef<NodeJS.Timeout | null>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const touchStartY = useRef<number | null>(null);
  const touchStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const watchStartTimeRef = useRef<number>(Date.now());

  // Sync prop changes for mute state
  useEffect(() => {
    setIsAudioMuted(isGlobalAudioMuted);
    const activeVideo = videoRefs.current[activeIndex];
    if (activeVideo) {
      activeVideo.muted = isGlobalAudioMuted;
    }
  }, [isGlobalAudioMuted, activeIndex]);

  // 1. Resolve cached playback URL for active and upcoming videos
  useEffect(() => {
    if (!reels.length) return;

    const currentReel = reels[activeIndex];
    if (currentReel && !cachedUrls[currentReel.videoUrl]) {
      videoCacheManager.getPlaybackUrl(currentReel.videoUrl).then((url) => {
        setCachedUrls((prev) => ({ ...prev, [currentReel.videoUrl]: url }));
      });
    }

    // Preload next videos for zero-buffer instant smooth scrolling
    const upcomingUrls = reels
      .slice(activeIndex + 1, activeIndex + 4)
      .map((r) => r.videoUrl)
      .filter(Boolean);

    if (upcomingUrls.length > 0) {
      videoCacheManager.preloadNextVideos(upcomingUrls);
    }
  }, [activeIndex, reels, cachedUrls]);

  // 2. Play center active video with user-selected speed and mute settings
  useEffect(() => {
    watchStartTimeRef.current = Date.now();

    videoRefs.current.forEach((video, idx) => {
      if (!video) return;

      if (idx === activeIndex) {
        video.currentTime = 0;
        video.muted = isAudioMuted;
        video.playbackRate = selectedSpeed;

        const playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlayingMap((prev) => ({ ...prev, [idx]: true }));
            })
            .catch(() => {
              video.muted = true;
              setIsAudioMuted(true);
              video.play().catch(() => {});
              setIsPlayingMap((prev) => ({ ...prev, [idx]: true }));
            });
        }
      } else {
        video.pause();
        video.currentTime = 0;
        setIsPlayingMap((prev) => ({ ...prev, [idx]: false }));
      }
    });

    // Play/Pause photo mode background audio
    photoAudioRefs.current.forEach((audio, idx) => {
      if (!audio) return;
      if (idx === activeIndex) {
        audio.currentTime = 0;
        audio.muted = isAudioMuted;
        audio.play().catch(() => {});
      } else {
        audio.pause();
        audio.currentTime = 0;
      }
    });

    return () => {
      if (reels[activeIndex]) {
        const watchDurationSec = (Date.now() - watchStartTimeRef.current) / 1000;
        recommendationEngine.trackWatchSession(
          reels[activeIndex].id,
          watchDurationSec,
          15,
          reels[activeIndex].tags,
          reels[activeIndex].creator.id
        );
      }
    };
  }, [activeIndex, reels, isAudioMuted, selectedSpeed]);

  // 3. Ultra-smooth scroll snapping listener
  const handleScroll = useCallback(() => {
    if (!containerRef.current) return;
    const { scrollTop, clientHeight } = containerRef.current;
    if (clientHeight === 0) return;

    const newIndex = Math.round(scrollTop / clientHeight);
    if (newIndex !== activeIndex && newIndex >= 0 && newIndex < feedItems.length) {
      setActiveIndex(newIndex);
    }
  }, [activeIndex, feedItems.length]);

  // 4. Scroll to next or previous video programmatically
  const scrollToReel = (targetIndex: number) => {
    if (!containerRef.current) return;
    const clamped = Math.max(0, Math.min(targetIndex, feedItems.length - 1));
    const targetScrollTop = clamped * containerRef.current.clientHeight;
    containerRef.current.scrollTo({
      top: targetScrollTop,
      behavior: 'smooth',
    });
  };

  // 5. Long Press Detection (Hold for 700ms triggers Half-Sheet smoothly)
  const startLongPress = () => {
    cancelLongPress();
    hasTriggeredLongPressRef.current = false;
    longPressTimerRef.current = setTimeout(() => {
      hasTriggeredLongPressRef.current = true;
      try {
        if (navigator.vibrate) navigator.vibrate(50);
      } catch {}
      setShowActionSheet(true);
    }, 700); // 700ms hold triggers sheet
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  // 6. Double tap to like & Single tap to pause/play (User Request)
  // "এবং শুধু ভিডিওর উপর একবার টাচ করলে ভিডিও বন্ধ হবে দ্বিতীয়বার টাচ করলে ভিডিও চলতে শুরু করবে"
  const handleVideoTap = (e: React.MouseEvent, reel: VideoReel, index: number) => {
    cancelLongPress();

    // If hold/long-press opened the sheet, ignore tap
    if (hasTriggeredLongPressRef.current) {
      hasTriggeredLongPressRef.current = false;
      return;
    }

    // If clear display is active, tapping exits clear display
    if (isClearDisplay) {
      setIsClearDisplay(false);
      return;
    }

    const now = Date.now();
    const DOUBLE_TAP_DELAY = 280;

    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      // Double tap: cancel single-tap play/pause and trigger like
      if (singleTapTimerRef.current) {
        clearTimeout(singleTapTimerRef.current);
        singleTapTimerRef.current = null;
      }

      if (!reel.isLiked) {
        onToggleLike(reel.id);
        recommendationEngine.trackLike(reel, true);
      }
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      const heartId = `hrt-${Date.now()}`;
      setFloatingHearts((prev) => [...prev, { id: heartId, x, y }]);
      setTimeout(() => {
        setFloatingHearts((prev) => prev.filter((h) => h.id !== heartId));
      }, 1800);
    } else {
      // Single tap: toggle play / pause with 230ms debounce
      if (singleTapTimerRef.current) clearTimeout(singleTapTimerRef.current);
      singleTapTimerRef.current = setTimeout(() => {
        const video = videoRefs.current[index];
        if (video) {
          if (video.paused) {
            video.play().catch(() => {});
            setIsPlayingMap((prev) => ({ ...prev, [index]: true }));
          } else {
            video.pause();
            setIsPlayingMap((prev) => ({ ...prev, [index]: false }));
          }
        }
      }, 230);
    }
    lastTapRef.current = now;
  };

  // 7. Touch gestures for smooth scroll and pull-to-refresh
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    touchStartPosRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    startLongPress();
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStartPosRef.current) return;
    const dx = Math.abs(e.touches[0].clientX - touchStartPosRef.current.x);
    const dy = Math.abs(e.touches[0].clientY - touchStartPosRef.current.y);

    // Cancel long press if user moves finger (> 8px)
    if (dx > 8 || dy > 8) {
      cancelLongPress();
    }

    if (touchStartY.current === null || !containerRef.current) return;
    const deltaY = e.touches[0].clientY - touchStartY.current;

    if (containerRef.current.scrollTop === 0 && deltaY > 0) {
      setPullDistance(Math.min(deltaY * 0.4, 60));
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    cancelLongPress();
    if (touchStartY.current !== null) {
      const deltaY = (e.changedTouches?.[0]?.clientY || 0) - touchStartY.current;

      if (deltaY > 60) {
        if (activeIndex > 0) {
          scrollToReel(activeIndex - 1);
        } else if (onRefreshFeed) {
          onRefreshFeed();
        }
      } else if (deltaY < -60) {
        if (activeIndex < reels.length - 1) {
          scrollToReel(activeIndex + 1);
        }
      } else if (pullDistance > 35 && onRefreshFeed) {
        onRefreshFeed();
      }
    }
    touchStartY.current = null;
    touchStartPosRef.current = null;
    setPullDistance(0);
  };

  // 8. Toggle Audio Mute (User Request: উপরের মিউট অপশন)
  const toggleAudio = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onToggleAudioMute) {
      onToggleAudioMute();
      return;
    }
    const nextMuted = !isAudioMuted;
    setIsAudioMuted(nextMuted);
    const activeVideo = videoRefs.current[activeIndex];
    if (activeVideo) {
      activeVideo.muted = nextMuted;
      if (!nextMuted) {
        activeVideo.play().catch(() => {});
      }
    }
    onToast?.(
      nextMuted
        ? (language === 'bn' ? '🔇 সাউন্ড বন্ধ (মিউট)' : '🔇 Muted')
        : (language === 'bn' ? '🔊 সাউন্ড চালু (আসল গান)' : '🔊 Sound On')
    );
  };

  // ==========================================
  // ACTIONS FOR THE TIKTOK LONG-PRESS HALF-SHEET
  // ==========================================

  // 1. Download
  const handleDownload = () => {
    setShowActionSheet(false);
    if (!activeReel) return;
    try {
      const a = document.createElement('a');
      a.href = activeReel.videoUrl;
      a.download = `tiktok_${activeReel.id}.mp4`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      onToast?.(language === 'bn' ? '✓ ভিডিও ডাউনলোড শুরু হয়েছে...' : '✓ Downloading video...');
    } catch {
      window.open(activeReel.videoUrl, '_blank');
    }
  };

  // 2. Not Interested
  const handleNotInterested = () => {
    setShowActionSheet(false);
    scrollToReel(activeIndex + 1);
    onToast?.(
      language === 'bn'
        ? '✓ আগ্রহী নন হিসেবে চিহ্নিত করা হয়েছে। এই ধরণের ভিডিও আর আসবে না।'
        : '✓ Marked as Not Interested'
    );
  };

  // 3. Report
  const handleReport = () => {
    setShowActionSheet(false);
    onToast?.(
      language === 'bn'
        ? '✓ আপনার রিপোর্ট জমা দেওয়া হয়েছে। মডারেশন টিম দ্রুত পর্যালোচনা করবে।'
        : '✓ Report submitted. Thank you for keeping TikTok safe.'
    );
  };

  // 4. Set Playback Speed (0.5x, 1.0x, 1.5x, 2.0x)
  const handleSetSpeed = (speed: number) => {
    setSelectedSpeed(speed);
    const activeVideo = videoRefs.current[activeIndex];
    if (activeVideo) {
      activeVideo.playbackRate = speed;
    }
    onToast?.(language === 'bn' ? `✓ স্পিড ${speed}x সেট করা হয়েছে` : `✓ Speed set to ${speed}x`);
  };

  // 5. Clear Display
  const handleToggleClearDisplay = () => {
    setIsClearDisplay(!isClearDisplay);
    setShowActionSheet(false);
    onToast?.(
      !isClearDisplay
        ? (language === 'bn' ? '✓ ক্লিয়ার ডিসপ্লে চালু (ফিরতে ট্যাপ করুন)' : '✓ Clear display mode enabled')
        : (language === 'bn' ? 'ক্লিয়ার ডিসপ্লে বন্ধ' : 'Clear display disabled')
    );
  };

  // 6. Auto Scroll
  const handleToggleAutoScroll = () => {
    setIsAutoScroll(!isAutoScroll);
    setShowActionSheet(false);
    onToast?.(
      !isAutoScroll
        ? (language === 'bn' ? '✓ অটো স্ক্রল চালু (ভিডিও শেষে পরবর্তী ভিডিও আসবে)' : '✓ Auto-scroll enabled')
        : (language === 'bn' ? 'অটো স্ক্রল বন্ধ করা হয়েছে' : 'Auto-scroll disabled')
    );
  };

  // 7. Captions and Translation
  const handleToggleCaptions = () => {
    setShowCaptions(!showCaptions);
    setShowActionSheet(false);
    onToast?.(
      !showCaptions
        ? (language === 'bn' ? '✓ ক্যাপশন ও অনুবাদ চালু হয়েছে' : '✓ Captions & translation enabled')
        : (language === 'bn' ? 'ক্যাপশন বন্ধ করা হয়েছে' : 'Captions disabled')
    );
  };

  // 8. Picture in Picture
  const handlePictureInPicture = async () => {
    setShowActionSheet(false);
    const activeVideo = videoRefs.current[activeIndex];
    if (activeVideo) {
      try {
        if ((document as any).pictureInPictureElement) {
          await (document as any).exitPictureInPicture();
        } else if ((activeVideo as any).requestPictureInPicture) {
          await (activeVideo as any).requestPictureInPicture();
        }
      } catch (err) {
        onToast?.(language === 'bn' ? 'এই ব্রাউজারে PiP সমর্থিত নয়' : 'PiP not supported');
      }
    }
  };

  // 9. Background Audio
  const handleToggleBackgroundAudio = () => {
    const next = !isBackgroundAudio;
    setIsBackgroundAudio(next);
    networkQualityService.setBackgroundAudio(next);
    onToast?.(
      next
        ? (language === 'bn' ? '✓ ব্যাকগ্রাউন্ড অডিও মিউজিক চালু (অ্যাপ মিনিমাইজ করলেও গান বাজবে)' : '✓ Background audio enabled')
        : (language === 'bn' ? 'ব্যাকগ্রাউন্ড অডিও বন্ধ' : 'Background audio disabled')
    );
  };

  // 10. Battery Optimizer / Saver
  const handleToggleBatterySaver = () => {
    const next = !isBatterySaver;
    setIsBatterySaver(next);
    networkQualityService.setBatterySaver(next);
    onToast?.(
      next
        ? (language === 'bn' ? '🔋 ব্যাটারি অপটিমাইজ মোড সক্রিয় (হালকা সিপিইউ ও দীর্ঘস্থায়ী ব্যাটারি)' : '🔋 Battery Saver Enabled')
        : (language === 'bn' ? 'ব্যাটারি অপটিমাইজ মোড বন্ধ' : 'Battery Saver Disabled')
    );
  };

  // 11. 3G Network & Data Saver Mode for Budget Phones
  const handleToggleDataSaver3G = () => {
    const next = !isDataSaver3G;
    setIsDataSaver3G(next);
    networkQualityService.setDataSaver3G(next);
    networkQualityService.setLowEndSmoothMode(next);
    setIsLowEndSmoothMode(next);
    onToast?.(
      next
        ? (language === 'bn' ? '📶 ডাটা সেভার ও ৩জি মোড চালু! কমদামী ফোনেও স্মুথলি অ্যাপ চলবে' : '📶 3G Network & Data Saver Enabled!')
        : (language === 'bn' ? 'ডাটা সেভার বন্ধ' : 'Data Saver Disabled')
    );
  };

  // 12. Quality selector
  const handleSelectQuality = (q: 'auto' | '1080p' | '480p') => {
    setSelectedQuality(q);
    networkQualityService.setQuality(q === '480p' ? 'data_saver' : q === '1080p' ? '1080p' : 'auto');
    onToast?.(
      language === 'bn'
        ? `✓ কোয়ালিটি: ${q === 'auto' ? 'অটো অ্যাডাপ্টিভ' : q === '1080p' ? '১০৮০পি হাই কোয়ালিটি' : '৪৮০পি ডাটা সেভার ৩জি'}`
        : `✓ Video Quality set to ${q.toUpperCase()}`
    );
  };

  // Background audio keep-alive listener
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && isBackgroundAudio) {
        const activeReel = reels[activeIndex];
        if (activeReel) {
          backgroundMusicManager.playTrack(activeReel.music);
        }
      } else if (!document.hidden && isBackgroundAudio) {
        backgroundMusicManager.stop();
        const activeVideo = videoRefs.current[activeIndex];
        if (activeVideo && isPlayingMap[activeIndex] !== false) {
          activeVideo.play().catch(() => {});
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [isBackgroundAudio, activeIndex, reels, isPlayingMap]);

  // 13. Why This Post
  const handleWhyThisPost = () => {
    setShowActionSheet(false);
    setShowWhyThisPostModal(true);
  };

  return (
    <div 
      className={`relative w-full h-full bg-black select-none overflow-hidden ${isBatterySaver ? 'reduce-motion' : ''}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={startLongPress}
      onMouseMove={cancelLongPress}
      onMouseUp={cancelLongPress}
    >
      {/* Pull to Refresh Indicator at Top */}
      {pullDistance > 0 && (
        <div className="absolute top-12 inset-x-0 z-35 flex items-center justify-center py-2 text-white text-xs font-bold gap-1.5 bg-black/60 backdrop-blur-md pointer-events-none">
          <RefreshCw className={`w-4 h-4 text-[#fe2c55] ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>{isRefreshing ? 'ভিডিও লোড হচ্ছে...' : 'ছেড়ে দিন রিফ্রেশ করার জন্য'}</span>
        </div>
      )}

      {/* Floating Action Buttons: Mute/Unmute & Quick Sheet (User Request) */}
      {!isClearDisplay && (
        <div className="absolute top-14 right-3 z-30 flex items-center gap-2">
          {/* Quick Sheet Button (হোমপেজে ভিডিওর অপশন শীট ওপেন বাটন) */}
          <button
            type="button"
            onClick={() => setShowActionSheet(true)}
            className="px-2.5 py-1 rounded-full bg-black/55 hover:bg-black/80 backdrop-blur-md flex items-center gap-1.5 text-white/95 hover:text-white border border-white/15 active:scale-90 transition-transform cursor-pointer shadow-lg"
            title="কন্ট্রোল শীট (Controls Sheet)"
          >
            <Sliders className="w-3.5 h-3.5 text-[#25f4ee]" />
            <span className="text-[10px] font-black">{language === 'bn' ? 'শীট' : 'Sheet'}</span>
          </button>

          {/* Mute / Unmute Button */}
          <button
            type="button"
            onClick={toggleAudio}
            className="w-8 h-8 rounded-full bg-black/50 hover:bg-black/75 backdrop-blur-md flex items-center justify-center text-white/90 hover:text-white border border-white/10 active:scale-90 transition-transform cursor-pointer"
            title={isAudioMuted ? 'সাউন্ড চালু করুন' : 'সাউন্ড বন্ধ করুন'}
          >
            {isAudioMuted ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#25f4ee]" />
            )}
          </button>
        </div>
      )}

      {/* Clear Display Exit Pill */}
      {isClearDisplay && (
        <div 
          onClick={() => setIsClearDisplay(false)}
          className="absolute top-14 left-1/2 -translate-x-1/2 z-40 px-3.5 py-1 rounded-full bg-black/65 backdrop-blur-md border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer animate-pulse shadow-xl"
        >
          <Eye className="w-3.5 h-3.5 text-[#25f4ee]" />
          <span>{language === 'bn' ? 'স্বাভাবিক ডিসপ্লেতে ফিরতে ট্যাপ করুন' : 'Tap to exit clear display'}</span>
        </div>
      )}

      {/* TikTok Full-Screen Vertical Snapping Container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="w-full h-full overflow-y-scroll snap-y snap-mandatory no-scrollbar"
        style={{ scrollSnapType: 'y mandatory', WebkitOverflowScrolling: 'touch', scrollBehavior: 'smooth' }}
      >
        {feedItems.map((item, idx) => {
          const isCurrent = idx === activeIndex;

          // Render Official AdMob Native Advanced Ad Card after every N videos
          if (item.type === 'native_ad' && item.adIndex !== undefined) {
            return (
              <div
                key={item.id}
                className="w-full h-full snap-start relative flex items-center justify-center bg-black overflow-hidden flex-shrink-0"
                style={{ scrollSnapAlign: 'start', scrollSnapStop: 'always' }}
              >
                <NativeFeedAdCard
                  ad={admobService.getNativeAdForIndex(item.adIndex)}
                  isActive={isCurrent}
                  language={language}
                  onToast={onToast}
                />
              </div>
            );
          }

          const reel = item.reel!;
          const isPlaying = isPlayingMap[idx] !== false;
          const playbackSrc = cachedUrls[reel.videoUrl] || reel.videoUrl;

          return (
            <div
              key={reel.id}
              className="w-full h-full snap-start relative flex items-center justify-center bg-black overflow-hidden flex-shrink-0"
              style={{ scrollSnapAlign: 'start', scrollSnapStop: 'always' }}
            >
              {/* Media Element: Multi-Photo Carousel or Video */}
              {(() => {
                const isPhotoPost = reel.postType === 'photo_carousel' || (Boolean(reel.images && reel.images.length > 0));
                const photoList = isPhotoPost ? (reel.images && reel.images.length > 0 ? reel.images : [reel.posterUrl]) : [];
                const currentPhotoIndex = photoIndexMap[reel.id] || 0;

                if (isPhotoPost) {
                  return (
                    <div 
                      className="relative w-full h-full flex items-center justify-center overflow-hidden select-none"
                      onTouchStart={(e) => {
                        photoTouchStartX.current = e.touches[0].clientX;
                        startLongPress();
                      }}
                      onTouchMove={() => {
                        cancelLongPress();
                      }}
                      onTouchEnd={(e) => {
                        cancelLongPress();
                        if (photoTouchStartX.current !== null) {
                          const deltaX = (e.changedTouches?.[0]?.clientX || 0) - photoTouchStartX.current;
                          // User Requirement: ছবির ডান থেকে বামে চেপে নিয়ে গেলে পরের ছবি এভাবে কাজ করবে
                          if (deltaX < -35) {
                            // Swiped right-to-left: next photo
                            setPhotoIndexMap((prev) => ({
                              ...prev,
                              [reel.id]: Math.min(photoList.length - 1, (prev[reel.id] || 0) + 1),
                            }));
                          } else if (deltaX > 35) {
                            // Swiped left-to-right: prev photo
                            setPhotoIndexMap((prev) => ({
                              ...prev,
                              [reel.id]: Math.max(0, (prev[reel.id] || 0) - 1),
                            }));
                          }
                        }
                      }}
                    >
                      {/* Current Image */}
                      <img
                        src={photoList[currentPhotoIndex] || reel.posterUrl}
                        alt=""
                        className="w-full h-full object-cover transition-transform duration-300 cursor-pointer"
                        onClick={(e) => handleVideoTap(e, reel, idx)}
                      />

                      {/* Photo mode background music element */}
                      <audio
                        ref={(el) => (photoAudioRefs.current[idx] = el)}
                        src={reel.music?.audioUrl || 'https://cdn.freesound.org/previews/536/536108_11537498-lq.mp3'}
                        loop
                        playsInline
                      />

                      {/* Photo mode indicator badge (top right) */}
                      <div className="absolute top-16 right-4 z-20 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white flex items-center gap-1.5 shadow-lg">
                        <ImageIcon className="w-3.5 h-3.5 text-[#25f4ee]" />
                        <span className="text-[11px] font-black font-mono">
                          {currentPhotoIndex + 1}/{photoList.length}
                        </span>
                      </div>

                      {/* Navigation Arrow Left */}
                      {currentPhotoIndex > 0 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPhotoIndexMap((prev) => ({
                              ...prev,
                              [reel.id]: Math.max(0, (prev[reel.id] || 0) - 1),
                            }));
                          }}
                          className="absolute left-2 z-20 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md text-white flex items-center justify-center border border-white/20 shadow-md cursor-pointer active:scale-90 transition-transform"
                        >
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                      )}

                      {/* Navigation Arrow Right */}
                      {currentPhotoIndex < photoList.length - 1 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPhotoIndexMap((prev) => ({
                              ...prev,
                              [reel.id]: Math.min(photoList.length - 1, (prev[reel.id] || 0) + 1),
                            }));
                          }}
                          className="absolute right-2 z-20 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md text-white flex items-center justify-center border border-white/20 shadow-md cursor-pointer active:scale-90 transition-transform"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      )}

                      {/* Pagination Dots Indicator */}
                      {photoList.length > 1 && (
                        <div className="absolute bottom-28 inset-x-0 z-20 flex items-center justify-center gap-1.5 pointer-events-none">
                          {photoList.map((_, pIdx) => (
                            <span
                              key={pIdx}
                              className={`transition-all duration-200 rounded-full ${
                                pIdx === currentPhotoIndex
                                  ? 'w-5 h-1.5 bg-white shadow-xs'
                                  : 'w-1.5 h-1.5 bg-white/40'
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <video
                    ref={(el) => (videoRefs.current[idx] = el)}
                    src={playbackSrc}
                    poster={reel.thumbnailUrl || reel.posterUrl}
                    loop={!isAutoScroll}
                    playsInline
                    preload={isDataSaver3G ? (idx === activeIndex ? 'auto' : 'none') : (Math.abs(idx - activeIndex) <= 1 ? 'auto' : 'none')}
                    onClick={(e) => handleVideoTap(e, reel, idx)}
                    onMouseDown={startLongPress}
                    onMouseUp={cancelLongPress}
                    onTouchStart={(e) => {
                      touchStartY.current = e.touches[0].clientY;
                      startLongPress();
                    }}
                    onTouchMove={cancelLongPress}
                    onTouchEnd={cancelLongPress}
                    onEnded={() => {
                      if (isAutoScroll) {
                        scrollToReel(activeIndex + 1);
                      }
                    }}
                    className={`w-full h-full object-cover cursor-pointer ${isBatterySaver ? 'filter-none' : ''}`}
                  />
                );
              })()}

              {/* Dark Vignette Overlay for Crisp Contrast */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/85 pointer-events-none" />

              {/* Paused Overlay Indicator (Big animated Play button on single tap pause - user can tap to resume) */}
              {!isPlaying && (
                <div 
                  onClick={(e) => {
                    e.stopPropagation();
                    const video = videoRefs.current[idx];
                    if (video) {
                      video.play().catch(() => {});
                      setIsPlayingMap((prev) => ({ ...prev, [idx]: true }));
                    }
                  }}
                  className="absolute z-10 w-20 h-20 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white border border-white/25 cursor-pointer animate-in zoom-in-75 duration-150 shadow-2xl active:scale-90 transition-transform pointer-events-auto"
                  title="চালু করতে ক্লিক করুন (Tap to play)"
                >
                  <Play className="w-10 h-10 ml-1 fill-white" />
                </div>
              )}

              {/* Double Tap Floating Hearts */}
              {isCurrent &&
                floatingHearts.map((h) => (
                  <div
                    key={h.id}
                    style={{ left: `${h.x}%`, top: `${h.y}%` }}
                    className="absolute z-30 pointer-events-none animate-float-heart-2s select-none"
                  >
                    <Heart className="w-24 h-24 text-[#fe2c55] fill-[#fe2c55] drop-shadow-2xl" />
                  </div>
                ))}

              {/* Captions and Translation Overlay (User Feature) */}
              {showCaptions && (
                <div className="absolute left-4 right-18 bottom-32 z-25 p-2 rounded-xl bg-black/75 backdrop-blur-md border border-white/15 text-white animate-in fade-in duration-200">
                  <div className="flex items-center gap-1.5 text-[10px] text-[#25f4ee] font-black uppercase tracking-wider mb-0.5">
                    <Subtitles className="w-3 h-3" />
                    <span>{language === 'bn' ? 'অটো ক্যাপশন ও অনুবাদ' : 'Live Translation'}</span>
                  </div>
                  <p className="text-xs font-semibold text-white leading-snug">
                    {reel.captionBn || reel.caption}
                  </p>
                  <p className="text-[10px] text-zinc-400 font-medium italic mt-0.5">
                    En: {reel.caption}
                  </p>
                </div>
              )}

              {/* BOTTOM METADATA & SCROLLING TICKER (Hidden in Clear Display mode) */}
              {!isClearDisplay && (
                <div className="absolute left-3 right-18 bottom-16 z-20 text-white select-none pointer-events-auto">
                  {/* Creator Handle */}
                  <div
                    onClick={() => onOpenCreator(reel.creator)}
                    className="flex items-center gap-1.5 cursor-pointer hover:opacity-90 transition-opacity w-fit"
                  >
                    <span className="font-black text-sm sm:text-base drop-shadow-md">
                      @{reel.creator.handle}
                    </span>
                    {reel.creator.verified && (
                      <CheckCircle2 className="w-4 h-4 fill-cyan-400 text-black shrink-0" />
                    )}
                    {reel.isPromoted && (
                      <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-[#fe2c55] text-white text-[9px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
                        <Zap className="w-2.5 h-2.5 fill-current" />
                        <span>Sponsored</span>
                      </span>
                    )}
                  </div>

                  {/* Caption */}
                  <p className="text-xs sm:text-sm text-white/95 mt-1 line-clamp-2 drop-shadow-md font-medium leading-tight">
                    {language === 'bn' && reel.captionBn ? reel.captionBn : reel.caption}
                  </p>

                  {/* Location */}
                  {reel.location && (
                    <div className="flex items-center gap-1 text-[11px] text-zinc-300 font-semibold mt-1">
                      <MapPin className="w-3 h-3 text-[#25f4ee]" />
                      <span>{reel.location}</span>
                    </div>
                  )}

                  {/* TikTok Algorithm Reach & Viral Progression Pill */}
                  {reel.algorithmTier && (
                    <button
                      type="button"
                      onClick={() => onOpenAlgorithmInsights?.(reel)}
                      className={`mt-1.5 flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black border backdrop-blur-md shadow-md cursor-pointer transition-all active:scale-95 ${
                        reel.algorithmTier === 'tier_50'
                          ? 'bg-amber-950/80 text-amber-300 border-amber-500/40 hover:bg-amber-900/90'
                          : reel.algorithmTier === 'tier_1000'
                          ? 'bg-sky-950/80 text-sky-300 border-sky-500/40 hover:bg-sky-900/90'
                          : 'bg-rose-950/85 text-rose-300 border-rose-500/50 hover:bg-rose-900/90 animate-pulse'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
                      <span>
                        {reel.algorithmTier === 'tier_50' && (language === 'bn' ? '⚡ অ্যালগরিদম: ৫০ জন অডিয়েন্স টেস্ট' : '⚡ 50 Users Test (Tier 1)')}
                        {reel.algorithmTier === 'tier_1000' && (language === 'bn' ? '🚀 ১,০০০ জনের কাছে সম্প্রসারিত' : '🚀 1,000 Users Reach (Tier 2)')}
                        {(reel.algorithmTier === 'tier_10000' || reel.algorithmTier === 'tier_viral') && (language === 'bn' ? '🔥 ১০,০০০+ ভাইরাল FYP' : '🔥 10,000+ Viral FYP')}
                      </span>
                      <span className="text-[9px] opacity-75 underline ml-1">
                        {language === 'bn' ? 'রিপোর্ট' : 'Insights'}
                      </span>
                    </button>
                  )}

                  {/* SCROLLING TICKER: Track Title & Creator Name */}
                  <div
                    onClick={() => onUseSound(reel.music)}
                    className="flex items-center gap-2 mt-2 w-full max-w-[240px] bg-black/45 hover:bg-black/65 px-2.5 py-1 rounded-full border border-white/15 backdrop-blur-md cursor-pointer active:scale-95 transition-all overflow-hidden"
                    title="এই সাউন্ড ব্যবহার করুন (Reuse Audio)"
                  >
                    <Music className="w-3.5 h-3.5 text-[#25f4ee] animate-pulse shrink-0" />
                    <div className="overflow-hidden whitespace-nowrap flex-1">
                      <div className="animate-marquee flex gap-6 text-[11px] font-bold text-zinc-200">
                        <span>
                          {reel.audioTitle || reel.music.title} - {reel.creator.name} (Original Sound)
                        </span>
                        <span>
                          {reel.audioTitle || reel.music.title} - {reel.creator.name} (Original Sound)
                        </span>
                      </div>
                    </div>
                    <span
                      className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded-full shrink-0 ${
                        (reel.audioSource || reel.music.source) === 'spotify'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-950 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {(reel.audioSource || reel.music.source) === 'spotify' ? 'Spotify' : 'YouTube'}
                    </span>
                  </div>
                </div>
              )}

              {/* RIGHT SIDE ACTIONS (Hidden in Clear Display mode) */}
              {!isClearDisplay && (
                <div className="absolute right-2 sm:right-3 bottom-18 z-20 flex flex-col items-center gap-3.5 text-white select-none pointer-events-auto">
                  {/* 1. Creator Profile Avatar */}
                  <div className="relative mb-0.5">
                    <div
                      onClick={() => onOpenCreator(reel.creator)}
                      className="w-11 h-11 rounded-full border-2 border-white overflow-hidden shadow-lg cursor-pointer hover:scale-105 active:scale-95 transition-transform"
                    >
                      <img
                        src={reel.creator.avatar}
                        alt={reel.creator.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {!reel.creator.isFollowed && (
                      <button
                        onClick={() => onOpenCreator(reel.creator)}
                        className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-4.5 h-4.5 rounded-full bg-[#fe2c55] text-white flex items-center justify-center shadow-md active:scale-90 transition-transform cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5 stroke-[3]" />
                      </button>
                    )}
                  </div>

                  {/* 2. Like Button */}
                  <button
                    onClick={() => onToggleLike(reel.id)}
                    className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                  >
                    <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
                      <Heart
                        className={`w-6 h-6 transition-colors ${
                          reel.isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : 'text-white'
                        }`}
                      />
                    </div>
                    <span className="text-[11px] font-black font-mono drop-shadow-md">
                      {formatCount(reel.likesCount)}
                    </span>
                  </button>

                  {/* 3. Comments Button */}
                  <button
                    onClick={() => onOpenComments(reel)}
                    className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                  >
                    <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
                      <MessageCircle className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[11px] font-black font-mono drop-shadow-md">
                      {formatCount(reel.commentsCount)}
                    </span>
                  </button>

                  {/* 4. Bookmark Button */}
                  <button
                    onClick={() => onToggleBookmark(reel.id)}
                    className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                  >
                    <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
                      <Bookmark
                        className={`w-6 h-6 transition-colors ${
                          reel.isBookmarked ? 'fill-amber-400 text-amber-400' : 'text-white'
                        }`}
                      />
                    </div>
                    <span className="text-[11px] font-black font-mono drop-shadow-md">
                      {formatCount(reel.bookmarksCount)}
                    </span>
                  </button>

                  {/* 5. Share Button */}
                  <button
                    onClick={() => onOpenShare(reel)}
                    className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                  >
                    <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
                      <Share2 className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[11px] font-black font-mono drop-shadow-md">
                      {formatCount(reel.sharesCount)}
                    </span>
                  </button>

                  {/* 5.5 Unlimited Copy Link Button */}
                  <button
                    onClick={() => {
                      try {
                        navigator.clipboard?.writeText(window.location.origin + '/video/' + reel.id);
                      } catch {}
                      onCopyLink?.(reel);
                      onToast?.(
                        language === 'bn' 
                          ? '✓ ভিডিওর লিংক আনলিমিটেড কপি করা হয়েছে!' 
                          : '✓ Unlimited video link copied!'
                      );
                    }}
                    className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                    title="লিংক কপি করুন (Copy Link)"
                  >
                    <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
                      <Copy className="w-5 h-5 text-[#25f4ee]" />
                    </div>
                    <span className="text-[10px] font-black font-mono drop-shadow-md text-[#25f4ee]">
                      {language === 'bn' ? 'কপি' : 'Copy'}
                    </span>
                  </button>

                  {/* 6. ROTATING MUSIC DISC & AUDIO REUSE */}
                  <div
                    onClick={() => onUseSound(reel.music)}
                    className="relative mt-2 cursor-pointer group active:scale-90 transition-transform"
                    title="এই সাউন্ড ব্যবহার করুন (Reuse Audio)"
                  >
                    <span className="absolute -top-3 -left-2 text-[11px] text-[#25f4ee] font-black pointer-events-none animate-music-note">
                      ♪
                    </span>
                    <span
                      className="absolute -top-5 left-1 text-[10px] text-[#fe2c55] font-black pointer-events-none animate-music-note"
                      style={{ animationDelay: '1.2s' }}
                    >
                      ♫
                    </span>

                    <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-black via-zinc-900 to-black border-2 border-zinc-700/80 p-2 flex items-center justify-center shadow-2xl animate-spin-slow">
                      <div className="w-full h-full rounded-full overflow-hidden border border-zinc-800">
                        <img
                          src={reel.audioThumbnailUrl || reel.music.cover}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-4.5 h-4.5 rounded-full bg-[#fe2c55] flex items-center justify-center text-white text-[9px] shadow-lg border border-black">
                      <Music className="w-2.5 h-2.5" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 2-SECOND LONG-PRESS HALF-SHEET (User Request: টিকটকের মতো অর্ধেক স্ক্রিন সিট) */}
      {/* ========================================================================= */}
      {showActionSheet && (
        <div 
          onClick={() => setShowActionSheet(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center select-none animate-in fade-in duration-200"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md max-h-[58vh] bg-zinc-950/95 border-t border-zinc-800 rounded-t-3xl shadow-2xl p-4 text-white overflow-y-auto no-scrollbar animate-in slide-in-from-bottom duration-250 space-y-4"
          >
            {/* Top Handle Bar */}
            <div className="w-12 h-1 bg-zinc-700 hover:bg-zinc-500 rounded-full mx-auto cursor-pointer" onClick={() => setShowActionSheet(false)} />

            {/* Quick Top Actions: Download | Not Interested | Report */}
            <div className="grid grid-cols-3 gap-3 border-b border-zinc-850 pb-3.5">
              {/* 1. Download */}
              <button
                type="button"
                onClick={handleDownload}
                className="flex flex-col items-center gap-1.5 p-2 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-200 hover:text-white transition-all cursor-pointer active:scale-95"
              >
                <div className="w-11 h-11 rounded-full bg-zinc-800 flex items-center justify-center text-white shadow-md">
                  <Download className="w-5 h-5 stroke-[2.3]" />
                </div>
                <span className="text-[11px] font-bold">
                  {language === 'bn' ? 'ডাউনলোড' : 'Download'}
                </span>
              </button>

              {/* 2. Not interested */}
              <button
                type="button"
                onClick={handleNotInterested}
                className="flex flex-col items-center gap-1.5 p-2 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-200 hover:text-white transition-all cursor-pointer active:scale-95"
              >
                <div className="w-11 h-11 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-300 shadow-md">
                  <EyeOff className="w-5 h-5 stroke-[2.3]" />
                </div>
                <span className="text-[11px] font-bold">
                  {language === 'bn' ? 'আগ্রহী নই' : 'Not interested'}
                </span>
              </button>

              {/* 3. Report */}
              <button
                type="button"
                onClick={handleReport}
                className="flex flex-col items-center gap-1.5 p-2 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-200 hover:text-white transition-all cursor-pointer active:scale-95"
              >
                <div className="w-11 h-11 rounded-full bg-zinc-800 flex items-center justify-center text-rose-400 shadow-md">
                  <Flag className="w-5 h-5 stroke-[2.3]" />
                </div>
                <span className="text-[11px] font-bold">
                  {language === 'bn' ? 'রিপোর্ট' : 'Report'}
                </span>
              </button>
            </div>

            {/* 4. Speed 0.5 1.0 1.5 2.0 (User Request) */}
            <div className="p-3 rounded-2xl bg-zinc-900/90 border border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-zinc-300">
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-[#25f4ee]" />
                  <span>{language === 'bn' ? 'প্লেব্যাক স্পিড' : 'Playback Speed'}</span>
                </span>
                <span className="text-[#25f4ee] font-mono font-black">{selectedSpeed}x</span>
              </div>
              <div className="grid grid-cols-4 gap-2 pt-1">
                {[0.5, 1.0, 1.5, 2.0].map((spd) => (
                  <button
                    key={spd}
                    type="button"
                    onClick={() => handleSetSpeed(spd)}
                    className={`py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      selectedSpeed === spd
                        ? 'bg-gradient-to-r from-[#fe2c55] to-amber-500 text-white shadow-md shadow-rose-600/30'
                        : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>

            {/* Line-by-Line Core Controls (User Request: সুন্দর করে লাইন হয়ে সাজিয়ে টিকটকের মতো) */}
            <div className="space-y-2">
              
              {/* LINE 1: ব্যাকগ্রাউন্ড অডিও মিউজিক (Background Audio) */}
              <button
                type="button"
                onClick={handleToggleBackgroundAudio}
                className="w-full p-3 rounded-2xl bg-zinc-900/80 hover:bg-zinc-900 border border-zinc-800/80 flex items-center justify-between transition-all cursor-pointer active:scale-[0.99] group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-purple-950/70 text-purple-400 border border-purple-500/30 flex items-center justify-center shadow-xs">
                    <Headphones className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-black text-white">
                        {language === 'bn' ? 'ব্যাকগ্রাউন্ড অডিও মিউজিক' : 'Background Audio Music'}
                      </p>
                      <span className="text-[9px] font-bold text-purple-400 bg-purple-950/80 px-1.5 py-0.2 rounded-full border border-purple-500/20">
                        TikTok Music
                      </span>
                    </div>
                    <p className="text-[10px] text-zinc-400 leading-tight mt-0.5">
                      {language === 'bn' ? 'ডিসপ্লে বন্ধ বা অ্যাপ মিনিমাইজ করলেও ব্যাকগ্রাউন্ডে গান চলবে' : 'Keep audio playing when minimized or screen locked'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-full border transition-all ${
                    isBackgroundAudio 
                      ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-600/30' 
                      : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                  }`}>
                    {isBackgroundAudio ? 'ON' : 'OFF'}
                  </span>
                </div>
              </button>

              {/* LINE 2: অটো স্ক্রল (Auto Scroll) */}
              <button
                type="button"
                onClick={handleToggleAutoScroll}
                className="w-full p-3 rounded-2xl bg-zinc-900/80 hover:bg-zinc-900 border border-zinc-800/80 flex items-center justify-between transition-all cursor-pointer active:scale-[0.99] group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-cyan-950/70 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shadow-xs">
                    <ArrowDownCircle className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-black text-white">
                        {language === 'bn' ? 'অটো স্ক্রল' : 'Auto Scroll'}
                      </p>
                      <span className="text-[9px] font-bold text-cyan-400 bg-cyan-950/80 px-1.5 py-0.2 rounded-full border border-cyan-500/20">
                        Hands-Free
                      </span>
                    </div>
                    <p className="text-[10px] text-zinc-400 leading-tight mt-0.5">
                      {language === 'bn' ? 'একটি ভিডিও শেষ হলে নিজে থেকেই নিচের পরবর্তী ভিডিও চলবে' : 'Automatically advances to next video when ended'}
                    </p>
                  </div>
                </div>
                <span className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-full border transition-all ${
                  isAutoScroll 
                    ? 'bg-cyan-600 text-white border-cyan-400 shadow-md shadow-cyan-600/30' 
                    : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                }`}>
                  {isAutoScroll ? 'ON' : 'OFF'}
                </span>
              </button>

              {/* LINE 3: ব্যাটারি অপটিমাইজ / ব্যাটারি সেভার (Battery Saver Mode) */}
              <button
                type="button"
                onClick={handleToggleBatterySaver}
                className="w-full p-3 rounded-2xl bg-zinc-900/80 hover:bg-zinc-900 border border-zinc-800/80 flex items-center justify-between transition-all cursor-pointer active:scale-[0.99] group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-950/70 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-xs">
                    <BatteryCharging className="w-5 h-5 stroke-[2.2]" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-black text-white">
                        {language === 'bn' ? 'ব্যাটারি অপটিমাইজ ও ব্যাটারি সেভার' : 'Battery Optimize & Saver'}
                      </p>
                      <span className="text-[9px] font-bold text-amber-400 bg-amber-950/80 px-1.5 py-0.2 rounded-full border border-amber-500/20">
                        Eco Power
                      </span>
                    </div>
                    <p className="text-[10px] text-zinc-400 leading-tight mt-0.5">
                      {language === 'bn' ? 'সিপিইউ ও ব্যাটারি সেভ মোড, কমদামী ফোনে ফোন ঠান্ডা ও মসৃণ রাখবে' : 'Lightweight rendering saves battery & reduces CPU heat'}
                    </p>
                  </div>
                </div>
                <span className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-full border transition-all ${
                  isBatterySaver 
                    ? 'bg-amber-600 text-white border-amber-400 shadow-md shadow-amber-600/30' 
                    : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                }`}>
                  {isBatterySaver ? 'ON' : 'OFF'}
                </span>
              </button>

              {/* LINE 4: ডাটা সেভার ও ৩জি নেটওয়ার্ক মোড (Data Saver & 3G Low-Phone Mode) */}
              <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 space-y-2">
                <div 
                  onClick={handleToggleDataSaver3G}
                  className="flex items-center justify-between cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-sky-950/70 text-sky-400 border border-sky-500/30 flex items-center justify-center shadow-xs">
                      <Wifi className="w-5 h-5 stroke-[2.2]" />
                    </div>
                    <div className="text-left">
                      <div className="flex items-center gap-1.5">
                        <p className="text-xs font-black text-white">
                          {language === 'bn' ? 'ডাটা সেভার ও ৩জি নেটওয়ার্ক অপটিমাইজার' : 'Data Saver & 3G Network Mode'}
                        </p>
                        <span className="text-[9px] font-bold text-sky-400 bg-sky-950/80 px-1.5 py-0.2 rounded-full border border-sky-500/20">
                          3G Smooth
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-400 leading-tight mt-0.5">
                        {language === 'bn' ? 'থ্রি জি নেট থেকে শুরু কমদামী ফোনেও স্মুথলি অ্যাপস চলবে' : 'Ultra-smooth streaming on 3G and budget smartphones'}
                      </p>
                    </div>
                  </div>
                  <span className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-full border transition-all ${
                    isDataSaver3G 
                      ? 'bg-sky-600 text-white border-sky-400 shadow-md shadow-sky-600/30' 
                      : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                  }`}>
                    {isDataSaver3G ? 'ON' : 'OFF'}
                  </span>
                </div>

                {/* Network Awareness Status Bar */}
                <div className="flex items-center justify-between pt-1 text-[10px] border-t border-zinc-800/70">
                  <span className="text-zinc-400 flex items-center gap-1.5">
                    <Radio className="w-3 h-3 text-sky-400 animate-pulse" />
                    <span>নেটওয়ার্ক: <strong>{networkStatus?.effectiveType?.toUpperCase() || '3G/4G'}</strong> (স্মার্ট অ্যাডাপ্টিভ মোড সক্রিয়)</span>
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">বাফারলেস ✓</span>
                </div>
              </div>

              {/* LINE 5: ভিডিও কোয়ালিটি অ্যাডাপ্টার (Adaptive Video Quality Selector) */}
              <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-emerald-400" />
                    <span className="font-bold text-white">
                      {language === 'bn' ? 'ভিডিও কোয়ালিটি রেজুলেশন' : 'Video Resolution Quality'}
                    </span>
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono">
                    {selectedQuality === 'auto' ? 'অটো' : selectedQuality === '1080p' ? '1080p HD' : '480p 3G'}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-0.5">
                  {[
                    { id: 'auto', label: '⚡ অটো অ্যাডাপ্টিভ', desc: 'নেট অনুযায়ী অটো' },
                    { id: '1080p', label: '💎 হাই HD (1080p)', desc: 'ফুল ক্রিস্প ও শার্প' },
                    { id: '480p', label: '🍃 ৩জি ডাটা সেভার', desc: 'কমদামী ফোনে স্মুথ' },
                  ].map((q) => {
                    const isSel = selectedQuality === q.id;
                    return (
                      <button
                        key={q.id}
                        type="button"
                        onClick={() => handleSelectQuality(q.id as any)}
                        className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                          isSel
                            ? 'bg-emerald-950/80 border-emerald-500/50 text-white ring-1 ring-emerald-500'
                            : 'bg-zinc-850 border-zinc-750 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        <span className="text-[11px] font-black block truncate">{q.label}</span>
                        <span className="text-[9px] text-zinc-500 block truncate mt-0.5">{q.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* LINE 6: ক্লিয়ার ডিসপ্লে (Clear Display) */}
              <button
                type="button"
                onClick={handleToggleClearDisplay}
                className="w-full p-2.5 rounded-xl bg-zinc-900/60 hover:bg-zinc-900 flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-300">
                    <Eye className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-white">
                      {language === 'bn' ? 'ক্লিয়ার ডিসপ্লে' : 'Clear display'}
                    </p>
                    <p className="text-[10px] text-zinc-400">
                      {language === 'bn' ? 'সকল বাটন ও লেখা লুকিয়ে ফুলস্ক্রিন সিনেমাটিক দেখুন' : 'Hide buttons and captions for clean view'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-full border border-cyan-500/20">
                  {isClearDisplay ? 'ON' : 'OFF'}
                </span>
              </button>

              {/* LINE 7: ক্যাপশন ও অনুবাদ (Captions & Translation) */}
              <button
                type="button"
                onClick={handleToggleCaptions}
                className="w-full p-2.5 rounded-xl bg-zinc-900/60 hover:bg-zinc-900 flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-300">
                    <Subtitles className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-white">
                      {language === 'bn' ? 'ক্যাপশন ও লাইভ অনুবাদ' : 'Captions and translation'}
                    </p>
                    <p className="text-[10px] text-zinc-400">
                      {language === 'bn' ? 'স্ক্রিনে সিনেমাটিক বাংলা ও ইংরেজি সাবটাইটেল' : 'Show subtitles and translations'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-full border border-cyan-500/20">
                  {showCaptions ? 'ON' : 'OFF'}
                </span>
              </button>

              {/* LINE 8: পিকচার ইন পিকচার (Picture in Picture) */}
              <button
                type="button"
                onClick={handlePictureInPicture}
                className="w-full p-2.5 rounded-xl bg-zinc-900/60 hover:bg-zinc-900 flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-300">
                    <ExternalLink className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-white">
                      {language === 'bn' ? 'পিকচার ইন পিকচার (PiP)' : 'Picture in picture'}
                    </p>
                    <p className="text-[10px] text-zinc-400">
                      {language === 'bn' ? 'ভাসমান ছোট উইন্ডোতে ভিডিও চালু রাখুন' : 'Mini floating player window'}
                    </p>
                  </div>
                </div>
              </button>

              {/* LINE 9: কেন এই পোস্ট? (Why this post - Algorithm Transparency) */}
              <button
                type="button"
                onClick={handleWhyThisPost}
                className="w-full p-2.5 rounded-xl bg-zinc-900/60 hover:bg-zinc-900 flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-amber-400">
                    <HelpCircle className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-white">
                      {language === 'bn' ? 'কেন এই পোস্ট?' : 'Why this post'}
                    </p>
                    <p className="text-[10px] text-zinc-400">
                      {language === 'bn' ? 'ফর ইউ অ্যালগরিদম কেন এই ভিডিওটি সুপারিশ করেছে' : 'Why TikTok FYP recommended this video'}
                    </p>
                  </div>
                </div>
                <span className="text-xs text-zinc-400">➔</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* WHY THIS POST MODAL (Algorithm Transparency) */}
      {/* ========================================================================= */}
      {showWhyThisPostModal && (
        <div 
          onClick={() => setShowWhyThisPostModal(false)}
          className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-3xl p-5 text-white shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-zinc-850 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#fe2c55] to-amber-500 flex items-center justify-center text-white">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h4 className="font-black text-sm text-white">
                  {language === 'bn' ? 'কেন এই পোস্ট দেখানো হয়েছে?' : 'Why this post was recommended'}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowWhyThisPostModal(false)}
                className="w-7 h-7 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-zinc-300">
              <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-start gap-2.5">
                <Zap className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-white">
                    {language === 'bn' ? 'দর্শকের ইতিবাচক রেসপন্স' : 'High Viewer Retention'}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    {language === 'bn' 
                      ? 'ভিডিওটি প্রাথমিক ৫০ জনের টেস্ট ব্যাচে ৮৪%+ সম্পূর্ণ দেখা হয়েছে এবং ভালো লাইক পেয়েছে।' 
                      : 'Watched over 84% completion in the initial 50 test users batch.'}
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-start gap-2.5">
                <Music className="w-4 h-4 text-[#25f4ee] shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-white">
                    {language === 'bn' ? 'ট্রেন্ডিং মিউজিক সাউন্ড' : 'Trending Audio'}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    {activeReel.audioTitle || activeReel.music.title} সাউন্ডটি বর্তমানে আপনার অঞ্চলে ভাইরাল।
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#fe2c55] shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-white">
                    {language === 'bn' ? 'আশেপাশের দর্শকদের আগ্রহ' : 'Local Affinity'}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    আপনার লোকেশন ও পছন্দের বিষয়ের সাথে ভিডিওটির কনটেন্ট সাদৃশ্যপূর্ণ।
                  </p>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowWhyThisPostModal(false)}
              className="w-full py-2.5 rounded-2xl bg-white text-black font-black text-xs hover:bg-zinc-200 transition-colors cursor-pointer"
            >
              {language === 'bn' ? 'বুঝেছি' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
