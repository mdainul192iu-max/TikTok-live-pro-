import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Search, Wifi, Battery, Radio, Volume2, VolumeX } from 'lucide-react';
import { TopFeedTab, AppLanguage } from '../types';

interface TopNavigationProps {
  activeTab: TopFeedTab;
  onTabChange: (tab: TopFeedTab) => void;
  onOpenSearch: () => void;
  onOpenLive: () => void;
  language: AppLanguage;
  onToggleLanguage?: () => void;
  isPhoneFrame?: boolean;
  onTogglePhoneFrame?: () => void;
  onSystemBack?: () => void;
  canGoBack?: boolean;
  isAudioMuted?: boolean;
  onToggleAudioMute?: () => void;
}

export const TopNavigation: React.FC<TopNavigationProps> = ({
  activeTab,
  onTabChange,
  onOpenSearch,
  onOpenLive,
  language,
  onSystemBack,
  canGoBack = false,
  isAudioMuted = false,
  onToggleAudioMute,
}) => {
  const [timeStr, setTimeStr] = useState('12:28');
  const [isStatusBarVisible, setIsStatusBarVisible] = useState(false);
  const statusTimerRef = useRef<NodeJS.Timeout | null>(null);
  const topTouchStartY = useRef<number | null>(null);

  const showStatusBar = () => {
    setIsStatusBarVisible(true);
    if (statusTimerRef.current) {
      clearTimeout(statusTimerRef.current);
    }
    // Exactly 2 seconds auto-hide timer as requested!
    statusTimerRef.current = setTimeout(() => {
      setIsStatusBarVisible(false);
    }, 2000);
  };

  const handleTopTouchStart = (e: React.TouchEvent) => {
    topTouchStartY.current = e.touches[0].clientY;
  };

  const handleTopTouchMove = (e: React.TouchEvent) => {
    if (topTouchStartY.current !== null) {
      const deltaY = e.touches[0].clientY - topTouchStartY.current;
      if (deltaY > 6) {
        showStatusBar();
        topTouchStartY.current = null;
      }
    }
  };

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const h = d.getHours().toString().padStart(2, '0');
      const m = d.getMinutes().toString().padStart(2, '0');
      setTimeStr(`${h}:${m}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => {
      clearInterval(interval);
      if (statusTimerRef.current) {
        clearTimeout(statusTimerRef.current);
      }
    };
  }, []);

  return (
    <header className="absolute top-0 left-0 right-0 z-30 flex flex-col pointer-events-auto bg-gradient-to-b from-black/85 via-black/40 to-transparent">
      {/* Top swipe-down trigger area to reveal status bar on pull/touch */}
      <div 
        onTouchStart={handleTopTouchStart}
        onTouchMove={handleTopTouchMove}
        onMouseEnter={showStatusBar}
        onClick={showStatusBar}
        className="absolute top-0 inset-x-0 h-6 z-40 flex items-start justify-center pt-1 cursor-pointer pointer-events-auto select-none group"
        title={language === 'bn' ? 'নোটিফিকেশন বার নামাতে সোয়াইপ করুন (২ সেকেন্ড থাকবে)' : 'Swipe down for status bar (2s)'}
      >
        {!isStatusBarVisible && (
          <div className="w-16 h-1 rounded-full bg-white/30 group-hover:bg-white/80 transition-colors shadow-xs" />
        )}
      </div>

      {/* 1. Android System Status Bar (Hidden by default, slides down for 2s on swipe/touch) */}
      <div className={`transition-all duration-300 ease-in-out overflow-hidden ${
        isStatusBarVisible 
          ? 'max-h-8 opacity-100 translate-y-0 py-1.5' 
          : 'max-h-0 opacity-0 -translate-y-full py-0 pointer-events-none'
      } px-4 flex items-center justify-between text-[11px] font-semibold text-white/95 select-none bg-black/90 backdrop-blur-md border-b border-white/10`}>
        <div className="flex items-center gap-2">
          <span className="font-mono tracking-tight font-bold">{timeStr}</span>
          <span className="text-[9px] text-zinc-400 font-medium">TikTok</span>
        </div>
        <div className="flex items-center gap-2 text-[10px]">
          {/* SIM Signal Bars */}
          <div className="flex items-end gap-0.5 h-2.5">
            <div className="w-0.5 h-1 bg-white rounded-xs" />
            <div className="w-0.5 h-1.5 bg-white rounded-xs" />
            <div className="w-0.5 h-2 bg-white rounded-xs" />
            <div className="w-0.5 h-2.5 bg-white rounded-xs" />
          </div>
          <span className="font-mono text-[9px] text-cyan-400 font-extrabold">5G</span>
          <Wifi className="w-3 h-3 text-white stroke-[2.5]" />
          {/* Battery */}
          <div className="flex items-center gap-1">
            <span className="font-mono text-[9px] font-bold">100%</span>
            <div className="w-4.5 h-2.5 border border-white/90 rounded-xs p-0.5 flex items-center">
              <div className="w-full h-full bg-emerald-400 rounded-xs" />
            </div>
          </div>
        </div>
      </div>

      {/* 2. Top Tabs: STEM | Community | Following | For You, with Search on right */}
      <div className="pt-2 pb-2 px-3 flex items-center justify-between text-white">
        {/* Left: Back button if in modal/subview, or LIVE icon (Exact TikTok layout) */}
        <div className="flex items-center gap-1.5 min-w-[32px]">
          {canGoBack && onSystemBack ? (
            <button
              onClick={onSystemBack}
              className="w-7 h-7 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md flex items-center justify-center text-white transition-all active:scale-90 cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onOpenLive}
              className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/30 hover:bg-black/50 text-white/90 hover:text-white backdrop-blur-xs transition-colors border border-white/10 active:scale-95 cursor-pointer"
              title="TikTok LIVE"
            >
              <Radio className="w-3.5 h-3.5 text-[#fe2c55] animate-pulse" />
              <span className="text-[11px] font-black tracking-wider uppercase">LIVE</span>
            </button>
          )}
        </div>

        {/* Center Tabs: STEM | Community | Following | For You */}
        <div className="flex items-center gap-3 sm:gap-4 text-xs sm:text-sm font-bold tracking-tight">
          <button
            onClick={() => onTabChange('stem')}
            className={`transition-all duration-150 cursor-pointer ${
              activeTab === 'stem'
                ? 'text-white font-black scale-105 border-b-2 border-white pb-0.5'
                : 'text-white/60 hover:text-white/80'
            }`}
          >
            STEM
          </button>
          <button
            onClick={() => onTabChange('community')}
            className={`transition-all duration-150 cursor-pointer ${
              activeTab === 'community'
                ? 'text-white font-black scale-105 border-b-2 border-white pb-0.5'
                : 'text-white/60 hover:text-white/80'
            }`}
          >
            {language === 'bn' ? 'কমিউনিটি' : 'Community'}
          </button>
          <button
            onClick={() => onTabChange('following')}
            className={`transition-all duration-150 cursor-pointer ${
              activeTab === 'following'
                ? 'text-white font-black scale-105 border-b-2 border-white pb-0.5'
                : 'text-white/60 hover:text-white/80'
            }`}
          >
            {language === 'bn' ? 'ফলোয়িং' : 'Following'}
          </button>
          <button
            onClick={() => onTabChange('foryou')}
            className={`transition-all duration-150 cursor-pointer ${
              activeTab === 'foryou'
                ? 'text-white font-black scale-105 border-b-2 border-white pb-0.5'
                : 'text-white/60 hover:text-white/80'
            }`}
          >
            {language === 'bn' ? 'ফর ইউ' : 'For You'}
          </button>
        </div>

        {/* Right: Audio Mute/Unmute & Search Icon */}
        <div className="flex items-center gap-1.5 min-w-[64px] justify-end">
          {onToggleAudioMute && (
            <button
              onClick={onToggleAudioMute}
              className="w-8 h-8 rounded-full bg-black/45 hover:bg-black/70 flex items-center justify-center text-white/95 transition-all active:scale-90 cursor-pointer border border-white/10"
              title={
                isAudioMuted
                  ? language === 'bn'
                    ? 'সাউন্ড চালু করুন (আনমিউট)'
                    : 'Unmute sound'
                  : language === 'bn'
                  ? 'সাউন্ড বন্ধ করুন (মিউট)'
                  : 'Mute sound'
              }
            >
              {isAudioMuted ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-[#25f4ee]" />
              )}
            </button>
          )}

          <button
            onClick={onOpenSearch}
            className="w-8 h-8 rounded-full bg-black/35 hover:bg-black/60 flex items-center justify-center text-white/90 hover:text-white transition-all active:scale-90 cursor-pointer"
            title="Search"
          >
            <Search className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
