import React from 'react';
import { Home, Users, Plus, MessageSquare, User, RefreshCw } from 'lucide-react';
import { NavTab, AppLanguage } from '../types';

interface BottomNavBarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  onOpenUpload: () => void;
  onHomeRefresh?: () => void;
  isHomeRefreshing?: boolean;
  language: AppLanguage;
  userAvatar?: string;
  themeMode?: 'dark' | 'light';
  hasStory?: boolean;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  onOpenUpload,
  onHomeRefresh,
  isHomeRefreshing = false,
  language,
  userAvatar,
  hasStory = false,
}) => {
  return (
    <nav className="absolute bottom-0 inset-x-0 z-40 bg-black/95 backdrop-blur-md border-t border-white/10 px-2 py-1 flex items-center justify-around select-none">
      {/* 1. Home Button (হোম) */}
      <button
        type="button"
        onClick={() => onTabChange('home')}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
          activeTab === 'home'
            ? 'bg-white text-black font-black shadow-lg scale-105'
            : 'text-zinc-400 hover:text-white'
        }`}
        title={language === 'bn' ? 'হোম' : 'Home'}
      >
        {isHomeRefreshing ? (
          <RefreshCw className="w-5 h-5 animate-spin text-[#fe2c55]" />
        ) : (
          <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.8]' : ''}`} />
        )}
        <span className="text-[10px] tracking-tight mt-0.5">
          {language === 'bn' ? 'হোম' : 'Home'}
        </span>
      </button>

      {/* 2. Friends Button (ফ্রেন্ডস) */}
      <button
        type="button"
        onClick={() => onTabChange('friends')}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
          activeTab === 'friends'
            ? 'bg-white text-black font-black shadow-lg scale-105'
            : 'text-zinc-400 hover:text-white'
        }`}
        title={language === 'bn' ? 'ফ্রেন্ডস' : 'Friends'}
      >
        <Users className={`w-5 h-5 ${activeTab === 'friends' ? 'stroke-[2.8]' : ''}`} />
        <span className="text-[10px] tracking-tight mt-0.5">
          {language === 'bn' ? 'ফ্রেন্ডস' : 'Friends'}
        </span>
      </button>

      {/* 3. Plus Button (প্লাস বাটন) */}
      <button
        type="button"
        onClick={() => {
          onTabChange('upload');
          onOpenUpload();
        }}
        className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-2xl transition-all cursor-pointer ${
          activeTab === 'upload'
            ? 'bg-white text-black font-black shadow-lg scale-105'
            : 'text-zinc-400 hover:text-white'
        }`}
        title={language === 'bn' ? 'প্লাস বাটন' : 'Create video'}
      >
        <div className="relative w-10 h-6.5 rounded-lg bg-white flex items-center justify-center shadow-md">
          <div className="absolute -left-1 w-4.5 h-6.5 rounded-l-lg bg-[#25f4ee] -z-10" />
          <div className="absolute -right-1 w-4.5 h-6.5 rounded-r-lg bg-[#fe2c55] -z-10" />
          <Plus className="w-4.5 h-4.5 text-black stroke-[3]" />
        </div>
        <span className="text-[10px] tracking-tight mt-0.5 font-medium">
          {language === 'bn' ? 'প্লাস' : 'Post'}
        </span>
      </button>

      {/* 4. Inbox Button (ইনবক্স) */}
      <button
        type="button"
        onClick={() => onTabChange('inbox')}
        className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
          activeTab === 'inbox'
            ? 'bg-white text-black font-black shadow-lg scale-105'
            : 'text-zinc-400 hover:text-white'
        }`}
        title={language === 'bn' ? 'ইনবক্স' : 'Inbox'}
      >
        <MessageSquare className={`w-5 h-5 ${activeTab === 'inbox' ? 'stroke-[2.8]' : ''}`} />
        <span className="text-[10px] tracking-tight mt-0.5">
          {language === 'bn' ? 'ইনবক্স' : 'Inbox'}
        </span>
        <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-[#fe2c55]" />
      </button>

      {/* 5. Profile Button (প্রোফাইল) */}
      <button
        type="button"
        onClick={() => onTabChange('profile')}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
          activeTab === 'profile'
            ? 'bg-white text-black font-black shadow-lg scale-105'
            : 'text-zinc-400 hover:text-white'
        }`}
        title={language === 'bn' ? 'প্রোফাইল' : 'Profile'}
      >
        {userAvatar ? (
          <div className="relative w-5.5 h-5.5 flex items-center justify-center p-[1px]">
            {/* Thin rotating color ring: প্রোফাইলের চার পাশ দিয়ে চিকন রঙ কালার ঘুরবে */}
            <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-xs" />
            <img
              src={userAvatar}
              alt=""
              className={`relative z-1 w-4.5 h-4.5 rounded-full object-cover border ${
                activeTab === 'profile' ? 'border-black' : 'border-black/50'
              }`}
            />
          </div>
        ) : (
          <User className={`w-5 h-5 ${activeTab === 'profile' ? 'stroke-[2.8]' : ''}`} />
        )}
        <span className="text-[10px] tracking-tight mt-0.5">
          {language === 'bn' ? 'প্রোফাইল' : 'Profile'}
        </span>
      </button>
    </nav>
  );
};
