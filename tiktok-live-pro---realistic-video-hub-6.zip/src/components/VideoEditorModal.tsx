import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, 
  Scissors, 
  Sparkles, 
  Type, 
  Volume2, 
  Sliders, 
  Check, 
  Play, 
  Pause, 
  RotateCcw,
  Layers,
  Wand2,
  Trash2,
  Plus,
  Video,
  Download,
  Crown,
  Lock,
  Copy,
  CheckCircle2,
  PhoneCall,
  CreditCard,
  Zap,
  Split,
  FastForward,
  Palette,
  Mic2,
  Gauge,
  ShieldCheck,
  AlertCircle,
  X,
  LayoutTemplate,
  MessageSquareText,
  Globe2,
  Upload,
  Film,
  ExternalLink
} from 'lucide-react';
import { 
  SoundTrack, 
  AppLanguage, 
  UserAccount, 
  VipCapCutPurchase, 
  CapCutTemplate, 
  AutoSubtitleItem 
} from '../types';
import { 
  isFeatureVipUnlocked, 
  saveVipPurchase, 
  unlockVipFeatureLocally 
} from '../services/firebaseService';

export interface TextOverlayItem {
  id: string;
  text: string;
  color: string;
  size: number;
  position: 'top' | 'center' | 'bottom';
  hasBackground: boolean;
  fontFamily?: string;
  animation?: 'none' | 'pop' | 'typewriter' | 'bounce';
  isVip?: boolean;
}

export type EditorFilter = 
  | 'normal' 
  | 'beauty' 
  | 'glitch' 
  | 'neon' 
  | 'sunset' 
  | 'cyberpunk' 
  | 'vintage' 
  | 'noir' 
  | 'vibrant'
  | 'teal_orange'
  | 'retro_vhs'
  | 'ai_clone' // VIP
  | 'cyber_aura' // VIP
  | 'hdr_ultra'; // VIP

export type VideoQuality = '4k' | '1080p' | '720p' | '480p';

interface VideoEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string;
  activeSound?: SoundTrack;
  language?: AppLanguage;
  currentUser?: UserAccount | null;
  onApplyEdits: (edits: {
    filter: EditorFilter;
    textOverlays: TextOverlayItem[];
    trimStart: number;
    trimEnd: number;
    originalVolume: number;
    musicVolume: number;
    quality: VideoQuality;
    speed: number;
    voiceFx?: string;
  }) => void;
  initialFilter?: EditorFilter;
  initialOverlays?: TextOverlayItem[];
  initialQuality?: VideoQuality;
  onToast?: (msg: string) => void;
}

const ADMIN_PHONE = '01875328569';

// Viral CapCut Templates with video previews & one-click auto creation
export const VIRAL_CAPCUT_TEMPLATES: CapCutTemplate[] = [
  {
    id: 'tpl-1',
    title: 'Beat Drop Velocity 2026',
    category: 'Phonk & Beat Sync',
    previewVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-light-futuristic-concept-42209-large.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400',
    requiredClips: 3,
    musicTitle: 'Phonk Drift Beat (VIP Sync)',
    durationSec: 12,
    usesCount: 142000,
    filterPreset: 'cyberpunk',
    speedPreset: 2.0,
    tags: ['#velocity', '#beatsync', '#capcut'],
  },
  {
    id: 'tpl-2',
    title: 'Cyberpunk Neon Glow VFX',
    category: 'Cyberpunk',
    previewVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-neon-lights-reflection-on-the-water-43306-large.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400',
    requiredClips: 4,
    musicTitle: 'Cyber Neon Horizon',
    durationSec: 15,
    usesCount: 98400,
    filterPreset: 'neon',
    speedPreset: 1.5,
    tags: ['#cyberpunk', '#neon', '#glow'],
  },
  {
    id: 'tpl-3',
    title: '3D Photo Zoom Velocity',
    category: '3D Zoom',
    previewVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-in-black-leather-jacket-41555-large.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
    requiredClips: 5,
    musicTitle: 'Trap Bass 3D Zoom',
    durationSec: 10,
    usesCount: 231000,
    filterPreset: 'vibrant',
    speedPreset: 1.2,
    tags: ['#3dzoom', '#photomontage', '#viral'],
  },
  {
    id: 'tpl-4',
    title: 'Cinematic Travel Slowmo',
    category: 'Cinematic',
    previewVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-waves-coming-to-the-beach-5016-large.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400',
    requiredClips: 3,
    musicTitle: 'Aesthetic Sunset Lofi',
    durationSec: 14,
    usesCount: 87500,
    filterPreset: 'teal_orange',
    speedPreset: 0.5,
    tags: ['#cinematic', '#travel', '#slowmo'],
  },
  {
    id: 'tpl-5',
    title: 'Golden Hour Lyric Vibe',
    category: 'Aesthetic',
    previewVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-sparkler-at-night-42171-large.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1519750157634-b6d493a0f77c?w=400',
    requiredClips: 2,
    musicTitle: 'Heart Touching Acoustic',
    durationSec: 15,
    usesCount: 65400,
    filterPreset: 'sunset',
    speedPreset: 1.0,
    tags: ['#goldenhour', '#lyrics', '#vibes'],
  },
  {
    id: 'tpl-6',
    title: 'Trending Sound Speed Ramp',
    category: 'Trending',
    previewVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-pov-of-a-person-in-a-roller-coaster-41570-large.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400',
    requiredClips: 4,
    musicTitle: 'Brazilian Funk Beat Drop',
    durationSec: 11,
    usesCount: 195000,
    filterPreset: 'beauty',
    speedPreset: 3.0,
    tags: ['#trending', '#funk', '#capcuttemplate'],
  },
];

// Auto-Subtitle multi-country language presets
const SUBTITLE_LANGUAGES = [
  { 
    code: 'bn', 
    name: 'বাংলা (বাংলাদেশ)', 
    flag: '🇧🇩', 
    captions: [
      { text: 'আজকের ভাইরাল ভিডিও ক্লিপ...', start: 0, end: 4 },
      { text: 'ক্যাপকাট অটো সাবটাইটেল তৈরি হচ্ছে...', start: 4, end: 9 },
      { text: 'লাইক ও শেয়ার করতে ভুলবেন না 🔥', start: 9, end: 15 },
    ] 
  },
  { 
    code: 'en', 
    name: 'English (Global)', 
    flag: '🇺🇸', 
    captions: [
      { text: 'Watch this incredible moment...', start: 0, end: 4 },
      { text: 'CapCut auto-subtitles generated!', start: 4, end: 9 },
      { text: 'Follow and share for more viral edits 🔥', start: 9, end: 15 },
    ] 
  },
  { 
    code: 'hi', 
    name: 'हिन्दी (भारत)', 
    flag: '🇮🇳', 
    captions: [
      { text: 'आज का सबसे शानदार वीडियो...', start: 0, end: 4 },
      { text: 'कैपकट ऑटो सबटाइटल तैयार है!', start: 4, end: 9 },
      { text: 'लाइक और शेयर जरूर करें 🔥', start: 9, end: 15 },
    ] 
  },
  { 
    code: 'ar', 
    name: 'العربية (الشرق الأوسط)', 
    flag: '🇸🇦', 
    captions: [
      { text: 'شاهد هذا المشهد الخيالي...', start: 0, end: 4 },
      { text: 'تم إنشاء الترجمة التلقائية كاب كات!', start: 4, end: 9 },
      { text: 'لا تنسى المتابعة والإعجاب 🔥', start: 9, end: 15 },
    ] 
  },
  { 
    code: 'es', 
    name: 'Español (Latino/España)', 
    flag: '🇪🇸', 
    captions: [
      { text: '¡Mira este video increíble!...', start: 0, end: 4 },
      { text: '¡Subtítulos automáticos de CapCut!', start: 4, end: 9 },
      { text: 'Dale like y comparte para más 🔥', start: 9, end: 15 },
    ] 
  },
  { 
    code: 'fr', 
    name: 'Français (France)', 
    flag: '🇫🇷', 
    captions: [
      { text: 'Regardez ce moment incroyable...', start: 0, end: 4 },
      { text: 'Sous-titres automatiques CapCut générés!', start: 4, end: 9 },
      { text: 'Aimez et partagez pour plus de vidéos 🔥', start: 9, end: 15 },
    ] 
  },
];

export const VideoEditorModal: React.FC<VideoEditorModalProps> = ({
  isOpen,
  onClose,
  videoUrl,
  activeSound,
  language = 'bn',
  currentUser,
  onApplyEdits,
  initialFilter = 'normal',
  initialOverlays = [],
  initialQuality = '1080p',
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'trim' | 'templates' | 'subtitles' | 'speed' | 'effects' | 'text' | 'audio' | 'quality'>('trim');
  
  // Active playing video URL (updates when template or uploaded clip is applied)
  const [currentVideoUrl, setCurrentVideoUrl] = useState<string>(videoUrl);

  // Editor state
  const [filter, setFilter] = useState<EditorFilter>(initialFilter);
  const [textOverlays, setTextOverlays] = useState<TextOverlayItem[]>(initialOverlays);
  const [newText, setNewText] = useState('');
  const [newTextColor, setNewTextColor] = useState('#ffffff');
  const [newTextSize, setNewTextSize] = useState(22);
  const [newTextPosition, setNewTextPosition] = useState<'top' | 'center' | 'bottom'>('center');
  const [newTextBg, setNewTextBg] = useState(true);
  const [selectedFont, setSelectedFont] = useState<'sans' | 'bangla' | 'serif' | 'mono'>('bangla');
  const [textAnimation, setTextAnimation] = useState<'none' | 'pop' | 'typewriter' | 'bounce'>('none');

  // Playback & Speed
  const [speed, setSpeed] = useState<number>(1);
  const [speedPreset, setSpeedPreset] = useState<string>('normal');
  const [currentTime, setCurrentTime] = useState<number>(0);

  // Audio adjustments & Voice FX
  const [originalVolume, setOriginalVolume] = useState(100);
  const [musicVolume, setMusicVolume] = useState(85);
  const [voiceFx, setVoiceFx] = useState<'none' | 'chipmunk' | 'robot' | 'echo' | 'studio_voice'>('none');

  // Quality adjustments
  const [quality, setQuality] = useState<VideoQuality>(initialQuality);

  // Trimming & Split
  const [videoDuration, setVideoDuration] = useState(15);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(15);
  const [isPlaying, setIsPlaying] = useState(true);
  const [rotation, setRotation] = useState(0);

  // CapCut Templates state
  const [selectedTemplate, setSelectedTemplate] = useState<CapCutTemplate>(VIRAL_CAPCUT_TEMPLATES[0]);
  const templateMediaInputRef = useRef<HTMLInputElement>(null);

  // Auto Subtitles state
  const [subtitleLang, setSubtitleLang] = useState<string>(language === 'bn' ? 'bn' : 'en');
  const [subtitleStyle, setSubtitleStyle] = useState<'classic_yellow' | 'neon_cyan' | 'bold_stroke' | 'bounce_pop'>('classic_yellow');
  const [autoSubtitles, setAutoSubtitles] = useState<AutoSubtitleItem[]>([]);
  const [isGeneratingSubtitles, setIsGeneratingSubtitles] = useState(false);

  // VIP / In-App Purchase Modal State
  const [showVipPaymentModal, setShowVipPaymentModal] = useState(false);
  const [vipFeatureToUnlock, setVipFeatureToUnlock] = useState<{
    key: string;
    title: string;
    amountBDT: number;
    amountUSD: number;
  }>({
    key: 'all_vip_access',
    title: 'CapCut VIP All-In-One Lifetime Access',
    amountBDT: 299,
    amountUSD: 2.99,
  });

  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'nagad' | 'binance' | 'paypal' | 'mastercard' | 'bank'>('bkash');
  const [trxId, setTrxId] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [vipUnlockedVersion, setVipUnlockedVersion] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    setCurrentVideoUrl(videoUrl);
  }, [videoUrl]);

  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.currentTime = trimStart;
      videoRef.current.playbackRate = speed;
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  }, [isOpen, trimStart, speed, currentVideoUrl]);

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const dur = Math.round(videoRef.current.duration) || 15;
      setVideoDuration(dur);
      setTrimEnd(dur);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const cur = videoRef.current.currentTime;
      setCurrentTime(cur);
      if (cur >= trimEnd) {
        videoRef.current.currentTime = trimStart;
      }
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  // Check if a VIP feature is unlocked
  const isUnlocked = (key: string) => {
    return isFeatureVipUnlocked(key);
  };

  // Trigger VIP Gateway
  const promptVipUnlock = (featureKey: string, title: string, amountBDT = 99, amountUSD = 0.99) => {
    setVipFeatureToUnlock({
      key: featureKey,
      title,
      amountBDT,
      amountUSD,
    });
    setShowVipPaymentModal(true);
  };

  // Generate Auto-Subtitles in user's country language
  const handleGenerateSubtitles = () => {
    setIsGeneratingSubtitles(true);
    setTimeout(() => {
      const chosenLang = SUBTITLE_LANGUAGES.find((l) => l.code === subtitleLang) || SUBTITLE_LANGUAGES[0];
      const items: AutoSubtitleItem[] = chosenLang.captions.map((c, i) => ({
        id: `sub-${Date.now()}-${i}`,
        text: c.text,
        startSec: c.start,
        endSec: c.end,
        style: subtitleStyle,
      }));
      setAutoSubtitles(items);
      setIsGeneratingSubtitles(false);
      onToast?.(
        language === 'bn'
          ? `✓ ${chosenLang.name} ভাষায় ক্যাপকাট অটো সাবটাইটেল তৈরি হয়েছে!`
          : `✓ Auto subtitles generated for ${chosenLang.name}!`
      );
    }, 1200);
  };

  // Active Subtitle for current video time
  const activeSubtitle = useMemo(() => {
    if (!autoSubtitles.length) return null;
    return autoSubtitles.find((s) => currentTime >= s.startSec && currentTime <= s.endSec) || null;
  }, [autoSubtitles, currentTime]);

  // Handle template selection and video preview
  const handleSelectTemplate = (tpl: CapCutTemplate) => {
    setSelectedTemplate(tpl);
    setCurrentVideoUrl(tpl.previewVideoUrl);
    setFilter(tpl.filterPreset as EditorFilter);
    setSpeed(tpl.speedPreset);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
    onToast?.(language === 'bn' ? `🎬 টেমপ্লেট প্রিভিউ: ${tpl.title}` : `Template: ${tpl.title}`);
  };

  // Apply template using user's uploaded photos or videos (Free CapCut Template)
  const handleApplyTemplateWithUserMedia = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const mediaBlobUrl = URL.createObjectURL(file);
    setCurrentVideoUrl(mediaBlobUrl);
    setFilter(selectedTemplate.filterPreset as EditorFilter);
    setSpeed(selectedTemplate.speedPreset);

    // Auto-generate matching overlay text from template
    const templateText: TextOverlayItem = {
      id: `tpl-txt-${Date.now()}`,
      text: selectedTemplate.title,
      color: '#25f4ee',
      size: 24,
      position: 'top',
      hasBackground: true,
      animation: 'pop',
    };
    setTextOverlays((prev) => [...prev.filter((t) => !t.id.startsWith('tpl-txt')), templateText]);

    onToast?.(
      language === 'bn'
        ? `🎉 [${selectedTemplate.title}] সম্পূর্ণ টেমপ্লেট আপনার ভিডিওতে ফ্রিতে অ্যাপ্লাই করা হয়েছে!`
        : `🎉 [${selectedTemplate.title}] applied to your media for FREE!`
    );
  };

  // Add text overlay
  const handleAddText = () => {
    if (!newText.trim()) return;
    const item: TextOverlayItem = {
      id: `txt-${Date.now()}`,
      text: newText.trim(),
      color: newTextColor,
      size: newTextSize,
      position: newTextPosition,
      hasBackground: newTextBg,
      fontFamily: selectedFont,
      animation: textAnimation,
    };
    setTextOverlays((prev) => [...prev, item]);
    setNewText('');
    onToast?.(language === 'bn' ? '✓ টেক্সট যুক্ত হয়েছে' : '✓ Text added');
  };

  const handleRemoveText = (id: string) => {
    setTextOverlays((prev) => prev.filter((t) => t.id !== id));
  };

  // Split video at current playhead
  const handleSplitAtCurrent = () => {
    if (!videoRef.current) return;
    const current = Math.round(videoRef.current.currentTime);
    if (current > trimStart && current < trimEnd) {
      setTrimEnd(current);
      onToast?.(language === 'bn' ? `✂️ ভিডিও স্প্লিট করা হয়েছে (${current} সেকেন্ডে)` : `✂️ Video split at ${current}s`);
    } else {
      onToast?.(language === 'bn' ? 'ভিডিও মাঝখানে প্লেহেড রেখে স্প্লিট করুন' : 'Move playhead inside trim area to split');
    }
  };

  // Submit VIP Payment Order
  const handleConfirmVipPayment = () => {
    if (!trxId.trim()) {
      onToast?.('⚠️ অনুগ্রহ করে পেমেন্ট করার পর প্রাপ্ত TrxID প্রদান করুন!');
      return;
    }

    const purchase: VipCapCutPurchase = {
      id: `vip-${Date.now()}`,
      userId: currentUser?.id || 'usr-self',
      userUid: (currentUser as any)?.uid || '7192849204',
      userName: currentUser?.name || 'Creator',
      userHandle: currentUser?.handle || 'user',
      userAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      featureKey: vipFeatureToUnlock.key,
      featureTitle: vipFeatureToUnlock.title,
      amountBDT: vipFeatureToUnlock.amountBDT,
      amountUSD: vipFeatureToUnlock.amountUSD,
      paymentMethod,
      transactionId: trxId.trim(),
      senderPhone: senderPhone.trim() || ADMIN_PHONE,
      adminPhoneContact: ADMIN_PHONE,
      createdAt: Date.now(),
      status: 'verified',
    };

    saveVipPurchase(purchase);
    unlockVipFeatureLocally(vipFeatureToUnlock.key);
    setVipUnlockedVersion((v) => v + 1);

    setShowVipPaymentModal(false);
    setTrxId('');
    setSenderPhone('');

    onToast?.(`🎉 অভিনন্দন! [${vipFeatureToUnlock.title}] সফলভাবে আনলক হয়েছে! এডমিনকে TrxID (${purchase.transactionId}) পাঠানো হয়েছে।`);
  };

  // Save edits and apply
  const handleSaveAndBack = () => {
    onApplyEdits({
      filter,
      textOverlays,
      trimStart,
      trimEnd,
      originalVolume,
      musicVolume,
      quality,
      speed,
      voiceFx,
    });
    onClose();
  };

  // CSS filter classes
  const getFilterStyle = () => {
    switch (filter) {
      case 'beauty': return 'brightness-110 contrast-105 saturate-125';
      case 'teal_orange': return 'contrast-125 saturate-150 hue-rotate-15';
      case 'vintage': return 'sepia-[0.35] contrast-90 brightness-95 saturate-75';
      case 'retro_vhs': return 'contrast-130 brightness-110 saturate-150';
      case 'sunset': return 'sepia-[0.25] saturate-150 brightness-105 hue-rotate-[-10deg]';
      case 'noir': return 'grayscale contrast-140 brightness-90';
      case 'vibrant': return 'saturate-200 contrast-110';
      case 'glitch': return 'contrast-150 invert-[0.1]';
      case 'neon': return 'contrast-150 saturate-200 brightness-110 hue-rotate-90';
      case 'ai_clone': return 'contrast-125 brightness-115 hue-rotate-180 drop-shadow-[0_0_15px_rgba(37,244,238,0.7)]';
      case 'cyber_aura': return 'contrast-130 saturate-180 drop-shadow-[0_0_20px_rgba(254,44,85,0.8)]';
      case 'hdr_ultra': return 'contrast-140 brightness-105 saturate-135 sharpness-120';
      default: return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between select-none animate-in fade-in duration-200">
      
      {/* Hidden File Input for Applying User Media to CapCut Templates */}
      <input
        type="file"
        ref={templateMediaInputRef}
        onChange={handleApplyTemplateWithUserMedia}
        multiple
        accept="image/*,video/*"
        className="hidden"
      />

      {/* ------------------------------------------------------------- */}
      {/* TOP HEADER: CAPCUT BRANDING & VIP STATUS                      */}
      {/* ------------------------------------------------------------- */}
      <div className="px-4 py-3 bg-zinc-950/90 border-b border-zinc-800 flex items-center justify-between z-20">
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-300 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-cyan-400 via-sky-500 to-indigo-600 flex items-center justify-center shadow-md">
            <Scissors className="w-3.5 h-3.5 text-black stroke-[3]" />
          </div>
          <span className="font-black text-sm tracking-wider bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent">
            CapCut Studio Pro
          </span>
          {isUnlocked('all_vip_access') ? (
            <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-300 text-black text-[9px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
              <Crown className="w-2.5 h-2.5 fill-black" />
              VIP PRO
            </span>
          ) : (
            <button
              type="button"
              onClick={() => promptVipUnlock('all_vip_access', 'CapCut VIP All-In-One Lifetime Access', 299, 2.99)}
              className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[9px] font-black uppercase tracking-wider hover:bg-amber-500/30 transition-all flex items-center gap-1 cursor-pointer animate-pulse"
            >
              <Crown className="w-2.5 h-2.5" />
              VIP আনলক
            </button>
          )}
        </div>

        {/* Save & Apply */}
        <button
          type="button"
          onClick={handleSaveAndBack}
          className="px-3.5 py-1.5 rounded-full bg-[#fe2c55] hover:bg-[#e0264a] text-white font-black text-xs shadow-md transition-all flex items-center gap-1 active:scale-95 cursor-pointer"
        >
          <Check className="w-3.5 h-3.5 stroke-[3]" />
          <span>{language === 'bn' ? 'প্রয়োগ করুন' : 'Apply'}</span>
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* VIDEO PREVIEW CANVAS & REAL-TIME KARAOKE SUBTITLES             */}
      {/* ------------------------------------------------------------- */}
      <div className="relative flex-1 bg-zinc-950 flex items-center justify-center overflow-hidden">
        <video
          ref={videoRef}
          src={currentVideoUrl}
          playsInline
          muted
          loop
          onLoadedMetadata={handleLoadedMetadata}
          onTimeUpdate={handleTimeUpdate}
          onClick={togglePlay}
          style={{ transform: `rotate(${rotation}deg)` }}
          className={`max-h-full max-w-full object-contain cursor-pointer transition-all duration-300 ${getFilterStyle()}`}
        />

        {/* Play/Pause Button Overlay */}
        {!isPlaying && (
          <div 
            onClick={togglePlay}
            className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[1px] cursor-pointer"
          >
            <div className="w-16 h-16 rounded-full bg-black/60 border border-white/20 flex items-center justify-center text-white shadow-2xl">
              <Play className="w-8 h-8 fill-current ml-1" />
            </div>
          </div>
        )}

        {/* Real-Time Auto-Subtitles Karaoke Banner on Video */}
        {activeSubtitle && (
          <div className="absolute bottom-12 left-0 right-0 z-30 flex justify-center px-4 pointer-events-none select-none animate-in fade-in zoom-in-95">
            <div className={`px-4 py-1.5 rounded-xl font-black text-center max-w-[90%] transition-all ${
              subtitleStyle === 'classic_yellow'
                ? 'bg-black/80 text-[#ffe600] border border-amber-400/50 text-xs sm:text-sm shadow-2xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]'
                : subtitleStyle === 'neon_cyan'
                ? 'bg-black/85 text-[#25f4ee] border border-cyan-400 text-xs sm:text-sm shadow-2xl drop-shadow-[0_0_8px_rgba(37,244,238,0.8)]'
                : subtitleStyle === 'bounce_pop'
                ? 'bg-[#fe2c55] text-white text-xs sm:text-sm shadow-xl font-black animate-bounce rounded-full border border-white/30'
                : 'text-white text-sm sm:text-base font-black drop-shadow-[0_2px_6px_rgba(0,0,0,1)] bg-black/40 px-3 py-1 rounded-lg'
            }`}>
              {activeSubtitle.text}
            </div>
          </div>
        )}

        {/* Applied Text Overlays Rendered in Real-Time */}
        {textOverlays.map((item) => (
          <div
            key={item.id}
            className={`absolute z-20 pointer-events-none select-none max-w-[85%] text-center font-black ${
              item.position === 'top'
                ? 'top-8'
                : item.position === 'bottom'
                ? 'bottom-8'
                : 'top-1/2 -translate-y-1/2'
            }`}
          >
            <span
              style={{
                color: item.color,
                fontSize: `${item.size}px`,
                fontFamily: item.fontFamily === 'bangla' ? 'system-ui, sans-serif' : 'monospace',
                textShadow: '0 2px 10px rgba(0,0,0,0.8)',
              }}
              className={`inline-block px-3 py-1 rounded-lg ${
                item.hasBackground ? 'bg-black/60 backdrop-blur-xs' : ''
              } ${item.animation === 'bounce' ? 'animate-bounce' : item.animation === 'pop' ? 'animate-pulse' : ''}`}
            >
              {item.text}
            </span>
          </div>
        ))}

        {/* Filter Indicators */}
        {filter === 'ai_clone' && (
          <div className="absolute top-3 left-3 z-20 px-2.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-400 text-cyan-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg">
            <Sparkles className="w-3 h-3 animate-spin" />
            <span>AI Clone Active</span>
          </div>
        )}
        {filter === 'cyber_aura' && (
          <div className="absolute top-3 left-3 z-20 px-2.5 py-1 rounded-full bg-rose-950/80 border border-rose-400 text-rose-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg">
            <Zap className="w-3 h-3" />
            <span>Cyberpunk VIP Aura Active</span>
          </div>
        )}
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CAPCUT TIMELINE & CONTROLS TOOLBAR                            */}
      {/* ------------------------------------------------------------- */}
      <div className="bg-zinc-900 border-t border-zinc-800 shrink-0">
        
        {/* Sub-tools scrollable selector */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar px-3 py-2 border-b border-zinc-800">
          {[
            { id: 'trim', label: language === 'bn' ? 'কাট ও স্প্লিট' : 'Trim/Split', icon: Scissors },
            { id: 'templates', label: language === 'bn' ? 'ক্যাপকাট টেমপ্লেট 🔥' : 'CapCut Templates 🔥', icon: LayoutTemplate },
            { id: 'subtitles', label: language === 'bn' ? 'অটো সাবটাইটেল 💬' : 'Auto Subtitles', icon: MessageSquareText },
            { id: 'speed', label: language === 'bn' ? 'স্পিড কার্ভ' : 'Speed', icon: FastForward },
            { id: 'effects', label: language === 'bn' ? 'ফিল্টার ও VFX' : 'Filters & VFX', icon: Sparkles },
            { id: 'text', label: language === 'bn' ? 'কাইনেটিক টেক্সট' : 'Text', icon: Type },
            { id: 'audio', label: language === 'bn' ? 'অডিও ও ভয়েস' : 'Audio FX', icon: Volume2 },
            { id: 'quality', label: language === 'bn' ? '৪K কোয়ালিটি' : 'Quality', icon: Gauge },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#fe2c55] text-white shadow-md'
                    : 'bg-zinc-800/80 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Active Tool Panel Content */}
        <div className="p-4 max-h-64 overflow-y-auto no-scrollbar">
          
          {/* 1. TRIM & SPLIT PANEL */}
          {activeTab === 'trim' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-zinc-400">
                  {language === 'bn' ? 'টাইমলাইন ট্রিম (শুরু ও শেষ):' : 'Trim Timeline:'}
                </span>
                <span className="font-mono text-[#fe2c55]">
                  {trimStart}s ➔ {trimEnd}s ({trimEnd - trimStart}s Duration)
                </span>
              </div>

              {/* Range sliders */}
              <div className="space-y-2 bg-zinc-950 p-3 rounded-2xl border border-zinc-800">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-zinc-500 font-bold w-10">Start:</span>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(1, trimEnd - 1)}
                    value={trimStart}
                    onChange={(e) => setTrimStart(Number(e.target.value))}
                    className="flex-1 accent-[#fe2c55] cursor-pointer"
                  />
                  <span className="text-xs font-mono w-8 text-right">{trimStart}s</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-zinc-500 font-bold w-10">End:</span>
                  <input
                    type="range"
                    min={trimStart + 1}
                    max={videoDuration || 15}
                    value={trimEnd}
                    onChange={(e) => setTrimEnd(Number(e.target.value))}
                    className="flex-1 accent-amber-500 cursor-pointer"
                  />
                  <span className="text-xs font-mono w-8 text-right">{trimEnd}s</span>
                </div>
              </div>

              {/* CapCut Quick Actions */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleSplitAtCurrent}
                  className="flex-1 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-750 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Split className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{language === 'bn' ? 'স্প্লিট (Split)' : 'Split'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRotation((r) => (r + 90) % 360)}
                  className="flex-1 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-750 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  <span>{language === 'bn' ? 'ঘোরান (Rotate)' : 'Rotate'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTrimStart(0);
                    setTrimEnd(videoDuration);
                    setRotation(0);
                  }}
                  className="py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-750 text-zinc-400 text-xs font-bold cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>
          )}

          {/* 2. CAPCUT VIRAL TEMPLATES PANEL (User Request: ক্যাপ কাটের অটো টেমপ্লেট ভিতর এডিট ভিডিও থাকবে এবং ক্লিক করলে হিউজ টেমপ্লেট বাটন আসবে যাতে ক্লিক করে ছবি/ভিডিও আপলোড করে সম্পূর্ণ টেমপ্লেট ফ্রিতে পাবে) */}
          {activeTab === 'templates' && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#25f4ee]" />
                    <span>{language === 'bn' ? 'ক্যাপকাট ভাইরাল অটো টেমপ্লেট' : 'CapCut Viral Templates'}</span>
                  </h4>
                  <span className="text-[10px] text-zinc-400">
                    {language === 'bn' ? 'ভিডিওতে ক্লিক করে প্রিভিউ দেখুন ও নিচে হিউজ টেমপ্লেটে আপনার ছবি/ভিডিও আপলোড করুন' : 'Click template to preview, then use template with your media'}
                  </span>
                </div>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  ১০০% ফ্রি
                </span>
              </div>

              {/* Template Video Cards Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {VIRAL_CAPCUT_TEMPLATES.map((tpl) => {
                  const isSelected = selectedTemplate?.id === tpl.id;
                  return (
                    <div
                      key={tpl.id}
                      onClick={() => handleSelectTemplate(tpl)}
                      className={`group relative rounded-2xl overflow-hidden border-2 cursor-pointer transition-all bg-zinc-950 ${
                        isSelected 
                          ? 'border-[#fe2c55] ring-2 ring-[#fe2c55]/40 scale-[1.02]' 
                          : 'border-zinc-800 hover:border-zinc-700 opacity-90 hover:opacity-100'
                      }`}
                    >
                      <div className="aspect-[9/12] w-full relative overflow-hidden bg-black">
                        <img 
                          src={tpl.coverUrl} 
                          alt="" 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                        
                        {/* Play Icon */}
                        <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 text-white flex items-center justify-center">
                          <Play className="w-3 h-3 fill-current ml-0.5" />
                        </div>

                        {/* Tag & Info */}
                        <div className="absolute bottom-2 left-2 right-2">
                          <span className="text-[9px] font-black text-[#25f4ee] uppercase block truncate">
                            {tpl.category}
                          </span>
                          <span className="text-xs font-black text-white block truncate leading-tight">
                            {tpl.title}
                          </span>
                          <span className="text-[9px] text-zinc-400 block mt-0.5">
                            {tpl.requiredClips} Clips • {(tpl.usesCount / 1000).toFixed(0)}k Used
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* HUGE CAPCUT USE TEMPLATE BUTTON (User Requirement: নিচে কেপ কাটের মত হিউজ টেমপ্লেট লেখা আসবে যাতে ক্লিক করে ভিডিও বা ছবি আপলোড করে ওই ভিডিও র ইডিয়ট সম্পুর্ন টেম্পলেট করে ফ্রীতে পাবে) */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => templateMediaInputRef.current?.click()}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#fe2c55] via-rose-500 to-amber-500 hover:from-[#fe2c55] hover:to-amber-400 text-white font-black text-xs sm:text-sm shadow-2xl shadow-rose-600/40 flex items-center justify-center gap-2 cursor-pointer active:scale-98 transition-all"
                >
                  <Sparkles className="w-4 h-4 fill-white animate-pulse" />
                  <span>
                    {language === 'bn' 
                      ? `🎬 হিউজ টেমপ্লেট ব্যবহার করুন (${selectedTemplate.requiredClips}টি ছবি/ভিডিও আপলোড - ফ্রি)` 
                      : `🎬 Use Huge Template (${selectedTemplate.requiredClips} Clips Free)`}
                  </span>
                  <Upload className="w-4 h-4" />
                </button>
                <p className="text-center text-[10px] text-zinc-400 mt-1.5">
                  {language === 'bn' 
                    ? 'ক্যাপকাটের মতোই কাট, ট্রানজিশন ও মিউজিক সম্পূর্ণ স্বয়ংক্রিয়ভাবে তৈরি হবে' 
                    : 'Auto-applies cuts, transitions, sound sync & filters completely free'}
                </p>
              </div>
            </div>
          )}

          {/* 3. CAPCUT AUTO SUBTITLES PANEL (User Request: যে দেশের লোকেশন বা যে দেশের থাকেন তিনি সে দেশের অনুযায়ী তার ভাষায় অটো সাব টাইটেল যুক্ত থাকবে যা ক্যাপ কাটের মতো কাজ করবে সব) */}
          {activeTab === 'subtitles' && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                    <MessageSquareText className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{language === 'bn' ? 'ক্যাপকাট অটো সাবটাইটেল (Auto Subtitles)' : 'CapCut Auto Subtitles'}</span>
                  </h4>
                  <span className="text-[10px] text-zinc-400">
                    {language === 'bn' ? 'আপনার দেশ বা পছন্দের ভাষায় রিয়েল-টাইম কারাওকে সাবটাইটেল তৈরি করুন' : 'Generate dynamic karaoke subtitles in any country language'}
                  </span>
                </div>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                  AI Powered
                </span>
              </div>

              {/* Language Selector (Country / Location based) */}
              <div>
                <label className="text-[11px] font-bold text-zinc-400 block mb-1.5 flex items-center gap-1">
                  <Globe2 className="w-3 h-3 text-cyan-400" />
                  <span>{language === 'bn' ? 'দেশ ও ভাষার লোকেশন নির্বাচন করুন:' : 'Select Country Language:'}</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SUBTITLE_LANGUAGES.map((langItem) => (
                    <button
                      key={langItem.code}
                      type="button"
                      onClick={() => setSubtitleLang(langItem.code)}
                      className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                        subtitleLang === langItem.code
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200 ring-1 ring-cyan-400/50'
                          : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <span className="text-base block">{langItem.flag}</span>
                      <span className="text-xs font-bold block mt-0.5 truncate">{langItem.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Subtitle Animation & Aesthetic Style */}
              <div>
                <label className="text-[11px] font-bold text-zinc-400 block mb-1.5">
                  {language === 'bn' ? 'ক্যাপকাট সাবটাইটেল স্টাইল:' : 'CapCut Karaoke Style:'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'classic_yellow', name: '🟡 Classic Yellow Glow', preview: 'bg-black text-[#ffe600]' },
                    { id: 'neon_cyan', name: '🔵 Neon Cyber Cyan', preview: 'bg-black text-[#25f4ee]' },
                    { id: 'bold_stroke', name: '⚪ Bold Stroke White', preview: 'bg-zinc-800 text-white' },
                    { id: 'bounce_pop', name: '🟣 Punchy Pop Bounce', preview: 'bg-[#fe2c55] text-white' },
                  ].map((styleItem) => (
                    <button
                      key={styleItem.id}
                      type="button"
                      onClick={() => setSubtitleStyle(styleItem.id as any)}
                      className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                        subtitleStyle === styleItem.id
                          ? 'border-[#fe2c55] bg-rose-950/30 text-white ring-1 ring-[#fe2c55]'
                          : 'border-zinc-800 bg-zinc-950 text-zinc-400'
                      }`}
                    >
                      <span className="text-xs font-black block">{styleItem.name}</span>
                      <div className={`mt-1 px-2 py-0.5 rounded text-[10px] font-black text-center ${styleItem.preview}`}>
                        Sample Subtitle
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Generate Button */}
              <button
                type="button"
                disabled={isGeneratingSubtitles}
                onClick={handleGenerateSubtitles}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-xs shadow-xl flex items-center justify-center gap-2 cursor-pointer active:scale-98 transition-all"
              >
                {isGeneratingSubtitles ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{language === 'bn' ? 'সাবটাইটেল তৈরি হচ্ছে...' : 'Generating Subtitles...'}</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>
                      {language === 'bn' 
                        ? '✨ ক্যাপকাট অটো সাবটাইটেল যুক্ত করুন (Generate Subtitles)' 
                        : '✨ Generate CapCut Auto Subtitles'}
                    </span>
                  </>
                )}
              </button>

              {/* Active Subtitles Preview List */}
              {autoSubtitles.length > 0 && (
                <div className="p-3 bg-zinc-950 rounded-2xl border border-zinc-800 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-zinc-400">
                    <span>সক্রিয় সাবটাইটেল লাইন ({autoSubtitles.length}):</span>
                    <button
                      type="button"
                      onClick={() => setAutoSubtitles([])}
                      className="text-rose-400 hover:underline cursor-pointer"
                    >
                      মুছে ফেলুন
                    </button>
                  </div>
                  {autoSubtitles.map((sub, i) => (
                    <div key={sub.id} className="flex items-center justify-between text-xs py-1 border-b border-zinc-850 last:border-none">
                      <span className="text-zinc-200 truncate max-w-[220px]">
                        {i + 1}. {sub.text}
                      </span>
                      <span className="text-[10px] font-mono text-cyan-400 shrink-0">
                        {sub.startSec}s - {sub.endSec}s
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 4. SPEED CURVES PANEL */}
          {activeTab === 'speed' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-zinc-400">
                  {language === 'bn' ? 'প্লেব্যাক গতি (Speed):' : 'Playback Speed:'}
                </span>
                <span className="font-mono text-[#25f4ee] font-black text-sm">{speed}x</span>
              </div>

              <input
                type="range"
                min={0.1}
                max={5.0}
                step={0.1}
                value={speed}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setSpeed(val);
                  setSpeedPreset('custom');
                }}
                className="w-full accent-[#25f4ee] cursor-pointer"
              />

              {/* Speed Presets */}
              <div className="grid grid-cols-4 gap-2 pt-1">
                {[
                  { id: 'slow', label: '0.3x স্লো-মো', val: 0.3 },
                  { id: 'half', label: '0.5x Half', val: 0.5 },
                  { id: 'normal', label: '1.0x Normal', val: 1.0 },
                  { id: 'fast', label: '2.0x Fast', val: 2.0 },
                  { id: 'super', label: '3.0x Flash', val: 3.0 },
                  { id: 'montage', label: '4.0x Montage', val: 4.0 },
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => {
                      setSpeed(s.val);
                      setSpeedPreset(s.id);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      speed === s.val
                        ? 'bg-[#25f4ee] text-black font-black shadow-md'
                        : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 5. FILTERS & VFX PANEL (WITH VIP UNLOCK) */}
          {activeTab === 'effects' && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-zinc-400 block">
                {language === 'bn' ? 'সিনেমাটিক ফিল্টার ও এআই স্পেশাল ইফেক্টস:' : 'Cinematic Filters & VFX:'}
              </span>

              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {[
                  { id: 'normal', name: 'Normal', isVip: false },
                  { id: 'beauty', name: 'Beauty Glow', isVip: false },
                  { id: 'teal_orange', name: 'Teal & Orange', isVip: false },
                  { id: 'vintage', name: 'Vintage 90s', isVip: false },
                  { id: 'retro_vhs', name: 'Retro VHS', isVip: false },
                  { id: 'sunset', name: 'Golden Hour', isVip: false },
                  { id: 'noir', name: 'Classic Noir', isVip: false },
                  // VIP Features
                  { id: 'ai_clone', name: 'AI Body Clone', isVip: true, vipKey: 'ai_clone' },
                  { id: 'cyber_aura', name: 'Cyberpunk Aura', isVip: true, vipKey: 'cyber_aura' },
                  { id: 'hdr_ultra', name: '4K Ultra HDR', isVip: true, vipKey: 'hdr_ultra' },
                  { id: 'glitch', name: 'Matrix Glitch', isVip: false },
                  { id: 'neon', name: 'Neon Pop', isVip: false },
                ].map((f) => {
                  const isSelected = filter === f.id;
                  const vipLocked = f.isVip && !isUnlocked(f.vipKey || f.id);
                  return (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => {
                        if (vipLocked) {
                          promptVipUnlock(f.vipKey || f.id, `CapCut VIP: ${f.name} VFX`, 99, 0.99);
                        } else {
                          setFilter(f.id as EditorFilter);
                        }
                      }}
                      className={`p-2 rounded-xl text-left border relative transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#fe2c55] bg-[#fe2c55]/20 text-white ring-1 ring-[#fe2c55]'
                          : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold truncate block">{f.name}</span>
                        {f.isVip && (
                          <Crown className={`w-3 h-3 shrink-0 ${vipLocked ? 'text-amber-400' : 'text-emerald-400 fill-emerald-400'}`} />
                        )}
                      </div>
                      <span className="text-[9px] text-zinc-500 block mt-0.5">
                        {vipLocked ? '🔒 VIP আনলক' : f.isVip ? '✓ আনলকড' : 'ফ্রি'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 6. KINETIC TEXT & TYPOGRAPHY PANEL */}
          {activeTab === 'text' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  placeholder={language === 'bn' ? 'বাংলা বা ইংরেজি ক্যাপশন লিখুন...' : 'Add kinetic subtitle or text...'}
                  className="flex-1 px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                />
                <button
                  type="button"
                  onClick={handleAddText}
                  className="px-4 py-2 rounded-xl bg-[#fe2c55] text-white font-black text-xs shrink-0 cursor-pointer"
                >
                  {language === 'bn' ? 'যোগ করুন' : 'Add'}
                </button>
              </div>

              {/* Style controls */}
              <div className="flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-400 text-[10px]">রং:</span>
                  {['#ffffff', '#fe2c55', '#25f4ee', '#facc15', '#a855f7'].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewTextColor(c)}
                      style={{ backgroundColor: c }}
                      className={`w-5 h-5 rounded-full border border-white/20 cursor-pointer ${
                        newTextColor === c ? 'ring-2 ring-white scale-110' : ''
                      }`}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-400 text-[10px]">পজিশন:</span>
                  {(['top', 'center', 'bottom'] as const).map((pos) => (
                    <button
                      key={pos}
                      type="button"
                      onClick={() => setNewTextPosition(pos)}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase cursor-pointer ${
                        newTextPosition === pos ? 'bg-zinc-700 text-white' : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {pos}
                    </button>
                  ))}
                </div>
              </div>

              {/* Active Overlays List */}
              {textOverlays.length > 0 && (
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] text-zinc-400 font-bold block">সংযুক্ত টেক্সট তালিকা:</span>
                  {textOverlays.map((t) => (
                    <div
                      key={t.id}
                      className="flex items-center justify-between p-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs"
                    >
                      <span className="truncate max-w-[200px]" style={{ color: t.color }}>
                        {t.text}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveText(t.id)}
                        className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 7. AUDIO & VOICE FX PANEL */}
          {activeTab === 'audio' && (
            <div className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-zinc-400">মূল ভিডিওর ভলিউম:</span>
                  <span className="font-mono text-zinc-200">{originalVolume}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={originalVolume}
                  onChange={(e) => setOriginalVolume(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-zinc-400">ব্যাকগ্রাউন্ড মিউজিক ভলিউম:</span>
                  <span className="font-mono text-zinc-200">{musicVolume}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={musicVolume}
                  onChange={(e) => setMusicVolume(Number(e.target.value))}
                  className="w-full accent-[#fe2c55] cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* 8. RESOLUTION & 4K VIP EXPORT PANEL */}
          {activeTab === 'quality' && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-zinc-400 block">
                {language === 'bn' ? 'এক্সপোর্ট রেজোলিউশন ও ফ্রেমরেট:' : 'Export Resolution & Bitrate:'}
              </span>

              <div className="grid grid-cols-2 gap-2.5">
                {[
                  {
                    id: '480p',
                    title: '480p SD',
                    desc: 'স্ট্যান্ডার্ড কোয়ালিটি (সব ফোনে সুপার ফাস্ট চলবে)',
                    isVip: false,
                  },
                  {
                    id: '720p',
                    title: '720p / 780p HD Pro',
                    desc: 'ক্রিস্প এইচডি ব্যালেন্সড ফ্রেমরেট',
                    isVip: true,
                    vipKey: 'hd_780p_export',
                    price: 99,
                    usd: 0.99,
                  },
                  {
                    id: '1080p',
                    title: '1080p Full HD Pro',
                    desc: 'হাই-ডেফিনিশন ক্রিস্টাল ক্লিয়ার প্রো কোয়ালিটি',
                    isVip: true,
                    vipKey: 'fhd_1080p_export',
                    price: 149,
                    usd: 1.49,
                  },
                  {
                    id: '4k',
                    title: '4K Ultra HD (60FPS)',
                    desc: 'সিনেমাটিক আল্ট্রা এইচডি রিমাস্টার প্রো ইঞ্জিন',
                    isVip: true,
                    vipKey: '4k_hdr_export',
                    price: 199,
                    usd: 1.99,
                  },
                ].map((q) => {
                  const isSelected = quality === q.id;
                  const isLocked = q.isVip && !isUnlocked(q.vipKey || q.id);

                  return (
                    <div
                      key={q.id}
                      onClick={() => {
                        if (isLocked) {
                          promptVipUnlock(q.vipKey || q.id, `CapCut VIP: ${q.title} Export`, q.price || 99, q.usd || 0.99);
                        } else {
                          setQuality(q.id as VideoQuality);
                          onToast?.(`✓ রেজোলিউশন সেট করা হয়েছে: ${q.title}`);
                        }
                      }}
                      className={`p-3 rounded-2xl border text-left cursor-pointer transition-all ${
                        isSelected
                          ? 'border-[#fe2c55] bg-[#fe2c55]/20 ring-1 ring-[#fe2c55]'
                          : 'border-zinc-800 bg-zinc-950 hover:bg-zinc-900'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-white">{q.title}</span>
                        {q.isVip && (
                          <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full flex items-center gap-1 ${
                            isLocked ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-emerald-500/20 text-emerald-400'
                          }`}>
                            <Crown className="w-2.5 h-2.5" />
                            {isLocked ? `৳${q.price}` : 'VIP Unlocked'}
                          </span>
                        )}
                        {!q.isVip && (
                          <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-zinc-800 text-zinc-400">
                            Free
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-zinc-400 mt-1 leading-snug">{q.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CAPCUT VIP PAYMENT & UNLOCK MODAL                             */}
      {/* ------------------------------------------------------------- */}
      {showVipPaymentModal && (
        <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-zinc-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl text-white space-y-4">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Crown className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">CapCut VIP Unlock</h3>
                  <span className="text-[10px] text-amber-400 font-mono">Official Instant Verification</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowVipPaymentModal(false)}
                className="w-7 h-7 rounded-full bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Feature to Unlock */}
            <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
              <span className="text-[10px] text-zinc-400 uppercase tracking-wider block">Selected Feature</span>
              <span className="text-xs font-black text-white block mt-0.5">{vipFeatureToUnlock.title}</span>
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-800/80">
                <span className="text-xs text-zinc-400">Activation Fee:</span>
                <span className="text-base font-black text-amber-400 font-mono">
                  ৳{vipFeatureToUnlock.amountBDT} BDT (${vipFeatureToUnlock.amountUSD})
                </span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <span className="text-[11px] font-bold text-zinc-400 block mb-1.5">Payment Method:</span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'bkash', name: 'bKash (বিকাশ)', badge: 'সক্রিয়', isFrozen: false },
                  { id: 'nagad', name: 'Nagad (নগদ)', badge: 'সক্রিয়', isFrozen: false },
                  { id: 'binance', name: 'Binance Pay', badge: '❄️ ফ্রিজ', isFrozen: true },
                  { id: 'mastercard', name: 'Card / Visa', badge: '❄️ ফ্রিজ', isFrozen: true },
                ].map((pm) => (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => {
                      if (pm.isFrozen) {
                        onToast?.('❄️ এই পেমেন্ট মেথডটি সাময়িকভাবে ফ্রিজ রয়েছে। অনুগ্রহ করে বিকাশ বা নগদ ব্যবহার করুন।');
                        return;
                      }
                      setPaymentMethod(pm.id as any);
                    }}
                    className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                      pm.isFrozen
                        ? 'border-zinc-800 bg-zinc-950 text-zinc-600 opacity-60'
                        : paymentMethod === pm.id
                        ? 'border-[#fe2c55] bg-rose-950/30 text-white ring-1 ring-[#fe2c55]'
                        : 'border-zinc-800 bg-zinc-950 text-zinc-300'
                    }`}
                  >
                    <span className={`text-[8px] font-black uppercase block ${pm.isFrozen ? 'text-sky-400' : 'text-emerald-400'}`}>
                      {pm.badge}
                    </span>
                    <span className="text-xs font-black block mt-0.5">{pm.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Merchant Details */}
            <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-1.5">
              <span className="text-[10px] text-zinc-400 block">Official Merchant Send Money:</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono font-black text-[#fe2c55]">{ADMIN_PHONE}</span>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(ADMIN_PHONE);
                    onToast?.(`✓ Copied: ${ADMIN_PHONE}`);
                  }}
                  className="px-2 py-1 rounded-lg bg-zinc-800 text-zinc-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer hover:bg-zinc-700"
                >
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </button>
              </div>
            </div>

            {/* Transaction Verification Inputs */}
            <div className="space-y-2">
              <div>
                <label className="text-[10px] font-bold text-zinc-400 block mb-1">
                  Transaction ID (TrxID):
                </label>
                <input
                  type="text"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  placeholder="e.g. BL9A82D19X"
                  className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-mono font-bold text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-zinc-400 block mb-1">
                  আপনার মোবাইল নম্বর (Sender Phone):
                </label>
                <input
                  type="text"
                  value={senderPhone}
                  onChange={(e) => setSenderPhone(e.target.value)}
                  placeholder="e.g. 017XXXXXXXX"
                  className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-mono text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Submit */}
            <button
              type="button"
              onClick={handleConfirmVipPayment}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs shadow-xl flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>পেমেন্ট কনফার্ম ও VIP আনলক করুন</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
