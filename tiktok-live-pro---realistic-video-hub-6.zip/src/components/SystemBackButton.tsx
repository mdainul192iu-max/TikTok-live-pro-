import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Circle, Square, ChevronUp } from 'lucide-react';
import { AppLanguage } from '../types';

interface SystemBackButtonProps {
  onBack: () => void;
  onHome: () => void;
  onOverview: () => void;
  language: AppLanguage;
  showBar?: boolean;
  themeMode?: 'dark' | 'light';
}

export const SystemBackButton: React.FC<SystemBackButtonProps> = ({
  onBack,
  onHome,
  onOverview,
  language,
  showBar = true,
  themeMode = 'dark',
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const hideTimerRef = useRef<NodeJS.Timeout | null>(null);
  const touchStartY = useRef<number | null>(null);

  const resetHideTimer = () => {
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
    }
    // 5 seconds auto-hide timer as requested!
    hideTimerRef.current = setTimeout(() => {
      setIsVisible(false);
    }, 5000);
  };

  const handleShowBar = () => {
    setIsVisible(true);
    resetHideTimer();
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartY.current !== null) {
      const deltaY = e.touches[0].clientY - touchStartY.current;
      if (deltaY < -6) {
        handleShowBar();
        touchStartY.current = null;
      }
    }
  };

  useEffect(() => {
    return () => {
      if (hideTimerRef.current) {
        clearTimeout(hideTimerRef.current);
      }
    };
  }, []);

  if (!showBar) return null;

  const isDark = themeMode === 'dark';

  return (
    <>
      {/* Subtle bottom edge swipe-up trigger bar with pill indicator */}
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onMouseEnter={handleShowBar}
        onClick={handleShowBar}
        className="absolute bottom-0 inset-x-0 h-6 z-45 flex items-center justify-center cursor-pointer pointer-events-auto select-none group"
        title={language === 'bn' ? 'সিস্টেম বাটন উঠাতে সোয়াইপ করুন (৫ সেকেন্ড থাকবে)' : 'Swipe up for navigation buttons (5s)'}
      >
        {!isVisible && (
          <div className="flex flex-col items-center gap-0.5">
            <ChevronUp className="w-3.5 h-3.5 text-white/60 group-hover:text-white animate-bounce" />
            <div className="w-16 h-1 rounded-full bg-white/50 group-hover:bg-white/90 transition-colors shadow-md" />
          </div>
        )}
      </div>

      {/* 3-Button Android Navigation Bar (◁ Back, ○ Home, ▢ Recents) */}
      <div
        onMouseEnter={resetHideTimer}
        onTouchStart={resetHideTimer}
        className={`absolute bottom-0 inset-x-0 h-9 z-50 flex items-center justify-around px-8 select-none pointer-events-auto transition-transform duration-300 ease-in-out border-t ${
          isVisible ? 'translate-y-0 opacity-100 shadow-2xl' : 'translate-y-full opacity-0 pointer-events-none'
        } ${
          isDark 
            ? 'bg-black/95 border-zinc-800 text-white' 
            : 'bg-zinc-900/95 border-zinc-800 text-white'
        }`}
        title={language === 'bn' ? 'সিস্টেম নেভিগেশন বার (৫ সেকেন্ড থাকবে)' : 'System Navigation Bar (5s auto-hide)'}
      >
        {/* 1. ◁ Back Button (পিছনে যাওয়া বাটন) */}
        <button
          type="button"
          onClick={() => {
            resetHideTimer();
            onBack();
          }}
          className="p-1.5 hover:text-[#25f4ee] active:scale-75 transition-transform flex items-center justify-center rounded-xl hover:bg-white/10"
          title={language === 'bn' ? 'ব্যাক বাটন (◁)' : 'Back'}
          aria-label="Back"
        >
          <ArrowLeft className="w-4.5 h-4.5 stroke-[2.8]" />
        </button>

        {/* 2. ○ Home Button (হোমে আনা বাটন) */}
        <button
          type="button"
          onClick={() => {
            resetHideTimer();
            onHome();
          }}
          className="p-1.5 hover:text-[#fe2c55] active:scale-75 transition-transform flex items-center justify-center rounded-xl hover:bg-white/10"
          title={language === 'bn' ? 'হোমে আনা বাটন (○)' : 'Home'}
          aria-label="Home"
        >
          <Circle className="w-4 h-4 stroke-[2.8]" />
        </button>

        {/* 3. ▢ Square / Recents Button (চার কোন বাটন) */}
        <button
          type="button"
          onClick={() => {
            resetHideTimer();
            onOverview();
          }}
          className="p-1.5 hover:text-amber-400 active:scale-75 transition-transform flex items-center justify-center rounded-xl hover:bg-white/10"
          title={language === 'bn' ? 'চার কোন বাটন / সাম্প্রতিক অ্যাপস (▢)' : 'Recent Apps'}
          aria-label="Recent Apps"
        >
          <Square className="w-4 h-4 stroke-[2.8]" />
        </button>
      </div>
    </>
  );
};
