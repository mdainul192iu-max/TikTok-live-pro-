import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Music, Heart, UserPlus, UserCheck, ChevronRight, ChevronLeft, ArrowRight } from 'lucide-react';
import { UserStory, AppLanguage, Creator } from '../types';

interface StoryViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  stories: UserStory[];
  initialIndex?: number;
  onOpenProfile?: (creator: Creator) => void;
  openProfileOnClose?: boolean;
  onToggleFollow?: (creatorId: string) => void;
  language?: AppLanguage;
  onToast?: (msg: string) => void;
}

export const StoryViewerModal: React.FC<StoryViewerModalProps> = ({
  isOpen,
  onClose,
  stories,
  initialIndex = 0,
  onOpenProfile,
  openProfileOnClose = false,
  onToggleFollow,
  language = 'bn',
  onToast,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isHolding, setIsHolding] = useState(false);
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});

  const videoRef = useRef<HTMLVideoElement>(null);
  const holdTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Sync index when initialIndex changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(Math.min(initialIndex, Math.max(0, stories.length - 1)));
      setProgress(0);
      setIsPaused(false);
    }
  }, [isOpen, initialIndex, stories.length]);

  const currentStory = stories[currentIndex] || stories[0];

  // Calculate 24-hour expiration time remaining
  const getTimeRemainingText = useCallback((createdAt: number) => {
    const elapsed = Date.now() - createdAt;
    const remainingMs = 24 * 60 * 60 * 1000 - elapsed;
    if (remainingMs <= 0) {
      return language === 'bn' ? 'মেয়াদ শেষ' : 'Expired';
    }
    const hours = Math.floor(remainingMs / (60 * 60 * 1000));
    const minutes = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000));
    if (hours > 0) {
      return language === 'bn' ? `২৪ ঘণ্টার স্টোরি • আর ${hours} ঘণ্টা বাকি` : `24h Story • ${hours}h left`;
    }
    return language === 'bn' ? `২৪ ঘণ্টার স্টোরি • আর ${minutes} মিনিট বাকি` : `24h Story • ${minutes}m left`;
  }, [language]);

  const handleNextStory = useCallback(() => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setProgress(0);
    } else {
      // Reached the end of all stories!
      if (openProfileOnClose && currentStory && onOpenProfile) {
        onOpenProfile(currentStory.creator);
      } else {
        onClose();
      }
    }
  }, [currentIndex, stories.length, openProfileOnClose, currentStory, onOpenProfile, onClose]);

  const handlePrevStory = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setProgress(0);
    } else {
      setProgress(0);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
      }
    }
  }, [currentIndex]);

  // Handle Video Timeupdate / Timer progress
  useEffect(() => {
    if (!isOpen || !currentStory || isPaused || isHolding) return;

    // If it's a video, progress is driven by actual video playback
    if (currentStory.videoUrl && videoRef.current) {
      const video = videoRef.current;
      const handleTimeUpdate = () => {
        if (video.duration && !isNaN(video.duration)) {
          const pct = (video.currentTime / video.duration) * 100;
          setProgress(pct);
        }
      };

      const handleEnded = () => {
        handleNextStory();
      };

      video.addEventListener('timeupdate', handleTimeUpdate);
      video.addEventListener('ended', handleEnded);

      return () => {
        video.removeEventListener('timeupdate', handleTimeUpdate);
        video.removeEventListener('ended', handleEnded);
      };
    } else {
      // Fallback timer for poster images (5 seconds)
      const duration = 5000;
      const intervalTime = 50;
      const step = (intervalTime / duration) * 100;

      const timer = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            handleNextStory();
            return 0;
          }
          return prev + step;
        });
      }, intervalTime);

      return () => clearInterval(timer);
    }
  }, [isOpen, currentIndex, isPaused, isHolding, currentStory, handleNextStory]);

  // Click on screen: Left side -> Prev Story, Right side -> Next Story, Center -> Pause/Play
  const handleScreenClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Avoid triggering if clicking buttons in overlays
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = rect.width;
    const clickRatio = x / width;

    if (clickRatio < 0.35) {
      // Left 35%: Go to previous story
      handlePrevStory();
    } else if (clickRatio > 0.65) {
      // Right 35%: Go to next story
      handleNextStory();
    } else {
      // Center 30%: Toggle Pause / Play
      setIsPaused((prev) => !prev);
    }
  };

  // Touch and Hold to pause story
  const handleTouchStart = () => {
    holdTimeoutRef.current = setTimeout(() => {
      setIsHolding(true);
      if (videoRef.current) videoRef.current.pause();
    }, 180);
  };

  const handleTouchEnd = () => {
    if (holdTimeoutRef.current) clearTimeout(holdTimeoutRef.current);
    if (isHolding) {
      setIsHolding(false);
      if (videoRef.current && !isPaused) {
        videoRef.current.play().catch(() => {});
      }
    }
  };

  // Close story handler
  // Prompt requirement: "হোমপেজ থেকে কেউ যদি তার প্রোফাইলে ক্লিক করে যদি তার স্টোরি তার প্রোফাইলে থাকে প্রথমে স্টোরি দেখাবে উপরে কাটা চিহ্ন থাকবে কেটে দিয়ে তার প্রোফাইলে সোজা ঢুকে যাবে"
  const handleClose = () => {
    if (openProfileOnClose && currentStory && onOpenProfile) {
      onOpenProfile(currentStory.creator);
    } else {
      onClose();
    }
  };

  // Live Follow Toggle
  const handleToggleFollowCreator = (creatorId: string) => {
    setFollowingMap((prev) => ({ ...prev, [creatorId]: !prev[creatorId] }));
    onToggleFollow?.(creatorId);
    onToast?.(
      followingMap[creatorId]
        ? (language === 'bn' ? 'আনফলো করা হয়েছে' : 'Unfollowed')
        : (language === 'bn' ? `✓ ${currentStory?.creator.name}-কে লাইভ ফলো করা হয়েছে!` : '✓ Following live!')
    );
  };

  if (!isOpen || !currentStory) return null;

  const isLiked = Boolean(likedMap[currentStory.id]);
  const isFollowing = currentStory.creator.isFollowed || Boolean(followingMap[currentStory.creator.id]);

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center select-none animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-sm h-full bg-zinc-950 flex flex-col justify-between overflow-hidden shadow-2xl"
        onMouseDown={handleTouchStart}
        onMouseUp={handleTouchEnd}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* ======================================================== */}
        {/* 1. TOP PROGRESS BARS (Multi-story ticks, 5-6+ stories supported) */}
        {/* ======================================================== */}
        <div className="absolute top-2 inset-x-3 z-35 flex items-center gap-1">
          {stories.map((st, idx) => (
            <div 
              key={st.id || idx} 
              className="flex-1 h-1 rounded-full bg-white/30 backdrop-blur-xs overflow-hidden"
            >
              <div 
                className="h-full bg-white transition-all duration-75 ease-linear"
                style={{ 
                  width: idx < currentIndex ? '100%' : idx === currentIndex ? `${progress}%` : '0%' 
                }}
              />
            </div>
          ))}
        </div>

        {/* ======================================================== */}
        {/* 2. TOP HEADER (Avatar, Name, 24h Expiry Countdown, Follow, X Close) */}
        {/* ======================================================== */}
        <div className="absolute top-5 inset-x-3 z-35 flex items-center justify-between pt-1">
          {/* Creator Profile Link & Avatar */}
          <div 
            onClick={() => {
              if (onOpenProfile) onOpenProfile(currentStory.creator);
              else handleClose();
            }}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="relative w-9 h-9 rounded-full p-0.5 bg-gradient-to-tr from-[#25f4ee] via-amber-400 to-[#fe2c55] shadow-md group-hover:scale-105 transition-transform">
              <img 
                src={currentStory.creator.avatar} 
                alt={currentStory.creator.name} 
                className="w-full h-full rounded-full object-cover" 
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white block drop-shadow-md truncate max-w-[130px]">
                  {currentStory.creator.name}
                </span>
                {/* Live Follow Button on Story Header */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleToggleFollowCreator(currentStory.creator.id);
                  }}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-black transition-all cursor-pointer flex items-center gap-1 shadow-xs ${
                    isFollowing 
                      ? 'bg-white/20 text-white backdrop-blur-xs' 
                      : 'bg-[#fe2c55] hover:bg-[#e0264b] text-white active:scale-95'
                  }`}
                >
                  {isFollowing ? (
                    <>
                      <UserCheck className="w-2.5 h-2.5" />
                      <span>{language === 'bn' ? 'ফলোয়িং' : 'Following'}</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-2.5 h-2.5 stroke-[3]" />
                      <span>{language === 'bn' ? 'ফলো' : 'Follow'}</span>
                    </>
                  )}
                </button>
              </div>

              {/* 24-Hour Expiration & Story Count Badge */}
              <div className="flex items-center gap-1.5 text-[9px] text-zinc-300 font-bold">
                <span className="text-[#25f4ee]">
                  {getTimeRemainingText(currentStory.createdAt)}
                </span>
                <span>•</span>
                <span>
                  {currentIndex + 1}/{stories.length}
                </span>
              </div>
            </div>
          </div>

          {/* Action Icons: Mute, Direct Profile, and (X) Close button */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsMuted(!isMuted);
              }}
              className="p-1.5 rounded-full bg-black/45 hover:bg-black/70 text-white backdrop-blur-md cursor-pointer transition-colors"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* View Profile Shortcut Button */}
            {onOpenProfile && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenProfile(currentStory.creator);
                }}
                className="px-2 py-1 rounded-full bg-white/20 hover:bg-white/30 text-white text-[10px] font-bold backdrop-blur-md cursor-pointer transition-colors flex items-center gap-0.5"
                title="প্রোফাইলে যান"
              >
                <span>{language === 'bn' ? 'প্রোফাইল' : 'Profile'}</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            )}

            {/* Prominent (X) Close Button -> Direct entry to profile when opened from home feed */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleClose();
              }}
              className="p-1.5 rounded-full bg-black/55 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer transition-colors active:scale-90"
              title={openProfileOnClose ? 'কেটে সরাসরি প্রোফাইলে যান' : 'বন্ধ করুন'}
            >
              <X className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>
        </div>

        {/* ======================================================== */}
        {/* 3. SCREEN VIEWPORT & TAP REGIONS (Left=Prev, Right=Next, Center=Pause) */}
        {/* ======================================================== */}
        <div 
          onClick={handleScreenClick}
          className="relative w-full h-full flex items-center justify-center bg-black cursor-pointer overflow-hidden"
        >
          {currentStory.videoUrl ? (
            <video
              ref={videoRef}
              key={currentStory.id || currentStory.videoUrl}
              src={currentStory.videoUrl}
              autoPlay
              playsInline
              muted={isMuted}
              className="w-full h-full object-cover"
            />
          ) : (
            <img 
              src={currentStory.posterUrl} 
              alt="" 
              className="w-full h-full object-cover" 
            />
          )}

          {/* Left / Right Tap Direction Hints (Subtle visual aid) */}
          <div className="absolute inset-y-0 left-0 w-12 flex items-center justify-start pl-2 pointer-events-none opacity-0 hover:opacity-40 transition-opacity">
            <ChevronLeft className="w-7 h-7 text-white drop-shadow-lg" />
          </div>
          <div className="absolute inset-y-0 right-0 w-12 flex items-center justify-end pr-2 pointer-events-none opacity-0 hover:opacity-40 transition-opacity">
            <ChevronRight className="w-7 h-7 text-white drop-shadow-lg" />
          </div>

          {/* Paused or Holding Overlay */}
          {(isPaused || isHolding) && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center backdrop-blur-2xs pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-black/70 flex items-center justify-center text-white border border-white/20 shadow-2xl">
                <Pause className="w-7 h-7 fill-white" />
              </div>
            </div>
          )}
        </div>

        {/* ======================================================== */}
        {/* 4. BOTTOM STORY FOOTER (Caption, Sound, Live Like, Tap guide) */}
        {/* ======================================================== */}
        <div className="absolute bottom-4 inset-x-3 z-35 space-y-2 pointer-events-auto">
          {currentStory.caption && (
            <p className="text-xs font-bold text-white drop-shadow-lg px-2 line-clamp-2 leading-relaxed">
              {currentStory.caption}
            </p>
          )}

          {currentStory.music && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white text-[11px] font-bold shadow-md">
              <Music className="w-3 h-3 text-[#fe2c55] animate-spin" />
              <span className="truncate max-w-[190px]">{currentStory.music.title}</span>
            </div>
          )}

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5 text-[10px] text-zinc-300 font-bold bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
              <span>👈 বামে আগের</span>
              <span>|</span>
              <span>ডানে পরের স্টোরি 👉</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setLikedMap((prev) => {
                    const next = !prev[currentStory.id];
                    onToast?.(next ? '✓ স্টোরিতে লাইক দেওয়া হয়েছে ❤️' : 'লাইক রিমুভ হয়েছে');
                    return { ...prev, [currentStory.id]: next };
                  });
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-md text-white border border-white/10 active:scale-90 transition-all cursor-pointer"
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : 'text-white'}`} />
                <span className="text-[11px] font-black font-mono">
                  {(currentStory.likesCount || 120) + (isLiked ? 1 : 0)}
                </span>
              </button>

              {onOpenProfile && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenProfile(currentStory.creator);
                  }}
                  className="p-1.5 rounded-full bg-[#fe2c55] text-white hover:bg-[#e0264b] active:scale-95 shadow-md cursor-pointer"
                  title="সম্পূর্ণ প্রোফাইল দেখুন"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
