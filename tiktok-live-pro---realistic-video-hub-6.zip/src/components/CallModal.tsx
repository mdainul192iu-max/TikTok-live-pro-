import React, { useState, useEffect, useRef } from 'react';
import { 
  PhoneOff, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Camera, 
  Volume2, 
  VolumeX, 
  RefreshCw,
  Sparkles,
  Maximize2
} from 'lucide-react';
import { LiveCallSession, AppLanguage } from '../types';

interface CallModalProps {
  session: LiveCallSession;
  onEndCall: (durationSec: number) => void;
  language: AppLanguage;
  onToast?: (msg: string) => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  session,
  onEndCall,
  language,
  onToast,
}) => {
  const [seconds, setSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoDisabled, setIsVideoDisabled] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Call duration timer
  useEffect(() => {
    const timer = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  // Initialize real camera stream for video call (imo-style live video)
  useEffect(() => {
    if (session.type !== 'video') return;

    let isMounted = true;

    async function startCamera() {
      try {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
        }

        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode },
            audio: true,
          });

          if (!isMounted) {
            stream.getTracks().forEach((track) => track.stop());
            return;
          }

          streamRef.current = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
          setCameraActive(true);
          setCameraError(null);
        } else {
          setCameraActive(false);
        }
      } catch (err: any) {
        console.warn('Camera access unavailable or declined:', err);
        if (isMounted) {
          setCameraActive(false);
          setCameraError('ক্যামেরা চালু করা যায়নি (সিমুলেশন মোড চালু)');
        }
      }
    }

    startCamera();

    return () => {
      isMounted = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [session.type, facingMode]);

  // Flip camera between front & back
  const handleFlipCamera = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
    onToast?.(
      facingMode === 'user'
        ? (language === 'bn' ? '🔄 ব্যাক ক্যামেরা চালু হয়েছে' : 'Flipped to Back Camera')
        : (language === 'bn' ? '🔄 ফ্রন্ট ক্যামেরা চালু হয়েছে' : 'Flipped to Front Camera')
    );
  };

  const formatTimer = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-60 bg-black flex flex-col justify-between select-none animate-in fade-in duration-200 overflow-hidden">
      
      {/* ============================================================== */}
      {/* VIDEO CALL BACKGROUND / REMOTE STREAM */}
      {/* ============================================================== */}
      {session.type === 'video' ? (
        <div className="absolute inset-0 z-0">
          {/* Simulated remote person video stream or realistic animation */}
          <div className="relative w-full h-full bg-zinc-950 flex items-center justify-center overflow-hidden">
            <img
              src={session.receiverAvatar}
              alt=""
              className="w-full h-full object-cover brightness-90 filter blur-xs scale-105"
            />
            
            {/* Center live badge */}
            <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span className="text-xs font-mono font-bold text-white tracking-wider">
                LIVE HD • {formatTimer(seconds)}
              </span>
            </div>

            {/* Remote Friend Avatar overlay */}
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-gradient-to-t from-black/80 via-transparent to-black/60">
              <div className="relative w-28 h-28 rounded-full p-1 bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-2xl mb-3">
                <img
                  src={session.receiverAvatar}
                  alt={session.receiverName}
                  className="w-full h-full object-cover rounded-full border-2 border-white"
                />
              </div>
              <h3 className="font-black text-2xl text-white tracking-tight drop-shadow-md">
                {session.receiverName}
              </h3>
              <p className="text-xs text-white/80 font-medium mt-1">
                {language === 'bn' ? 'সরাসরি লাইভ কানেক্টেড...' : 'Live Connected...'}
              </p>
            </div>
          </div>

          {/* ============================================================ */}
          {/* LOCAL USER PIP (REAL CAMERA FEED - Like IMO / WhatsApp) */}
          {/* ============================================================ */}
          <div className="absolute top-16 right-4 z-20 w-28 sm:w-36 h-40 sm:h-52 rounded-2xl overflow-hidden border-2 border-white/60 shadow-2xl bg-zinc-900 backdrop-blur-md">
            {cameraActive && !isVideoDisabled ? (
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-800 text-white p-2 text-center">
                <VideoOff className="w-7 h-7 text-rose-400 mb-1" />
                <span className="text-[10px] font-bold text-zinc-300">
                  {isVideoDisabled ? 'ভিডিও বন্ধ' : 'ক্যামেরা প্রিভিউ'}
                </span>
              </div>
            )}

            {/* Camera Switch Mini Button */}
            <button
              onClick={handleFlipCamera}
              className="absolute bottom-2 right-2 p-1.5 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors"
              title="ক্যামেরা পরিবর্তন (Flip Camera)"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        /* AUDIO CALL VIEW */
        <div className="relative z-10 flex-1 flex flex-col items-center justify-center pt-16 text-center">
          <div className="relative w-32 h-32 rounded-full p-1 bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-2xl mb-6">
            <img
              src={session.receiverAvatar}
              alt={session.receiverName}
              className="w-full h-full object-cover rounded-full border-2 border-white"
            />
          </div>
          <h3 className="font-extrabold text-2xl text-white tracking-tight">
            {session.receiverName}
          </h3>
          <span className="text-xs text-emerald-400 font-mono font-bold mt-2 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full">
            📞 {language === 'bn' ? 'অডিও কল চলছে' : 'Audio Call Connected'} • {formatTimer(seconds)}
          </span>
        </div>
      )}

      {/* ============================================================== */}
      {/* BOTTOM CALL CONTROLS */}
      {/* ============================================================== */}
      <div className="relative z-20 pb-12 pt-6 px-6 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-center gap-5 sm:gap-7">
        
        {/* 1. Mute Mic */}
        <button
          onClick={() => {
            setIsMuted(!isMuted);
            if (streamRef.current) {
              streamRef.current.getAudioTracks().forEach((track) => {
                track.enabled = isMuted;
              });
            }
          }}
          className={`w-13 h-13 rounded-full flex items-center justify-center text-white border transition-all cursor-pointer ${
            isMuted ? 'bg-rose-600/80 border-rose-500 text-white' : 'bg-white/15 border-white/25 hover:bg-white/25'
          }`}
          title={isMuted ? 'আনমিউট করুন' : 'মিউট করুন'}
        >
          {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </button>

        {/* 2. Video Toggle (for video calls) or Speaker Toggle */}
        {session.type === 'video' ? (
          <button
            onClick={() => {
              setIsVideoDisabled(!isVideoDisabled);
              if (streamRef.current) {
                streamRef.current.getVideoTracks().forEach((track) => {
                  track.enabled = isVideoDisabled;
                });
              }
            }}
            className={`w-13 h-13 rounded-full flex items-center justify-center text-white border transition-all cursor-pointer ${
              isVideoDisabled ? 'bg-rose-600/80 border-rose-500' : 'bg-white/15 border-white/25 hover:bg-white/25'
            }`}
            title="ভিডিও অন/অফ"
          >
            {isVideoDisabled ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
          </button>
        ) : (
          <button
            onClick={() => setIsSpeakerOn(!isSpeakerOn)}
            className={`w-13 h-13 rounded-full flex items-center justify-center text-white border transition-all cursor-pointer ${
              isSpeakerOn ? 'bg-white/25 border-white/30 text-white' : 'bg-white/10 border-white/20'
            }`}
            title="স্পিকার অন/অফ"
          >
            {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6 text-zinc-400" />}
          </button>
        )}

        {/* 3. Flip Camera (for video call) */}
        {session.type === 'video' && (
          <button
            onClick={handleFlipCamera}
            className="w-13 h-13 rounded-full bg-white/15 border border-white/25 hover:bg-white/25 flex items-center justify-center text-white transition-all cursor-pointer active:scale-95"
            title="ক্যামেরা ফ্লিপ করুন"
          >
            <Camera className="w-6 h-6" />
          </button>
        )}

        {/* 4. End Call Button (Big Red) */}
        <button
          onClick={() => {
            if (streamRef.current) {
              streamRef.current.getTracks().forEach((track) => track.stop());
            }
            onEndCall(seconds);
          }}
          className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 flex items-center justify-center text-white shadow-2xl active:scale-95 transition-transform cursor-pointer"
          title="কল শেষ করুন"
        >
          <PhoneOff className="w-7 h-7" />
        </button>
      </div>
    </div>
  );
};
