import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, 
  CheckCircle2, 
  UserPlus, 
  UserCheck, 
  Heart, 
  Bookmark, 
  Grid, 
  Lock, 
  Repeat2, 
  Share2, 
  Settings, 
  Edit3, 
  Eye, 
  Menu, 
  Plus, 
  ChevronDown, 
  MessageSquare, 
  RefreshCw, 
  Play, 
  Music, 
  Copy,
  MessageCircle,
  X,
  QrCode,
  CreditCard,
  Download,
  Shield,
  Activity,
  Sparkles,
  HardDrive,
  LogOut,
  Users,
  ChevronRight,
  Flame,
  Check,
  User,
  Home,
  Wifi,
  Gift
} from 'lucide-react';
import { Creator, VideoReel, AppLanguage, UserAccount, UserStory, CommentItem } from '../types';
import { UserListModal, UserListMode } from './UserListModal';
import { EditProfileModal } from './EditProfileModal';
import { MediaGalleryModal } from './MediaGalleryModal';
import { StoryViewerModal } from './StoryViewerModal';
import { AuthModal } from './AuthModal';
import { videoCacheManager } from '../services/videoCacheManager';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  creator: Creator;
  allReels: VideoReel[];
  onSelectReel: (reelId: string) => void;
  onToggleFollow?: (creatorId: string) => void;
  onUpdateProfile?: (name: string, bio: string, handle: string, avatar?: string, otherFields?: any) => void;
  onDeleteReel?: (reelId: string) => void;
  onStartChat?: (targetUser: Creator) => void;
  savedAccounts?: Creator[];
  onSwitchAccount?: (account: Creator) => void;
  onOpenSettings?: () => void;
  currentUser?: UserAccount | null;
  userAccount?: UserAccount | null;
  onLoginUser?: (user: UserAccount) => void;
  language?: AppLanguage;
  onToast?: (msg: string) => void;
  onLogout?: () => void;
  onPublishReel?: (reel: VideoReel) => void;
  themeMode?: 'dark' | 'light';
  drafts?: any[];
  userStories?: any[];
  onOpenDraft?: (draft: any) => void;
  onOpenHome?: () => void;
  onOpenFriends?: () => void;
  onOpenUpload?: () => void;
  onOpenInbox?: () => void;
  onToggleLikeReel?: (reelId: string) => void;
  onToggleBookmarkReel?: (reelId: string) => void;
  onAddCommentReel?: (reelId: string, text: string) => void;
  onRepostReel?: (reel: VideoReel) => void;
  allComments?: Record<string, CommentItem[]>;
  onOpenReferAndEarn?: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  creator,
  allReels,
  onSelectReel,
  onToggleFollow,
  onUpdateProfile,
  onDeleteReel,
  onStartChat,
  savedAccounts = [],
  onSwitchAccount,
  onOpenSettings,
  onOpenReferAndEarn,
  currentUser,
  userAccount,
  onLoginUser,
  language = 'bn',
  onToast,
  onLogout,
  drafts = [],
  userStories = [],
  onOpenDraft,
  onOpenHome,
  onOpenFriends,
  onOpenUpload,
  onOpenInbox,
  onToggleLikeReel,
  onToggleBookmarkReel,
  onAddCommentReel,
  onRepostReel,
  allComments = {},
}) => {
  const [activeTab, setActiveTab] = useState<'videos' | 'saved' | 'liked'>('videos');
  const [userListModalMode, setUserListModalMode] = useState<UserListMode | null>(null);

  // Active Profile Navigation Stack
  const [currentViewCreator, setCurrentViewCreator] = useState<Creator>(creator);
  const [creatorHistory, setCreatorHistory] = useState<Creator[]>([]);
  const [activeViewerReel, setActiveViewerReel] = useState<VideoReel | null>(null);
  const [showStoryViewer, setShowStoryViewer] = useState<boolean>(false);
  const [showViewerComments, setShowViewerComments] = useState<boolean>(false);
  const [viewerCommentInput, setViewerCommentInput] = useState<string>('');
  const [showViewerShare, setShowViewerShare] = useState<boolean>(false);

  // Three Horizontal Lines Menu Sheet State (User request: থ্রি সমান সমান বাটন ☰)
  const [showMenuSheet, setShowMenuSheet] = useState(false);

  // Sub-modal states from menu sheet
  const [showQrModal, setShowQrModal] = useState(false);
  const [showBalanceModal, setShowBalanceModal] = useState(false);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [showOfflineModal, setShowOfflineModal] = useState(false);
  const [showUidAuthSheet, setShowUidAuthSheet] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);

  // Edit modals inside profile
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showMediaGalleryPicker, setShowMediaGalleryPicker] = useState(false);

  // Pull-to-refresh
  const [isProfileRefreshing, setIsProfileRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const touchStartY = useRef<number | null>(null);
  const profileVideoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCurrentViewCreator(creator);
    setCreatorHistory([]);
    setActiveViewerReel(null);
    setWarningCopyCount(creator.warningCopyLinksCount || 4);
    setWarningCleared(false);
  }, [creator]);

  // User Requirement: ২ সপ্তাহ পর একাউন্টে Warning ⚠️ ঝুলবে, বেশি বেশি কপি লিংক করলে ৩ দিনের মধ্যে ওয়ার্নিং চলে যাবে
  const [warningCopyCount, setWarningCopyCount] = useState<number>(creator.warningCopyLinksCount || 4);
  const [warningCleared, setWarningCleared] = useState<boolean>(false);

  const handleCopyLinkToClearWarning = () => {
    try {
      navigator.clipboard?.writeText(window.location.origin + '/user/' + currentViewCreator.handle);
    } catch {}
    setWarningCopyCount((prev) => {
      const next = prev + 1;
      if (next >= 10) {
        onToast?.(
          language === 'bn' 
            ? '🎉 ১০টি কপি লিংক সম্পন্ন! ৩ দিনের কাউন্টডাউন শুরু হয়েছে, ওয়ার্নিং উঠে যাবে!' 
            : '🎉 10 copy links reached! 3-day recovery countdown started to remove warning!'
        );
      } else {
        onToast?.(
          language === 'bn' 
            ? `✓ ভিডিও কপি লিংক করা হয়েছে (${next}/১০)! ৩ দিনের মধ্যে ওয়ার্নিং প্রত্যাহার হবে` 
            : `✓ Link copied (${next}/10)! Warning will be removed within 3 days`
        );
      }
      return next;
    });
  };

  const isSelf = Boolean(
    currentUser 
      ? currentUser.id === currentViewCreator.id 
      : currentViewCreator.id === 'self' || (currentViewCreator.id === creator.id && creatorHistory.length === 0 && (creator.id === 'self' || creator.id === 'guest'))
  );

  // Unauthenticated self mode (when clicking Profile tab before logging in)
  const isUnauthenticatedSelf = !currentUser && (isSelf || currentViewCreator.id === 'self' || creator.id === 'self');
  const [showAuthSheet, setShowAuthSheet] = useState(false);

  const formatCount = (count: number) => {
    if (count >= 1000000) return (count / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (count >= 1000) return (count / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    return count.toString();
  };

  // Derive UID
  const displayUid = currentUser?.uid || '7192849204';

  // Dynamically supply rich video reels for viewed creator
  const creatorReels = useMemo(() => {
    const existing = allReels.filter((r) => r.creator.id === currentViewCreator.id);
    if (existing.length > 0) return existing;

    return [
      {
        id: `reel-${currentViewCreator.id}-1`,
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-vlogger-recording-video-for-social-networks-42173-large.mp4',
        posterUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
        caption: `${currentViewCreator.name} official video 🌟 #viral #trending #fyp`,
        tags: ['#viral', '#trending', '#fyp'],
        creator: currentViewCreator,
        likesCount: 14200,
        isLiked: false,
        commentsCount: 382,
        sharesCount: 1240,
        bookmarksCount: 940,
        isBookmarked: false,
        viewsCount: 89000,
        category: 'foryou' as const,
        createdAt: '২ ঘণ্টা আগে',
        music: {
          id: `snd-${currentViewCreator.id}-1`,
          title: `Original Sound - ${currentViewCreator.name}`,
          artist: currentViewCreator.name,
          youtubeVideoId: 'f_4dK39Jk2U',
          audioUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/90/Kevin_MacLeod_-_Monkeys_Spinning_Monkeys.ogg',
          cover: currentViewCreator.avatar,
          duration: '0:22',
          usesCount: 4210,
          category: 'trending' as const,
        },
      },
      {
        id: `reel-${currentViewCreator.id}-2`,
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-light-futuristic-concept-42209-large.mp4',
        posterUrl: 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800&auto=format&fit=crop&q=80',
        caption: `Aesthetic cinematography 🔥 #bangla #trending #dhaka`,
        tags: ['#bangla', '#trending', '#dhaka'],
        creator: currentViewCreator,
        likesCount: 8940,
        isLiked: false,
        commentsCount: 215,
        sharesCount: 680,
        bookmarksCount: 520,
        isBookmarked: false,
        viewsCount: 64000,
        category: 'foryou' as const,
        createdAt: '৫ ঘণ্টা আগে',
        music: {
          id: `snd-${currentViewCreator.id}-2`,
          title: `Automotivo Bibi Fogosa (Remix)`,
          artist: 'DJ Brunin XM',
          youtubeVideoId: 'k9q2m34Klx',
          audioUrl: 'https://upload.wikimedia.org/wikipedia/commons/e/ec/Kevin_MacLeod_-_Sneaky_Snitch.ogg',
          cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
          duration: '0:24',
          usesCount: 890000,
          category: 'brazilian_funk' as const,
        },
      },
    ];
  }, [allReels, currentViewCreator]);

  // Filter 24h stories for the viewed creator only (User requirement: ইনবক্স থেকে প্রোফাইল থেকে ক্লিক করলে শুধু তার নিজের স্টোরি দেখতে পাবে)
  const creatorStories = useMemo(() => {
    return userStories.filter((s) => {
      if (isSelf) {
        return (
          s.creator.id === currentViewCreator.id ||
          s.creator.id === 'usr-self' ||
          s.creator.id === 'self' ||
          (currentUser && s.creator.id === currentUser.id)
        );
      }
      return s.creator.id === currentViewCreator.id;
    });
  }, [userStories, currentViewCreator.id, isSelf, currentUser]);

  // Video tabs content: 'videos' -> posted, 'saved' -> bookmarked, 'liked' -> liked videos
  const displayedReels = useMemo(() => {
    if (activeTab === 'saved') {
      return allReels.filter((r) => r.isBookmarked);
    }
    if (activeTab === 'liked') {
      return allReels.filter((r) => r.isLiked);
    }
    return creatorReels;
  }, [activeTab, allReels, creatorReels]);

  const handleTopLeftBack = () => {
    if (activeViewerReel) {
      setActiveViewerReel(null);
      return;
    }
    if (creatorHistory.length > 0) {
      const prevCreator = creatorHistory[creatorHistory.length - 1];
      setCreatorHistory((prev) => prev.slice(0, prev.length - 1));
      setCurrentViewCreator(prevCreator);
      setUserListModalMode('profile_views');
      return;
    }
    onClose();
  };

  const handleProfileRefresh = () => {
    setIsProfileRefreshing(true);
    setPullDistance(50);
    setTimeout(() => {
      setIsProfileRefreshing(false);
      setPullDistance(0);
      onToast?.(language === 'bn' ? '✓ প্রোফাইল রিফ্রেশ সম্পন্ন!' : '✓ Profile refreshed!');
    }, 800);
  };

  // Direct 1-Tap UID Login / Account Creation (User request: জিমেইল, ফেসবুক, টুইটার দিয়ে সরাসরি আইডি ক্রিয়েট)
  const handleFastUidAuth = (method: 'gmail' | 'facebook' | 'twitter' | 'phone') => {
    const randomUid = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    const names = {
      gmail: 'Google User (Ainul)',
      facebook: 'Facebook Creator',
      twitter: 'X Alpha Streamer',
      phone: 'Mobile User BD',
    };
    const handles = {
      gmail: 'ainul_google',
      facebook: 'fb_creator_pro',
      twitter: 'x_alpha_live',
      phone: 'tiktok_bd_user',
    };

    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      uid: randomUid,
      name: names[method],
      handle: handles[method],
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      authMethod: method,
      identifier: method === 'gmail' ? 'ainulgood12345@gmail.com' : `user_${method}_auth`,
      verified: true,
      followers: 120,
      following: 15,
      likesTotal: 4500,
      bio: `TikTok Creator • Verified via ${method.toUpperCase()} 🚀\nUID: ${randomUid}`,
      createdAt: 'এইমাত্র',
    };

    onLoginUser?.(newUser);
    setCurrentViewCreator(newUser);
    setShowUidAuthSheet(false);
    onToast?.(
      language === 'bn'
        ? `✓ ${method.toUpperCase()} দিয়ে নতুন টিকটক আইডি (UID: ${randomUid}) তৈরি ও লগইন সফল!`
        : `✓ Logged in via ${method.toUpperCase()}! UID: ${randomUid}`
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md select-none pointer-events-auto">
      <div className="relative w-full max-w-[480px] h-full sm:h-[94vh] bg-white text-zinc-900 sm:rounded-3xl border border-zinc-200 shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {isUnauthenticatedSelf ? (
          <div className="flex-1 flex flex-col bg-white overflow-hidden">
            {/* Status Bar matching Screenshot_20261016-183446.png (6:34, VoLTE, 42) */}
            <div className="px-5 pt-2 pb-1 flex items-center justify-between text-xs font-bold text-zinc-800 bg-white select-none">
              <span className="tracking-tight text-sm font-black">6:34</span>
              <div className="flex items-center gap-1.5">
                <Wifi className="w-3.5 h-3.5 stroke-[2.4]" />
                <span className="text-[10px] font-mono font-bold">VoLTE</span>
                <div className="flex items-center gap-0.5 border border-zinc-600 rounded-sm px-1 py-0.2">
                  <span className="text-[9px] font-bold">42</span>
                  <div className="w-1.5 h-2 bg-zinc-800 rounded-xs" />
                </div>
              </div>
            </div>

            {/* Header: Center Profile, Right Hamburger Menu ☰ */}
            <div className="px-5 py-3 flex items-center justify-between border-b border-zinc-100 bg-white">
              <div className="w-8" />
              <h3 className="font-extrabold text-base sm:text-lg text-zinc-900 tracking-tight">
                Profile
              </h3>
              <button
                type="button"
                onClick={() => setShowMenuSheet(true)}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-900 transition-colors cursor-pointer active:scale-90"
                title="Settings & Options"
              >
                <Menu className="w-6 h-6 stroke-[2.8]" />
              </button>
            </div>

            {/* Centered Body matching Screenshot_20261016-183446.png */}
            <div className="flex-1 flex flex-col items-center justify-center px-6 text-center bg-white">
              <div className="w-24 h-24 mb-3 flex items-center justify-center">
                <svg className="w-22 h-22 stroke-zinc-400 fill-none stroke-[2] stroke-linecap-round stroke-linejoin-round" viewBox="0 0 48 48">
                  <circle cx="24" cy="16" r="8" />
                  <path d="M10 40c0-7.732 6.268-14 14-14s14 6.268 14 14" />
                </svg>
              </div>

              {/* Text: Log into existing account */}
              <p className="text-sm font-medium text-zinc-600 mb-6">
                Log into existing account
              </p>

              {/* Big Red Button: Login */}
              <button
                type="button"
                onClick={() => setShowAuthSheet(true)}
                className="w-64 py-3.5 rounded-full bg-[#fe2c55] text-white font-extrabold text-base shadow-lg hover:brightness-105 active:scale-95 transition-all cursor-pointer"
              >
                Login
              </button>
            </div>

            {/* TikTok 5-Button Bottom Navigation Bar matching Screenshot_20261016-183446.png */}
            <div className="border-t border-zinc-150 bg-white py-1.5 px-3 flex items-center justify-around select-none">
              <button
                type="button"
                onClick={() => {
                  onOpenHome ? onOpenHome() : onClose();
                }}
                className="flex flex-col items-center justify-center text-zinc-500 hover:text-black transition-colors cursor-pointer"
              >
                <Home className="w-5.5 h-5.5 stroke-[2]" />
                <span className="text-[10px] font-semibold mt-0.5">Home</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onOpenFriends ? onOpenFriends() : onClose();
                }}
                className="flex flex-col items-center justify-center text-zinc-500 hover:text-black transition-colors cursor-pointer"
              >
                <Users className="w-5.5 h-5.5 stroke-[2]" />
                <span className="text-[10px] font-semibold mt-0.5">Friends</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onOpenUpload ? onOpenUpload() : onClose();
                }}
                className="flex flex-col items-center justify-center cursor-pointer active:scale-95 transition-transform"
              >
                <div className="relative w-11 h-7 rounded-lg bg-white flex items-center justify-center shadow-xs">
                  <div className="absolute -left-1 w-5 h-7 rounded-l-lg bg-[#25f4ee] -z-10" />
                  <div className="absolute -right-1 w-5 h-7 rounded-r-lg bg-[#fe2c55] -z-10" />
                  <div className="w-full h-full bg-zinc-900 rounded-md flex items-center justify-center text-white">
                    <Plus className="w-4 h-4 stroke-[3]" />
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  onOpenInbox ? onOpenInbox() : onClose();
                }}
                className="flex flex-col items-center justify-center text-zinc-500 hover:text-black transition-colors cursor-pointer"
              >
                <MessageSquare className="w-5.5 h-5.5 stroke-[2]" />
                <span className="text-[10px] font-semibold mt-0.5">Inbox</span>
              </button>

              <button
                type="button"
                className="flex flex-col items-center justify-center text-zinc-900 font-extrabold cursor-pointer"
              >
                <User className="w-5.5 h-5.5 stroke-[2.5]" />
                <span className="text-[10px] font-bold mt-0.5">Profile</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden bg-white">
            {/* ========================================================================= */}
            {/* TOP HEADER: Back, Pencil, Center Name, Eye Visitors, and HAMBURGER (☰) */}
            {/* ========================================================================= */}
            <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100 bg-white">
          {/* Top-Left Back Button & Pencil Edit Button */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleTopLeftBack}
              className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800 transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
            </button>

            {isSelf && (
              <button
                onClick={() => setShowEditProfileModal(true)}
                className="w-8 h-8 rounded-full hover:bg-rose-50 flex items-center justify-center text-zinc-800 hover:text-[#fe2c55] active:scale-95 transition-all cursor-pointer"
                title={language === 'bn' ? 'প্রোফাইল এডিট করুন' : 'Edit profile'}
              >
                <Edit3 className="w-4.5 h-4.5 stroke-[2.4]" />
              </button>
            )}
          </div>

          {/* Center Name */}
          <div className="text-center font-extrabold text-sm sm:text-base text-zinc-900 tracking-tight max-w-[150px] truncate">
            {currentViewCreator.name}
          </div>

          {/* Right: Eye 16 visitors & THREE HORIZONTAL LINES BUTTON (☰ / Menu) */}
          <div className="flex items-center gap-2">
            <div
              onClick={() => setUserListModalMode('profile_views')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold cursor-pointer transition-colors active:scale-95"
              title="Profile views"
            >
              <Eye className="w-3.5 h-3.5 text-zinc-500" />
              <span>16</span>
            </div>

            {/* User Request: সবার উপরে থ্রি সমান সমান বাটন থাকবে (☰ Hamburger Menu) */}
            <button
              onClick={() => setShowMenuSheet(true)}
              className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-900 transition-colors cursor-pointer active:scale-90"
              title="Menu Options"
            >
              <Menu className="w-5 h-5 stroke-[2.8]" />
            </button>
          </div>
        </div>

        {/* Scrollable Profile Body with Pull-to-refresh */}
        <div
          onTouchStart={(e) => (touchStartY.current = e.touches[0].clientY)}
          onTouchMove={(e) => {
            if (touchStartY.current !== null) {
              const delta = e.touches[0].clientY - touchStartY.current;
              if (delta > 0) setPullDistance(Math.min(delta * 0.4, 60));
            }
          }}
          onTouchEnd={() => {
            if (pullDistance > 40) handleProfileRefresh();
            else setPullDistance(0);
            touchStartY.current = null;
          }}
          className="flex-1 overflow-y-auto no-scrollbar"
        >
          {/* Pull to refresh visual */}
          {pullDistance > 0 && (
            <div className="w-full flex items-center justify-center py-2 bg-zinc-50 text-xs font-bold text-zinc-600 gap-1.5">
              <RefreshCw className={`w-3.5 h-3.5 text-[#fe2c55] ${isProfileRefreshing ? 'animate-spin' : ''}`} />
              <span>{isProfileRefreshing ? 'লোড হচ্ছে...' : 'ছেড়ে দিন লোড করার জন্য'}</span>
            </div>
          )}

          {/* Avatar Area with Story Ring & Plus button */}
          <div className="p-4 flex flex-col items-center text-center">
            <div className="relative mb-3">
              {/* Thin rotating colorful story ring:
                  User Request: স্টটোরি দিলে প্রোফাইল পিকচার এর চার পাস দিয়ে কালার হয়ে ঘুরবে চিকন ভাবে
              */}
              <input
                type="file"
                ref={profileVideoInputRef}
                accept="video/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const url = URL.createObjectURL(file);
                    const newStory: UserStory = {
                      id: `story-${Date.now()}`,
                      videoUrl: url,
                      posterUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&auto=format&fit=crop&q=80',
                      createdAt: Date.now(),
                      creator: currentViewCreator,
                    };
                    try {
                      const saved = localStorage.getItem('tiktok_user_stories');
                      const list = saved ? JSON.parse(saved) : [];
                      localStorage.setItem('tiktok_user_stories', JSON.stringify([newStory, ...list]));
                    } catch {}
                    onToast?.(language === 'bn' ? '✓ ফোনের গ্যালারি থেকে সম্পূর্ণ ভিডিও স্টোরি যুক্ত হয়েছে ও রঙিন বর্ডার ঘুরছে!' : '✓ Video story added from gallery!');
                  }
                }}
              />

              <div 
                onClick={() => {
                  if (creatorStories.length > 0) {
                    setShowStoryViewer(true);
                  } else if (isSelf) {
                    profileVideoInputRef.current?.click();
                  }
                }}
                className="relative w-22 h-22 rounded-full flex items-center justify-center p-[2.5px] cursor-pointer hover:scale-105 active:scale-95 transition-transform shadow-md"
                title={creatorStories.length > 0 ? `স্টোরি দেখুন (${creatorStories.length}টি স্টোরি)` : 'প্রোফাইল পিকচার'}
              >
                {/* Thin rotating colorful ring for active 24h story */}
                <div 
                  className={`absolute inset-0 rounded-full ${
                    creatorStories.length > 0
                      ? 'bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow ring-2 ring-offset-2 ring-[#fe2c55]/30'
                      : 'border-2 border-zinc-200'
                  }`} 
                />
                <div className="relative w-full h-full rounded-full overflow-hidden bg-white z-1 p-0.5">
                  <img
                    src={currentViewCreator.avatar}
                    alt={currentViewCreator.name}
                    className="w-full h-full object-cover rounded-full bg-white"
                  />
                </div>
                {creatorStories.length > 0 && (
                  <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-[#fe2c55] text-[8px] font-black uppercase text-white shadow-xs z-2">
                    Story • {creatorStories.length}
                  </span>
                )}
              </div>

              {isSelf && (
                <button
                  type="button"
                  onClick={() => profileVideoInputRef.current?.click()}
                  className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-6.5 h-6.5 rounded-full bg-gradient-to-r from-[#fe2c55] to-[#25f4ee] text-white flex items-center justify-center border-2 border-white shadow-md hover:scale-110 active:scale-95 transition-transform cursor-pointer"
                  title="ফোনের গ্যালারি থেকে ভিডিও স্টোরি দিন (+)"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[3]" />
                </button>
              )}
            </div>

            {/* Name + Verified Badge */}
            <h2 className="text-base sm:text-lg font-black text-zinc-900 tracking-tight flex items-center gap-1.5">
              <span>{currentViewCreator.name}</span>
              {currentViewCreator.verified && (
                <CheckCircle2 className="w-4 h-4 fill-cyan-400 text-black" />
              )}
            </h2>

            {/* Handle with Copy Button */}
            <div className="flex items-center justify-center gap-1.5 mt-0.5">
              <p className="text-xs text-zinc-500 font-semibold">
                @{currentViewCreator.handle}
              </p>
              <button
                type="button"
                onClick={() => {
                  try {
                    navigator.clipboard?.writeText(`@${currentViewCreator.handle}`);
                  } catch {}
                  onToast?.(
                    language === 'bn'
                      ? `✓ ইউজারনেম @${currentViewCreator.handle} কপি করা হয়েছে!`
                      : `✓ Copied @${currentViewCreator.handle}!`
                  );
                }}
                className="p-1 rounded-md hover:bg-zinc-100 text-zinc-400 hover:text-zinc-700 transition-colors cursor-pointer"
                title="Copy username"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* User Request: হুবহু টিকটক এর মতো ইউ আইডি প্রদর্শন (UID Display) */}
            <div className="flex items-center justify-center gap-1.5 mt-1 bg-zinc-100 px-3 py-1 rounded-full border border-zinc-200">
              <span className="text-[11px] font-mono font-bold text-zinc-700">
                UID: {displayUid}
              </span>
              <button
                onClick={() => {
                  try {
                    navigator.clipboard?.writeText(displayUid);
                  } catch {}
                  onToast?.(`✓ Copied UID: ${displayUid}`);
                }}
                className="text-zinc-400 hover:text-zinc-800"
                title="Copy UID"
              >
                <Copy className="w-3 h-3" />
              </button>
            </div>

            {/* Stats: Following | Followers | Likes */}
            <div className="flex items-center justify-center gap-8 mt-4 py-2 w-full max-w-sm">
              <div 
                onClick={() => setUserListModalMode('following')}
                className="text-center cursor-pointer hover:opacity-80 transition-all active:scale-95"
              >
                <span className="block text-base font-black text-zinc-900 font-mono">
                  {formatCount(currentViewCreator.following)}
                </span>
                <span className="text-[11px] text-zinc-500 font-semibold">
                  {language === 'bn' ? 'ফলো করছেন' : 'Following'}
                </span>
              </div>

              <div 
                onClick={() => setUserListModalMode('followers')}
                className="text-center cursor-pointer hover:opacity-80 transition-all active:scale-95"
              >
                <span className="block text-base font-black text-zinc-900 font-mono">
                  {formatCount(currentViewCreator.followers)}
                </span>
                <span className="text-[11px] text-zinc-500 font-semibold">
                  {language === 'bn' ? 'ফলোয়ার্স' : 'Followers'}
                </span>
              </div>

              <div className="text-center">
                <span className="block text-base font-black text-zinc-900 font-mono">
                  {formatCount(currentViewCreator.likesTotal)}
                </span>
                <span className="text-[11px] text-zinc-500 font-semibold">
                  {language === 'bn' ? 'লাইক' : 'Likes'}
                </span>
              </div>
            </div>

            {/* Action Buttons: Edit Profile, Share, or UID Create/Login */}
            <div className="flex items-center justify-center gap-2 mt-3 w-full max-w-sm">
              {isSelf ? (
                <>
                  <button
                    onClick={() => setShowEditProfileModal(true)}
                    className="flex-1 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-900 text-xs font-black transition-all cursor-pointer shadow-xs active:scale-95"
                  >
                    {language === 'bn' ? 'প্রোফাইল এডিট করুন' : 'Edit profile'}
                  </button>

                  {/* Switch / Create TikTok UID Button */}
                  <button
                    onClick={() => setShowUidAuthSheet(true)}
                    className="py-2 px-3 rounded-xl bg-gradient-to-r from-[#fe2c55] to-rose-600 text-white text-xs font-black transition-all cursor-pointer shadow-md hover:brightness-110 active:scale-95 flex items-center gap-1"
                    title="UID তৈরি / লগইন করুন"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'নতুন আইডি' : 'New ID'}</span>
                  </button>

                  <button
                    onClick={() => setShowQrModal(true)}
                    className="p-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 transition-colors cursor-pointer"
                    title="QR Code"
                  >
                    <QrCode className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      onToggleFollow?.(currentViewCreator.id);
                      setCurrentViewCreator((prev) => ({
                        ...prev,
                        isFollowed: !prev.isFollowed,
                        followers: prev.isFollowed ? Math.max(0, prev.followers - 1) : prev.followers + 1,
                      }));
                      onToast?.(
                        currentViewCreator.isFollowed
                          ? (language === 'bn' ? '✓ আনফলো করা হয়েছে' : '✓ Unfollowed')
                          : (language === 'bn' ? '✓ সফলভাবে ফলো করা হয়েছে' : '✓ Followed successfully')
                      );
                    }}
                    className={`flex-1 py-2 rounded-xl text-xs font-black transition-all cursor-pointer shadow-md active:scale-95 ${
                      currentViewCreator.isFollowed
                        ? 'bg-zinc-100 hover:bg-rose-50 hover:text-rose-600 text-zinc-800 border border-zinc-200'
                        : 'bg-[#fe2c55] hover:bg-[#e0264b] text-white'
                    }`}
                  >
                    {currentViewCreator.isFollowed ? (
                      <span className="flex items-center justify-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>{language === 'bn' ? 'আনফলো করুন' : 'Following (Unfollow)'}</span>
                      </span>
                    ) : (
                      <span>{language === 'bn' ? 'ফলো করুন' : 'Follow'}</span>
                    )}
                  </button>
                  <button
                    onClick={() => onStartChat?.(currentViewCreator)}
                    className="flex-1 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-900 text-xs font-black transition-all cursor-pointer active:scale-95"
                  >
                    {language === 'bn' ? 'মেসেজ' : 'Message'}
                  </button>
                </>
              )}
            </div>

            {/* TikTok UID Create & Login Card (Only shown on own profile, never on other creators' profiles) */}
            {isSelf && (
              <div className="w-full max-w-sm mt-3 p-3 rounded-2xl bg-gradient-to-r from-zinc-50 via-zinc-100/90 to-zinc-50 border border-zinc-200/90 text-left shadow-xs">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#fe2c55]" />
                    <span className="text-[11px] font-black text-zinc-900 tracking-tight">
                      {language === 'bn' ? 'টিকটক ইউ আইডি (UID) ক্রিয়েট ও লগইন' : 'TikTok UID Create & Login'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowUidAuthSheet(true)}
                    className="text-[10px] font-black text-[#fe2c55] hover:underline cursor-pointer"
                  >
                    {language === 'bn' ? 'সব অপশন' : 'More'}
                  </button>
                </div>
                <p className="text-[10.5px] text-zinc-500 mb-2 font-medium">
                  {language === 'bn'
                    ? 'জিমেইল, ফেসবুক বা টুইটার দিয়ে সরাসরি আসল আইডি তৈরি করুন:'
                    : 'Directly create ID or log in with:'}
                </p>
                
                {/* Direct 1-Tap Providers: Gmail, Facebook, Twitter */}
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleFastUidAuth('gmail')}
                    className="py-1.5 px-2 rounded-xl bg-white border border-zinc-200 hover:border-rose-400 active:scale-95 flex items-center justify-center gap-1.5 text-[11px] font-black text-zinc-800 transition-all shadow-xs cursor-pointer hover:bg-rose-50/50"
                    title="Gmail দিয়ে সরাসরি আইডি তৈরি"
                  >
                    <span className="w-4 h-4 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-[10px] font-black">G</span>
                    <span>Gmail</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleFastUidAuth('facebook')}
                    className="py-1.5 px-2 rounded-xl bg-white border border-zinc-200 hover:border-blue-400 active:scale-95 flex items-center justify-center gap-1.5 text-[11px] font-black text-zinc-800 transition-all shadow-xs cursor-pointer hover:bg-blue-50/50"
                    title="Facebook দিয়ে সরাসরি আইডি তৈরি"
                  >
                    <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-[10px] font-black">f</span>
                    <span>Facebook</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleFastUidAuth('twitter')}
                    className="py-1.5 px-2 rounded-xl bg-white border border-zinc-200 hover:border-zinc-800 active:scale-95 flex items-center justify-center gap-1.5 text-[11px] font-black text-zinc-800 transition-all shadow-xs cursor-pointer hover:bg-zinc-100"
                    title="Twitter (X) দিয়ে সরাসরি আইডি তৈরি"
                  >
                    <span className="w-4 h-4 rounded-full bg-zinc-900 text-white flex items-center justify-center text-[9px] font-black">𝕏</span>
                    <span>Twitter</span>
                  </button>
                </div>
              </div>
            )}

            {/* User Requirement: কেউ যদি গালা গালি বা খারাপ আনলিগেল ভিডিও যেমন অটোমেটিক একাউন্ট খোলার পর 2 সপ্তাহ পর আইডির বায়োতে Warning ⚠️ লেখা সো করবে এবং বেশি বেশি কপি লিংক করলে ওয়ার্নিং চলে যাবে ৩ দিন এর ভিতর */}
            {(currentViewCreator.hasWarning && !warningCleared) && (
              <div className="w-full max-w-sm mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 border-2 border-amber-400 text-left shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm">⚠️</span>
                    <span className="text-xs font-black text-amber-900 uppercase tracking-tight">
                      Account Warning ⚠️
                    </span>
                  </div>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 border border-amber-300">
                    {language === 'bn' ? '২ সপ্তাহ পর কার্যকর' : 'Active (2 wks)'}
                  </span>
                </div>

                <p className="text-[11px] text-amber-950 mt-1 font-semibold leading-snug">
                  {currentViewCreator.warningReason || (language === 'bn' ? 'গালা গালি বা অনুপযুক্ত ভিডিও আপলোডের কারণে বায়োতে Warning ⚠️ কার্যকর রয়েছে।' : 'Community Guidelines violation for abusive/inappropriate video.')}
                </p>

                {/* Bio Warning indicator pill */}
                <div className="mt-2 flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-black flex items-center gap-1 shadow-xs">
                    <span>Warning ⚠️</span>
                  </span>
                  <span className="text-[10px] text-amber-800 font-medium">
                    {language === 'bn' ? 'হোম পেজে সবার কাছে ভিডিও যাবে' : 'Videos still distributed to For You feed'}
                  </span>
                </div>

                {/* Copy Link Removal progress */}
                <div className="mt-3 pt-2.5 border-t border-amber-200/80 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-extrabold text-amber-900">
                    <span>{language === 'bn' ? 'কপি লিংক অগ্রগতি (অটো রিমুভ):' : 'Copy Link Progress (Auto-Remove):'}</span>
                    <span className="font-mono text-xs">{warningCopyCount} / 10</span>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full h-2 rounded-full bg-amber-200 overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-amber-500 to-rose-500 transition-all duration-300" 
                      style={{ width: `${Math.min(100, (warningCopyCount / 10) * 100)}%` }} 
                    />
                  </div>

                  <p className="text-[10px] text-amber-900/90 font-medium">
                    {warningCopyCount >= 10
                      ? (language === 'bn' ? '✓ লক্ষ্যমাত্রা পূর্ণ! ৩ দিনের কাউন্টডাউন শুরু — ওয়ার্নিং মুছে যাবে।' : '✓ Goal reached! 3-day recovery countdown started to remove warning.')
                      : (language === 'bn' ? '💡 বেশি বেশি ভিডিওর কপি লিংক করলে ৩ দিনের মধ্যে ওয়ার্নিং চলে যাবে!' : '💡 More copy links will remove the warning within 3 days!')}
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyLinkToClearWarning}
                      className="flex-1 py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'কপি লিংক করুন (Copy Link)' : 'Copy Link'}</span>
                    </button>

                    {warningCopyCount >= 10 && (
                      <button
                        type="button"
                        onClick={() => {
                          setWarningCleared(true);
                          onToast?.(language === 'bn' ? '✓ ৩ দিন সম্পন্ন! অ্যাকাউন্ট ওয়ার্নিং প্রত্যাহার করা হয়েছে!' : '✓ 3 days completed! Account Warning cleared!');
                        }}
                        className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs shadow-md transition-all cursor-pointer"
                      >
                        {language === 'bn' ? 'ওয়ার্নিং মুক্ত ✓' : 'Clear Warning ✓'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Bio text with Warning ⚠️ tag if active */}
            <div className="mt-2.5 max-w-sm text-left">
              {(currentViewCreator.hasWarning && !warningCleared) && (
                <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500 text-black text-[10px] font-black uppercase mr-1.5 mb-1 shadow-xs">
                  <span>Warning ⚠️</span>
                </div>
              )}
              <p className="text-xs text-zinc-700 whitespace-pre-line font-medium leading-relaxed">
                {currentViewCreator.bio}
              </p>
            </div>
          </div>

          {/* Profile Video Grid Tabs */}
          <div className="border-t border-zinc-100 mt-2">
            <div className="flex items-center justify-around text-zinc-400 border-b border-zinc-100">
              <button
                onClick={() => setActiveTab('videos')}
                className={`flex-1 py-3 flex items-center justify-center cursor-pointer transition-colors ${
                  activeTab === 'videos'
                    ? 'text-zinc-900 border-b-2 border-zinc-900'
                    : 'hover:text-zinc-600'
                }`}
              >
                <Grid className="w-5 h-5 stroke-[2.2]" />
              </button>
              <button
                onClick={() => setActiveTab('saved')}
                className={`flex-1 py-3 flex items-center justify-center cursor-pointer transition-colors ${
                  activeTab === 'saved'
                    ? 'text-zinc-900 border-b-2 border-zinc-900'
                    : 'hover:text-zinc-600'
                }`}
              >
                <Bookmark className="w-5 h-5 stroke-[2.2]" />
              </button>
              <button
                onClick={() => setActiveTab('liked')}
                className={`flex-1 py-3 flex items-center justify-center cursor-pointer transition-colors ${
                  activeTab === 'liked'
                    ? 'text-zinc-900 border-b-2 border-zinc-900'
                    : 'hover:text-zinc-600'
                }`}
              >
                <Heart className="w-5 h-5 stroke-[2.2]" />
              </button>
            </div>

            {/* Video Reels Grid */}
            <div className="p-1 grid grid-cols-3 gap-1 pb-16">
              {/* User Request: ড্রাপট করলে প্রোফাইলে প্রথম ভিডিও এড অপশনে এড হবে এবং পরে যেকোনো সময় ক্লিক করে ইডিয়ট বা যেকোনো গান এড করে পোস্ট বা স্টটোরি দিতে পারবে */}
              {isSelf && activeTab === 'videos' && drafts && drafts.length > 0 && (
                <div
                  onClick={() => onOpenDraft?.(drafts[0])}
                  className="relative aspect-[3/4] bg-zinc-900 border-2 border-dashed border-[#fe2c55] rounded-lg overflow-hidden group cursor-pointer shadow-md flex flex-col justify-between p-2 text-white hover:brightness-110 active:scale-95 transition-all"
                >
                  <img
                    src={drafts[0].posterUrl || 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800&auto=format&fit=crop&q=80'}
                    alt="Draft"
                    className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform"
                  />
                  <div className="relative z-10 flex items-center justify-between">
                    <span className="px-1.5 py-0.5 rounded bg-[#fe2c55] text-[9px] font-black uppercase text-white shadow-xs">
                      Drafts: {drafts.length}
                    </span>
                    <Bookmark className="w-3.5 h-3.5 fill-[#fe2c55] text-[#fe2c55]" />
                  </div>
                  <div className="relative z-10 bg-black/80 backdrop-blur-xs p-1.5 rounded-lg border border-white/10">
                    <span className="text-[10px] font-black block truncate text-white">{drafts[0].title || 'ড্রাফট ভিডিও'}</span>
                    <span className="text-[9px] text-[#25f4ee] font-black block">এডিট ও পোস্ট →</span>
                  </div>
                </div>
              )}

              {displayedReels.length === 0 ? (
                <div className="col-span-3 py-16 flex flex-col items-center justify-center text-center px-4">
                  {activeTab === 'saved' ? (
                    <>
                      <div className="w-16 h-16 rounded-full bg-zinc-100 flex items-center justify-center mb-3 text-zinc-400">
                        <Bookmark className="w-8 h-8" />
                      </div>
                      <h4 className="text-sm font-black text-zinc-800">কোনো সেভ করা ভিডিও নেই</h4>
                      <p className="text-xs text-zinc-500 mt-1 max-w-xs">
                        হোমপেজের ফর ইউ ভিডিওতে হলুদ বুকমার্ক/সেভ আইকনে ক্লিক করুন, সেই ভিডিওগুলো এখানে জমা হবে।
                      </p>
                    </>
                  ) : activeTab === 'liked' ? (
                    <>
                      <div className="w-16 h-16 rounded-full bg-rose-50 flex items-center justify-center mb-3 text-rose-400">
                        <Heart className="w-8 h-8" />
                      </div>
                      <h4 className="text-sm font-black text-zinc-800">কোনো লাইক করা ভিডিও নেই</h4>
                      <p className="text-xs text-zinc-500 mt-1 max-w-xs">
                        হোমপেজে বা প্রোফাইলে লাভ আইকনে চাপ দিয়ে লাইক করুন, এখানে সমস্ত লাইক ভিডিও দেখতে পাবেন।
                      </p>
                    </>
                  ) : (
                    <>
                      <div className="w-16 h-16 rounded-full bg-zinc-100 flex items-center justify-center mb-3 text-zinc-400">
                        <Grid className="w-8 h-8" />
                      </div>
                      <h4 className="text-sm font-black text-zinc-800">কোনো পোস্ট নেই</h4>
                      <p className="text-xs text-zinc-500 mt-1 max-w-xs">
                        এখনো কোনো ভিডিও পোস্ট করা হয়নি।
                      </p>
                    </>
                  )}
                </div>
              ) : (
                displayedReels.map((reel) => (
                  <div
                    key={reel.id}
                    onClick={() => setActiveViewerReel(reel)}
                    className="relative aspect-[3/4] bg-zinc-900 rounded-lg overflow-hidden group cursor-pointer shadow-xs active:scale-95 transition-transform"
                  >
                    <img
                      src={reel.posterUrl}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-1.5">
                      <span className="text-[10px] text-white font-bold flex items-center gap-1 font-mono">
                        <Play className="w-2.5 h-2.5 fill-white" />
                        {reel.viewsCount ? (reel.viewsCount / 1000).toFixed(0) + 'K' : '1.2K'}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    )}

        {/* ========================================================================= */}
        {/* THREE HORIZONTAL LINES MENU SHEET (User Request: সমান বাটনে ক্লিক করলে প্রথমে বামে থেকে একটা শিট স্ক্রিনের অর্ধেক এর বেশি হয়ে থাকবে, বেক বাটন উপরে থাকবে, অপশন গুলো ইংরেজি ভাবে সাজানো) */}
        {/* ========================================================================= */}
        {showMenuSheet && (
          <div className="absolute inset-0 z-60 bg-black/65 backdrop-blur-xs flex justify-start animate-in fade-in duration-200">
            {/* Sheet covering more than half the screen from left (84% width) */}
            <div className="w-[84%] sm:w-[350px] h-full bg-white text-zinc-900 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-left duration-300 border-r border-zinc-200">
              
              {/* Sheet Top Header with Back button (বেক বাটন উপরে থাকবে) */}
              <div className="px-4 py-3.5 border-b border-zinc-100 flex items-center justify-between bg-zinc-50">
                <button
                  onClick={() => setShowMenuSheet(false)}
                  className="flex items-center gap-2 hover:bg-zinc-200/80 px-2.5 py-1.5 -ml-1 rounded-xl text-zinc-800 transition-colors cursor-pointer group active:scale-95"
                  title="Back"
                >
                  <ArrowLeft className="w-5 h-5 stroke-[2.4] group-hover:-translate-x-0.5 transition-transform" />
                  <span className="font-extrabold text-sm text-zinc-900">Back</span>
                </button>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono font-bold text-zinc-400">TikTok Menu</span>
                  <button
                    onClick={() => setShowMenuSheet(false)}
                    className="w-7 h-7 rounded-full bg-zinc-200/80 hover:bg-zinc-300 flex items-center justify-center text-zinc-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Sheet Options arranged line by line in English (ইংরেজি ভাবে লাইন করে সাজানো) */}
              <div className="flex-1 overflow-y-auto p-3 space-y-1.5 no-scrollbar text-xs font-bold text-zinc-800">
                
                {/* 1. Settings */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    onOpenSettings?.();
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-700">
                      <Settings className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Settings and privacy</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Manage Post, Account, Privacy & all app controls</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Privacy */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    setShowPrivacyModal(true);
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                      <Shield className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Privacy</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Private account & safety</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 3. Balance */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    if (onOpenReferAndEarn) {
                      onOpenReferAndEarn();
                    } else {
                      setShowBalanceModal(true);
                    }
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center text-amber-600">
                      <CreditCard className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Balance</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Coins, gifts & wallet</span>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-amber-600 bg-amber-100 px-2 py-0.5 rounded-full">
                    120 Coins
                  </span>
                </div>

                {/* 3.1 Refer & Earn ৳499 Bonus (User Requirement: রেফার অপশন ও ৪৯৯ টাকা আনলক) */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    if (onOpenReferAndEarn) {
                      onOpenReferAndEarn();
                    } else if (onOpenSettings) {
                      onOpenSettings();
                    }
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-rose-500/10 via-amber-500/10 to-cyan-500/10 border border-rose-300/60 dark:border-rose-500/30 hover:scale-[1.01] transition-all cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#fe2c55] to-amber-500 flex items-center justify-center text-white shadow-md">
                      <Gift className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold text-xs flex items-center gap-1.5">
                        <span>{language === 'bn' ? 'রেফার ও আর্ন (৳৪৯৯ বোনাস)' : 'Refer & Earn (৳499 Bonus)'}</span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-[#fe2c55] text-white">নতুন</span>
                      </span>
                      <span className="text-[10px] text-zinc-500 font-normal">
                        {language === 'bn' ? 'রেফারেন্স আইডি শেয়ার ও ভিডিও বুস্ট' : 'Share ID, earn & boost videos'}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-black text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded-full">
                    ৳499
                  </span>
                </div>

                {/* 4. Offline Videos */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    setShowOfflineModal(true);
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-cyan-50 flex items-center justify-center text-cyan-600">
                      <Download className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Offline Videos</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Watch 100% offline</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-700 bg-cyan-100 px-2 py-0.5 rounded-full">
                    30 Videos
                  </span>
                </div>

                {/* 5. Your QR Code */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    setShowQrModal(true);
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                      <QrCode className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Your QR Code</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Share your TikTok profile</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 6. Activity Center */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    setShowActivityModal(true);
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-rose-50 flex items-center justify-center text-[#fe2c55]">
                      <Activity className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Activity Center</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Watch history & engagement</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 7. Creator Tools */}
                <div
                  onClick={() => {
                    setShowMenuSheet(false);
                    onToast?.('✓ Creator Tools & Analytics portal active!');
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                      <Sparkles className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Creator Tools</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Analytics & video performance</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 8. Free up space */}
                <div
                  onClick={async () => {
                    await videoCacheManager.clearAllCache();
                    onToast?.('✓ Video cache cleared! (3-day auto-purge policy active)');
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-600">
                      <HardDrive className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <span className="block text-zinc-900 font-extrabold">Free up space</span>
                      <span className="text-[10px] text-zinc-400 font-normal">Cap: 100 videos | 3 days</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500 bg-zinc-100 px-2 py-0.5 rounded-full">
                    {videoCacheManager.getCacheStats().sizeMb} MB
                  </span>
                </div>

                <div className="pt-2 border-t border-zinc-100 mt-2">
                  {/* 9. Switch Account */}
                  <div
                    onClick={() => {
                      setShowMenuSheet(false);
                      setShowUidAuthSheet(true);
                    }}
                    className="flex items-center justify-between p-3 rounded-2xl hover:bg-zinc-100 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-700">
                        <Users className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div>
                        <span className="block text-zinc-900 font-extrabold">Switch Account</span>
                        <span className="text-[10px] text-zinc-400 font-normal">Log in or create new UID</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-zinc-400" />
                  </div>

                  {/* 10. Log Out */}
                  <div
                    onClick={() => {
                      setShowMenuSheet(false);
                      onLogout?.();
                      onToast?.('Logged out successfully');
                    }}
                    className="flex items-center justify-between p-3 rounded-2xl hover:bg-rose-50 text-rose-600 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-rose-100/60 flex items-center justify-center text-rose-600">
                        <LogOut className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <span className="font-extrabold">Log out</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TIKTOK UID CREATE & LOGIN SHEET (User Request: টিকটকের মত হুবহু ইউ আইডি ক্রিয়েট ও লগইন) */}
        {/* ========================================================================= */}
        {showUidAuthSheet && (
          <div className="absolute inset-0 z-70 bg-black/75 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
            <div className="relative w-full max-w-sm bg-white text-zinc-900 rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-black text-base text-zinc-900">
                    {language === 'bn' ? 'টিকটক অ্যাকাউন্ট ও UID ক্রিয়েট' : 'Sign up or Log in to TikTok'}
                  </h3>
                  <p className="text-[11px] text-zinc-500">
                    {language === 'bn' ? 'সরাসরি ১-ক্লিকে আইডি তৈরি করে লগইন করুন' : 'Instant 1-click TikTok UID login'}
                  </p>
                </div>
                <button
                  onClick={() => setShowUidAuthSheet(false)}
                  className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500 hover:text-zinc-900 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* 1-Click Fast Auth Providers */}
              <div className="space-y-2.5 pt-2">
                {/* 1. Google Gmail */}
                <button
                  onClick={() => handleFastUidAuth('gmail')}
                  className="w-full py-2.5 px-4 rounded-2xl border border-zinc-200 hover:bg-zinc-50 active:scale-95 flex items-center justify-between text-xs font-black transition-all cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-rose-50 text-[#fe2c55] font-black flex items-center justify-center">
                      G
                    </div>
                    <span>Continue with Google (Gmail)</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </button>

                {/* 2. Facebook */}
                <button
                  onClick={() => handleFastUidAuth('facebook')}
                  className="w-full py-2.5 px-4 rounded-2xl border border-zinc-200 hover:bg-zinc-50 active:scale-95 flex items-center justify-between text-xs font-black transition-all cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 font-black flex items-center justify-center">
                      f
                    </div>
                    <span>Continue with Facebook</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </button>

                {/* 3. Twitter / X */}
                <button
                  onClick={() => handleFastUidAuth('twitter')}
                  className="w-full py-2.5 px-4 rounded-2xl border border-zinc-200 hover:bg-zinc-50 active:scale-95 flex items-center justify-between text-xs font-black transition-all cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-zinc-900 text-white font-black flex items-center justify-center">
                      𝕏
                    </div>
                    <span>Continue with Twitter (X)</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </button>

                {/* 4. Phone Number */}
                <button
                  onClick={() => handleFastUidAuth('phone')}
                  className="w-full py-2.5 px-4 rounded-2xl border border-zinc-200 hover:bg-zinc-50 active:scale-95 flex items-center justify-between text-xs font-black transition-all cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 font-black flex items-center justify-center">
                      📱
                    </div>
                    <span>Use Phone Number (+880)</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </button>
              </div>

              <p className="text-[10px] text-zinc-400 text-center mt-2 leading-tight">
                By continuing, you agree to TikTok's Terms of Service and Privacy Policy.
              </p>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* YOUR QR CODE MODAL */}
        {/* ========================================================================= */}
        {showQrModal && (
          <div className="absolute inset-0 z-70 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="relative w-full max-w-xs bg-white rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center gap-3 border border-zinc-200">
              <button
                onClick={() => setShowQrModal(false)}
                className="absolute top-4 right-4 w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500 hover:text-zinc-900"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="w-16 h-16 rounded-full border-2 border-[#fe2c55] overflow-hidden p-0.5 shadow-md">
                <img src={currentViewCreator.avatar} alt="" className="w-full h-full rounded-full object-cover" />
              </div>
              <div>
                <h4 className="font-black text-sm text-zinc-900">{currentViewCreator.name}</h4>
                <p className="text-xs text-zinc-500 font-semibold">@{currentViewCreator.handle}</p>
                <span className="text-[10px] font-mono font-bold text-zinc-400">UID: {displayUid}</span>
              </div>

              {/* Simulated QR Code box */}
              <div className="w-44 h-44 bg-zinc-900 rounded-2xl p-3 flex flex-col items-center justify-center border-4 border-[#25f4ee]/40 shadow-xl">
                <QrCode className="w-32 h-32 text-white" />
              </div>

              <p className="text-[11px] text-zinc-500">
                Scan this QR code to follow @{currentViewCreator.handle} on TikTok
              </p>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* BALANCE MODAL */}
        {/* ========================================================================= */}
        {showBalanceModal && (
          <div className="absolute inset-0 z-70 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="relative w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl flex flex-col gap-3 border border-zinc-200">
              <div className="flex items-center justify-between">
                <h4 className="font-black text-base text-zinc-900">TikTok Balance</h4>
                <button
                  onClick={() => setShowBalanceModal(false)}
                  className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-4 text-white shadow-md">
                <span className="text-[11px] font-bold text-amber-100 uppercase tracking-wider block">
                  Total Coins
                </span>
                <span className="text-2xl font-black font-mono">120 Coins</span>
                <span className="text-[11px] block mt-1 text-amber-100">≈ $1.80 USD</span>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  onClick={() => onToast?.('✓ Recharge successful (+65 coins)!')}
                  className="py-2.5 bg-[#fe2c55] text-white rounded-xl text-xs font-black shadow-md hover:brightness-110 cursor-pointer"
                >
                  Recharge
                </button>
                <button
                  onClick={() => onToast?.('✓ Live Gifts rewards wallet active!')}
                  className="py-2.5 bg-zinc-100 text-zinc-800 rounded-xl text-xs font-black hover:bg-zinc-200 cursor-pointer"
                >
                  LIVE Gifts
                </button>
              </div>

              {/* Referral & Boost Wallet (User Requirement: 499 টাকা আনলক ও নিচে 600 টাকা উইথড্র নোটিশ ও বুস্ট) */}
              <div className="bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-600 rounded-2xl p-3.5 text-white shadow-lg space-y-1.5 mt-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-amber-100 uppercase tracking-wider block">
                    রেফারেল ও বুস্ট ওয়ালেট ব্যালেন্স
                  </span>
                  <span className="text-[9px] font-bold bg-white/20 px-2 py-0.5 rounded-full">
                    আনলক বোনাস
                  </span>
                </div>
                <span className="text-2xl font-black font-mono block">৳499 BDT</span>
                <p className="text-[10px] text-zinc-100 leading-tight">
                  ⚠️ <strong className="text-amber-200">ন্যূনতম ৬০০ টাকা</strong> হলে নগদ বা বিকাশ একাউন্টে উইথড্র করতে পারবেন। অথবা এই ৪৯৯ টাকা দিয়ে এখনই সরাসরি ভিডিও বুস্ট করতে পারবেন।
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => {
                      setShowBalanceModal(false);
                      onOpenReferAndEarn?.();
                    }}
                    className="py-2 bg-white text-zinc-900 rounded-xl text-xs font-black shadow-md cursor-pointer hover:bg-zinc-100 transition-all active:scale-95 text-center"
                  >
                    রেফার ও আর্ন
                  </button>
                  <button
                    onClick={() => {
                      setShowBalanceModal(false);
                      onOpenReferAndEarn?.();
                    }}
                    className="py-2 bg-zinc-950 text-white rounded-xl text-xs font-black shadow-md cursor-pointer hover:bg-zinc-900 transition-all active:scale-95 text-center"
                  >
                    🚀 ভিডিও বুস্ট
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* ACTIVITY CENTER MODAL */}
        {/* ========================================================================= */}
        {showActivityModal && (
          <div className="absolute inset-0 z-70 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="relative w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl flex flex-col gap-3 border border-zinc-200">
              <div className="flex items-center justify-between">
                <h4 className="font-black text-base text-zinc-900">Activity Center</h4>
                <button
                  onClick={() => setShowActivityModal(false)}
                  className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-xs font-bold text-zinc-800">
                <div 
                  onClick={() => onToast?.('Watch history: 48 videos watched today')}
                  className="p-3 rounded-xl bg-zinc-50 flex items-center justify-between cursor-pointer hover:bg-zinc-100"
                >
                  <span>Watch History</span>
                  <span className="text-zinc-400 font-mono">48 vids</span>
                </div>
                <div 
                  onClick={() => onToast?.('Comment history: 12 comments posted')}
                  className="p-3 rounded-xl bg-zinc-50 flex items-center justify-between cursor-pointer hover:bg-zinc-100"
                >
                  <span>Comment History</span>
                  <span className="text-zinc-400 font-mono">12 items</span>
                </div>
                <div 
                  onClick={() => onToast?.('Search history: 15 queries')}
                  className="p-3 rounded-xl bg-zinc-50 flex items-center justify-between cursor-pointer hover:bg-zinc-100"
                >
                  <span>Search History</span>
                  <span className="text-zinc-400 font-mono">Clear</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* OFFLINE VIDEOS MODAL */}
        {/* ========================================================================= */}
        {showOfflineModal && (
          <div className="absolute inset-0 z-70 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="relative w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl flex flex-col gap-3 border border-zinc-200">
              <div className="flex items-center justify-between">
                <h4 className="font-black text-base text-zinc-900">Offline Videos</h4>
                <button
                  onClick={() => setShowOfflineModal(false)}
                  className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-zinc-600">
                You have 30 trending videos cached and available to watch without cellular data or Wi-Fi.
              </p>
              <button
                onClick={() => {
                  setShowOfflineModal(false);
                  onToast?.('✓ Offline stream ready!');
                }}
                className="py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-black shadow-md hover:bg-emerald-700 cursor-pointer"
              >
                Start Watching Offline
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* PRIVACY MODAL */}
        {/* ========================================================================= */}
        {showPrivacyModal && (
          <div className="absolute inset-0 z-70 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="relative w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl flex flex-col gap-3 border border-zinc-200">
              <div className="flex items-center justify-between">
                <h4 className="font-black text-base text-zinc-900">Privacy & Safety</h4>
                <button
                  onClick={() => setShowPrivacyModal(false)}
                  className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-xs font-bold text-zinc-800">
                <div className="p-3 rounded-xl bg-zinc-50 flex items-center justify-between">
                  <span>Private Account</span>
                  <span className="text-xs text-emerald-600 font-black">Off</span>
                </div>
                <div className="p-3 rounded-xl bg-zinc-50 flex items-center justify-between">
                  <span>Direct Messages</span>
                  <span className="text-xs text-zinc-500">Everyone</span>
                </div>
                <div className="p-3 rounded-xl bg-zinc-50 flex items-center justify-between">
                  <span>Duet & Stitch</span>
                  <span className="text-xs text-zinc-500">Enabled</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Fullscreen Video Player for Profile Viewer Reels with Complete Home Feed Actions */}
        {activeViewerReel && (
          <div className="absolute inset-0 z-50 bg-black flex flex-col animate-in fade-in duration-200">
            {/* Top Bar: Back, Tab title, Feed Jump */}
            <div className="px-4 py-3 flex items-center justify-between bg-black/60 backdrop-blur-md border-b border-white/10 z-20 text-white">
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setActiveViewerReel(null);
                    setShowViewerComments(false);
                    setShowViewerShare(false);
                  }}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer active:scale-90"
                >
                  <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
                </button>
                <div>
                  <span className="text-xs font-black block">
                    {activeTab === 'saved' ? 'সেভ করা ভিডিও' : activeTab === 'liked' ? 'লাইক করা ভিডিও' : 'পোস্ট করা ভিডিও'}
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    @{activeViewerReel.creator.handle}
                  </span>
                </div>
              </div>

              {/* Prev / Next Video Quick Navigators */}
              <div className="flex items-center gap-1.5">
                {displayedReels.length > 1 && (
                  <div className="flex items-center bg-white/10 rounded-full p-0.5 border border-white/10">
                    <button
                      type="button"
                      onClick={() => {
                        const curIdx = displayedReels.findIndex((r) => r.id === activeViewerReel.id);
                        if (curIdx > 0) {
                          setActiveViewerReel(displayedReels[curIdx - 1]);
                        } else {
                          setActiveViewerReel(displayedReels[displayedReels.length - 1]);
                        }
                      }}
                      className="px-2 py-1 text-[10px] font-bold text-white hover:bg-white/20 rounded-full cursor-pointer"
                      title="আগের ভিডিও"
                    >
                      ▲ আগের
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const curIdx = displayedReels.findIndex((r) => r.id === activeViewerReel.id);
                        if (curIdx < displayedReels.length - 1) {
                          setActiveViewerReel(displayedReels[curIdx + 1]);
                        } else {
                          setActiveViewerReel(displayedReels[0]);
                        }
                      }}
                      className="px-2 py-1 text-[10px] font-bold text-white hover:bg-white/20 rounded-full cursor-pointer"
                      title="পরের ভিডিও"
                    >
                      পরের ▼
                    </button>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => {
                    onSelectReel(activeViewerReel.id);
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-full bg-[#fe2c55] text-white text-[11px] font-black shadow-md hover:bg-[#e0264b] transition-all cursor-pointer"
                >
                  ফিডে দেখুন
                </button>
              </div>
            </div>

            {/* Video Viewport */}
            <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-black">
              <video
                key={activeViewerReel.id}
                src={activeViewerReel.videoUrl}
                poster={activeViewerReel.posterUrl}
                autoPlay
                loop
                playsInline
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/85 pointer-events-none" />

              {/* Bottom Left Info: Creator avatar, handle, caption, music sound */}
              <div className="absolute bottom-4 left-3 right-18 text-white space-y-1.5 z-10 pointer-events-auto">
                <div 
                  onClick={() => {
                    if (activeViewerReel.creator.id !== currentViewCreator.id) {
                      setCreatorHistory((prev) => [...prev, currentViewCreator]);
                      setCurrentViewCreator(activeViewerReel.creator);
                      setActiveViewerReel(null);
                    }
                  }}
                  className="flex items-center gap-2 cursor-pointer group"
                >
                  <img 
                    src={activeViewerReel.creator.avatar} 
                    alt="" 
                    className="w-9 h-9 rounded-full border-2 border-white object-cover group-hover:scale-105 transition-transform" 
                  />
                  <div>
                    <span className="text-xs font-black block drop-shadow-md">
                      {activeViewerReel.creator.name}
                    </span>
                    <span className="text-[10px] text-zinc-300 font-medium block">
                      @{activeViewerReel.creator.handle}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-white/95 line-clamp-2 font-medium drop-shadow-md">
                  {activeViewerReel.caption}
                </p>

                <div className="flex items-center gap-1.5 text-[11px] text-white/90 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 w-fit">
                  <Music className="w-3.5 h-3.5 text-[#25f4ee] animate-spin" />
                  <span className="truncate max-w-[180px] font-bold">
                    {activeViewerReel.music?.title || 'Original Sound'}
                  </span>
                </div>
              </div>

              {/* RIGHT SIDE ACTIONS: Like, Comment, Bookmark/Save, Share, Copy Link, Repost (Same as Home Feed) */}
              <div className="absolute right-2.5 bottom-6 z-20 flex flex-col items-center gap-3.5 text-white select-none pointer-events-auto">
                {/* 1. Creator Follow (+) Button */}
                <div className="relative mb-0.5">
                  <div className="w-10 h-10 rounded-full border-2 border-white overflow-hidden shadow-md">
                    <img
                      src={activeViewerReel.creator.avatar}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {!isSelf && activeViewerReel.creator.id !== currentUser?.id && !activeViewerReel.creator.isFollowed && (
                    <button
                      type="button"
                      onClick={() => {
                        onToggleFollow?.(activeViewerReel.creator.id);
                        onToast?.(language === 'bn' ? '✓ ফলো করা হয়েছে' : '✓ Following');
                      }}
                      className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4.5 h-4.5 rounded-full bg-[#fe2c55] text-white flex items-center justify-center shadow-md active:scale-90 transition-transform cursor-pointer"
                      title="ফলো করুন"
                    >
                      <Plus className="w-3 h-3 stroke-[3]" />
                    </button>
                  )}
                </div>

                {/* 2. Like Button (Heart) - Allowed on own videos and all videos! */}
                <button
                  type="button"
                  onClick={() => {
                    const nextLiked = !activeViewerReel.isLiked;
                    const nextCount = nextLiked ? activeViewerReel.likesCount + 1 : Math.max(0, activeViewerReel.likesCount - 1);
                    setActiveViewerReel({
                      ...activeViewerReel,
                      isLiked: nextLiked,
                      likesCount: nextCount,
                    });
                    onToggleLikeReel?.(activeViewerReel.id);
                    onToast?.(
                      nextLiked 
                        ? (language === 'bn' ? '✓ লাইক দেওয়া হয়েছে ❤️' : '✓ Liked') 
                        : (language === 'bn' ? 'লাইক প্রত্যাহার হয়েছে' : 'Unliked')
                    );
                  }}
                  className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition-colors border border-white/10">
                    <Heart
                      className={`w-6 h-6 transition-colors ${
                        activeViewerReel.isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : 'text-white'
                      }`}
                    />
                  </div>
                  <span className="text-[11px] font-black font-mono drop-shadow-md">
                    {formatCount(activeViewerReel.likesCount)}
                  </span>
                </button>

                {/* 3. Comment Button (MessageCircle) */}
                <button
                  type="button"
                  onClick={() => setShowViewerComments(true)}
                  className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition-colors border border-white/10">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-[11px] font-black font-mono drop-shadow-md">
                    {formatCount(activeViewerReel.commentsCount || (allComments[activeViewerReel.id]?.length || 0))}
                  </span>
                </button>

                {/* 4. Bookmark / Save Button (Bookmark) */}
                <button
                  type="button"
                  onClick={() => {
                    const nextBookmarked = !activeViewerReel.isBookmarked;
                    const nextCount = nextBookmarked ? activeViewerReel.bookmarksCount + 1 : Math.max(0, activeViewerReel.bookmarksCount - 1);
                    setActiveViewerReel({
                      ...activeViewerReel,
                      isBookmarked: nextBookmarked,
                      bookmarksCount: nextCount,
                    });
                    onToggleBookmarkReel?.(activeViewerReel.id);
                    onToast?.(
                      nextBookmarked
                        ? (language === 'bn' ? '✓ ভিডিও সেভ হয়েছে! প্রোফাইলের সেভ আইকনে জমা থাকবে।' : '✓ Saved to profile!')
                        : (language === 'bn' ? 'সেভ রিমুভ হয়েছে' : 'Removed from saved')
                    );
                  }}
                  className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition-colors border border-white/10">
                    <Bookmark
                      className={`w-6 h-6 transition-colors ${
                        activeViewerReel.isBookmarked ? 'fill-amber-400 text-amber-400' : 'text-white'
                      }`}
                    />
                  </div>
                  <span className="text-[11px] font-black font-mono drop-shadow-md">
                    {formatCount(activeViewerReel.bookmarksCount)}
                  </span>
                </button>

                {/* 5. Share & Copy Link Button (Share2) */}
                <button
                  type="button"
                  onClick={() => setShowViewerShare(true)}
                  className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition-colors border border-white/10">
                    <Share2 className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-[11px] font-black font-mono drop-shadow-md">
                    {formatCount(activeViewerReel.sharesCount)}
                  </span>
                </button>

                {/* Unlimited Copy Link Button */}
                <button
                  type="button"
                  onClick={() => {
                    try {
                      navigator.clipboard?.writeText(window.location.origin + '/video/' + activeViewerReel.id);
                    } catch {}
                    handleCopyLinkToClearWarning();
                    onToast?.(
                      language === 'bn' 
                        ? '✓ প্রোফাইল থেকে আনলিমিটেড লিংক কপি করা হয়েছে!' 
                        : '✓ Unlimited video link copied from profile!'
                    );
                  }}
                  className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                  title="লিংক কপি করুন"
                >
                  <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition-colors border border-white/10">
                    <Copy className="w-5 h-5 text-[#25f4ee]" />
                  </div>
                  <span className="text-[10px] font-black font-mono drop-shadow-md text-[#25f4ee]">
                    {language === 'bn' ? 'কপি' : 'Copy'}
                  </span>
                </button>

                {/* 6. Repost Button (Repeat2) */}
                <button
                  type="button"
                  onClick={() => {
                    setActiveViewerReel({
                      ...activeViewerReel,
                      sharesCount: activeViewerReel.sharesCount + 1,
                    });
                    onRepostReel?.(activeViewerReel);
                    onToast?.(language === 'bn' ? '✓ ভিডিওটি রিপোস্ট করা হয়েছে!' : '✓ Video Reposted!');
                  }}
                  className="flex flex-col items-center gap-0.5 active:scale-75 transition-transform cursor-pointer group"
                  title="রিপোস্ট করুন"
                >
                  <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition-colors border border-white/10">
                    <Repeat2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <span className="text-[10px] font-black text-emerald-400">
                    {language === 'bn' ? 'রিপোস্ট' : 'Repost'}
                  </span>
                </button>
              </div>

              {/* COMMENTS DRAWER INSIDE VIDEO VIEWER */}
              {showViewerComments && (
                <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-xs flex flex-col justify-end animate-in fade-in duration-150">
                  <div className="w-full max-h-[65%] bg-white rounded-t-3xl p-4 flex flex-col shadow-2xl text-zinc-900 border-t border-zinc-200">
                    <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
                      <span className="text-sm font-black text-zinc-900">
                        কমেন্টস ({(allComments[activeViewerReel.id] || []).length})
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowViewerComments(false)}
                        className="p-1.5 rounded-full bg-zinc-100 text-zinc-500 hover:text-zinc-800"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex-1 overflow-y-auto py-3 space-y-3 max-h-[220px]">
                      {(allComments[activeViewerReel.id] || []).length === 0 ? (
                        <div className="text-center py-6 text-zinc-400 text-xs font-medium">
                          কোনো কমেন্ট নেই। প্রথম কমেন্টটি আপনিই করুন!
                        </div>
                      ) : (
                        (allComments[activeViewerReel.id] || []).map((comm) => (
                          <div key={comm.id} className="flex items-start gap-2.5">
                            <img src={comm.user.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                            <div className="flex-1 bg-zinc-50 p-2.5 rounded-2xl">
                              <span className="text-[11px] font-black text-zinc-800 block">
                                {comm.user.name}
                              </span>
                              <p className="text-xs text-zinc-700 mt-0.5 font-medium">{comm.text}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!viewerCommentInput.trim()) return;
                        onAddCommentReel?.(activeViewerReel.id, viewerCommentInput.trim());
                        setViewerCommentInput('');
                        onToast?.('✓ কমেন্ট পোস্ট হয়েছে');
                      }}
                      className="pt-2 flex items-center gap-2 border-t border-zinc-100"
                    >
                      <input
                        type="text"
                        value={viewerCommentInput}
                        onChange={(e) => setViewerCommentInput(e.target.value)}
                        placeholder="একটি কমেন্ট লিখুন..."
                        className="flex-1 px-3.5 py-2 rounded-full bg-zinc-100 text-xs text-zinc-800 focus:outline-none focus:ring-2 focus:ring-[#fe2c55]"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-full bg-[#fe2c55] text-white text-xs font-black shadow-md hover:bg-[#e0264b] active:scale-95"
                      >
                        পোস্ট
                      </button>
                    </form>
                  </div>
                </div>
              )}

              {/* SHARE DRAWER INSIDE VIDEO VIEWER (Copy Link, Facebook, WhatsApp, Repost) */}
              {showViewerShare && (
                <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-xs flex flex-col justify-end animate-in fade-in duration-150">
                  <div className="w-full bg-white rounded-t-3xl p-5 shadow-2xl text-zinc-900 border-t border-zinc-200 space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-zinc-100">
                      <h4 className="text-sm font-black text-zinc-900">ভিডিও শেয়ার ও লিঙ্ক কপি</h4>
                      <button
                        type="button"
                        onClick={() => setShowViewerShare(false)}
                        className="p-1.5 rounded-full bg-zinc-100 text-zinc-500 hover:text-zinc-800"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-4 gap-3 text-center">
                      {/* Copy Link Button */}
                      <button
                        type="button"
                        onClick={() => {
                          try {
                            navigator.clipboard?.writeText(window.location.origin + '/video/' + activeViewerReel.id);
                          } catch {}
                          setShowViewerShare(false);
                          onToast?.('✓ ভিডিওর কপি লিংক সম্পন্ন হয়েছে!');
                        }}
                        className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-50 active:scale-95 transition-all cursor-pointer"
                      >
                        <div className="w-12 h-12 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-700 shadow-xs">
                          <Copy className="w-5 h-5" />
                        </div>
                        <span className="text-[11px] font-black text-zinc-800">কপি লিঙ্ক</span>
                      </button>

                      {/* Repost Button */}
                      <button
                        type="button"
                        onClick={() => {
                          onRepostReel?.(activeViewerReel);
                          setShowViewerShare(false);
                          onToast?.('✓ বন্ধুদের কাছে রিপোস্ট করা হয়েছে!');
                        }}
                        className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-50 active:scale-95 transition-all cursor-pointer"
                      >
                        <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 shadow-xs">
                          <Repeat2 className="w-5 h-5" />
                        </div>
                        <span className="text-[11px] font-black text-zinc-800">রিপোস্ট</span>
                      </button>

                      {/* Facebook Button */}
                      <button
                        type="button"
                        onClick={() => {
                          setShowViewerShare(false);
                          onToast?.('✓ Facebook এ শেয়ার লিঙ্ক কপি হয়েছে!');
                        }}
                        className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-50 active:scale-95 transition-all cursor-pointer"
                      >
                        <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 shadow-xs font-black text-lg">
                          f
                        </div>
                        <span className="text-[11px] font-black text-zinc-800">Facebook</span>
                      </button>

                      {/* WhatsApp Button */}
                      <button
                        type="button"
                        onClick={() => {
                          setShowViewerShare(false);
                          onToast?.('✓ WhatsApp এ লিঙ্ক শেয়ারের জন্য প্রস্তুত!');
                        }}
                        className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-50 active:scale-95 transition-all cursor-pointer"
                      >
                        <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 shadow-xs font-black">
                          WA
                        </div>
                        <span className="text-[11px] font-black text-zinc-800">WhatsApp</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* User List Modal (Followers, Following, Profile Views) */}
        {userListModalMode && (
          <UserListModal
            isOpen={true}
            onClose={() => setUserListModalMode(null)}
            mode={userListModalMode}
            targetCount={
              userListModalMode === 'profile_views'
                ? 16
                : userListModalMode === 'following'
                ? currentViewCreator.following
                : currentViewCreator.followers
            }
            targetName={
              userListModalMode === 'profile_views'
                ? (language === 'bn' ? 'প্রোফাইল ভিউয়ার্স' : 'Profile Views')
                : currentViewCreator.name
            }
            language={language}
            currentUser={currentUser}
            onSelectCreator={(selectedUser) => {
              setCreatorHistory((prev) => [...prev, currentViewCreator]);
              setCurrentViewCreator(selectedUser);
              setUserListModalMode(null);
              onToast?.(
                language === 'bn'
                  ? `✓ ${selectedUser.name}-এর প্রোফাইল ও ভিডিওসমূহ লোড হয়েছে`
                  : `✓ Loaded profile for ${selectedUser.name}`
              );
            }}
            onToggleFollow={(creatorId) => {
              onToggleFollow?.(creatorId);
            }}
            onToast={onToast}
          />
        )}

        {/* Edit Profile Modal */}
        <EditProfileModal
          isOpen={showEditProfileModal}
          onClose={() => setShowEditProfileModal(false)}
          creator={creator}
          userAccount={userAccount}
          language={language}
          onToast={onToast}
          onOpenGallery={() => setShowMediaGalleryPicker(true)}
          onSave={(newName, newBio, newHandle, newAvatar, otherFields) => {
            if (onUpdateProfile) {
              onUpdateProfile(newName, newBio, newHandle, newAvatar, otherFields);
            }
          }}
        />

        {/* Media Gallery Picker Modal */}
        <MediaGalleryModal
          isOpen={showMediaGalleryPicker}
          onClose={() => setShowMediaGalleryPicker(false)}
          language={language}
          creator={creator}
          onToast={onToast}
          onSelectProfilePhoto={(url) => {
            if (onUpdateProfile) {
              onUpdateProfile(creator.name, creator.bio, creator.handle, url);
            }
          }}
        />

        {/* Story Viewer Modal (User Request: ইনবক্স ও প্রোফাইল থেকে ক্লিক করলে শুধু তার নিজের স্টোরি দেখতে পাবে) */}
        {showStoryViewer && creatorStories && creatorStories.length > 0 && (
          <StoryViewerModal
            isOpen={showStoryViewer}
            onClose={() => setShowStoryViewer(false)}
            stories={creatorStories}
            language={language}
            onToast={onToast}
            onToggleFollow={onToggleFollow}
          />
        )}

        {/* AuthModal: 95% TikTok Bottom Sheet (Screenshot_20261016-183513.png) */}
        <AuthModal
          isOpen={showAuthSheet}
          onClose={() => setShowAuthSheet(false)}
          onSuccess={(newUser) => {
            onLoginUser?.(newUser);
            setCurrentViewCreator(newUser);
            setShowAuthSheet(false);
            onToast?.(language === 'bn' ? '✓ সফলভাবে টিকটক অ্যাকাউন্টে লগইন হয়েছে!' : '✓ Logged in to TikTok!');
          }}
          language={language}
        />
      </div>
    </div>
  );
};
