import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Bot, Move } from 'lucide-react';
import { AppLanguage } from '../types';

interface FloatingGeminiAssistantProps {
  onOpenAssistant: () => void;
  language: AppLanguage;
  isVisible?: boolean;
}

export const FloatingGeminiAssistant: React.FC<FloatingGeminiAssistantProps> = ({
  onOpenAssistant,
  language,
  isVisible = true,
}) => {
  // Saved position or default bottom-right
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = localStorage.getItem('tiktok_gemini_assistant_pos');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    // Safe default position (bottom-right above nav bar)
    return {
      x: typeof window !== 'undefined' ? Math.max(16, window.innerWidth - 76) : 290,
      y: typeof window !== 'undefined' ? Math.max(80, window.innerHeight - 220) : 500,
    };
  });

  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number } | null>(null);
  const hasMovedRef = useRef<boolean>(false);

  // Keep within window viewport upon resize
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => ({
        x: Math.max(8, Math.min(window.innerWidth - 64, prev.x)),
        y: Math.max(48, Math.min(window.innerHeight - 90, prev.y)),
      }));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Save to localStorage when position updates
  const updatePosition = (newX: number, newY: number) => {
    const clampedX = Math.max(8, Math.min(window.innerWidth - 64, newX));
    const clampedY = Math.max(48, Math.min(window.innerHeight - 90, newY));
    setPosition({ x: clampedX, y: clampedY });
    try {
      localStorage.setItem('tiktok_gemini_assistant_pos', JSON.stringify({ x: clampedX, y: clampedY }));
    } catch {}
  };

  // Pointer Down (Touch / Mouse)
  const handlePointerDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    hasMovedRef.current = false;
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: position.x,
      initialY: position.y,
    };
    setIsDragging(true);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  // Pointer Move (Touch / Mouse)
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !dragStartRef.current) return;
    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;

    if (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4) {
      hasMovedRef.current = true;
    }

    updatePosition(
      dragStartRef.current.initialX + deltaX,
      dragStartRef.current.initialY + deltaY
    );
  };

  // Pointer Up (Touch / Mouse)
  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}

    // If user tapped without dragging, open Gemini Assistant
    if (!hasMovedRef.current) {
      onOpenAssistant();
    }
  };

  if (!isVisible) return null;

  return (
    <div
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
        touchAction: 'none',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={() => setIsDragging(false)}
      className={`fixed top-0 left-0 z-[89] cursor-grab active:cursor-grabbing select-none transition-shadow ${
        isDragging ? 'scale-110 opacity-95' : 'hover:scale-105 active:scale-95'
      }`}
      title={
        language === 'bn'
          ? 'ভাসমান জিমিনি এআই এসিস্ট্যান্ট (স্ক্রিনের যেকোনো জায়গায় টেনে রাখুন বা প্রশ্ন করতে ট্যাপ করুন)'
          : 'Floating Gemini AI Assistant (Drag anywhere across screen or tap to open)'
      }
    >
      <div className="relative group">
        
        {/* Iridescent Breathing Outer Glow Ring */}
        <div className="absolute -inset-1.5 rounded-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-fuchsia-500 opacity-80 blur-xs group-hover:opacity-100 transition-opacity animate-pulse" />

        {/* Circular Gemini Bubble Button */}
        <div className="relative w-13 h-13 rounded-full bg-zinc-950 border border-white/30 p-1 flex flex-col items-center justify-center text-white shadow-2xl overflow-hidden backdrop-blur-md">
          
          {/* Glowing Animated Gradient Background */}
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-950/70 via-indigo-900/50 to-fuchsia-950/70 opacity-90" />

          {/* Gemini Icon */}
          <Sparkles className="relative z-10 w-6 h-6 text-[#25f4ee] stroke-[2.2] animate-spin-slow drop-shadow-md" />

          {/* Tiny Label Badge */}
          <span className="relative z-10 text-[8px] font-black tracking-tighter text-white drop-shadow-md uppercase mt-0.5">
            Gemini
          </span>

          {/* Online Green Beacon */}
          <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-zinc-950 shadow-xs" />
        </div>

        {/* Floating Tooltip hint on hover or drag */}
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-md bg-black/90 text-[9px] font-bold text-cyan-300 border border-cyan-500/30 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-lg">
          {isDragging
            ? (language === 'bn' ? 'নড়াচড়া হচ্ছে...' : 'Moving...')
            : (language === 'bn' ? 'টেনে নিন / ট্যাপ করুন' : 'Drag / Tap')}
        </div>
      </div>
    </div>
  );
};
