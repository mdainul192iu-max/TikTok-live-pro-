import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Play, Pause, Music, Heart, MessageCircle, Share2 } from 'lucide-react';
import { initialReels, mockSoundTracks } from '../data/mockData';
import { SoundTrack } from '../types';

interface VideoData {
  video_id: string;
  video_url: string;
  poster_url: string;
  audio_url: string;
  song_title: string;
  artist: string;
  caption: string;
}

interface TikTokVideoFeedProps {
  onBack: () => void;
  onUseSound: (sound: SoundTrack) => void;
  onOpenComment?: () => void;
  onShareVideo?: () => void;
}

export const TikTokVideoFeed: React.FC<TikTokVideoFeedProps> = ({
  onBack,
  onUseSound,
  onOpenComment,
  onShareVideo,
}) => {
  const [videos, setVideos] = useState<VideoData[]>([]);
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);

  // 1. Load initial 10 items (limitToFirst(10))
  useEffect(() => {
    loadVideos(1);
  }, []);

  const loadVideos = (pageNum: number) => {
    setIsLoadingMore(true);
    setTimeout(() => {
      const newItems: VideoData[] = Array.from({ length: 10 }).map((_, idx) => {
        const itemIdx = (pageNum - 1) * 10 + idx;
        const sourceReel = initialReels[itemIdx % initialReels.length];
        return {
          video_id: `v_${pageNum}_${idx}_${Date.now()}`,
          video_url: sourceReel.videoUrl,
          poster_url: sourceReel.posterUrl,
          audio_url: sourceReel.music.audioUrl,
          song_title: sourceReel.music.title,
          artist: sourceReel.creator.name,
          caption: sourceReel.caption,
        };
      });

      setVideos((prev) => (pageNum === 1 ? newItems : [...prev, ...newItems]));
      setIsLoadingMore(false);
    }, 400);
  };

  // 2. Scroll tracking for current active video and endless scroll trigger
  const handleScroll = () => {
    if (!containerRef.current) return;
    const { scrollTop, clientHeight, scrollHeight } = containerRef.current;
    const currentIndex = Math.round(scrollTop / clientHeight);

    if (currentIndex !== activeIndex && currentIndex >= 0 && currentIndex < videos.length) {
      setActiveIndex(currentIndex);
    }

    // Endless scroll: when within 2 items from bottom, load next 10 items
    if (scrollTop + clientHeight >= scrollHeight - clientHeight * 2 && !isLoadingMore) {
      setPage((prev) => {
        const next = prev + 1;
        loadVideos(next);
        return next;
      });
    }
  };

  useEffect(() => {
    videoRefs.current.forEach((v, idx) => {
      if (v) {
        if (idx === activeIndex) {
          v.play().catch(() => {});
        } else {
          v.pause();
          v.currentTime = 0;
        }
      }
    });
  }, [activeIndex, videos]);

  return (
    <div className="relative w-full h-full bg-black select-none">
      {/* Top Back Header */}
      <div className="absolute top-3 left-3 z-30 flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md flex items-center justify-center text-white cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
        </button>
        <span className="text-xs font-black text-white bg-black/40 px-3 py-1 rounded-full backdrop-blur-md border border-white/10">
          RTDB Endless Stream (10-Items)
        </span>
      </div>

      {/* Snap Scroll Video Container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="w-full h-full overflow-y-scroll snap-y snap-mandatory no-scrollbar"
      >
        {videos.map((vid, idx) => (
          <div
            key={vid.video_id}
            className="w-full h-full snap-start relative flex items-center justify-center bg-black overflow-hidden"
          >
            <video
              ref={(el) => (videoRefs.current[idx] = el)}
              src={vid.video_url}
              poster={vid.poster_url}
              loop
              playsInline
              muted={false}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80 pointer-events-none" />

            {/* Bottom Info */}
            <div className="absolute bottom-16 left-4 right-16 text-white space-y-1 pointer-events-none">
              <span className="text-sm font-black">@{vid.artist.toLowerCase().replace(/\s+/g, '_')}</span>
              <p className="text-xs text-white/90 line-clamp-2">{vid.caption}</p>
              <div
                onClick={() =>
                  onUseSound({
                    id: `snd_${vid.video_id}`,
                    title: vid.song_title,
                    artist: vid.artist,
                    audioUrl: vid.audio_url,
                    cover: vid.poster_url,
                    duration: '0:30',
                    usesCount: 14200,
                    category: 'trending',
                  })
                }
                className="flex items-center gap-1.5 text-xs text-zinc-300 pointer-events-auto cursor-pointer"
              >
                <Music className="w-3.5 h-3.5 animate-spin" />
                <span>{vid.song_title}</span>
              </div>
            </div>

            {/* Right Actions */}
            <div className="absolute bottom-20 right-3 flex flex-col items-center gap-4 text-white z-20">
              <button
                onClick={onOpenComment}
                className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center cursor-pointer active:scale-90"
              >
                <MessageCircle className="w-5 h-5" />
              </button>
              <button
                onClick={onShareVideo}
                className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center cursor-pointer active:scale-90"
              >
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
