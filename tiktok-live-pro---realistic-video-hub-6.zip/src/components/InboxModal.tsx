import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, 
  Search, 
  Phone, 
  Video, 
  Send, 
  Camera, 
  Plus, 
  UserPlus, 
  BellOff, 
  ChevronDown, 
  Check, 
  X, 
  Zap,
  Users,
  ShieldCheck,
  Eye,
  EyeOff,
  Home,
  MessageSquare,
  User,
  Heart,
  Share2,
  CheckCircle2,
  Wifi,
  Battery,
  MoreHorizontal,
  Image as ImageIcon,
  Smile,
  Mic,
  MicOff,
  Bookmark,
  Share,
  Sliders,
  Flag,
  Ban,
  ChevronRight,
  Palette,
  Volume2,
  Pin,
  Play,
  Film,
  Paperclip,
  Trash2,
  CornerDownRight
} from 'lucide-react';
import { AppLanguage, UserAccount, Creator, UserStory, InboxActivityItem } from '../types';
import { StoryViewerModal } from './StoryViewerModal';

export interface FriendChat {
  id: string;
  name: string;
  handle: string;
  uid?: string;
  avatar: string;
  isOnline: boolean;
  lastMessage: string;
  time: string;
  unreadCount?: number;
  isMuted?: boolean;
  isCameraAction?: boolean;
  isGroup?: boolean;
  isPinned?: boolean;
  isMuteMessages?: boolean;
  isMuteCalls?: boolean;
  isBlocked?: boolean;
  bubbleTheme?: string;
  wallpaper?: string;
  alertTone?: string;
}

export interface ChatMessageItem {
  id: string;
  sender: 'me' | 'them';
  text?: string;
  time: string;
  type?: 'text' | 'image' | 'video' | 'voice' | 'sticker' | 'shared_reel';
  mediaUrl?: string;
  voiceDuration?: string;
  stickerEmoji?: string;
  isSaved?: boolean;
  sharedReelTitle?: string;
}

interface InboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  currentUser?: UserAccount | Creator | null;
  userStories?: UserStory[];
  initialTargetChat?: Creator | FriendChat | null;
  activities?: InboxActivityItem[];
  onSelectReelFromActivity?: (reelId: string) => void;
  onToggleFollow?: (creatorId: string) => void;
  onOpenStory?: (story: UserStory) => void;
  onAddStory?: (videoUrl: string) => void;
  onOpenProfile?: (creator?: Creator) => void;
  onStartCall?: (user: any, type: 'video' | 'audio') => void;
  onToast?: (msg: string) => void;
  onOpenHome?: () => void;
  onOpenFriends?: () => void;
  onOpenUpload?: () => void;
}

export const InboxModal: React.FC<InboxModalProps> = ({
  isOpen,
  onClose,
  language,
  currentUser,
  userStories = [],
  initialTargetChat,
  activities = [],
  onSelectReelFromActivity,
  onToggleFollow,
  onOpenStory,
  onAddStory,
  onOpenProfile,
  onStartCall,
  onToast,
  onOpenHome,
  onOpenFriends,
  onOpenUpload,
}) => {
  // Views: 'inbox' (main dashboard) | 'group_create' | 'search_accounts' | 'chat' | 'chat_details' | 'activity'
  const [activeView, setActiveView] = useState<'inbox' | 'group_create' | 'search_accounts' | 'chat' | 'chat_details' | 'activity'>('inbox');
  const [activityFilter, setActivityFilter] = useState<'all' | 'like' | 'comment' | 'reply' | 'follow'>('all');
  
  // Activity Status: Public (🟢) | Friends (🟢) | No one (⚪)
  const [onlineStatus, setOnlineStatus] = useState<'public' | 'friends' | 'no_one'>('public');
  const [showStatusDropdown, setShowStatusDropdown] = useState<boolean>(false);

  // Search screen query
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Group Create selection
  const [selectedFriendsForGroup, setSelectedFriendsForGroup] = useState<string[]>([]);
  const [groupNameInput, setGroupNameInput] = useState<string>('');

  // Active chat & messages
  const [activeChat, setActiveChat] = useState<FriendChat | null>(null);
  const [inputText, setInputText] = useState<string>('');
  const [showStickerDrawer, setShowStickerDrawer] = useState<boolean>(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState<boolean>(false);
  const [voiceDurationCount, setVoiceDurationCount] = useState<number>(0);
  const voiceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Detail Sheet Sub-modals for Screenshot_20261016-175440.png
  const [showChatBubbleModal, setShowChatBubbleModal] = useState<boolean>(false);
  const [showWallpaperModal, setShowWallpaperModal] = useState<boolean>(false);
  const [showAlertToneModal, setShowAlertToneModal] = useState<boolean>(false);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [activeMediaTab, setActiveMediaTab] = useState<'share' | 'gallery' | 'saved'>('share');
  const [inboxStoryViewerList, setInboxStoryViewerList] = useState<UserStory[] | null>(null);

  // Hidden native video/image file inputs
  const galleryVideoInputRef = useRef<HTMLInputElement>(null);
  const chatMediaInputRef = useRef<HTMLInputElement>(null);

  // SVG Data URI for exact black circular avatar with 2 white stripes (==) from screenshot
  const alArafatAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23050505"/><rect x="24" y="41" width="52" height="7" rx="3.5" fill="white"/><rect x="24" y="53" width="52" height="7" rx="3.5" fill="white"/></svg>`;

  // 4-Split Collage SVG for Groups 5 and 6
  const groupPhdAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23222"/><rect x="0" y="0" width="49" height="49" fill="%23e2e8f0"/><text x="18" y="32" font-size="20">🍒</text><rect x="51" y="0" width="49" height="49" fill="%23cbd5e1"/><text x="65" y="32" font-size="20">✨</text><rect x="0" y="51" width="49" height="49" fill="%2394a3b8"/><text x="18" y="80" font-size="20">🔥</text><rect x="51" y="51" width="49" height="49" fill="%23f43f5e"/><text x="65" y="80" font-size="20">💃</text></svg>`;

  const groupVondoAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23111"/><rect x="0" y="0" width="49" height="49" fill="%23fef08a"/><text x="15" y="32" font-size="22">🙂</text><rect x="51" y="0" width="49" height="49" fill="%23bbf7d0"/><text x="65" y="32" font-size="22">🐸</text><rect x="0" y="51" width="49" height="49" fill="%23fbcfe8"/><text x="15" y="80" font-size="22">👍</text><rect x="51" y="51" width="49" height="49" fill="%23ddd6fe"/><text x="65" y="80" font-size="22">🚩</text></svg>`;

  // Exact friend chats from the user's uploaded screenshot (Screenshot_20261016-165853.png)
  const initialFriends: FriendChat[] = [
    {
      id: 'mst-nila',
      name: 'Mst Nila Khatun 4064',
      handle: 'nila_khatun4064',
      uid: '7192837461',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      isOnline: true,
      lastMessage: 'Sent just now',
      time: 'Sent just now',
      isCameraAction: true,
      bubbleTheme: 'tiktok_red',
      wallpaper: 'default',
      alertTone: 'tiktok_chime',
      isPinned: false,
      isMuteMessages: false,
      isMuteCalls: false,
    },
    {
      id: 'al-arafat',
      name: '👑 𝑨𝑳 𝑨𝑹𝑨𝑭𝑨𝑻 👑',
      handle: 'al_arafat_king',
      uid: '8294719203',
      avatar: alArafatAvatar,
      isOnline: true,
      lastMessage: 'Sent just now',
      time: 'Sent just now',
      isCameraAction: true,
      bubbleTheme: 'classic',
      wallpaper: 'night',
      alertTone: 'pop',
      isPinned: false,
    },
    {
      id: 'orko',
      name: 'Orko Ahamed',
      handle: 'orko_ahamed_official',
      uid: '9182746592',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&auto=format&fit=crop&q=80',
      isOnline: true,
      lastMessage: 'Sent just now',
      time: 'Sent just now',
      isCameraAction: true,
      bubbleTheme: 'cyan',
    },
    {
      id: 'group-bondhu',
      name: '😘বন্ধুদের 😉 আড্ডা❤️',
      handle: 'bondhuder_adda',
      uid: '4928174920',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      isOnline: true,
      lastMessage: 'M❤️❤️মা বাবার রাজকন্যা ...',
      time: '3h',
      isMuted: true,
      unreadCount: 2,
      isGroup: true,
    },
    {
      id: 'group-phd',
      name: '🍒 দুষ্টুমিতে -P.H.D 🍒',
      handle: 'dustomite_phd',
      uid: '6182940294',
      avatar: groupPhdAvatar,
      isOnline: true,
      lastMessage: '‿ ₊+♦Mehrin ₊˚ˑM: all like pl...',
      time: '7h',
      unreadCount: 6,
      isGroup: true,
    },
    {
      id: 'group-vondo',
      name: '🙂ভন্ডদের আড্ডা 🐸👍',
      handle: 'vondoder_adda',
      uid: '3948271029',
      avatar: groupVondoAvatar,
      isOnline: false,
      lastMessage: 'A🚩 shared a video',
      time: '7h',
      unreadCount: 3,
      isGroup: true,
    },
  ];

  const [friendList, setFriendList] = useState<FriendChat[]>(initialFriends);

  // Chat messages by friend ID
  const [chatMessages, setChatMessages] = useState<Record<string, ChatMessageItem[]>>({
    'mst-nila': [
      { id: 'm1', sender: 'them', text: 'হ্যালো! কেমন আছেন? আপনার ভিডিও দারুণ ছিল 🔥', time: '5:40 PM', type: 'text' },
      { id: 'm2', sender: 'them', time: '5:42 PM', type: 'shared_reel', mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-sign-city-40011-large.mp4', sharedReelTitle: 'Cyberpunk Dhaka Vibes 🌟 #fyp #viral', isSaved: true },
      { id: 'm3', sender: 'me', text: 'অনেক ধন্যবাদ নীলা! নতুন ভিডিওতে লাইক দিয়েন ❤️', time: '5:45 PM', type: 'text' },
    ],
    'al-arafat': [
      { id: 'm1', sender: 'them', text: 'আসসালামু আলাইকুম ভাইয়া! আপনার রিয়েল মিউজিক ফিডটা অসাধারণ 🎶', time: 'Sent just now', type: 'text' },
    ],
    'orko': [
      { id: 'm1', sender: 'them', text: 'ভাই আপনার সাথে নতুন ভাইরাল ভিডিও বানাতে চাই 🎬', time: 'Sent just now', type: 'text' },
    ],
    'group-bondhu': [
      { id: 'm1', sender: 'them', text: 'M❤️❤️মা বাবার রাজকন্যা ... সবাই লাইভে আসো!', time: '3h', type: 'text' },
    ],
    'group-phd': [
      { id: 'm1', sender: 'them', text: '‿ ₊+♦Mehrin ₊˚ˑM: all like please ❤️', time: '7h', type: 'text' },
    ],
    'group-vondo': [
      { id: 'm1', sender: 'them', text: 'A🚩 shared a video', time: '7h', type: 'text' },
    ],
  });

  // Handle Initial Target Chat (e.g. from Profile "Message" button click)
  useEffect(() => {
    if (initialTargetChat) {
      const existing = friendList.find((f) => f.id === initialTargetChat.id);
      if (existing) {
        setActiveChat(existing);
      } else {
        const newFriend: FriendChat = {
          id: initialTargetChat.id,
          name: initialTargetChat.name,
          handle: initialTargetChat.handle,
          uid: (initialTargetChat as any).uid || '8927192049',
          avatar: initialTargetChat.avatar,
          isOnline: true,
          lastMessage: 'নতুন কথোপকথন শুরু হয়েছে',
          time: 'Sent just now',
          isCameraAction: true,
        };
        setFriendList((prev) => [newFriend, ...prev]);
        setActiveChat(newFriend);
      }
      setActiveView('chat');
    }
  }, [initialTargetChat]);

  // Quick Friends for Horizontal Story Bar (exact matches from screenshot)
  const quickFriends = [
    {
      id: 'q-jibon',
      name: '✨Jibon✨🎀',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    },
    {
      id: 'q-shuvo',
      name: 'Shuvo 4499',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    },
    {
      id: 'q-nobito',
      name: '👅NOBITO ...',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    },
    {
      id: 'q-arafat',
      name: '👑 AL ARAFAT',
      avatar: alArafatAvatar,
    },
  ];

  if (!isOpen) return null;

  // Bump friend to top of the list whenever a message is sent
  const bumpFriendToTop = (friendId: string, lastMsgText: string) => {
    setFriendList((prev) => {
      const target = prev.find((f) => f.id === friendId);
      if (!target) return prev;
      const updatedTarget = {
        ...target,
        lastMessage: lastMsgText,
        time: 'Sent just now',
      };
      const filtered = prev.filter((f) => f.id !== friendId);
      return [updatedTarget, ...filtered];
    });
  };

  // Handle Video Story Selected from Phone Gallery
  const handleGalleryVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      onAddStory?.(url);
      onToast?.(
        language === 'bn'
          ? '✓ ফোনের গ্যালারি থেকে সম্পূর্ণ ভিডিও স্টোরি সফলভাবে যুক্ত হয়েছে এবং প্রোফাইলে রঙিন বর্ডার ঘুরছে!'
          : '✓ Full video story uploaded from gallery with colorful animated ring!'
      );
    }
  };

  // Handle Sending Media from Phone Gallery into Chat
  const handleChatMediaSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeChat) return;

    const url = URL.createObjectURL(file);
    const isVid = file.type.startsWith('video');

    const newMsg: ChatMessageItem = {
      id: `media-${Date.now()}`,
      sender: 'me',
      type: isVid ? 'video' : 'image',
      mediaUrl: url,
      text: isVid ? 'ভিডিও শেয়ার করা হয়েছে 🎬' : 'ছবি শেয়ার করা হয়েছে 📷',
      time: 'এইমাত্র',
      isSaved: false,
    };

    setChatMessages((prev) => ({
      ...prev,
      [activeChat.id]: [...(prev[activeChat.id] || []), newMsg],
    }));

    bumpFriendToTop(activeChat.id, isVid ? 'Sent a video 📹' : 'Sent a photo 🖼️');
    onToast?.(language === 'bn' ? '✓ গ্যালারি থেকে ফাইল পাঠানো হয়েছে!' : '✓ Media sent to chat!');

    // Instant realistic reply
    setTimeout(() => {
      const replyMsg: ChatMessageItem = {
        id: `reply-${Date.now()}`,
        sender: 'them',
        type: 'text',
        text: isVid ? 'অসাধারণ ভিডিও ভাই! সেভ করে রাখলাম 🔥' : 'সুন্দর ছবি! দারুণ লেগেছে ❤️',
        time: 'এইমাত্র',
      };
      setChatMessages((prev) => ({
        ...prev,
        [activeChat.id]: [...(prev[activeChat.id] || []), replyMsg],
      }));
    }, 1200);
  };

  // Handle Voice Recording
  const startVoiceRecording = () => {
    setIsRecordingVoice(true);
    setVoiceDurationCount(0);
    voiceTimerRef.current = setInterval(() => {
      setVoiceDurationCount((c) => c + 1);
    }, 1000);
    onToast?.(language === 'bn' ? '🎙️ ভয়েস রেকর্ড হচ্ছে... শেষ করতে আবার চাপ দিন' : 'Recording voice...');
  };

  const stopAndSendVoiceRecording = () => {
    if (!activeChat) return;
    setIsRecordingVoice(false);
    if (voiceTimerRef.current) clearInterval(voiceTimerRef.current);

    const dur = `${Math.floor(voiceDurationCount / 60)}:${(voiceDurationCount % 60).toString().padStart(2, '0')}`;
    const newMsg: ChatMessageItem = {
      id: `voice-${Date.now()}`,
      sender: 'me',
      type: 'voice',
      voiceDuration: dur === '0:00' ? '0:03' : dur,
      text: 'ভয়েস মেসেজ 🎙️',
      time: 'এইমাত্র',
    };

    setChatMessages((prev) => ({
      ...prev,
      [activeChat.id]: [...(prev[activeChat.id] || []), newMsg],
    }));

    bumpFriendToTop(activeChat.id, 'Voice message 🎙️');
    onToast?.(language === 'bn' ? '✓ ভয়েস মেসেজ সফলভাবে পাঠানো হয়েছে!' : 'Voice message sent!');
  };

  // Handle Sending Sticker
  const handleSendSticker = (emoji: string) => {
    if (!activeChat) return;
    setShowStickerDrawer(false);

    const newMsg: ChatMessageItem = {
      id: `stk-${Date.now()}`,
      sender: 'me',
      type: 'sticker',
      stickerEmoji: emoji,
      text: emoji,
      time: 'এইমাত্র',
    };

    setChatMessages((prev) => ({
      ...prev,
      [activeChat.id]: [...(prev[activeChat.id] || []), newMsg],
    }));

    bumpFriendToTop(activeChat.id, `Sticker ${emoji}`);
  };

  // Handle Online Status Selection from top dropdown
  const handleSelectStatus = (status: 'public' | 'friends' | 'no_one') => {
    setOnlineStatus(status);
    setShowStatusDropdown(false);
    onToast?.(
      status === 'public'
        ? (language === 'bn' ? '🟢 অনলাইন স্ট্যাটাস: Public (সবাই অনলাইন দেখতে পাবে)' : '🟢 Active Status: Public')
        : status === 'friends'
        ? (language === 'bn' ? '🟢 অনলাইন স্ট্যাটাস: Friends (শুধু বন্ধুরা দেখতে পাবে)' : '🟢 Active Status: Friends only')
        : (language === 'bn' ? '⚪ অফলাইন মোড চালু: No one (কাউকে দেখাবে না)' : '⚪ Appear Offline (No one)')
    );
  };

  // Handle Send Text Message in active chat
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeChat) return;

    const textToSend = inputText.trim();
    const newMsg: ChatMessageItem = {
      id: `m-${Date.now()}`,
      sender: 'me',
      type: 'text',
      text: textToSend,
      time: 'এইমাত্র',
    };

    setChatMessages((prev) => ({
      ...prev,
      [activeChat.id]: [...(prev[activeChat.id] || []), newMsg],
    }));
    setInputText('');

    // Bump this friend to the very TOP of the friend list
    bumpFriendToTop(activeChat.id, textToSend);

    // Instant realistic reply from friend
    setTimeout(() => {
      const replyMsg: ChatMessageItem = {
        id: `reply-${Date.now()}`,
        sender: 'them',
        type: 'text',
        text: 'ধন্যবাদ মেসেজ দেওয়ার জন্য! আপনার ভিডিওগুলো নিয়মিত দেখি ❤️🔥',
        time: 'এইমাত্র',
      };
      setChatMessages((prev) => ({
        ...prev,
        [activeChat.id]: [...(prev[activeChat.id] || []), replyMsg],
      }));
    }, 1000);
  };

  // Toggle Save item into the Saved tab
  const handleToggleSaveItem = (msgId: string) => {
    if (!activeChat) return;
    setChatMessages((prev) => ({
      ...prev,
      [activeChat.id]: (prev[activeChat.id] || []).map((m) =>
        m.id === msgId ? { ...m, isSaved: !m.isSaved } : m
      ),
    }));
    onToast?.(language === 'bn' ? '✓ সেভ স্ট্যাটাস আপডেট হয়েছে!' : '✓ Save status updated!');
  };

  // Handle Group Create submission
  const handleCreateGroup = () => {
    const name = groupNameInput.trim() || 'আমার নতুন গ্রুপ 🔥';
    const newGroup: FriendChat = {
      id: `grp-${Date.now()}`,
      name,
      handle: `group_${Date.now().toString().slice(-4)}`,
      uid: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
      avatar: groupPhdAvatar,
      isOnline: true,
      lastMessage: 'গ্রুপ তৈরি সম্পন্ন হয়েছে',
      time: 'এইমাত্র',
      isGroup: true,
      unreadCount: 1,
    };

    setFriendList((prev) => [newGroup, ...prev]);
    setSelectedFriendsForGroup([]);
    setGroupNameInput('');
    setActiveView('inbox');
    onToast?.(
      language === 'bn'
        ? `✓ '${name}' গ্রুপ সফলভাবে তৈরি হয়েছে!`
        : `✓ Group '${name}' created successfully!`
    );
  };

  // Filtered accounts for Search View
  const searchResults = friendList.filter((f) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      f.name.toLowerCase().includes(q) ||
      f.handle.toLowerCase().includes(q) ||
      (f.uid && f.uid.includes(q))
    );
  });

  const topMatch = searchQuery.trim() && searchResults.length > 0 ? searchResults[0] : null;
  const otherMatches = topMatch ? searchResults.filter((f) => f.id !== topMatch.id) : searchResults;

  // Media items for the 3 tabs in Screenshot_20261016-175440.png
  const currentChatMessages = activeChat ? chatMessages[activeChat.id] || [] : [];
  const sharedReels = currentChatMessages.filter((m) => m.type === 'shared_reel');
  const galleryMedia = currentChatMessages.filter((m) => m.type === 'image' || m.type === 'video');
  const savedItems = currentChatMessages.filter((m) => m.isSaved);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md select-none pointer-events-auto animate-in fade-in duration-200">
      
      {/* Hidden Native Phone Video Gallery File Input for Full Video Story */}
      <input
        type="file"
        ref={galleryVideoInputRef}
        onChange={handleGalleryVideoSelect}
        accept="video/*"
        className="hidden"
      />

      {/* Hidden Native Media Picker for Chat (Photos & Videos) */}
      <input
        type="file"
        ref={chatMediaInputRef}
        onChange={handleChatMediaSelect}
        accept="image/*,video/*"
        className="hidden"
      />

      {/* Main TikTok White Frame Container */}
      <div className="relative w-full max-w-[430px] h-full sm:h-[95vh] bg-white text-zinc-900 sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden">

        {/* ========================================================================= */}
        {/* VIEW 1: MAIN INBOX DASHBOARD (Screenshot_20261016-165853.png) */}
        {/* ========================================================================= */}
        {activeView === 'inbox' && (
          <div className="flex-1 flex flex-col overflow-hidden bg-white">
            
            {/* REALISTIC MOBILE STATUS BAR (4:58, WiFi, Battery 62) */}
            <div className="px-5 pt-2 pb-1 flex items-center justify-between text-xs font-bold text-zinc-800 bg-white select-none">
              <span className="tracking-tight text-sm font-black">4:58</span>
              <div className="flex items-center gap-1.5">
                <Wifi className="w-3.5 h-3.5 stroke-[2.4]" />
                <span className="text-[10px] font-mono font-bold">LTE</span>
                <div className="flex items-center gap-0.5 border border-zinc-600 rounded-sm px-1 py-0.2">
                  <span className="text-[9px] font-bold">62</span>
                  <div className="w-1.5 h-2 bg-zinc-800 rounded-xs" />
                </div>
              </div>
            </div>

            {/* 1. TOP HEADER APP BAR (Screenshot matching) */}
            <div className="px-4 py-2 flex items-center justify-between border-b border-zinc-100 bg-white sticky top-0 z-30">
              
              {/* Left: Group Create icon (👥+) */}
              <button
                type="button"
                onClick={() => setActiveView('group_create')}
                className="w-9 h-9 rounded-full hover:bg-zinc-100 active:scale-95 flex items-center justify-center text-zinc-900 transition-all cursor-pointer"
                title="গ্রুপ তৈরি করুন (Create Group)"
              >
                <div className="relative flex items-center justify-center">
                  <svg className="w-6 h-6 fill-none stroke-zinc-900 stroke-[2.2] stroke-linecap-round stroke-linejoin-round" viewBox="0 0 24 24">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                  <span className="absolute -top-1 -right-1 text-[11px] font-black text-zinc-900 leading-none">+</span>
                </div>
              </button>

              {/* Center: Inbox with Activity Status Dropdown Trigger [ 🟢 ▾ ] */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowStatusDropdown(!showStatusDropdown)}
                  className="flex items-center gap-1.5 py-1 px-2 rounded-full hover:bg-zinc-100 active:scale-95 transition-all cursor-pointer"
                  title="অনলাইন স্ট্যাটাস পরিবর্তন করুন (Public / Friends / No one)"
                >
                  <h3 className="font-extrabold text-lg text-zinc-900 tracking-tight">
                    Inbox
                  </h3>
                  <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-zinc-100 border border-zinc-200">
                    <span className={`w-2 h-2 rounded-full ${onlineStatus === 'no_one' ? 'bg-zinc-400' : 'bg-emerald-500 shadow-xs'}`} />
                    <ChevronDown className="w-3 h-3 text-zinc-500 stroke-[2.5]" />
                  </div>
                </button>

                {/* Dropdown Sheet / Popover: Public | Friends | No one */}
                {showStatusDropdown && (
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 bg-white border border-zinc-200 rounded-2xl shadow-2xl p-2 z-50 text-zinc-850 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="flex items-center justify-between px-3 py-1 border-b border-zinc-100 mb-1">
                      <p className="text-[10px] font-black text-zinc-400 uppercase tracking-wider">
                        {language === 'bn' ? 'অ্যাক্টিভিটি স্ট্যাটাস' : 'Active Status'}
                      </p>
                      <button 
                        onClick={() => setShowStatusDropdown(false)}
                        className="text-zinc-400 hover:text-black p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    
                    {/* Public */}
                    <button
                      type="button"
                      onClick={() => handleSelectStatus('public')}
                      className={`w-full p-2.5 rounded-xl flex items-center justify-between text-xs font-bold transition-colors cursor-pointer ${
                        onlineStatus === 'public' ? 'bg-emerald-50 text-emerald-700' : 'hover:bg-zinc-100 text-zinc-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                        <div className="text-left">
                          <p className="font-extrabold text-xs">Public</p>
                          <p className="text-[10px] text-zinc-500 font-normal">সবাই আপনাকে অনলাইন দেখতে পাবে</p>
                        </div>
                      </div>
                      {onlineStatus === 'public' && <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />}
                    </button>

                    {/* Friends */}
                    <button
                      type="button"
                      onClick={() => handleSelectStatus('friends')}
                      className={`w-full p-2.5 rounded-xl flex items-center justify-between text-xs font-bold transition-colors cursor-pointer ${
                        onlineStatus === 'friends' ? 'bg-emerald-50 text-emerald-700' : 'hover:bg-zinc-100 text-zinc-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                        <div className="text-left">
                          <p className="font-extrabold text-xs">Friends</p>
                          <p className="text-[10px] text-zinc-500 font-normal">শুধু ফ্রেন্ড লিস্টের বন্ধুরা দেখতে পাবে</p>
                        </div>
                      </div>
                      {onlineStatus === 'friends' && <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />}
                    </button>

                    {/* No one */}
                    <button
                      type="button"
                      onClick={() => handleSelectStatus('no_one')}
                      className={`w-full p-2.5 rounded-xl flex items-center justify-between text-xs font-bold transition-colors cursor-pointer ${
                        onlineStatus === 'no_one' ? 'bg-zinc-100 text-zinc-900 font-black' : 'hover:bg-zinc-100 text-zinc-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-zinc-400" />
                        <div className="text-left">
                          <p className="font-extrabold text-xs">No one</p>
                          <p className="text-[10px] text-zinc-500 font-normal">অফলাইন হিসেবে দেখাবে</p>
                        </div>
                      </div>
                      {onlineStatus === 'no_one' && <Check className="w-4 h-4 text-zinc-700 stroke-[3]" />}
                    </button>
                  </div>
                )}
              </div>

              {/* Right: Search icon */}
              <button
                type="button"
                onClick={() => setActiveView('search_accounts')}
                className="w-9 h-9 rounded-full hover:bg-zinc-100 active:scale-95 flex items-center justify-center text-zinc-900 transition-all cursor-pointer"
                title="অ্যাকাউন্ট সার্চ (Search Users)"
              >
                <Search className="w-5.5 h-5.5 stroke-[2.4]" />
              </button>
            </div>

            {/* SCROLLABLE INBOX CONTENT */}
            <div className="flex-1 overflow-y-auto no-scrollbar">

              {/* 2. HORIZONTAL STORY & QUICK FRIENDS REEL */}
              <div className="pt-3 pb-3 px-3 border-b border-zinc-100 bg-white">
                <div className="flex items-start gap-4 overflow-x-auto no-scrollbar py-1">
                  
                  {/* Item 1: User's Profile / Story Create ("Spill the tea" bubble) */}
                  <div className="flex flex-col items-center shrink-0">
                    <div className="relative mb-1">
                      {/* Speech Bubble "Spill the tea" pointing down */}
                      <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-white border border-zinc-200 px-2 py-0.5 rounded-xl shadow-xs whitespace-nowrap pointer-events-none z-10">
                        <span className="text-[9px] font-bold text-zinc-600">Spill the tea</span>
                        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-white border-r border-b border-zinc-200 rotate-45" />
                      </div>

                      {/* Avatar with Rainbow Rotating Ring (User Requirement: ইনবক্স থেকে ক্লিক করলে শুধু তার নিজের স্টোরি দেখতে পাবে) */}
                      <div 
                        onClick={() => {
                          const ownStories = userStories.filter(
                            (s) =>
                              s.creator.id === currentUser?.id ||
                              s.creator.id === 'usr-self' ||
                              s.creator.id === 'self' ||
                              (currentUser && s.creator.handle === currentUser.handle)
                          );
                          if (ownStories.length > 0) {
                            setInboxStoryViewerList(ownStories);
                          } else {
                            onOpenProfile?.();
                          }
                        }}
                        className="relative w-15 h-15 rounded-full p-[2px] cursor-pointer hover:scale-105 active:scale-95 transition-transform flex items-center justify-center shadow-xs"
                        title="নিজের স্টোরি দেখুন"
                      >
                        <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-sm" />
                        <div className="relative w-full h-full rounded-full overflow-hidden bg-white z-1 p-0.5">
                          <img
                            src={currentUser?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80'}
                            alt=""
                            className="w-full h-full object-cover rounded-full bg-zinc-100"
                          />
                        </div>
                      </div>

                      {/* Blue Plus Button: opens phone gallery video picker for full video story */}
                      <button
                        type="button"
                        onClick={() => galleryVideoInputRef.current?.click()}
                        className="absolute -bottom-1 -right-1 w-5.5 h-5.5 rounded-full bg-[#25f4ee] text-black flex items-center justify-center border-2 border-white shadow-md hover:scale-110 active:scale-90 transition-transform cursor-pointer z-2"
                        title="গ্যালারি থেকে সম্পূর্ণ ভিডিও স্টোরি দিন (+)"
                      >
                        <Plus className="w-3.5 h-3.5 stroke-[3]" />
                      </button>
                    </div>

                    <span className="text-[11px] font-bold text-zinc-800">
                      Create
                    </span>
                  </div>

                  {/* Friends Story Items with Cyan Rings and [+👤] badges */}
                  {quickFriends.map((friend) => (
                    <div 
                      key={friend.id}
                      onClick={() => onToast?.(`✓ ${friend.name} এর স্টোরি চালু হচ্ছে...`)}
                      className="flex flex-col items-center shrink-0 cursor-pointer group"
                    >
                      <div className="relative mb-1">
                        <div className="w-15 h-15 rounded-full p-[2px] bg-gradient-to-tr from-[#25f4ee] to-sky-400 group-hover:scale-105 transition-transform shadow-xs">
                          <img
                            src={friend.avatar}
                            alt=""
                            className="w-full h-full object-cover rounded-full border border-white"
                          />
                        </div>

                        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-5.5 h-5.5 rounded-full bg-white border border-zinc-200 text-zinc-900 flex items-center justify-center shadow-xs">
                          <UserPlus className="w-3 h-3 stroke-[2.5]" />
                        </div>
                      </div>

                      <span className="text-[11px] font-bold text-zinc-800 truncate max-w-[68px]">
                        {friend.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 3. ACTIVITY & NEW FOLLOWERS (Pinned Item from screenshot with quick category pills) */}
              <div className="border-b border-zinc-100 bg-white">
                <div 
                  onClick={() => {
                    setActivityFilter('all');
                    setActiveView('activity');
                  }}
                  className="px-4 py-3 flex items-center gap-3.5 hover:bg-zinc-50 cursor-pointer transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#fe2c55] via-rose-500 to-pink-500 flex items-center justify-center text-white shadow-md shrink-0">
                    <Zap className="w-6 h-6 fill-white stroke-[2.2]" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-extrabold text-sm sm:text-base text-zinc-900 leading-tight">
                        {language === 'bn' ? 'অ্যাক্টিভিটি ও নোটিফিকেশন' : 'Activity & new followers'}
                      </h4>
                      {activities.length > 0 && (
                        <span className="px-2 py-0.5 rounded-full bg-[#fe2c55] text-white text-[10px] font-black">
                          {activities.length}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500 truncate mt-0.5">
                      {activities.length > 0
                        ? `${activities[0].actor.name}: ${activities[0].text || 'নতুন অ্যাক্টিভিটি'}`
                        : (language === 'bn' ? 'আপনার ভিডিওর লাইক, কমেন্ট ও ফলোয়ার্স দেখুন' : 'Check who liked, commented, or followed')}
                    </p>
                  </div>
                </div>

                {/* Direct quick category filter bar (লম্বা অপশন - লাইক, কমেন্ট, ফলো, রিপ্লাই) */}
                <div className="px-4 pb-2.5 pt-0.5 flex items-center gap-2 overflow-x-auto no-scrollbar">
                  {[
                    { id: 'all', label: language === 'bn' ? 'সব' : 'All', icon: Zap },
                    { id: 'like', label: language === 'bn' ? 'লাইক' : 'Likes', icon: Heart, color: 'text-rose-500' },
                    { id: 'comment', label: language === 'bn' ? 'কমেন্ট' : 'Comments', icon: MessageSquare, color: 'text-sky-500' },
                    { id: 'reply', label: language === 'bn' ? 'রিপ্লাই' : 'Replies', icon: CornerDownRight, color: 'text-purple-500' },
                    { id: 'follow', label: language === 'bn' ? 'ফলোয়ার্স' : 'Followers', icon: UserPlus, color: 'text-emerald-500' },
                  ].map((cat) => {
                    const IconComp = cat.icon;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActivityFilter(cat.id as any);
                          setActiveView('activity');
                        }}
                        className="px-3 py-1 rounded-full bg-zinc-100 hover:bg-zinc-200 active:scale-95 text-zinc-800 text-[11px] font-black shrink-0 flex items-center gap-1 transition-all cursor-pointer border border-zinc-200/60"
                      >
                        <IconComp className={`w-3 h-3 ${cat.color || 'text-zinc-700'}`} />
                        <span>{cat.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4. DIRECT MESSAGES / FRIENDS CHAT LIST (Exact match with screenshot) */}
              <div className="divide-y divide-zinc-100">
                {friendList.map((friend) => (
                  <div
                    key={friend.id}
                    onClick={() => {
                      setActiveChat(friend);
                      setActiveView('chat');
                    }}
                    className={`px-4 py-3 flex items-center justify-between gap-3 hover:bg-zinc-50 cursor-pointer transition-colors ${
                      friend.isPinned ? 'bg-amber-50/40' : ''
                    }`}
                  >
                    {/* Left: Avatar with Online indicator */}
                    <div className="flex items-center gap-3.5 min-w-0 flex-1">
                      <div className="relative w-13 h-13 rounded-full shrink-0">
                        <img
                          src={friend.avatar}
                          alt=""
                          className="w-full h-full object-cover rounded-full bg-zinc-200 border border-zinc-200 shadow-xs"
                        />
                        {friend.isOnline && onlineStatus !== 'no_one' && (
                          <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white shadow-xs" />
                        )}
                        {friend.isPinned && (
                          <span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-amber-500 text-white flex items-center justify-center text-[8px] shadow-xs">
                            📌
                          </span>
                        )}
                      </div>

                      {/* Middle: Name & Subtitle */}
                      <div className="min-w-0 flex-1">
                        <h5 className="font-extrabold text-sm text-zinc-900 truncate">
                          {friend.name}
                        </h5>
                        <div className="flex items-center gap-1.5 text-xs text-zinc-500 truncate mt-0.5">
                          <span className="truncate">{friend.lastMessage}</span>
                          <span>• {friend.time}</span>
                          {friend.isMuted && (
                            <BellOff className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Camera icon OR unread count badge */}
                    <div className="shrink-0 flex items-center">
                      {friend.unreadCount ? (
                        <span className={`px-2 py-0.5 rounded-full text-xs font-black shadow-xs ${
                          friend.id === 'group-bondhu' 
                            ? 'bg-zinc-200 text-zinc-700' 
                            : 'bg-[#fe2c55] text-white'
                        }`}>
                          {friend.unreadCount}
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToast?.(language === 'bn' ? '✓ ক্যামেরা স্ন্যাপ ওপেন হচ্ছে...' : 'Opening camera snap...');
                          }}
                          className="p-2 rounded-full hover:bg-zinc-100 text-zinc-500 hover:text-black transition-colors"
                          title="ক্যামেরা স্ন্যাপ পাঠান"
                        >
                          <Camera className="w-5.5 h-5.5 stroke-[1.8]" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5. TIKTOK 5-BUTTON BOTTOM NAVIGATION BAR (Exact match with screenshot) */}
            <div className="border-t border-zinc-150 bg-white py-1.5 px-3 flex items-center justify-around select-none">
              
              {/* Home */}
              <button
                type="button"
                onClick={() => {
                  onOpenHome ? onOpenHome() : onClose();
                }}
                className="flex flex-col items-center justify-center text-zinc-500 hover:text-black transition-colors cursor-pointer"
              >
                <Home className="w-5.5 h-5.5" />
                <span className="text-[10px] font-semibold mt-0.5">Home</span>
              </button>

              {/* Friends */}
              <button
                type="button"
                onClick={() => {
                  onOpenFriends ? onOpenFriends() : onClose();
                }}
                className="flex flex-col items-center justify-center text-zinc-500 hover:text-black transition-colors cursor-pointer"
              >
                <Users className="w-5.5 h-5.5" />
                <span className="text-[10px] font-semibold mt-0.5">Friends</span>
              </button>

              {/* Create (+) */}
              <button
                type="button"
                onClick={() => {
                  onOpenUpload ? onOpenUpload() : onClose();
                }}
                className="relative flex items-center justify-center px-1 cursor-pointer active:scale-95 transition-transform"
                title="Create Video"
              >
                <div className="relative w-10 h-7 flex items-center justify-center">
                  <div className="absolute inset-0 bg-[#25f4ee] rounded-lg -translate-x-0.5" />
                  <div className="absolute inset-0 bg-[#fe2c55] rounded-lg translate-x-0.5" />
                  <div className="relative w-full h-full bg-black rounded-lg flex items-center justify-center text-white">
                    <Plus className="w-4 h-4 stroke-[3]" />
                  </div>
                </div>
              </button>

              {/* Inbox (Active with Red 13 Badge) */}
              <button
                type="button"
                className="relative flex flex-col items-center justify-center text-black font-extrabold cursor-pointer"
              >
                <div className="relative">
                  <MessageSquare className="w-5.5 h-5.5 stroke-[2.8]" />
                  <span className="absolute -top-1 -right-2 px-1 py-0.2 rounded-full bg-[#fe2c55] text-white text-[9px] font-black leading-tight shadow-xs">
                    13
                  </span>
                </div>
                <span className="text-[10px] font-black mt-0.5">Inbox</span>
              </button>

              {/* Profile with Thin Rotating Color Ring */}
              <button
                type="button"
                onClick={() => onOpenProfile?.()}
                className="flex flex-col items-center justify-center text-zinc-500 hover:text-black transition-colors cursor-pointer"
              >
                <div className="relative w-5.5 h-5.5 flex items-center justify-center p-[1px]">
                  <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-xs" />
                  <img
                    src={currentUser?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                    alt=""
                    className="relative z-1 w-4.5 h-4.5 rounded-full object-cover border border-white"
                  />
                </div>
                <span className="text-[10px] font-semibold mt-0.5">Profile</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: GROUP CREATE SCREEN */}
        {/* ========================================================================= */}
        {activeView === 'group_create' && (
          <div className="flex-1 flex flex-col bg-white">
            <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-200">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveView('inbox')}
                  className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-700 cursor-pointer"
                  title="ব্যাক (Back to Inbox)"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h3 className="font-extrabold text-sm sm:text-base text-zinc-900">
                  {language === 'bn' ? 'নতুন গ্রুপ তৈরি করুন' : 'New Group'}
                </h3>
              </div>

              <button
                type="button"
                onClick={handleCreateGroup}
                className="px-4 py-1.5 rounded-full bg-[#fe2c55] text-white text-xs font-black shadow-md hover:brightness-110 active:scale-95 transition-all cursor-pointer"
              >
                {language === 'bn' ? 'তৈরি করুন' : 'Create'}
              </button>
            </div>

            <div className="p-3 border-b border-zinc-150">
              <input
                type="text"
                value={groupNameInput}
                onChange={(e) => setGroupNameInput(e.target.value)}
                placeholder={language === 'bn' ? 'গ্রুপের নাম লিখুন...' : 'Group name...'}
                className="w-full px-4 py-2.5 bg-zinc-100 rounded-xl text-xs font-bold text-zinc-900 placeholder-zinc-400 outline-none border border-zinc-200 focus:border-[#fe2c55]"
              />
            </div>

            <div className="flex-1 overflow-y-auto p-2 divide-y divide-zinc-100 no-scrollbar">
              <p className="text-[11px] font-black text-zinc-400 px-3 py-1.5 uppercase">
                {language === 'bn' ? 'ফ্রেন্ড লিস্ট থেকে সদস্য নির্বাচন করুন' : 'Select Friends'}
              </p>
              {friendList.filter((f) => !f.isGroup).map((friend) => {
                const isSelected = selectedFriendsForGroup.includes(friend.id);
                return (
                  <div
                    key={friend.id}
                    onClick={() => {
                      setSelectedFriendsForGroup((prev) =>
                        isSelected ? prev.filter((id) => id !== friend.id) : [...prev, friend.id]
                      );
                    }}
                    className="p-3 rounded-2xl flex items-center justify-between hover:bg-zinc-50 cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={friend.avatar}
                        alt=""
                        className="w-11 h-11 rounded-full object-cover border border-zinc-200"
                      />
                      <div>
                        <p className="font-extrabold text-xs text-zinc-900">{friend.name}</p>
                        <p className="text-[10px] text-zinc-500">@{friend.handle}</p>
                      </div>
                    </div>

                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                      isSelected ? 'bg-[#fe2c55] border-[#fe2c55] text-white' : 'border-zinc-300'
                    }`}>
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: SEARCH ALL ACCOUNTS (With UID / Message option) */}
        {/* ========================================================================= */}
        {activeView === 'search_accounts' && (
          <div className="flex-1 flex flex-col bg-white">
            <div className="px-3 py-2.5 flex items-center gap-2 border-b border-zinc-200 bg-white">
              <button
                type="button"
                onClick={() => setActiveView('inbox')}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-700 cursor-pointer"
                title="ব্যাক (Back to Inbox)"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div className="relative flex-1">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  autoFocus
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    language === 'bn'
                      ? 'নাম, ইউজারনেম বা UID দিয়ে সার্চ করুন...'
                      : 'Search by name, username or UID...'
                  }
                  className="w-full pl-9 pr-8 py-2 bg-zinc-100 rounded-full text-xs font-semibold text-zinc-900 placeholder-zinc-400 outline-none border border-zinc-200 focus:border-[#fe2c55]"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Results: Top Match Pinned at Top, Others Below */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3 no-scrollbar">
              {topMatch && (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-[10px] font-black text-rose-600 uppercase tracking-wider px-1">
                    <Zap className="w-3 h-3 fill-rose-600" />
                    <span>{language === 'bn' ? 'টপ ম্যাচ আইডি (UID সার্চ ফলাফল)' : 'Top Account Match'}</span>
                  </div>

                  <div 
                    onClick={() => {
                      setActiveChat(topMatch);
                      setActiveView('chat');
                    }}
                    className="p-3.5 rounded-2xl bg-gradient-to-r from-rose-50 to-amber-50 border border-rose-200 flex items-center justify-between cursor-pointer shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-[#fe2c55] to-amber-500">
                        <img
                          src={topMatch.avatar}
                          alt=""
                          className="w-full h-full object-cover rounded-full border border-white"
                        />
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-zinc-900">{topMatch.name}</h4>
                        <p className="text-xs text-zinc-600 font-semibold">@{topMatch.handle}</p>
                        <p className="text-[10px] font-mono text-rose-600 font-bold mt-0.5">UID: {topMatch.uid}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      className="px-3.5 py-1.5 rounded-full bg-[#fe2c55] text-white text-xs font-black shadow-md active:scale-95 transition-transform"
                    >
                      {language === 'bn' ? 'মেসেজ' : 'Message'}
                    </button>
                  </div>
                </div>
              )}

              {/* Other Accounts Below */}
              <div className="space-y-1">
                <p className="text-[10px] font-black text-zinc-400 px-1 uppercase">
                  {language === 'bn' ? 'অন্যান্য মানুষ ও ফ্রেন্ডস' : 'Other Accounts'}
                </p>
                <div className="divide-y divide-zinc-100">
                  {otherMatches.map((friend) => (
                    <div
                      key={friend.id}
                      onClick={() => {
                        setActiveChat(friend);
                        setActiveView('chat');
                      }}
                      className="py-2.5 px-2 flex items-center justify-between hover:bg-zinc-50 rounded-xl cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={friend.avatar}
                          alt=""
                          className="w-10 h-10 rounded-full object-cover border border-zinc-200"
                        />
                        <div>
                          <p className="font-bold text-xs text-zinc-900">{friend.name}</p>
                          <p className="text-[10px] text-zinc-500">@{friend.handle} • UID: {friend.uid}</p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveChat(friend);
                          setActiveView('chat');
                        }}
                        className="px-3.5 py-1 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-[11px] font-bold"
                      >
                        {language === 'bn' ? 'মেসেজ' : 'Message'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: LIVE DIRECT CHAT SCREEN (With Rich Input, Gallery, Voice, Call) */}
        {/* ========================================================================= */}
        {activeView === 'chat' && activeChat && (
          <div className="flex-1 flex flex-col bg-white">
            
            {/* Chat Header */}
            <div className="px-3 py-2 border-b border-zinc-200 flex items-center justify-between bg-white shadow-xs sticky top-0 z-20">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveView('inbox')}
                  className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800 cursor-pointer"
                  title="ব্যাক (Back)"
                >
                  <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
                </button>

                <div 
                  onClick={() => setActiveView('chat_details')}
                  className="flex items-center gap-2 cursor-pointer group"
                  title="চ্যাট সেটিংস ও বিবরণ"
                >
                  <div className="relative w-9 h-9 rounded-full shrink-0">
                    <img
                      src={activeChat.avatar}
                      alt=""
                      className="w-full h-full object-cover rounded-full border border-zinc-200"
                    />
                    {activeChat.isOnline && onlineStatus !== 'no_one' && (
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-zinc-900 truncate max-w-[130px] group-hover:text-[#fe2c55] transition-colors">
                      {activeChat.name}
                    </h4>
                    <p className="text-[10px] text-zinc-500">
                      {activeChat.isOnline && onlineStatus !== 'no_one' ? '🟢 Online' : 'Active recently'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Call buttons and Three-Dots Menu (•••) */}
              <div className="flex items-center gap-1">
                {/* Audio Call */}
                <button
                  type="button"
                  onClick={() => {
                    onStartCall?.(activeChat, 'audio');
                    onToast?.(language === 'bn' ? `📞 ${activeChat.name} কে অডিও কল করা হচ্ছে...` : 'Calling...');
                  }}
                  className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800 cursor-pointer active:scale-95"
                  title="অডিও কল"
                >
                  <Phone className="w-4.5 h-4.5 stroke-[2.2]" />
                </button>

                {/* Video Call (imo-style live camera) */}
                <button
                  type="button"
                  onClick={() => {
                    onStartCall?.(activeChat, 'video');
                    onToast?.(language === 'bn' ? `📹 ${activeChat.name} কে সরাসরি ভিডিও কল করা হচ্ছে...` : 'Starting video call...');
                  }}
                  className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-800 cursor-pointer active:scale-95"
                  title="ভিডিও কল (সরাসরি ক্যামেরা)"
                >
                  <Video className="w-4.5 h-4.5 stroke-[2.2]" />
                </button>

                {/* Three Dots Menu Button (•••) -> Opens Screenshot_20261016-175440.png Sheet */}
                <button
                  type="button"
                  onClick={() => setActiveView('chat_details')}
                  className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-900 cursor-pointer active:scale-95"
                  title="চ্যাট ডিটেইলস ও সেটিংস (•••)"
                >
                  <MoreHorizontal className="w-5 h-5 stroke-[2.4]" />
                </button>
              </div>
            </div>

            {/* Chat Messages List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-zinc-50 no-scrollbar">
              <div className="text-center py-2">
                <span className="text-[10px] font-bold text-zinc-400 bg-white px-2.5 py-1 rounded-full border border-zinc-200 shadow-2xs">
                  {language === 'bn' ? 'টিকটক এন্ড-টু-এন্ড এনক্রিপ্টেড চ্যাট' : 'TikTok End-to-End Encrypted'}
                </span>
              </div>

              {(chatMessages[activeChat.id] || []).map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[82%] rounded-2xl text-xs font-medium shadow-xs relative group ${
                      msg.sender === 'me'
                        ? 'bg-[#fe2c55] text-white rounded-br-xs p-3'
                        : 'bg-white text-zinc-900 border border-zinc-200 rounded-bl-xs p-3'
                    }`}
                  >
                    {/* 1. Media: Image or Video */}
                    {msg.type === 'image' && msg.mediaUrl && (
                      <div className="rounded-xl overflow-hidden mb-1 border border-black/10">
                        <img src={msg.mediaUrl} alt="" className="w-full max-h-48 object-cover" />
                      </div>
                    )}
                    {msg.type === 'video' && msg.mediaUrl && (
                      <div className="rounded-xl overflow-hidden mb-1 bg-black">
                        <video src={msg.mediaUrl} controls className="w-full max-h-52 object-cover" />
                      </div>
                    )}

                    {/* 2. Shared TikTok Reel */}
                    {msg.type === 'shared_reel' && msg.mediaUrl && (
                      <div className="rounded-xl overflow-hidden mb-1.5 bg-black text-white p-2 border border-white/20">
                        <div className="relative aspect-9/12 rounded-lg overflow-hidden mb-1">
                          <video src={msg.mediaUrl} autoPlay loop muted playsInline className="w-full h-full object-cover" />
                          <div className="absolute top-2 left-2 bg-black/60 px-2 py-0.5 rounded-full text-[9px] font-bold flex items-center gap-1">
                            <Film className="w-3 h-3 text-[#25f4ee]" />
                            <span>TikTok Reel</span>
                          </div>
                        </div>
                        <p className="text-[11px] font-bold truncate">{msg.sharedReelTitle || 'Shared Video'}</p>
                      </div>
                    )}

                    {/* 3. Voice Message */}
                    {msg.type === 'voice' && (
                      <div className="flex items-center gap-2 py-1">
                        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        </div>
                        <div className="flex-1">
                          <div className="h-2 w-28 bg-white/30 rounded-full overflow-hidden">
                            <div className="h-full w-2/3 bg-white rounded-full animate-pulse" />
                          </div>
                          <span className="text-[9px] opacity-80 mt-0.5 block">{msg.voiceDuration || '0:15'}</span>
                        </div>
                      </div>
                    )}

                    {/* 4. Sticker */}
                    {msg.type === 'sticker' && (
                      <div className="text-4xl py-1 animate-bounce">
                        {msg.stickerEmoji}
                      </div>
                    )}

                    {/* Text Message */}
                    {msg.text && <p className="leading-relaxed">{msg.text}</p>}

                    {/* Save Bookmark button and timestamp */}
                    <div className="flex items-center justify-between gap-3 mt-1 pt-1 opacity-75 text-[9px]">
                      <span>{msg.time}</span>
                      <button
                        type="button"
                        onClick={() => handleToggleSaveItem(msg.id)}
                        className="hover:scale-110 transition-transform p-0.5"
                        title={msg.isSaved ? 'আনসেভ করুন' : 'সেভ করুন'}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${msg.isSaved ? 'fill-amber-300 text-amber-300' : ''}`} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Sticker Drawer Sheet */}
            {showStickerDrawer && (
              <div className="p-3 bg-white border-t border-zinc-200 animate-in slide-in-from-bottom-2 duration-150">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-extrabold text-zinc-500 uppercase">টিকটক স্টিকার ও ইমোজি</span>
                  <button onClick={() => setShowStickerDrawer(false)} className="text-zinc-400 hover:text-black">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="grid grid-cols-7 gap-2 text-2xl text-center">
                  {['🔥', '❤️', '💃', '🎵', '👑', '🥳', '🥺', '💯', '🚀', '💎', '🍿', '🎬', '✨', '👏'].map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => handleSendSticker(emoji)}
                      className="p-2 hover:bg-zinc-100 rounded-xl active:scale-125 transition-transform cursor-pointer"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Rich Chat Input Bar (Gallery, Sticker, Voice, Send) */}
            <form onSubmit={handleSendMessage} className="p-2 border-t border-zinc-200 bg-white flex items-center gap-1.5 sticky bottom-0 z-20">
              
              {/* 1. Gallery Button (Opens phone photos/videos) */}
              <button
                type="button"
                onClick={() => chatMediaInputRef.current?.click()}
                className="w-8.5 h-8.5 rounded-full hover:bg-zinc-100 text-zinc-600 hover:text-black flex items-center justify-center transition-colors cursor-pointer"
                title="গ্যালারি থেকে ছবি বা ভিডিও পাঠান"
              >
                <ImageIcon className="w-5 h-5 stroke-[2]" />
              </button>

              {/* 2. Sticker Button */}
              <button
                type="button"
                onClick={() => setShowStickerDrawer(!showStickerDrawer)}
                className="w-8.5 h-8.5 rounded-full hover:bg-zinc-100 text-zinc-600 hover:text-black flex items-center justify-center transition-colors cursor-pointer"
                title="স্টিকার পাঠান"
              >
                <Smile className="w-5 h-5 stroke-[2]" />
              </button>

              {/* 3. Text Input */}
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={isRecordingVoice ? 'ভয়েস রেকর্ড হচ্ছে...' : (language === 'bn' ? 'মেসেজ লিখুন...' : 'Send a message...')}
                className="flex-1 px-4 py-2 bg-zinc-100 rounded-full text-xs font-semibold text-zinc-900 outline-none border border-zinc-200 focus:border-[#fe2c55]"
              />

              {/* 4. Voice Recorder / Send button */}
              {inputText.trim() ? (
                <button
                  type="submit"
                  className="w-8.5 h-8.5 rounded-full bg-[#fe2c55] text-white flex items-center justify-center cursor-pointer shadow-md hover:brightness-110 active:scale-95 transition-all"
                  title="মেসেজ পাঠান"
                >
                  <Send className="w-4 h-4 stroke-[2.2]" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={isRecordingVoice ? stopAndSendVoiceRecording : startVoiceRecording}
                  className={`w-8.5 h-8.5 rounded-full flex items-center justify-center cursor-pointer transition-all ${
                    isRecordingVoice ? 'bg-rose-600 text-white animate-pulse' : 'hover:bg-zinc-100 text-zinc-600 hover:text-black'
                  }`}
                  title={isRecordingVoice ? 'ভয়েস পাঠানো সম্পন্ন করুন' : 'ভয়েস মেসেজ দিন'}
                >
                  <Mic className="w-5 h-5 stroke-[2]" />
                </button>
              )}
            </form>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 5: CHAT DETAILS & SETTINGS SHEET (Screenshot_20261016-175440.png)    */}
        {/* ========================================================================= */}
        {activeView === 'chat_details' && activeChat && (
          <div className="flex-1 flex flex-col bg-white overflow-hidden">
            
            {/* Top Bar matching Screenshot (Back arrow on left, Three dots on right) */}
            <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-100 bg-white sticky top-0 z-20">
              <button
                type="button"
                onClick={() => setActiveView('chat')}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-900 cursor-pointer"
                title="চ্যাটে ফিরে যান"
              >
                <ArrowLeft className="w-5.5 h-5.5 stroke-[2.4]" />
              </button>

              <button
                type="button"
                onClick={() => setShowReportModal(true)}
                className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-900 cursor-pointer"
                title="Options"
              >
                <MoreHorizontal className="w-5.5 h-5.5 stroke-[2.4]" />
              </button>
            </div>

            {/* Scrollable Settings Body */}
            <div className="flex-1 overflow-y-auto no-scrollbar">
              
              {/* Profile Picture & Name Section */}
              <div className="flex flex-col items-center pt-5 pb-4 px-4 text-center border-b border-zinc-100">
                <div 
                  onClick={() => onOpenProfile?.()}
                  className="relative w-22 h-22 rounded-full p-[2px] mb-3 cursor-pointer hover:scale-105 active:scale-95 transition-transform shadow-md flex items-center justify-center"
                  title="প্রোফাইল পিকচার দেখুন / প্রোফাইলে যান"
                >
                  {/* Rotating thin color ring */}
                  <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-xs" />
                  <div className="relative w-full h-full rounded-full overflow-hidden bg-white z-1 p-0.5">
                    <img
                      src={activeChat.avatar}
                      alt={activeChat.name}
                      className="w-full h-full object-cover rounded-full"
                    />
                  </div>
                </div>

                <h2 className="font-extrabold text-xl text-zinc-900 tracking-tight">
                  {activeChat.name}
                </h2>

                {/* Two Round Action Buttons: View profile & Search */}
                <div className="flex items-center gap-6 mt-4">
                  
                  {/* View profile button */}
                  <div 
                    onClick={() => onOpenProfile?.()}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 rounded-full bg-zinc-100 group-hover:bg-zinc-200 flex items-center justify-center text-zinc-800 transition-colors shadow-2xs">
                      <User className="w-5 h-5 stroke-[2.2]" />
                    </div>
                    <span className="text-xs font-bold text-zinc-700">View profile</span>
                  </div>

                  {/* Search in chat button */}
                  <div 
                    onClick={() => {
                      setActiveView('chat');
                      onToast?.(language === 'bn' ? '🔍 চ্যাট সার্চ মোড সক্রিয়' : 'Search mode active in chat');
                    }}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 rounded-full bg-zinc-100 group-hover:bg-zinc-200 flex items-center justify-center text-zinc-800 transition-colors shadow-2xs">
                      <Search className="w-5 h-5 stroke-[2.2]" />
                    </div>
                    <span className="text-xs font-bold text-zinc-700">Search</span>
                  </div>
                </div>
              </div>

              {/* Exact Settings Options List from Screenshot_20261016-175440.png */}
              <div className="py-2 px-2 divide-y divide-zinc-100">
                
                {/* 1. Chat bubble */}
                <div 
                  onClick={() => setShowChatBubbleModal(true)}
                  className="py-3.5 px-3 flex items-center justify-between hover:bg-zinc-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Palette className="w-5 h-5 text-zinc-800 stroke-[2]" />
                    <span className="font-bold text-sm text-zinc-900">Chat bubble</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400 stroke-[2.5]" />
                </div>

                {/* 2. Wallpaper */}
                <div 
                  onClick={() => setShowWallpaperModal(true)}
                  className="py-3.5 px-3 flex items-center justify-between hover:bg-zinc-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Sliders className="w-5 h-5 text-zinc-800 stroke-[2]" />
                    <span className="font-bold text-sm text-zinc-900">Wallpaper</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400 stroke-[2.5]" />
                </div>

                {/* 3. Alert tones */}
                <div 
                  onClick={() => setShowAlertToneModal(true)}
                  className="py-3.5 px-3 flex items-center justify-between hover:bg-zinc-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Volume2 className="w-5 h-5 text-zinc-800 stroke-[2]" />
                    <span className="font-bold text-sm text-zinc-900">Alert tones</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400 stroke-[2.5]" />
                </div>

                {/* 4. Mute messages (Toggle Switch) */}
                <div className="py-3.5 px-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <BellOff className="w-5 h-5 text-zinc-800 stroke-[2]" />
                    <span className="font-bold text-sm text-zinc-900">Mute messages</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !activeChat.isMuteMessages;
                      setActiveChat({ ...activeChat, isMuteMessages: next, isMuted: next });
                      setFriendList((prev) =>
                        prev.map((f) => (f.id === activeChat.id ? { ...f, isMuteMessages: next, isMuted: next } : f))
                      );
                      onToast?.(next ? '🔕 মেসেজ মিউট করা হয়েছে' : '🔔 মেসেজ আনমিউট করা হয়েছে');
                    }}
                    className={`w-11 h-6 flex items-center rounded-full p-0.5 transition-colors cursor-pointer ${
                      activeChat.isMuteMessages ? 'bg-[#25f4ee]' : 'bg-zinc-300'
                    }`}
                  >
                    <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform ${
                      activeChat.isMuteMessages ? 'translate-x-5' : 'translate-x-0'
                    }`} />
                  </button>
                </div>

                {/* 5. Mute calls (Toggle Switch) */}
                <div className="py-3.5 px-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-zinc-800 stroke-[2]" />
                    <span className="font-bold text-sm text-zinc-900">Mute calls</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !activeChat.isMuteCalls;
                      setActiveChat({ ...activeChat, isMuteCalls: next });
                      setFriendList((prev) =>
                        prev.map((f) => (f.id === activeChat.id ? { ...f, isMuteCalls: next } : f))
                      );
                      onToast?.(next ? '🔕 কল মিউট করা হয়েছে' : '🔔 কল আনমিউট করা হয়েছে');
                    }}
                    className={`w-11 h-6 flex items-center rounded-full p-0.5 transition-colors cursor-pointer ${
                      activeChat.isMuteCalls ? 'bg-[#25f4ee]' : 'bg-zinc-300'
                    }`}
                  >
                    <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform ${
                      activeChat.isMuteCalls ? 'translate-x-5' : 'translate-x-0'
                    }`} />
                  </button>
                </div>

                {/* 6. Pin to top (Toggle Switch) */}
                <div className="py-3.5 px-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Pin className="w-5 h-5 text-zinc-800 stroke-[2]" />
                    <span className="font-bold text-sm text-zinc-900">Pin to top</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !activeChat.isPinned;
                      setActiveChat({ ...activeChat, isPinned: next });
                      setFriendList((prev) => {
                        const updated = prev.map((f) => (f.id === activeChat.id ? { ...f, isPinned: next } : f));
                        return updated.sort((a, b) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0));
                      });
                      onToast?.(next ? '📌 চ্যাট সবার উপরে পিন করা হয়েছে' : 'আনপিন করা হয়েছে');
                    }}
                    className={`w-11 h-6 flex items-center rounded-full p-0.5 transition-colors cursor-pointer ${
                      activeChat.isPinned ? 'bg-[#25f4ee]' : 'bg-zinc-300'
                    }`}
                  >
                    <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform ${
                      activeChat.isPinned ? 'translate-x-5' : 'translate-x-0'
                    }`} />
                  </button>
                </div>

                {/* 7. Report */}
                <div 
                  onClick={() => setShowReportModal(true)}
                  className="py-3.5 px-3 flex items-center justify-between hover:bg-zinc-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3 text-zinc-900">
                    <Flag className="w-5 h-5 stroke-[2]" />
                    <span className="font-bold text-sm">Report</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400 stroke-[2.5]" />
                </div>

                {/* 8. Block user */}
                <div 
                  onClick={() => {
                    setActiveChat({ ...activeChat, isBlocked: !activeChat.isBlocked });
                    onToast?.(
                      !activeChat.isBlocked 
                        ? '🚫 এই ব্যবহারকারীকে ব্লক করা হয়েছে' 
                        : '✓ ব্যবহারকারীকে আনব্লক করা হয়েছে'
                    );
                  }}
                  className="py-3.5 px-3 flex items-center justify-between hover:bg-rose-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3 text-rose-600">
                    <Ban className="w-5 h-5 stroke-[2]" />
                    <span className="font-bold text-sm">{activeChat.isBlocked ? 'Unblock user' : 'Block user'}</span>
                  </div>
                </div>
              </div>

              {/* Shared Media Content (Share, Gallery, Saved items display) */}
              <div className="p-3 bg-zinc-50 border-t border-zinc-200 mt-2">
                <div className="flex items-center justify-between mb-2 px-1">
                  <span className="text-[11px] font-extrabold text-zinc-700 uppercase">
                    {activeMediaTab === 'share' && 'শেয়ার করা টিকটক ভিডিও রিলস'}
                    {activeMediaTab === 'gallery' && 'গ্যালারি থেকে পাঠানো ছবি ও ভিডিও'}
                    {activeMediaTab === 'saved' && 'সংরক্ষিত (Saved) আইটেম'}
                  </span>
                  <span className="text-[10px] text-zinc-400 font-mono">
                    {activeMediaTab === 'share' && `${sharedReels.length} Items`}
                    {activeMediaTab === 'gallery' && `${galleryMedia.length} Items`}
                    {activeMediaTab === 'saved' && `${savedItems.length} Items`}
                  </span>
                </div>

                {activeMediaTab === 'share' && (
                  sharedReels.length > 0 ? (
                    <div className="grid grid-cols-3 gap-2">
                      {sharedReels.map((m) => (
                        <div key={m.id} className="aspect-9/12 rounded-xl bg-black overflow-hidden relative group cursor-pointer shadow-xs">
                          <video src={m.mediaUrl} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Play className="w-6 h-6 text-white fill-white" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-6 text-center text-xs text-zinc-400 font-medium">
                      এই চ্যাটে এখনও কোনো টিকটক ভিডিও শেয়ার করা হয়নি
                    </div>
                  )
                )}

                {activeMediaTab === 'gallery' && (
                  galleryMedia.length > 0 ? (
                    <div className="grid grid-cols-3 gap-2">
                      {galleryMedia.map((m) => (
                        <div key={m.id} className="aspect-square rounded-xl bg-zinc-200 overflow-hidden relative shadow-xs">
                          {m.type === 'video' ? (
                            <video src={m.mediaUrl} className="w-full h-full object-cover" />
                          ) : (
                            <img src={m.mediaUrl} alt="" className="w-full h-full object-cover" />
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-6 text-center text-xs text-zinc-400 font-medium">
                      গ্যালারি থেকে কোনো ছবি বা ভিডিও পাঠানো হয়নি
                    </div>
                  )
                )}

                {activeMediaTab === 'saved' && (
                  savedItems.length > 0 ? (
                    <div className="space-y-2">
                      {savedItems.map((m) => (
                        <div key={m.id} className="p-2.5 bg-white rounded-xl border border-zinc-200 flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2 truncate">
                            <Bookmark className="w-4 h-4 fill-amber-400 text-amber-500 shrink-0" />
                            <span className="truncate font-semibold">{m.text || 'Saved media'}</span>
                          </div>
                          <span className="text-[10px] text-zinc-400 shrink-0">{m.time}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-6 text-center text-xs text-zinc-400 font-medium">
                      কোনো সেভ করা মেসেজ নেই
                    </div>
                  )
                )}
              </div>
            </div>

            {/* Bottom 3 Media Tabs matching Screenshot_20261016-175440.png */}
            <div className="border-t border-zinc-200 bg-white py-2.5 px-8 flex items-center justify-around select-none">
              
              {/* 1. Share Tab (↪️) */}
              <button
                type="button"
                onClick={() => setActiveMediaTab('share')}
                className={`flex flex-col items-center justify-center p-1 transition-all cursor-pointer ${
                  activeMediaTab === 'share' ? 'text-black border-b-2 border-black pb-0.5' : 'text-zinc-400 hover:text-zinc-800'
                }`}
                title="Shared Videos"
              >
                <Share2 className="w-6 h-6 stroke-[2.2]" />
              </button>

              {/* 2. Gallery Tab (🖼️) */}
              <button
                type="button"
                onClick={() => setActiveMediaTab('gallery')}
                className={`flex flex-col items-center justify-center p-1 transition-all cursor-pointer ${
                  activeMediaTab === 'gallery' ? 'text-black border-b-2 border-black pb-0.5' : 'text-zinc-400 hover:text-zinc-800'
                }`}
                title="Gallery Media"
              >
                <ImageIcon className="w-6 h-6 stroke-[2.2]" />
              </button>

              {/* 3. Saved Tab (🔖) */}
              <button
                type="button"
                onClick={() => setActiveMediaTab('saved')}
                className={`flex flex-col items-center justify-center p-1 transition-all cursor-pointer ${
                  activeMediaTab === 'saved' ? 'text-black border-b-2 border-black pb-0.5' : 'text-zinc-400 hover:text-zinc-800'
                }`}
                title="Saved Items"
              >
                <Bookmark className="w-6 h-6 stroke-[2.2]" />
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 6: ACTIVITY & NOTIFICATIONS (লম্বা অপশন - লাইক, কমেন্ট, ফলো, রিপ্লাই) */}
        {/* ========================================================================= */}
        {activeView === 'activity' && (() => {
          const filteredActivities = activities.filter((act) => {
            if (activityFilter === 'all') return true;
            return act.type === activityFilter;
          });

          return (
            <div className="flex-1 flex flex-col bg-white overflow-hidden">
              {/* Header */}
              <div className="px-3 py-2.5 border-b border-zinc-200 flex items-center justify-between bg-white shrink-0">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveView('inbox')}
                    className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-700 cursor-pointer active:scale-90 transition-transform"
                    title="ব্যাক (Back)"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                  <h3 className="font-extrabold text-sm sm:text-base text-zinc-900">
                    {language === 'bn' ? 'অ্যাক্টিভিটি ও নোটিফিকেশন' : 'Activity & notifications'}
                  </h3>
                </div>
                <span className="text-[11px] font-mono font-bold text-zinc-400">
                  {filteredActivities.length} {language === 'bn' ? 'টি' : 'items'}
                </span>
              </div>

              {/* Filter Pills Bar */}
              <div className="px-3 py-2 bg-zinc-50 border-b border-zinc-200 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
                {[
                  { id: 'all', label: language === 'bn' ? 'সকল' : 'All' },
                  { id: 'like', label: language === 'bn' ? '❤️ লাইক' : '❤️ Likes' },
                  { id: 'comment', label: language === 'bn' ? '💬 কমেন্ট' : '💬 Comments' },
                  { id: 'reply', label: language === 'bn' ? '↩️ রিপ্লাই' : '↩️ Replies' },
                  { id: 'follow', label: language === 'bn' ? '👤 ফলোয়ার্স' : '👤 Followers' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActivityFilter(tab.id as any)}
                    className={`px-3 py-1 rounded-full text-xs font-black shrink-0 transition-all cursor-pointer ${
                      activityFilter === tab.id
                        ? 'bg-zinc-900 text-white shadow-xs'
                        : 'bg-white border border-zinc-200 text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Scrollable Activities Feed */}
              <div className="flex-1 overflow-y-auto p-3 space-y-3 divide-y divide-zinc-100 no-scrollbar">
                {filteredActivities.length === 0 ? (
                  <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-zinc-400">
                    <div className="w-12 h-12 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-400 mb-2">
                      <Zap className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-bold text-zinc-700">
                      {language === 'bn' ? 'কোনো অ্যাক্টিভিটি পাওয়া যায়নি' : 'No activity yet'}
                    </p>
                    <p className="text-[11px] text-zinc-400 mt-1">
                      {language === 'bn' ? 'ভিডিও পোস্ট করুন যাতে অন্যরা লাইক ও কমেন্ট করতে পারে' : 'Post more videos to gain likes and followers'}
                    </p>
                  </div>
                ) : (
                  filteredActivities.map((act) => (
                    <div key={act.id} className="pt-3 flex items-start justify-between gap-3 first:pt-0">
                      {/* Left: Avatar with type badge */}
                      <div className="relative shrink-0">
                        <div
                          onClick={() => onOpenProfile?.({
                            id: act.actor.id || act.actor.handle,
                            name: act.actor.name,
                            handle: act.actor.handle,
                            avatar: act.actor.avatar,
                            followers: 120,
                            following: 80,
                            likesTotal: 450,
                            verified: false,
                            bio: '',
                          })}
                          className="w-11 h-11 rounded-full overflow-hidden border border-zinc-200 cursor-pointer hover:scale-105 transition-transform"
                        >
                          <img src={act.actor.avatar} alt="" className="w-full h-full object-cover" />
                        </div>

                        {/* Action badge */}
                        <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white shadow-xs border-2 border-white ${
                          act.type === 'like' ? 'bg-gradient-to-tr from-rose-500 to-pink-500' :
                          act.type === 'comment' ? 'bg-gradient-to-tr from-sky-500 to-cyan-500' :
                          act.type === 'reply' ? 'bg-gradient-to-tr from-purple-500 to-indigo-500' :
                          'bg-gradient-to-tr from-emerald-500 to-teal-500'
                        }`}>
                          {act.type === 'like' && <Heart className="w-2.5 h-2.5 fill-white" />}
                          {act.type === 'comment' && <MessageSquare className="w-2.5 h-2.5 fill-white" />}
                          {act.type === 'reply' && <CornerDownRight className="w-2.5 h-2.5" />}
                          {act.type === 'follow' && <UserPlus className="w-2.5 h-2.5" />}
                        </div>
                      </div>

                      {/* Middle: Content */}
                      <div className="flex-1 min-w-0 pr-1">
                        <p className="text-xs text-zinc-900 leading-snug">
                          <span
                            onClick={() => onOpenProfile?.({
                              id: act.actor.id || act.actor.handle,
                              name: act.actor.name,
                              handle: act.actor.handle,
                              avatar: act.actor.avatar,
                              followers: 120,
                              following: 80,
                              likesTotal: 450,
                              verified: false,
                              bio: '',
                            })}
                            className="font-black text-zinc-900 hover:underline cursor-pointer mr-1"
                          >
                            {act.actor.name}
                          </span>
                          {act.type === 'like' && (language === 'bn' ? 'আপনার ভিডিও পছন্দ করেছেন' : 'liked your video')}
                          {act.type === 'comment' && (
                            <span>
                              {language === 'bn' ? 'আপনার ভিডিওতে মন্তব্য করেছেন: ' : 'commented on your video: '}
                              <span className="text-zinc-600 italic font-medium">"{act.text}"</span>
                            </span>
                          )}
                          {act.type === 'reply' && (
                            <span>
                              {language === 'bn' ? 'আপনার মন্তব্যের রিপ্লাই দিয়েছেন: ' : 'replied to your comment: '}
                              <span className="text-zinc-800 font-bold">"{act.text}"</span>
                            </span>
                          )}
                          {act.type === 'follow' && (language === 'bn' ? 'আপনাকে ফলো করা শুরু করেছেন' : 'started following you')}
                        </p>
                        <span className="text-[10px] text-zinc-400 font-mono mt-1 block">
                          {act.timestamp}
                        </span>
                      </div>

                      {/* Right action: Follow button or Video Thumbnail */}
                      {act.type === 'follow' ? (
                        <button
                          type="button"
                          onClick={() => {
                            if (act.actor.id) onToggleFollow?.(act.actor.id);
                            act.actor.isFollowed = !act.actor.isFollowed;
                            onToast?.(act.actor.isFollowed ? '✓ আপনিও ফলো করেছেন' : 'আনফলো করা হয়েছে');
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-black shadow-xs active:scale-95 transition-all shrink-0 cursor-pointer ${
                            act.actor.isFollowed
                              ? 'bg-zinc-100 text-zinc-800 border border-zinc-200'
                              : 'bg-[#fe2c55] text-white hover:bg-[#e0264b]'
                          }`}
                        >
                          {act.actor.isFollowed
                            ? (language === 'bn' ? 'Following' : 'Following')
                            : (language === 'bn' ? 'ফলো করুন' : 'Follow')}
                        </button>
                      ) : act.targetReelId ? (
                        <div
                          onClick={() => {
                            if (act.targetReelId) {
                              onSelectReelFromActivity?.(act.targetReelId);
                              onClose();
                            }
                          }}
                          className="relative w-12 h-16 rounded-xl overflow-hidden bg-black shrink-0 border border-zinc-200 shadow-2xs group cursor-pointer hover:opacity-90 active:scale-95 transition-all"
                          title="ভিডিওটি দেখুন"
                        >
                          <img
                            src={act.targetReelThumbnail || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=200&auto=format&fit=crop&q=80'}
                            alt=""
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                            <Play className="w-3.5 h-3.5 fill-white text-white opacity-80" />
                          </div>
                        </div>
                      ) : null}
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })()}

      </div>

      {/* ========================================================================= */}
      {/* POPUP SUB-MODALS: Chat bubble, Wallpaper, Alert tones, Report */}
      {/* ========================================================================= */}
      
      {/* 1. Chat bubble theme modal */}
      {showChatBubbleModal && (
        <div className="fixed inset-0 z-70 bg-black/60 flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 text-zinc-900 shadow-2xl">
            <h4 className="font-extrabold text-sm mb-3">Choose Chat Bubble Style</h4>
            <div className="space-y-2">
              {[
                { id: 'tiktok_red', name: 'TikTok Red / Classic Cyan', bg: 'bg-[#fe2c55]' },
                { id: 'classic', name: 'Clean White / Slate', bg: 'bg-zinc-800' },
                { id: 'cyan', name: 'Cyber Neon Cyan', bg: 'bg-[#25f4ee]' },
                { id: 'purple', name: 'Night Velvet Purple', bg: 'bg-purple-600' },
              ].map((style) => (
                <button
                  key={style.id}
                  onClick={() => {
                    setShowChatBubbleModal(false);
                    onToast?.(`✓ '${style.name}' বাবল থিম সক্রিয় করা হয়েছে!`);
                  }}
                  className="w-full p-2.5 rounded-xl border border-zinc-200 hover:bg-zinc-50 flex items-center gap-3 text-xs font-bold"
                >
                  <span className={`w-4 h-4 rounded-full ${style.bg}`} />
                  <span>{style.name}</span>
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowChatBubbleModal(false)}
              className="w-full mt-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-xs font-black rounded-xl"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 2. Wallpaper Modal */}
      {showWallpaperModal && (
        <div className="fixed inset-0 z-70 bg-black/60 flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 text-zinc-900 shadow-2xl">
            <h4 className="font-extrabold text-sm mb-3">Select Chat Wallpaper</h4>
            <div className="grid grid-cols-2 gap-2">
              {['Classic White', 'Dark AMOLED', 'Neon Cyber', 'Pastel Sunset'].map((wp) => (
                <button
                  key={wp}
                  onClick={() => {
                    setShowWallpaperModal(false);
                    onToast?.(`✓ '${wp}' ওয়ালপেপার সেট হয়েছে!`);
                  }}
                  className="p-3 rounded-xl border border-zinc-200 hover:border-black text-center text-xs font-bold bg-zinc-50"
                >
                  {wp}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowWallpaperModal(false)}
              className="w-full mt-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-xs font-black rounded-xl"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* 3. Alert Tones Modal */}
      {showAlertToneModal && (
        <div className="fixed inset-0 z-70 bg-black/60 flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 text-zinc-900 shadow-2xl">
            <h4 className="font-extrabold text-sm mb-3">Notification Alert Tone</h4>
            <div className="space-y-2">
              {['TikTok Chime', 'Pop Note', 'Subtle Ding', 'Digital Pulse'].map((tone) => (
                <button
                  key={tone}
                  onClick={() => {
                    setShowAlertToneModal(false);
                    onToast?.(`🎵 '${tone}' টোন সিলেক্ট করা হয়েছে!`);
                  }}
                  className="w-full p-2.5 rounded-xl border border-zinc-200 hover:bg-zinc-50 flex items-center justify-between text-xs font-bold"
                >
                  <span>{tone}</span>
                  <Volume2 className="w-4 h-4 text-zinc-500" />
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowAlertToneModal(false)}
              className="w-full mt-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-xs font-black rounded-xl"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 4. Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-70 bg-black/60 flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-white rounded-2xl p-4 text-zinc-900 shadow-2xl">
            <h4 className="font-extrabold text-sm mb-1 text-rose-600">Report Account</h4>
            <p className="text-[11px] text-zinc-500 mb-3">রিপোর্ট করার কারণ নির্বাচন করুন:</p>
            <div className="space-y-1.5 text-xs font-semibold">
              {['Spam or Fraud', 'Harassment or Bullying', 'Inappropriate Content', 'Impersonation'].map((reason) => (
                <button
                  key={reason}
                  onClick={() => {
                    setShowReportModal(false);
                    onToast?.('✓ রিপোর্ট গ্রহণ করা হয়েছে। টিকটক মডারেশন টিম খতিয়ে দেখবে।');
                  }}
                  className="w-full p-2.5 rounded-xl border border-zinc-200 hover:bg-rose-50 hover:border-rose-300 text-left"
                >
                  {reason}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowReportModal(false)}
              className="w-full mt-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-xs font-black rounded-xl"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* 5. User Story Viewer (User Requirement: ইনবক্স থেকে ক্লিক করলে শুধু তার নিজের স্টোরি দেখতে পাবে) */}
      {inboxStoryViewerList && inboxStoryViewerList.length > 0 && (
        <StoryViewerModal
          isOpen={true}
          onClose={() => setInboxStoryViewerList(null)}
          stories={inboxStoryViewerList}
          language={language}
          onToast={onToast}
        />
      )}

    </div>
  );
};
