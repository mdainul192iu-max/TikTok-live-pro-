import React from 'react';
import { Heart, MessageCircle, Bookmark, Share2, Plus, Music } from 'lucide-react';
import { VideoReel, AppLanguage } from '../types';

interface SideActionsProps {
  reel: VideoReel;
  onToggleLike: (id: string) => void;
  onToggleBookmark: (id: string) => void;
  onOpenComments: () => void;
  onOpenShare: () => void;
  onOpenCreator: () => void;
  onOpenSound: () => void;
  language: AppLanguage;
  formatCount: (num: number) => string;
}

export const SideActions: React.FC<SideActionsProps> = ({
  reel,
  onToggleLike,
  onToggleBookmark,
  onOpenComments,
  onOpenShare,
  onOpenCreator,
  onOpenSound,
  formatCount,
}) => {
  return (
    <div className="absolute right-2 sm:right-3 bottom-20 z-20 flex flex-col items-center gap-4 text-white select-none pointer-events-auto">
      {/* 1. Creator Profile Avatar with thin rotating color ring */}
      <div className="relative mb-1">
        <div
          onClick={onOpenCreator}
          className="relative w-11 h-11 rounded-full p-[2px] shadow-lg cursor-pointer hover:scale-105 active:scale-95 transition-transform flex items-center justify-center"
        >
          {/* Thin rotating color ring: প্রোফাইলের চার পাশ দিয়ে চিকন রঙ কালার ঘুরবে */}
          <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow" />
          <div className="relative w-full h-full rounded-full overflow-hidden bg-black z-1 border border-black/40">
            <img src={reel.creator.avatar} alt={reel.creator.name} className="w-full h-full object-cover" />
          </div>
        </div>
        {!reel.creator.isFollowed && (
          <button
            onClick={onOpenCreator}
            className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-4.5 h-4.5 rounded-full bg-[#fe2c55] text-white flex items-center justify-center shadow-md active:scale-90 transition-transform cursor-pointer z-2"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
          </button>
        )}
      </div>

      {/* 2. Like Button */}
      <button
        onClick={() => onToggleLike(reel.id)}
        className="flex flex-col items-center gap-1 active:scale-75 transition-transform cursor-pointer group"
      >
        <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
          <Heart
            className={`w-6 h-6 transition-colors ${
              reel.isLiked ? 'fill-[#fe2c55] text-[#fe2c55]' : 'text-white'
            }`}
          />
        </div>
        <span className="text-[11px] font-black font-mono drop-shadow-md">
          {formatCount(reel.likesCount)}
        </span>
      </button>

      {/* 3. Comments Button */}
      <button
        onClick={onOpenComments}
        className="flex flex-col items-center gap-1 active:scale-75 transition-transform cursor-pointer group"
      >
        <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
          <MessageCircle className="w-6 h-6 fill-white/10 text-white" />
        </div>
        <span className="text-[11px] font-black font-mono drop-shadow-md">
          {formatCount(reel.commentsCount)}
        </span>
      </button>

      {/* 4. Bookmark Button */}
      <button
        onClick={() => onToggleBookmark(reel.id)}
        className="flex flex-col items-center gap-1 active:scale-75 transition-transform cursor-pointer group"
      >
        <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
          <Bookmark
            className={`w-6 h-6 transition-colors ${
              reel.isBookmarked ? 'fill-amber-400 text-amber-400' : 'text-white'
            }`}
          />
        </div>
        <span className="text-[11px] font-black font-mono drop-shadow-md">
          {formatCount(reel.bookmarksCount)}
        </span>
      </button>

      {/* 5. Share Button */}
      <button
        onClick={onOpenShare}
        className="flex flex-col items-center gap-1 active:scale-75 transition-transform cursor-pointer group"
      >
        <div className="w-10 h-10 rounded-full bg-black/35 backdrop-blur-md flex items-center justify-center group-hover:bg-black/50 transition-colors">
          <Share2 className="w-6 h-6 text-white" />
        </div>
        <span className="text-[11px] font-black font-mono drop-shadow-md">
          {formatCount(reel.sharesCount)}
        </span>
      </button>

      {/* 6. Rotating Music Disc Widget (Tapping triggers Reuse Audio pipeline!) */}
      <div
        onClick={onOpenSound}
        className="relative mt-2 cursor-pointer group active:scale-90 transition-transform"
        title="এই সাউন্ড ব্যবহার করুন (Reuse Audio)"
      >
        {/* Floating musical notes */}
        <span className="absolute -top-3 -left-2 text-[11px] text-[#25f4ee] font-black pointer-events-none animate-music-note">
          ♪
        </span>
        <span className="absolute -top-5 left-1 text-[10px] text-[#fe2c55] font-black pointer-events-none animate-music-note" style={{ animationDelay: '1.2s' }}>
          ♫
        </span>

        {/* Vinyl Disc Outer with Grooves */}
        <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-black via-zinc-900 to-black border-2 border-zinc-700/80 p-2 flex items-center justify-center shadow-2xl animate-spin-slow">
          <div className="w-full h-full rounded-full overflow-hidden border border-zinc-800">
            <img
              src={reel.audioThumbnailUrl || reel.music.cover}
              alt=""
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        <div className="absolute -bottom-1 -right-1 w-4.5 h-4.5 rounded-full bg-[#fe2c55] flex items-center justify-center text-white text-[9px] shadow-lg border border-black">
          <Music className="w-2.5 h-2.5" />
        </div>
      </div>
    </div>
  );
};
