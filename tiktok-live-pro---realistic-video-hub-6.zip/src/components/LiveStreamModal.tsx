import React, { useState } from 'react';
import { X, Heart, MessageCircle, Send, Radio, Sparkles, Gift } from 'lucide-react';
import { AppLanguage } from '../types';

interface LiveStreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onToast?: (msg: string) => void;
}

export const LiveStreamModal: React.FC<LiveStreamModalProps> = ({
  isOpen,
  onClose,
  language,
  onToast,
}) => {
  const [messages, setMessages] = useState<string[]>([
    'সাকিব: ভাই কেমন আছেন? 🔥',
    'ফারজানা: দারুণ লাইভ চলছে!',
    'রাহিম: গানটা অনেক সুন্দর 😍',
  ]);
  const [inputVal, setInputVal] = useState('');
  const [hearts, setHearts] = useState<number>(1420);

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      setMessages((prev) => [...prev, `আপনি: ${inputVal.trim()}`]);
      setInputVal('');
    }
  };

  return (
    <div className="fixed inset-0 z-60 bg-black flex flex-col justify-between p-4 select-none animate-in fade-in duration-200">
      {/* Top Bar */}
      <div className="flex items-center justify-between text-white z-20">
        <div className="flex items-center gap-2 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
          <Radio className="w-3.5 h-3.5 text-[#fe2c55] animate-pulse" />
          <span className="text-xs font-black">TikTok LIVE</span>
          <span className="text-[10px] bg-[#fe2c55] text-white px-1.5 py-0.2 rounded-full font-bold">1.4K</span>
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-full bg-black/50 flex items-center justify-center text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Background Live Video */}
      <video
        src="https://assets.mixkit.co/videos/preview/mixkit-young-woman-vlogger-recording-video-for-social-networks-42173-large.mp4"
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80 pointer-events-none" />

      {/* Live Chat & Controls */}
      <div className="z-20 space-y-3">
        <div className="max-h-40 overflow-y-auto space-y-1.5 no-scrollbar">
          {messages.map((m, idx) => (
            <div key={idx} className="bg-black/40 backdrop-blur-xs text-xs text-white px-2.5 py-1 rounded-xl w-fit">
              {m}
            </div>
          ))}
        </div>

        <form onSubmit={handleSend} className="flex items-center gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="মন্তব্য করুন..."
            className="flex-1 bg-black/50 border border-white/20 rounded-full px-4 py-2 text-xs text-white placeholder-zinc-400 outline-none"
          />
          <button
            type="button"
            onClick={() => {
              setHearts((h) => h + 1);
              onToast?.('❤️ লাইভ গিফট লাভ পাঠানো হয়েছে');
            }}
            className="w-9 h-9 rounded-full bg-[#fe2c55] flex items-center justify-center text-white active:scale-90 transition-transform cursor-pointer"
          >
            <Heart className="w-5 h-5 fill-white" />
          </button>
        </form>
      </div>
    </div>
  );
};
