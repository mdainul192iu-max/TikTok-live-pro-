import React from 'react';
import { X, Trash2, Smartphone, Music, Youtube, Camera, Play } from 'lucide-react';
import { AppLanguage, VideoReel } from '../types';

interface RecentAppsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  activeReel?: VideoReel | null;
  onResumeTikTok: () => void;
  onToast?: (msg: string) => void;
}

export const RecentAppsModal: React.FC<RecentAppsModalProps> = ({
  isOpen,
  onClose,
  language,
  activeReel,
  onResumeTikTok,
  onToast,
}) => {
  if (!isOpen) return null;

  return (
    <div 
      onClick={onClose}
      className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex flex-col justify-between p-4 sm:p-6 animate-in fade-in duration-200 select-none pointer-events-auto"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between text-white/80 pt-2 px-2">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-[#25f4ee]" />
          <span className="font-extrabold text-sm tracking-wide">
            {language === 'bn' ? 'সাম্প্রতিক অ্যাপসমূহ (Recent Apps)' : 'Recent Apps'}
          </span>
        </div>
        <button 
          onClick={onClose}
          className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* App Cards Carousel / Grid */}
      <div 
        onClick={(e) => e.stopPropagation()}
        className="flex-1 flex items-center justify-center gap-4 overflow-x-auto no-scrollbar py-6"
      >
        {/* 1. TikTok (Active App Card) */}
        <div 
          onClick={() => {
            onResumeTikTok();
            onClose();
          }}
          className="relative w-64 sm:w-72 h-[420px] rounded-3xl bg-zinc-900 border-2 border-[#fe2c55] shadow-2xl flex flex-col overflow-hidden shrink-0 cursor-pointer hover:scale-105 active:scale-95 transition-all group"
        >
          {/* App Header */}
          <div className="px-4 py-3 bg-black/80 flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-black flex items-center justify-center border border-zinc-800">
                <span className="text-[#fe2c55] text-xs font-black">d</span>
              </div>
              <span className="text-xs font-bold text-white">TikTok</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
              Active
            </span>
          </div>

          {/* App Thumbnail Preview */}
          <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden">
            {activeReel ? (
              <img 
                src={activeReel.posterUrl} 
                alt="" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            ) : (
              <div className="text-zinc-500 text-xs font-bold">TikTok Feed</div>
            )}
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
              <div className="w-14 h-14 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white shadow-xl group-hover:scale-110 transition-transform">
                <Play className="w-6 h-6 fill-white ml-0.5" />
              </div>
            </div>
          </div>

          <div className="p-3 bg-zinc-950 text-center">
            <span className="text-xs font-bold text-white">
              {language === 'bn' ? 'টিকটকে ফিরে যান (Resume)' : 'Tap to Resume TikTok'}
            </span>
          </div>
        </div>

        {/* 2. Spotify Card */}
        <div 
          onClick={() => {
            onToast?.(language === 'bn' ? '🎵 Spotify ব্যাকগ্রাউন্ডে চলছে' : '🎵 Spotify running in background');
            onClose();
          }}
          className="relative w-64 sm:w-72 h-[420px] rounded-3xl bg-zinc-900 border border-zinc-800 shadow-xl flex flex-col overflow-hidden shrink-0 cursor-pointer hover:scale-102 active:scale-95 transition-all opacity-80 hover:opacity-100"
        >
          <div className="px-4 py-3 bg-black/80 flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <Music className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-bold text-white">Spotify</span>
            </div>
          </div>
          <div className="flex-1 bg-gradient-to-br from-emerald-950 via-zinc-900 to-black p-4 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-3">
              <Music className="w-10 h-10 animate-pulse" />
            </div>
            <h4 className="text-sm font-bold text-white">Global Hits & Phonk</h4>
            <p className="text-[11px] text-zinc-400 mt-1">Background Audio Stream</p>
          </div>
        </div>

        {/* 3. YouTube Music Card */}
        <div 
          onClick={() => {
            onToast?.(language === 'bn' ? 'YouTube Music অ্যাপ প্রিভিউ' : 'YouTube Music preview');
            onClose();
          }}
          className="relative w-64 sm:w-72 h-[420px] rounded-3xl bg-zinc-900 border border-zinc-800 shadow-xl flex flex-col overflow-hidden shrink-0 cursor-pointer hover:scale-102 active:scale-95 transition-all opacity-80 hover:opacity-100"
        >
          <div className="px-4 py-3 bg-black/80 flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <Youtube className="w-5 h-5 text-red-500" />
              <span className="text-xs font-bold text-white">YouTube Music</span>
            </div>
          </div>
          <div className="flex-1 bg-gradient-to-br from-red-950 via-zinc-900 to-black p-4 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-500 mb-3">
              <Youtube className="w-10 h-10" />
            </div>
            <h4 className="text-sm font-bold text-white">Trending Audio API v3</h4>
            <p className="text-[11px] text-zinc-400 mt-1">Direct Stream Engine</p>
          </div>
        </div>

        {/* 4. Camera & Gallery Card */}
        <div 
          onClick={() => {
            onToast?.(language === 'bn' ? 'ক্যামেরা প্রিভিউ' : 'Camera preview');
            onClose();
          }}
          className="relative w-64 sm:w-72 h-[420px] rounded-3xl bg-zinc-900 border border-zinc-800 shadow-xl flex flex-col overflow-hidden shrink-0 cursor-pointer hover:scale-102 active:scale-95 transition-all opacity-80 hover:opacity-100"
        >
          <div className="px-4 py-3 bg-black/80 flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-cyan-400" />
              <span className="text-xs font-bold text-white">Camera</span>
            </div>
          </div>
          <div className="flex-1 bg-gradient-to-br from-cyan-950 via-zinc-900 to-black p-4 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 mb-3">
              <Camera className="w-10 h-10" />
            </div>
            <h4 className="text-sm font-bold text-white">Live Recorder</h4>
            <p className="text-[11px] text-zinc-400 mt-1">Ready to Record with Sound</p>
          </div>
        </div>
      </div>

      {/* Bottom Clear All Button */}
      <div className="pb-4 flex items-center justify-center">
        <button
          onClick={() => {
            onToast?.(language === 'bn' ? '✓ সকল সাম্প্রতিক অ্যাপস মেমোরি থেকে মুক্ত করা হয়েছে!' : '✓ All recent apps cleared!');
            onClose();
          }}
          className="px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-extrabold flex items-center gap-2 border border-white/15 backdrop-blur-md shadow-xl transition-all cursor-pointer"
        >
          <Trash2 className="w-4 h-4 text-rose-400" />
          <span>{language === 'bn' ? 'সব মুছুন (Clear all)' : 'Clear all'}</span>
        </button>
      </div>
    </div>
  );
};
