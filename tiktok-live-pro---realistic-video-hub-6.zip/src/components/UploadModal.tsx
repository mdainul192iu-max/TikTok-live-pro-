import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  ArrowLeft,
  Camera, 
  Music, 
  Sparkles, 
  Upload, 
  Play, 
  Pause, 
  RotateCcw, 
  Check, 
  Volume2,
  VolumeX,
  Zap,
  ZapOff,
  Clock,
  Sliders,
  Scissors,
  Plus,
  MapPin,
  Globe2,
  Settings,
  Bookmark,
  Share2,
  Eye,
  Disc3,
  ChevronRight,
  Hash,
  AtSign,
  Image as ImageIcon
} from 'lucide-react';
import { VideoReel, SoundTrack, Creator, AppLanguage, DraftReel, UserStory, UserAccount } from '../types';
import { backgroundMusicManager } from '../services/musicApiService';
import { VideoEditorModal, TextOverlayItem, EditorFilter, VideoQuality } from './VideoEditorModal';
import { videoAiPipeline } from '../services/videoAiPipeline';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPublish: (reel: VideoReel) => void;
  onPostStory?: (story: UserStory) => void;
  onSaveDraft?: (draft: DraftReel) => void;
  selectedSound?: SoundTrack;
  onOpenSoundPicker?: () => void;
  currentCreator?: Creator;
  currentUser?: UserAccount | null;
  language?: AppLanguage;
  onToast?: (msg: string) => void;
  editingDraft?: DraftReel | null;
}

type RecordLengthMode = 'photo' | '15s' | '60s' | '10m' | 'text';

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onPublish,
  onPostStory,
  onSaveDraft,
  selectedSound,
  onOpenSoundPicker,
  currentCreator,
  currentUser,
  language = 'bn',
  onToast,
  editingDraft,
}) => {
  // Permission state
  const [hasPermission, setHasPermission] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_camera_granted') === 'true';
    } catch {
      return false;
    }
  });
  const [permissionPromptVisible, setPermissionPromptVisible] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_camera_granted') !== 'true';
    } catch {
      return true;
    }
  });
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Screen Stage: 'camera' | 'post_screen'
  const [screenStage, setScreenStage] = useState<'camera' | 'post_screen'>('camera');
  const [showEditorModal, setShowEditorModal] = useState<boolean>(false);
  const [showFullPreviewModal, setShowFullPreviewModal] = useState<boolean>(false);

  // Camera settings
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isFlashOn, setIsFlashOn] = useState<boolean>(false);
  const [isMicMuted, setIsMicMuted] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1);
  const [showSpeedSelector, setShowSpeedSelector] = useState<boolean>(false);
  const [timerDuration, setTimerDuration] = useState<number>(0);
  const [countdown, setCountdown] = useState<number | null>(null);

  // Recording states
  const [recordMode, setRecordMode] = useState<RecordLengthMode>('15s');
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordDuration, setRecordDuration] = useState<number>(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [videoPosterUrl, setVideoPosterUrl] = useState<string>(
    'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800&auto=format&fit=crop&q=80'
  );

  // Editor states (CapCut features)
  const [activeFilter, setActiveFilter] = useState<EditorFilter>('normal');
  const [textOverlays, setTextOverlays] = useState<TextOverlayItem[]>([]);
  const [trimRange, setTrimRange] = useState<{ start: number; end: number }>({ start: 0, end: 15 });
  const [videoQuality, setVideoQuality] = useState<VideoQuality>('1080p');
  const [originalAudioVolume, setOriginalAudioVolume] = useState<number>(100);
  const [musicAudioVolume, setMusicAudioVolume] = useState<number>(85);

  // Post form states (matching IMG_20261015_142338.jpg)
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [location, setLocation] = useState<string>('Kuakata Tourism Park');
  const [showLocationPicker, setShowLocationPicker] = useState<boolean>(false);
  const [privacySetting, setPrivacySetting] = useState<'everyone' | 'friends' | 'only_me'>('everyone');
  const [showPrivacyOptions, setShowPrivacyOptions] = useState<boolean>(false);
  const [allowComments, setAllowComments] = useState<boolean>(true);
  const [allowDuetStitch, setAllowDuetStitch] = useState<boolean>(true);
  const [highQualityUpload, setHighQualityUpload] = useState<boolean>(true);

  // Music state
  const [activeSound, setActiveSound] = useState<SoundTrack | undefined>(selectedSound);

  // Multi-Photo Carousel mode (User Requirement: কেউ শুধু ছবি এক সংগে চার টা দুইটা বা একাধিক আপলোড করতে পারবে)
  const [isPhotoCarouselPost, setIsPhotoCarouselPost] = useState<boolean>(false);
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const photoFileInputRef = useRef<HTMLInputElement>(null);

  // AI Pipeline States (Gemini Multimodal Ingestion, Subtitle Sync, Safety Moderation)
  const [isAiProcessing, setIsAiProcessing] = useState<boolean>(false);
  const [aiStepText, setAiStepText] = useState<string>('');

  // Refs
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const nativeCamcorderRef = useRef<HTMLInputElement>(null);

  // Load editing draft if provided
  useEffect(() => {
    if (editingDraft) {
      setRecordedVideoUrl(editingDraft.videoUrl);
      setVideoPosterUrl(editingDraft.posterUrl);
      setTitle(editingDraft.title || '');
      setDescription(editingDraft.caption || '');
      setLocation(editingDraft.location || 'Kuakata Tourism Park');
      if (editingDraft.music) setActiveSound(editingDraft.music);
      if (editingDraft.filter) setActiveFilter(editingDraft.filter as EditorFilter);
      if (editingDraft.textOverlays) setTextOverlays(editingDraft.textOverlays as any);
      setScreenStage('post_screen');
    }
  }, [editingDraft]);

  // Sync active sound prop
  useEffect(() => {
    if (selectedSound) {
      setActiveSound(selectedSound);
    }
  }, [selectedSound]);

  const getMaxSeconds = () => {
    if (recordMode === '15s') return 15;
    if (recordMode === '60s') return 60;
    if (recordMode === '10m') return 600;
    return 15;
  };

  // Start real camera stream with multi-tiered resilient fallback
  const startCamera = async (mode: 'user' | 'environment') => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
      setCameraError(null);

      let stream: MediaStream | null = null;
      // Tier 1: High quality video + audio
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: !isMicMuted,
        });
      } catch (err1) {
        // Tier 2: Video with facingMode (no audio requirement)
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: mode },
            audio: false,
          });
        } catch (err2) {
          // Tier 3: Standard generic video
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
          });
        }
      }

      if (stream) {
        streamRef.current = stream;
        if (videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = stream;
          videoPreviewRef.current.play().catch(() => {});
        }
        setHasPermission(true);
      }
    } catch (err: any) {
      console.warn('Real camera stream failed:', err);
      setCameraError(
        language === 'bn' 
          ? 'ক্যামেরা সরাসরি পাওয়া যায়নি। আপনি নিচে সরাসরি ফোন ক্যামেরা দিয়ে ভিডিও রেকর্ড করতে পারেন।' 
          : 'Live camera unavailable. You can record using your phone camera directly.'
      );
      setHasPermission(true);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoPreviewRef.current) {
      videoPreviewRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (hasPermission && !permissionPromptVisible && screenStage === 'camera') {
        startCamera(facingMode);
      }
    } else {
      stopCamera();
      backgroundMusicManager.stop();
      setIsRecording(false);
      setRecordDuration(0);
      setRecordedVideoUrl(null);
      setScreenStage('camera');
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const handleGrantPermission = () => {
    try {
      localStorage.setItem('tiktok_camera_granted', 'true');
    } catch {}
    setPermissionPromptVisible(false);
    setHasPermission(true);
    startCamera(facingMode);
    onToast?.(
      language === 'bn' ? '✓ ক্যামেরা ও মাইক্রোফোন চালু হয়েছে!' : '✓ Camera activated!'
    );
  };

  const handleToggleFlip = () => {
    const nextMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextMode);
    if (hasPermission && !permissionPromptVisible) {
      startCamera(nextMode);
    }
  };

  // Recording Timer Effect
  useEffect(() => {
    const maxSec = getMaxSeconds();
    if (isRecording) {
      timerIntervalRef.current = setInterval(() => {
        setRecordDuration((prev) => {
          if (prev >= maxSec) {
            handleStopRecording();
            return maxSec;
          }
          return prev + 1;
        });
      }, 1000);

      if (activeSound) {
        backgroundMusicManager.playTrack(activeSound, musicAudioVolume / 100);
        backgroundMusicManager.setRecordingMode(true);
      }
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      backgroundMusicManager.setRecordingMode(false);
      backgroundMusicManager.pause();
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isRecording, activeSound, musicAudioVolume]);

  const handleInitiateRecording = () => {
    if (timerDuration > 0) {
      let count = timerDuration;
      setCountdown(count);
      const countInterval = setInterval(() => {
        count -= 1;
        if (count <= 0) {
          clearInterval(countInterval);
          setCountdown(null);
          executeStartRecording();
        } else {
          setCountdown(count);
        }
      }, 1000);
    } else {
      executeStartRecording();
    }
  };

  const executeStartRecording = () => {
    setRecordedVideoUrl(null);
    setRecordDuration(0);
    recordedChunksRef.current = [];

    if (streamRef.current && typeof MediaRecorder !== 'undefined') {
      try {
        const recorder = new MediaRecorder(streamRef.current, {
          mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
            ? 'video/webm;codecs=vp9'
            : 'video/webm',
        });
        recorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) recordedChunksRef.current.push(e.data);
        };
        recorder.onstop = () => {
          if (recordedChunksRef.current.length > 0) {
            const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
            const url = URL.createObjectURL(blob);
            setRecordedVideoUrl(url);
          } else {
            setRecordedVideoUrl(
              'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4'
            );
          }
          // Direct transition to TikTok Post Page!
          setScreenStage('post_screen');
        };
        mediaRecorderRef.current = recorder;
        recorder.start(100);
      } catch (err) {
        console.warn('MediaRecorder error:', err);
      }
    }
    setIsRecording(true);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setTimeout(() => {
      if (!recordedVideoUrl) {
        setRecordedVideoUrl(
          'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4'
        );
      }
      setScreenStage('post_screen');
    }, 300);
    stopCamera();
    onToast?.(
      language === 'bn' ? '✓ ভিডিও রেকর্ড সম্পন্ন! পোস্ট অপশন ওপেন হয়েছে' : '✓ Recording completed!'
    );
  };

  // Gallery upload (Supports multiple files: videos or multiple photos)
  const handleDeviceUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (files.length > 1 || files[0].type.startsWith('image/')) {
      const urls: string[] = [];
      for (let i = 0; i < files.length; i++) {
        urls.push(URL.createObjectURL(files[i]));
      }
      setUploadedPhotos(urls);
      setIsPhotoCarouselPost(true);
      setRecordedVideoUrl(urls[0]);
      setVideoPosterUrl(urls[0]);
      stopCamera();
      setScreenStage('post_screen');
      onToast?.(
        language === 'bn' 
          ? `✓ ${urls.length}টি ছবি লোড হয়েছে (ফটো ক্যারোসেল মোড)!` 
          : `✓ ${urls.length} photos loaded for Photo Mode Carousel!`
      );
      return;
    }

    const file = files[0];
    const url = URL.createObjectURL(file);
    setIsPhotoCarouselPost(false);
    setUploadedPhotos([]);
    setRecordedVideoUrl(url);
    setVideoPosterUrl(
      'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800&auto=format&fit=crop&q=80'
    );
    stopCamera();
    setScreenStage('post_screen');
    onToast?.(language === 'bn' ? '✓ ভিডিও লোড হয়েছে' : '✓ Video uploaded');
  };

  // Specific Multi-Photo picker handler
  const handleMultiplePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const urls: string[] = [];
      for (let i = 0; i < files.length; i++) {
        urls.push(URL.createObjectURL(files[i]));
      }
      setUploadedPhotos(urls);
      setIsPhotoCarouselPost(true);
      setRecordedVideoUrl(urls[0]);
      setVideoPosterUrl(urls[0]);
      stopCamera();
      setScreenStage('post_screen');
      onToast?.(
        language === 'bn'
          ? `✓ ${urls.length}টি ছবি নির্বাচিত হয়েছে! ডান-বামে স্লাইড করা যাবে`
          : `✓ ${urls.length} photos selected for horizontal swipe carousel!`
      );
    }
  };

  // Preset multi-photo selection (2, 4, or 6 photos)
  const handleSelectPresetPhotos = (count: number) => {
    const presets = [
      'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=800&auto=format&fit=crop&q=80',
    ].slice(0, count);

    setUploadedPhotos(presets);
    setIsPhotoCarouselPost(true);
    setRecordedVideoUrl(presets[0]);
    setVideoPosterUrl(presets[0]);
    stopCamera();
    setScreenStage('post_screen');
    onToast?.(
      language === 'bn'
        ? `✓ ${count}টি আকর্ষণীয় ছবি ফটো মোডে যুক্ত হয়েছে!`
        : `✓ ${count} aesthetic photos loaded for Photo Mode Carousel!`
    );
  };

  // Retake video or clear photos
  const handleRetake = () => {
    setRecordedVideoUrl(null);
    setIsPhotoCarouselPost(false);
    setUploadedPhotos([]);
    setRecordDuration(0);
    setScreenStage('camera');
    startCamera(facingMode);
    backgroundMusicManager.stop();
  };

  // 1. ACTION: Post Reel to Feed & Profile via AI Ingestion Pipeline
  const handlePublishPost = async () => {
    setIsAiProcessing(true);
    setAiStepText(language === 'bn' ? 'এআই ভিডিও ইনজেশন ও মাল্টিমোডাল বিশ্লেষণ শুরু হচ্ছে...' : 'Starting Gemini Multimodal Video Ingestion...');

    const finalVideo =
      recordedVideoUrl ||
      'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4';

    const track: SoundTrack = activeSound || {
      id: `snd-${Date.now()}`,
      title: 'Original TikTok Audio',
      artist: currentCreator?.name || 'Creator',
      youtubeVideoId: 'f_4dK39Jk2U',
      audioUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/90/Kevin_MacLeod_-_Monkeys_Spinning_Monkeys.ogg',
      cover: currentCreator?.avatar || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80',
      duration: '0:30',
      usesCount: 1,
      category: 'trending',
      source: 'original',
    };

    try {
      setAiStepText(language === 'bn' ? 'অডিও ট্র্যান্সক্রিপশন ও সিনেমাটিক সাবটাইটেল সিঙ্ক্রোনাইজ হচ্ছে...' : 'Transcribing Speech-to-Text & Mapping Subtitles...');
      await new Promise((r) => setTimeout(r, 450));

      setAiStepText(language === 'bn' ? 'রিয়েল-টাইম সেফটি মডারেশন ও কমিউনিটি পলিসি স্ক্রিনিং...' : 'Running Safety Moderation & Community Guidelines Screen...');
      await new Promise((r) => setTimeout(r, 450));

      const aiResult = await videoAiPipeline.processVideoIngestion({
        videoUrl: isPhotoCarouselPost ? (uploadedPhotos[0] || finalVideo) : finalVideo,
        posterUrl: isPhotoCarouselPost ? (uploadedPhotos[0] || videoPosterUrl) : videoPosterUrl,
        title,
        description,
        soundTitle: track.title,
        location,
        creator: currentCreator || {
          id: 'usr-self',
          name: 'আমার অ্যাকাউন্ট',
          handle: 'mynameharshuok0',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          verified: false,
          followers: 320,
          following: 5,
          likesTotal: 8900,
          bio: 'TikTok Creator',
        },
        postType: isPhotoCarouselPost ? 'photo_carousel' : 'video',
        images: isPhotoCarouselPost && uploadedPhotos.length > 0 ? uploadedPhotos : undefined,
      });

      setAiStepText(language === 'bn' ? 'অটোমেটিক ডুয়াল-স্ট্রিম কোয়ালিটি এনকোডিং: হাই কোয়ালিটি HD ও ৩জি লো-ব্যান্ডউইথ কম্প্রেশন...' : 'Encoding Dual-Stream: Crisp 1080p HD & 3G Low-Phone Adaptive Stream...');
      await new Promise((r) => setTimeout(r, 400));

      setAiStepText(language === 'bn' ? '৪-টিয়ার ক্রিয়েটর ভাইরাল পুশ মেকানিজমে যুক্ত হচ্ছে (Tier 1: 200 Users Test Group)...' : 'Enrolling in 4-Tier Virality Algorithm (Tier 1: 200 Cold Start)...');
      await new Promise((r) => setTimeout(r, 350));

      if (aiResult.reviewStatus === 'rejected') {
        setIsAiProcessing(false);
        onToast?.(`⛔ কন্টেন্ট মডারেশন অ্যালার্ট: ${aiResult.creatorWarning?.warningReason || 'কমিউনিটি নীতিমালা লঙ্ঘন'}`);
        return;
      }

      const combinedCaption = `${title ? title + ' - ' : ''}${aiResult.enrichedCaption || description || (isPhotoCarouselPost ? 'আমার নতুন ফটো ক্যারোসেল 📸' : 'আমার নতুন টিকটক ভিডিও 🔥')}`.trim();

      const newReel: VideoReel = {
        id: `reel-${Date.now()}`,
        videoUrl: isPhotoCarouselPost ? (uploadedPhotos[0] || finalVideo) : finalVideo,
        posterUrl: isPhotoCarouselPost ? (uploadedPhotos[0] || videoPosterUrl) : videoPosterUrl,
        postType: isPhotoCarouselPost ? 'photo_carousel' : 'video',
        images: isPhotoCarouselPost && uploadedPhotos.length > 0 ? uploadedPhotos : undefined,
        caption: combinedCaption,
        captionBn: aiResult.captionBn,
        tags: aiResult.tags,
        creator: currentCreator || {
          id: 'usr-self',
          name: 'আমার অ্যাকাউন্ট',
          handle: 'mynameharshuok0',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          verified: false,
          followers: 320,
          following: 5,
          likesTotal: 8900,
          bio: 'TikTok Creator',
        },
        music: track,
        likesCount: 12,
        isLiked: false,
        commentsCount: 2,
        sharesCount: 1,
        bookmarksCount: 0,
        isBookmarked: false,
        viewsCount: 50,
        category: aiResult.category,
        createdAt: 'এইমাত্র',
        location: location,
        audioSource: track.source || 'youtube_music',
        audioId: track.id,
        audioTitle: track.title,
        audioThumbnailUrl: track.cover,
        subtitles: aiResult.subtitles,
        moderation: aiResult.moderation,
        reviewStatus: aiResult.reviewStatus,
        isShadowbanned: aiResult.isShadowbanned,
        // Dual-Stream Adaptive Quality & 3G Low-Phone Compression
        videoQuality: 'adaptive_hd',
        adaptiveStreamUrl: finalVideo,
        dataSaverCompressed: true,
        // Creator Viral Push Mechanism (Tier 1: 200 Users Test Group)
        algorithmTier: 'tier_200',
        algorithmReach: 200,
        algorithmScore: 88,
        algorithmStatusText: '🎯 ১ম ধাপ: ২০০ জনের টেস্ট গ্রুপে ওয়াচ-টাইম ও লাইক রেসপন্স পর্যবেক্ষণ করা হচ্ছে।',
        completionRate: 0.84,
        loopCount: 1,
        isFirebaseLive: true,
      };

      onPublish(newReel);
      backgroundMusicManager.stop();
      stopCamera();
      setIsAiProcessing(false);
      onClose();
      onToast?.(
        language === 'bn'
          ? '✓ এআই কোয়ালিটি প্রসেসিং সফল! হাই কোয়ালিটি HD ও ৩জি অপটিমাইজেশন সহ ২০০ জনের টেস্ট গ্রুপে ভিডিওটি লাইভ পুশ হয়েছে 🔥'
          : '✓ AI Pipeline complete! High HD & 3G stream optimized and pushed to 200 users test cohort!'
      );
    } catch (err) {
      console.error('AI pipeline error during publish:', err);
      setIsAiProcessing(false);
    }
  };

  // 2. ACTION: Post to Story (স্টোরি অপশন - হাই কোয়ালিটি ও অপটিমাইজড প্রসেসিং)
  const handlePostStory = async () => {
    setIsAiProcessing(true);
    setAiStepText(language === 'bn' ? 'স্টোরি এআই প্রসেসিং: হাই কোয়ালিটি HD ও লো-নেটওয়ার্ক অপটিমাইজেশন...' : 'Processing Story: High Quality HD & 3G Smooth Stream...');
    await new Promise((r) => setTimeout(r, 450));

    const finalVideo =
      recordedVideoUrl ||
      'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4';

    const newStory: UserStory = {
      id: `story-${Date.now()}`,
      videoUrl: finalVideo,
      posterUrl: videoPosterUrl,
      createdAt: Date.now(),
      expiresAt: Date.now() + 24 * 60 * 60 * 1000,
      creator: currentCreator || {
        id: 'usr-self',
        name: 'আমার অ্যাকাউন্ট',
        handle: 'mynameharshuok0',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        verified: false,
        followers: 320,
        following: 5,
        likesTotal: 8900,
        bio: 'TikTok Creator',
      },
      music: activeSound,
      caption: title || description || 'My TikTok Story ✨',
      likesCount: 0,
      isLiked: false,
      viewsCount: 1,
    };

    onPostStory?.(newStory);
    backgroundMusicManager.stop();
    stopCamera();
    setIsAiProcessing(false);
    onClose();
    onToast?.(
      language === 'bn'
        ? '✓ সম্পূর্ণ হাই কোয়ালিটি ভিডিও স্টোরি সফলভাবে প্রসেস ও আপলোড হয়েছে! এটি ২৪ ঘণ্টা সচল থাকবে এবং তারপর অটো ডিলিট হবে।'
        : '✓ Full HD video story processed & posted! Active for 24 hours.'
    );
  };

  // 3. ACTION: Save to Drafts (ড্রাফট অপশন)
  const handleSaveDraft = () => {
    const finalVideo =
      recordedVideoUrl ||
      'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4';

    const draft: DraftReel = {
      id: editingDraft?.id || `draft-${Date.now()}`,
      videoUrl: finalVideo,
      posterUrl: videoPosterUrl,
      title: title || 'আনটাইটেল্ড ড্রাফট',
      caption: description,
      location: location,
      music: activeSound,
      savedAt: 'এখনই সংরক্ষিত',
      filter: activeFilter,
      textOverlays: textOverlays as any,
      quality: videoQuality,
      musicVolume: musicAudioVolume,
      originalVolume: originalAudioVolume,
      trimStart: trimRange.start,
      trimEnd: trimRange.end,
    };

    onSaveDraft?.(draft);
    backgroundMusicManager.stop();
    stopCamera();
    onClose();
    onToast?.(
      language === 'bn'
        ? '✓ ড্রাফটে সেভ হয়েছে! প্রোফাইলের ড্রাফট অপশন থেকে যেকোনো সময় পোস্ট করতে পারবেন'
        : '✓ Saved to drafts!'
    );
  };

  // Helper for filter CSS
  const getFilterClass = () => {
    switch (activeFilter) {
      case 'beauty':
        return 'contrast-105 saturate-125 brightness-105';
      case 'sunset':
        return 'sepia-25 saturate-150 hue-rotate-15';
      case 'cyberpunk':
        return 'contrast-125 saturate-150 hue-rotate-180';
      case 'vintage':
        return 'sepia-50 contrast-110';
      case 'noir':
        return 'grayscale contrast-125';
      case 'vibrant':
        return 'saturate-150 contrast-110';
      case 'glitch':
        return 'contrast-150 hue-rotate-90';
      case 'neon':
        return 'saturate-200 contrast-125';
      default:
        return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 bg-black text-white select-none overflow-hidden animate-in fade-in duration-200">
      
      {/* ========================================================================= */}
      {/* 1. CAMERA & MIC PERMISSION PROMPT DIALOG */}
      {/* ========================================================================= */}
      {permissionPromptVisible && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in zoom-in-95 duration-200">
          <div className="w-full max-w-sm bg-zinc-900 border border-zinc-700/80 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <div className="mx-auto w-16 h-16 rounded-2xl bg-black border-2 border-zinc-700 flex items-center justify-center relative shadow-xl">
              <div className="absolute -left-1 w-6 h-10 rounded-l-xl bg-[#25f4ee] opacity-80 -z-10" />
              <div className="absolute -right-1 w-6 h-10 rounded-r-xl bg-[#fe2c55] opacity-80 -z-10" />
              <Camera className="w-8 h-8 text-white stroke-[2.2]" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                {language === 'bn' 
                  ? 'TikTok-কে ছবি তোলা এবং ভিডিও রেকর্ড করার অনুমতি দেবেন?' 
                  : 'Allow TikTok to take pictures and record video?'}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed pt-1">
                {language === 'bn'
                  ? 'লাইভ ক্যামেরা দিয়ে ভিডিও তৈরি করতে ও মিউজিক সিনক্রোনাইজ করতে ক্যামেরা ও মাইক্রোফোন এক্সেস প্রয়োজন।'
                  : 'To record videos, add filters, and synchronize music, TikTok needs access to your device camera and microphone.'}
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={handleGrantPermission}
                className="w-full py-3 px-4 rounded-2xl bg-[#fe2c55] hover:bg-[#e0264a] active:scale-98 text-white font-black text-xs sm:text-sm shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{language === 'bn' ? 'অ্যাপ ব্যবহার করার সময়' : 'While using the app'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleGrantPermission}
                className="w-full py-3 px-4 rounded-2xl bg-zinc-800 hover:bg-zinc-700 active:scale-98 text-white font-bold text-xs sm:text-sm border border-zinc-700 cursor-pointer"
              >
                <span>{language === 'bn' ? 'শুধুমাত্র এইবার' : 'Only this time'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPermissionPromptVisible(false);
                  setHasPermission(false);
                }}
                className="w-full py-2.5 px-4 rounded-2xl bg-transparent hover:bg-zinc-800/60 text-zinc-400 hover:text-white font-semibold text-xs cursor-pointer"
              >
                <span>{language === 'bn' ? 'অনুমতি দেবেন না' : "Don't allow"}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. CAPCUT FLOATING VIDEO EDITOR MODAL */}
      {/* ========================================================================= */}
      {showEditorModal && recordedVideoUrl && (
        <VideoEditorModal
          isOpen={showEditorModal}
          onClose={() => setShowEditorModal(false)}
          videoUrl={recordedVideoUrl}
          activeSound={activeSound}
          language={language}
          initialFilter={activeFilter}
          initialOverlays={textOverlays}
          initialQuality={videoQuality}
          onApplyEdits={(edits) => {
            setActiveFilter(edits.filter);
            setTextOverlays(edits.textOverlays);
            setTrimRange({ start: edits.trimStart, end: edits.trimEnd });
            setOriginalAudioVolume(edits.originalVolume);
            setMusicAudioVolume(edits.musicVolume);
            setVideoQuality(edits.quality);
          }}
          onToast={onToast}
        />
      )}

      {/* ========================================================================= */}
      {/* 3. FULL SCREEN PREVIEW MODAL */}
      {/* ========================================================================= */}
      {showFullPreviewModal && recordedVideoUrl && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between p-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between z-10">
            <button
              type="button"
              onClick={() => setShowFullPreviewModal(false)}
              className="p-2.5 rounded-full bg-black/60 backdrop-blur-md text-white border border-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="text-xs font-bold text-zinc-300">ভিডিও প্রিভিউ</span>
            <div className="w-9" />
          </div>

          <div className="relative flex-1 flex items-center justify-center my-4 overflow-hidden rounded-3xl">
            <video
              src={recordedVideoUrl}
              autoPlay
              loop
              playsInline
              className={`w-full h-full object-cover ${getFilterClass()}`}
            />
            {textOverlays.map((item) => (
              <div
                key={item.id}
                className={`absolute inset-x-4 pointer-events-none flex items-center justify-center ${
                  item.position === 'top'
                    ? 'top-8'
                    : item.position === 'bottom'
                    ? 'bottom-8'
                    : 'top-1/2 -translate-y-1/2'
                }`}
              >
                <div
                  className={`px-3 py-1.5 rounded-xl font-black text-center shadow-2xl ${
                    item.hasBackground ? 'bg-black/70 backdrop-blur-sm' : ''
                  }`}
                  style={{ color: item.color, fontSize: `${item.size}px` }}
                >
                  {item.text}
                </div>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setShowFullPreviewModal(false)}
            className="w-full py-3.5 rounded-2xl bg-[#fe2c55] text-white font-black text-sm"
          >
            পোস্টে ফিরে যান
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. POST / PUBLISH SCREEN (EXACT REPLICA OF USER'S SCREENSHOT IMG_20261015_142338.jpg) */}
      {/* ========================================================================= */}
      {screenStage === 'post_screen' ? (
        <div className="w-full max-w-md h-full bg-zinc-950 text-white flex flex-col justify-between overflow-y-auto no-scrollbar animate-in slide-in-from-right duration-250">
          
          {/* Top Bar: < Back | Preview Button */}
          <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-900 bg-zinc-950 sticky top-0 z-20">
            <button
              type="button"
              onClick={handleRetake}
              className="p-1 rounded-full text-zinc-300 hover:text-white transition-colors cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
            </button>
            <h4 className="font-bold text-sm text-zinc-300">পোস্ট</h4>
            <button
              type="button"
              onClick={() => setShowFullPreviewModal(true)}
              className="text-xs font-black text-zinc-300 hover:text-white px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center gap-1 cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Preview</span>
            </button>
          </div>

          <div className="flex-1 p-4 space-y-4">
            
            {/* Top Video Cover Box + '+' Add Box + CapCut Floating Edit Button */}
            <div className="flex items-start gap-3">
              {/* Cover Thumbnail Box (Shows video or photo carousel) */}
              <div className="relative w-24 h-32 rounded-2xl overflow-hidden border border-zinc-800 bg-black shadow-lg shrink-0 group">
                {isPhotoCarouselPost ? (
                  <img
                    src={uploadedPhotos[0] || videoPosterUrl}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <video
                    src={recordedVideoUrl || ''}
                    className={`w-full h-full object-cover ${getFilterClass()}`}
                  />
                )}
                {/* Cover Pill Badge */}
                <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-sm text-[10px] font-bold text-white border border-white/10">
                  {isPhotoCarouselPost ? `📸 ${uploadedPhotos.length}` : 'Cover'}
                </span>

                {/* Floating CapCut Edit Button right on the cover corner */}
                {!isPhotoCarouselPost && (
                  <button
                    type="button"
                    onClick={() => setShowEditorModal(true)}
                    className="absolute bottom-1.5 inset-x-1.5 py-1 rounded-lg bg-[#fe2c55]/90 hover:bg-[#fe2c55] backdrop-blur-md text-[10px] font-black text-white flex items-center justify-center gap-1 shadow-md transition-all active:scale-95 cursor-pointer"
                    title="CapCut Video Editor"
                  >
                    <Scissors className="w-3 h-3" />
                    <span>Edit</span>
                  </button>
                )}
              </div>

              {/* Add Media '+' Box (exact matching screenshot) */}
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleDeviceUpload}
                  accept="video/*,image/*"
                  multiple
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-24 h-32 rounded-2xl border-2 border-dashed border-zinc-800 hover:border-zinc-700 bg-zinc-900/40 flex flex-col items-center justify-center text-zinc-500 hover:text-zinc-300 transition-all cursor-pointer group"
                >
                  <Plus className="w-6 h-6 mb-1 group-hover:scale-110 transition-transform" />
                  <span className="text-[10px] font-bold">{isPhotoCarouselPost ? 'ছবি যোগ (+)' : 'ক্লিপ যোগ'}</span>
                </button>
              </div>

              {/* Selected Sound Tag beside thumbnail */}
              {activeSound && (
                <div 
                  onClick={onOpenSoundPicker}
                  className="flex-1 p-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 flex items-center gap-2 cursor-pointer"
                >
                  <Disc3 className="w-4 h-4 text-[#fe2c55] shrink-0 animate-spin" />
                  <div className="min-w-0 flex-1">
                    <span className="text-[9px] text-[#25f4ee] font-black uppercase block">অডিও সিঙ্ক</span>
                    <span className="text-xs font-bold text-white truncate block">{activeSound.title}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Input 1: "Add a catchy title" (exact matching screenshot) */}
            <div className="space-y-1">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Add a catchy title"
                className="w-full bg-transparent text-sm font-bold text-white placeholder-zinc-500 outline-none border-b border-zinc-850 pb-2 focus:border-[#fe2c55] transition-colors"
              />
            </div>

            {/* Input 2: "Writing a long description can help get 3x more views on average." */}
            <div className="space-y-2">
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Writing a long description can help get 3x more views on average."
                className="w-full bg-transparent text-xs text-zinc-300 placeholder-zinc-500 outline-none resize-none leading-relaxed"
              />

              {/* Quick Tags: '#' Hashtags & '@' Mentions (exact matching screenshot) */}
              <div className="flex items-center gap-2 pt-1 border-b border-zinc-850 pb-3">
                <button
                  type="button"
                  onClick={() => setDescription((prev) => `${prev} #viral #fyp`.trim())}
                  className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <Hash className="w-3.5 h-3.5 text-[#fe2c55]" />
                  <span>Hashtags</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDescription((prev) => `${prev} @friends`.trim())}
                  className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <AtSign className="w-3.5 h-3.5 text-[#25f4ee]" />
                  <span>Mention</span>
                </button>
              </div>
            </div>

            {/* Item 3: 📍 Location with suggestions (exact matching screenshot) */}
            <div className="space-y-2 border-b border-zinc-850 pb-3">
              <div 
                onClick={() => setShowLocationPicker(!showLocationPicker)}
                className="flex items-center justify-between text-xs font-bold text-zinc-300 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-zinc-400" />
                  <span>Location</span>
                </div>
                <span className="text-zinc-400 font-normal truncate max-w-[160px]">{location}</span>
              </div>

              {/* Location Suggestions Pills (exact like screenshot) */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                {['Kuakata Tourism Park...', 'কুয়াকাটা সুন্দরবন...', 'Cox\'s Bazar Beach', 'Dhaka, Bangladesh'].map((loc) => (
                  <button
                    key={loc}
                    type="button"
                    onClick={() => setLocation(loc)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium shrink-0 transition-all cursor-pointer ${
                      location === loc ? 'bg-zinc-800 text-white font-bold' : 'bg-zinc-900/80 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {loc}
                  </button>
                ))}
              </div>
            </div>

            {/* Item 4: 🌐 Everyone can view this post > (exact matching screenshot) */}
            <div 
              onClick={() => setShowPrivacyOptions(!showPrivacyOptions)}
              className="flex items-center justify-between py-2 border-b border-zinc-850 text-xs font-bold text-zinc-300 cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-zinc-400" />
                <span>Everyone can view this post</span>
              </div>
              <ChevronRight className="w-4 h-4 text-zinc-500" />
            </div>

            {/* Privacy Dropdown Options */}
            {showPrivacyOptions && (
              <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 space-y-1">
                {[
                  { id: 'everyone', label: 'Everyone (সবাই দেখতে পাবে)' },
                  { id: 'friends', label: 'Friends (শুধুমাত্র ফ্রেন্ডস)' },
                  { id: 'only_me', label: 'Only you (শুধুমাত্র আপনি)' },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setPrivacySetting(opt.id as any);
                      setShowPrivacyOptions(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between ${
                      privacySetting === opt.id ? 'bg-[#fe2c55] text-white font-bold' : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {privacySetting === opt.id && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            )}

            {/* Item 5: ⚙️ More options > (exact matching screenshot) */}
            <div className="flex items-center justify-between py-2 text-xs font-bold text-zinc-300 cursor-pointer">
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-zinc-400" />
                <span>More options</span>
              </div>
              <span className="text-[11px] text-zinc-500 font-normal">Allow comments, duet, HD</span>
            </div>

            {/* User Request: অটোমেটিক হাই ও লো কোয়ালিটি প্রসেসিং কার্ড */}
            <div className="p-3 rounded-2xl bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-950 border border-zinc-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-black text-white">
                    {language === 'bn' ? 'অটোমেটিক ডুয়াল-কোয়ালিটি প্রসেসিং' : 'Automatic Dual-Quality Stream'}
                  </span>
                </div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  HD 1080p + 3G Smooth
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 leading-relaxed">
                {language === 'bn'
                  ? 'হাই কোয়ালিটি ১০৮০পি ভিডিও পোস্ট হবে এবং কমদামী ফোন বা ৩জি নেটের জন্য কোয়ালিটি অটোমেটিক কম্প্রেস হয়ে ল্যাগ ছাড়া নিখুঁত চলবে।'
                  : 'Auto-processes high quality HD 1080p and compresses for 3G & budget devices for zero buffer.'}
              </p>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* BOTTOM BUTTONS (EXACT USER REQUIREMENT):
              - নিচে ড্রাফট বাটন বামে থাকবে
              - ডানে নিচে পোস্ট বাটন থাকবে
              - পোস্ট অপশন এর উপরে বা পাশে স্টোরি অপশন থাকবে
          */}
          {/* ========================================================================= */}
          <div className="p-4 bg-zinc-950 border-t border-zinc-900 space-y-2 sticky bottom-0 z-20">
            
            {/* Story Button (Your Story) - Placed directly above/alongside Post button */}
            <button
              type="button"
              onClick={handlePostStory}
              className="w-full py-2.5 rounded-2xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 active:scale-98 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md group"
            >
              <div className="w-4 h-4 rounded-full border-2 border-transparent bg-gradient-to-tr from-[#25f4ee] via-amber-400 to-[#fe2c55] flex items-center justify-center p-0.5">
                <div className="w-full h-full rounded-full bg-zinc-950" />
              </div>
              <span>{language === 'bn' ? 'আপনার স্টোরিতে দিন (Your Story)' : 'Your Story'}</span>
            </button>

            {/* Bottom Row: Drafts (Left) & Post (Right) */}
            <div className="flex items-center gap-3">
              {/* Drafts Button (নিচে ড্রাফট বাটন বামে থাকবে) */}
              <button
                type="button"
                onClick={handleSaveDraft}
                className="flex-1 py-3.5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 active:scale-95 text-zinc-300 hover:text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
              >
                <Bookmark className="w-4 h-4" />
                <span>{language === 'bn' ? 'ড্রাফটস (Drafts)' : 'Drafts'}</span>
              </button>

              {/* Post Button (ডানে নিচে পোস্ট বাটন থাকবে) */}
              <button
                type="button"
                onClick={handlePublishPost}
                className="flex-2 py-3.5 rounded-2xl bg-[#fe2c55] hover:bg-[#e0264a] active:scale-95 text-white font-black text-xs sm:text-sm shadow-xl shadow-rose-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Check className="w-5 h-5 stroke-[3]" />
                <span>{language === 'bn' ? 'পোস্ট করুন (Post)' : 'Post'}</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* ========================================================================= */
        /* 5. LIVE CAMERA RECORDING VIEWPORT */
        /* ========================================================================= */
        <div className="relative w-full max-w-md h-full bg-black text-white flex flex-col overflow-hidden">
          
          {/* Progress Bar */}
          {isRecording && (
            <div className="absolute top-0 inset-x-0 z-40 h-1.5 bg-zinc-800">
              <div 
                className="h-full bg-gradient-to-r from-[#fe2c55] to-amber-500 transition-all duration-300"
                style={{ width: `${(recordDuration / getMaxSeconds()) * 100}%` }}
              />
            </div>
          )}

          {/* Top Camera Bar */}
          <div className="relative z-30 px-4 pt-3 pb-2 flex items-center justify-between bg-gradient-to-b from-black/80 via-black/40 to-transparent">
            <button
              type="button"
              onClick={() => {
                backgroundMusicManager.stop();
                stopCamera();
                onClose();
              }}
              className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-center text-white cursor-pointer shadow-md"
            >
              <X className="w-5 h-5 stroke-[2.5]" />
            </button>

            {/* Add Sound Pill (Top Center) */}
            <button
              type="button"
              onClick={onOpenSoundPicker}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-black/55 backdrop-blur-md border border-white/20 hover:border-[#fe2c55] text-xs font-black shadow-lg transition-all active:scale-95 cursor-pointer max-w-[210px]"
            >
              <div className="w-5 h-5 rounded-full bg-[#fe2c55] flex items-center justify-center text-white shrink-0">
                <Music className="w-3 h-3" />
              </div>
              <span className="truncate text-white font-bold text-xs">
                {activeSound ? activeSound.title : (language === 'bn' ? 'সাউন্ড যোগ করুন' : 'Add sound')}
              </span>
              {activeSound && <span className="w-2 h-2 rounded-full bg-[#25f4ee] animate-pulse shrink-0" />}
            </button>

            <button
              type="button"
              onClick={() => setIsFlashOn(!isFlashOn)}
              className={`w-9 h-9 rounded-full backdrop-blur-md border border-white/10 flex items-center justify-center transition-all cursor-pointer shadow-md ${
                isFlashOn ? 'bg-amber-400 text-black border-amber-300' : 'bg-black/40 text-white'
              }`}
            >
              {isFlashOn ? <Zap className="w-4 h-4 fill-black" /> : <ZapOff className="w-4 h-4" />}
            </button>
          </div>

          {/* Viewfinder Video Stream */}
          <div className="relative flex-1 bg-zinc-950 flex items-center justify-center overflow-hidden">
            <video
              ref={videoPreviewRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${
                facingMode === 'user' ? 'scale-x-[-1]' : ''
              } ${getFilterClass()}`}
            />

            {cameraError && (
              <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/90 via-black/80 to-zinc-950/90 flex flex-col items-center justify-center p-6 text-center z-10">
                <div className="w-20 h-20 rounded-full bg-zinc-900 border-2 border-dashed border-[#fe2c55]/60 flex items-center justify-center text-[#fe2c55] mb-3 animate-pulse shadow-xl">
                  <Camera className="w-10 h-10" />
                </div>
                <h4 className="font-extrabold text-white text-sm">
                  {language === 'bn' ? 'ক্যামেরা স্টুডিও প্রস্তুত' : 'Camera Studio Ready'}
                </h4>
                <p className="text-xs text-zinc-400 mt-1 max-w-xs">{cameraError}</p>
                <div className="flex items-center gap-2 mt-3">
                  <button
                    type="button"
                    onClick={() => startCamera(facingMode)}
                    className="px-4 py-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold border border-zinc-700 cursor-pointer"
                  >
                    {language === 'bn' ? 'পুনরায় চেষ্টা করুন' : 'Retry Camera'}
                  </button>
                  <button
                    type="button"
                    onClick={() => nativeCamcorderRef.current?.click()}
                    className="px-4 py-2 rounded-full bg-[#fe2c55] hover:bg-[#e0264a] text-white text-xs font-black shadow-lg cursor-pointer"
                  >
                    {language === 'bn' ? 'ফোন ক্যামেরা দিয়ে রেকর্ড' : 'Phone Camera'}
                  </button>
                </div>
              </div>
            )}
            <input
              type="file"
              ref={nativeCamcorderRef}
              onChange={handleDeviceUpload}
              accept="video/*"
              capture="environment"
              className="hidden"
            />

            {countdown !== null && (
              <div className="absolute inset-0 z-40 bg-black/60 flex items-center justify-center backdrop-blur-sm">
                <span className="text-8xl font-black text-white drop-shadow-2xl animate-ping scale-150">
                  {countdown}
                </span>
              </div>
            )}

            {isRecording && (
              <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10">
                <span className="w-3 h-3 rounded-full bg-[#fe2c55] animate-ping" />
                <span className="text-xs font-mono font-black text-white">
                  {recordDuration < 10 ? `00:0${recordDuration}` : `00:${recordDuration}`} / {getMaxSeconds()}s
                </span>
              </div>
            )}

            {/* Right Sidebar Tools */}
            <div className="absolute right-3 top-16 z-30 flex flex-col items-center gap-4 py-2">
              <button
                type="button"
                onClick={handleToggleFlip}
                className="flex flex-col items-center gap-1 text-white cursor-pointer"
              >
                <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md border border-white/15 flex items-center justify-center shadow-lg">
                  <RotateCcw className="w-5 h-5 text-white" />
                </div>
                <span className="text-[10px] font-black">{language === 'bn' ? 'উল্টান' : 'Flip'}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSpeedSelector(!showSpeedSelector)}
                className="flex flex-col items-center gap-1 text-white cursor-pointer"
              >
                <div className={`w-10 h-10 rounded-full backdrop-blur-md border border-white/15 flex items-center justify-center shadow-lg ${
                  showSpeedSelector || speed !== 1 ? 'bg-[#fe2c55]' : 'bg-black/40'
                }`}>
                  <span className="text-xs font-black">{speed}x</span>
                </div>
                <span className="text-[10px] font-black">{language === 'bn' ? 'গতি' : 'Speed'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const nextTimer = timerDuration === 0 ? 3 : timerDuration === 3 ? 10 : 0;
                  setTimerDuration(nextTimer);
                }}
                className="flex flex-col items-center gap-1 text-white cursor-pointer"
              >
                <div className={`w-10 h-10 rounded-full backdrop-blur-md border border-white/15 flex items-center justify-center shadow-lg ${
                  timerDuration > 0 ? 'bg-amber-400 text-black' : 'bg-black/40'
                }`}>
                  <Clock className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black">{timerDuration > 0 ? `${timerDuration}s` : (language === 'bn' ? 'টাইমার' : 'Timer')}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsMicMuted(!isMicMuted)}
                className="flex flex-col items-center gap-1 text-white cursor-pointer"
              >
                <div className={`w-10 h-10 rounded-full backdrop-blur-md border border-white/15 flex items-center justify-center shadow-lg ${
                  isMicMuted ? 'bg-rose-900' : 'bg-black/40'
                }`}>
                  {isMicMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </div>
                <span className="text-[10px] font-black">{language === 'bn' ? 'মাইক' : 'Mic'}</span>
              </button>
            </div>

            {/* Speed Selector Drawer */}
            {showSpeedSelector && (
              <div className="absolute bottom-20 inset-x-8 z-30 p-1.5 rounded-2xl bg-black/80 backdrop-blur-md border border-white/20 flex items-center justify-around shadow-2xl animate-in slide-in-from-bottom duration-200">
                {[0.3, 0.5, 1, 2, 3].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setSpeed(s);
                      setShowSpeedSelector(false);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      speed === s ? 'bg-[#fe2c55] text-white shadow-md' : 'text-zinc-300 hover:text-white'
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Bottom Area: Mode tabs + Shutter Button */}
          <div className="relative z-30 bg-black/95 border-t border-zinc-900 p-4 space-y-3">
            <div className="flex items-center justify-center gap-5 text-xs font-black">
              {[
                { id: 'photo', label: language === 'bn' ? 'ছবি' : 'Photo' },
                { id: '15s', label: '15s' },
                { id: '60s', label: '60s' },
                { id: '10m', label: '10m' },
                { id: 'text', label: language === 'bn' ? 'টেক্সট' : 'Text' },
              ].map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => setRecordMode(mode.id as RecordLengthMode)}
                  className={`transition-all cursor-pointer pb-1 relative ${
                    recordMode === mode.id ? 'text-white font-black scale-105' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  <span>{mode.label}</span>
                  {recordMode === mode.id && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-white" />
                  )}
                </button>
              ))}
            </div>

            {/* User Requirement: ছবি এক সাথে ৪ টা, ২ টা বা একাধিক আপলোড করতে পারবে */}
            <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs">
              <div className="flex items-center gap-1.5 text-zinc-300 font-bold">
                <ImageIcon className="w-3.5 h-3.5 text-[#25f4ee]" />
                <span className="text-[11px]">{language === 'bn' ? 'ফটো ক্যারোসেল:' : 'Photo Carousel:'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleSelectPresetPhotos(2)}
                  className="px-2 py-0.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-[10px] font-black text-white border border-zinc-700 cursor-pointer"
                >
                  {language === 'bn' ? '২টি ছবি' : '2 Photos'}
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectPresetPhotos(4)}
                  className="px-2 py-0.5 rounded-lg bg-[#fe2c55] hover:bg-[#e0264a] active:scale-95 text-[10px] font-black text-white shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? '৪টি ছবি' : '4 Photos'}
                </button>
                <button
                  type="button"
                  onClick={() => photoFileInputRef.current?.click()}
                  className="px-2 py-0.5 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 hover:bg-cyan-900 active:scale-95 text-[10px] font-black cursor-pointer"
                >
                  {language === 'bn' ? 'গ্যালারি +' : 'Gallery +'}
                </button>
              </div>
            </div>

            <input
              type="file"
              ref={photoFileInputRef}
              onChange={handleMultiplePhotoUpload}
              accept="image/*"
              multiple
              className="hidden"
            />

            <div className="flex items-center justify-around pt-1">
              {/* Left: CapCut Video Editor Trigger */}
              <button
                type="button"
                onClick={() => {
                  if (!recordedVideoUrl) {
                    setRecordedVideoUrl(
                      'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4'
                    );
                  }
                  setShowEditorModal(true);
                }}
                className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-[#fe2c55] shadow-md">
                  <Scissors className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold">{language === 'bn' ? 'এডিট' : 'Edit'}</span>
              </button>

              {/* Center: Record Button */}
              <button
                type="button"
                onClick={isRecording ? handleStopRecording : handleInitiateRecording}
                className={`relative w-20 h-20 rounded-full border-4 flex items-center justify-center transition-all cursor-pointer ${
                  isRecording
                    ? 'border-white bg-[#fe2c55] scale-110 shadow-2xl shadow-rose-600 animate-pulse'
                    : 'border-white/90 bg-transparent hover:scale-105 active:scale-95 shadow-xl'
                }`}
              >
                <div
                  className={`transition-all duration-200 ${
                    isRecording 
                      ? 'w-7 h-7 rounded-lg bg-white shadow-md' 
                      : 'w-16 h-16 rounded-full bg-[#fe2c55] border-2 border-white/80 shadow-inner'
                  }`}
                />
              </button>

              {/* Right: Upload Button */}
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleDeviceUpload}
                  accept="video/*,image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center gap-1 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                >
                  <div className="w-11 h-11 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white shadow-md">
                    <Upload className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold">{language === 'bn' ? 'আপলোড' : 'Upload'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. AI PIPELINE PROCESSING OVERLAY */}
      {isAiProcessing && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 via-rose-500 to-amber-500 text-white flex items-center justify-center mx-auto shadow-xl animate-pulse">
              <Sparkles className="w-8 h-8 fill-current" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-mono font-black text-[#25f4ee] uppercase tracking-widest block">
                Gemini Multimodal AI & Firestore Engine
              </span>
              <h3 className="text-base font-black text-white">
                {language === 'bn' ? 'এআই ভিডিও ইনজেশন চলছে' : 'AI Video Ingestion Running'}
              </h3>
              <p className="text-xs text-zinc-300 font-medium pt-1">
                {aiStepText}
              </p>
            </div>

            {/* Step Indicators */}
            <div className="p-3 bg-zinc-950/80 rounded-2xl border border-zinc-800/80 text-left text-[11px] space-y-2">
              <div className="flex items-center gap-2 text-emerald-400">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>ভিজ্যুয়াল অবজেক্ট ও মিউজিক মুড বিশ্লেষণ</span>
              </div>
              <div className="flex items-center gap-2 text-cyan-400">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>৩-৪ শব্দের বাংলা ক্যাপশন ও মিলি-সেকেন্ড সিঙ্ক</span>
              </div>
              <div className="flex items-center gap-2 text-rose-400">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>রিয়েল-টাইম মডারেশন ও সেফটি পলিসি গার্ডরেইল</span>
              </div>
              <div className="flex items-center gap-2 text-amber-400">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>Tier 1: প্রারম্ভিক ৫০ জন ব্যবহারকারীর ফিডে ক্যাশিং</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. CAPCUT STUDIO PRO VIDEO EDITOR MODAL */}
      <VideoEditorModal
        isOpen={showEditorModal}
        onClose={() => setShowEditorModal(false)}
        videoUrl={
          recordedVideoUrl ||
          'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4'
        }
        activeSound={activeSound}
        language={language}
        currentUser={currentUser || (currentCreator as any)}
        onApplyEdits={(edits) => {
          setActiveFilter(edits.filter);
          setTextOverlays(edits.textOverlays);
          setTrimRange({ start: edits.trimStart, end: edits.trimEnd });
          setVideoQuality(edits.quality);
          setOriginalAudioVolume(edits.originalVolume);
          setMusicAudioVolume(edits.musicVolume);
          if (edits.speed) setSpeed(edits.speed);
        }}
        initialFilter={activeFilter}
        initialOverlays={textOverlays}
        initialQuality={videoQuality}
        onToast={onToast}
      />
    </div>
  );
};
