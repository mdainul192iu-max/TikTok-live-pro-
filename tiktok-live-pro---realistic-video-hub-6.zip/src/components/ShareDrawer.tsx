import React from 'react';
import { X, Copy, Repeat, MessageCircle, Share2, Send, Download } from 'lucide-react';
import { VideoReel, AppLanguage } from '../types';

interface ShareDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  reel: VideoReel;
  language: AppLanguage;
  onRepost?: () => void;
  onShareAction?: () => void;
  onShareToInbox?: (user: any) => void;
  onToast?: (msg: string) => void;
}

export const ShareDrawer: React.FC<ShareDrawerProps> = ({
  isOpen,
  onClose,
  reel,
  language,
  onRepost,
  onToast,
}) => {
  if (!isOpen) return null;

  const handleCopyLink = () => {
    try {
      navigator.clipboard?.writeText(`https://tiktok.com/@${reel.creator.handle}/video/${reel.id}`);
    } catch {}
    onToast?.(language === 'bn' ? '✓ ভিডিও লিংক কপি করা হয়েছে!' : '✓ Video link copied!');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs select-none pointer-events-auto">
      <div className="relative w-full max-w-[480px] bg-zinc-950 text-white rounded-t-3xl border-t border-zinc-800 p-4 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-300">
        <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
          <h4 className="font-extrabold text-sm">
            {language === 'bn' ? 'শেয়ার করুন' : 'Share to'}
          </h4>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Share Action Grid */}
        <div className="grid grid-cols-4 gap-3 text-center">
          <button
            onClick={() => {
              onRepost?.();
              onClose();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-900 cursor-pointer active:scale-95 transition-all"
          >
            <div className="w-12 h-12 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Repeat className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold">রিপোস্ট</span>
          </button>

          <button
            onClick={handleCopyLink}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-900 cursor-pointer active:scale-95 transition-all"
          >
            <div className="w-12 h-12 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-[#25f4ee]">
              <Copy className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold">কপি লিংক</span>
          </button>

          <button
            onClick={() => {
              onToast?.(language === 'bn' ? '✓ মেসেঞ্জারে পাঠানো হয়েছে' : '✓ Shared to Messenger');
              onClose();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-900 cursor-pointer active:scale-95 transition-all"
          >
            <div className="w-12 h-12 rounded-full bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <MessageCircle className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold">মেসেঞ্জার</span>
          </button>

          <button
            onClick={() => {
              onToast?.(language === 'bn' ? '✓ ভিডিও ডাউনলোড শুরু হয়েছে' : '✓ Video downloading...');
              onClose();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-zinc-900 cursor-pointer active:scale-95 transition-all"
          >
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Download className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold">ডাউনলোড</span>
          </button>
        </div>
      </div>
    </div>
  );
};
