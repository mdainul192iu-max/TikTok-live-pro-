import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  UserCheck, 
  UserPlus, 
  Heart, 
  Eye, 
  Sparkles, 
  CheckCircle2, 
  Flame, 
  X 
} from 'lucide-react';
import { Creator, AppLanguage, UserAccount } from '../types';

export type UserListMode = 'liked_by' | 'following' | 'followers' | 'profile_views' | 'likes_overview';

export interface ListedUserItem {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  verified?: boolean;
  isFollowed: boolean;
  subtitle?: string;
  timeAgo?: string;
}

interface UserListModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: UserListMode;
  targetName?: string;
  targetCount?: number;
  language: AppLanguage;
  currentUser?: UserAccount | null;
  reelIsLiked?: boolean;
  onSelectCreator?: (creator: Creator) => void;
  onToggleFollow?: (creatorId: string) => void;
  onToast?: (msg: string) => void;
}

export const UserListModal: React.FC<UserListModalProps> = ({
  isOpen,
  onClose,
  mode,
  targetName = '',
  targetCount,
  language,
  onSelectCreator,
  onToggleFollow,
  onToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // 16 Real Profile Viewers
  const [users, setUsers] = useState<ListedUserItem[]>([
    {
      id: 'usr-sakib',
      name: 'সাকিব মাহমুদ',
      handle: 'sakib_m',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'আপনাকে অনুসরণ করছে • গান ও রিলস লাভার',
      timeAgo: '১০ মিনিট আগে',
    },
    {
      id: 'usr-asif',
      name: 'ডা. আসিফ রহমান',
      handle: 'dr_asif',
      avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: false,
      subtitle: 'চিকিৎসক ও কন্টেন্ট ক্রিয়েটর',
      timeAgo: '১ ঘণ্টা আগে',
    },
    {
      id: 'usr-farjana',
      name: 'ফারজানা আক্তার',
      handle: 'farjana_bd',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: true,
      subtitle: 'পারস্পরিক বন্ধু (Friends)',
      timeAgo: '৩ ঘণ্টা আগে',
    },
    {
      id: 'usr-tanzila',
      name: 'তানজিলা সুলতানা',
      handle: 'tanzila_s',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'আপনাকে অনুসরণ করছে',
      timeAgo: '৫ ঘণ্টা আগে',
    },
    {
      id: 'usr-mehzabin',
      name: 'Mehzabin.. 🌺🥀',
      handle: 'mehzabin_official',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: true,
      subtitle: 'Lifestyle & Dance reels in Dhaka 🌺🥰',
      timeAgo: 'গতকাল',
    },
    {
      id: 'usr-mona',
      name: 'Mona_yours',
      handle: 'mona_yours_dance',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: true,
      subtitle: 'Trending TikTok Dance Duo ✨',
      timeAgo: 'গতকাল',
    },
    {
      id: 'usr-raju',
      name: 'bike lover Raju',
      handle: 'bike_lover_raju',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'R15 V3 & Village Bull Lifestyle 🖤',
      timeAgo: '২ দিন আগে',
    },
    {
      id: 'usr-rahim',
      name: 'রাহিম হাসান',
      handle: 'rahim_h',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'আপনাকে অনুসরণ করছে',
      timeAgo: '৩ দিন আগে',
    },
    {
      id: 'usr-afrin',
      name: 'আফরিন জাহান',
      handle: 'afrin_j',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'নতুন ব্যবহারকারী',
      timeAgo: '৪ দিন আগে',
    },
    {
      id: 'usr-tani',
      name: 'TANI EDITZ',
      handle: 'tani_editz_bd',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: true,
      subtitle: 'Bengali Drama & Cinema Edits 🗿🔥',
      timeAgo: '৫ দিন আগে',
    },
    {
      id: 'usr-suborna',
      name: 'সুবর্ণা রায় 🌸',
      handle: 'suborna_roy',
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'Lifestyle & Travel in Sylhet ☕',
      timeAgo: '৮ মিনিট আগে',
    },
    {
      id: 'usr-fahim',
      name: 'ফাহিম আহমেদ',
      handle: 'fahim_edits',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: true,
      subtitle: 'Bangla Beats & Phonk Editor ⚡',
      timeAgo: '২০ মিনিট আগে',
    },
    {
      id: 'usr-tanvir',
      name: 'তানভীর হোসেন',
      handle: 'tanvir_hossain_1',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: false,
      subtitle: 'টেক রিভিউয়ার ও ক্যামেরা লাভার',
      timeAgo: '৩৫ মিনিট আগে',
    },
    {
      id: 'usr-nusrat',
      name: 'নুসরাত জাহান',
      handle: 'nusrat_queen',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: false,
      subtitle: 'Acoustic Guitar & Vocals 🎸',
      timeAgo: '১ ঘণ্টা আগে',
    },
    {
      id: 'usr-maruf',
      name: 'মারুফ বিল্লাহ',
      handle: 'maruf_fitness',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80',
      verified: false,
      isFollowed: true,
      subtitle: 'Fitness & Gym Motivation BD 💪',
      timeAgo: '২ ঘণ্টা আগে',
    },
    {
      id: 'usr-saim',
      name: 'CRAZY SAIM 🥶',
      handle: 'crazy_saim_editz',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&auto=format&fit=crop&q=80',
      verified: true,
      isFollowed: false,
      subtitle: 'Aesthetic cinematography',
      timeAgo: '৩ ঘণ্টা আগে',
    },
  ]);

  if (!isOpen) return null;

  const handleToggleUserFollow = (e: React.MouseEvent, uId: string) => {
    e.stopPropagation();
    setUsers((prev) =>
      prev.map((u) => (u.id === uId ? { ...u, isFollowed: !u.isFollowed } : u))
    );
    if (onToggleFollow) onToggleFollow(uId);
  };

  const handleUserClick = (u: ListedUserItem) => {
    if (onSelectCreator) {
      const creatorObj: Creator = {
        id: u.id,
        name: u.name,
        handle: u.handle,
        avatar: u.avatar,
        verified: u.verified || false,
        followers: 1240,
        following: 54,
        likesTotal: 8400,
        bio: u.subtitle || 'TikTok creator in Bangladesh 🇧🇩',
        isFollowed: u.isFollowed,
      };
      onSelectCreator(creatorObj);
    }
  };

  const filteredUsers = users.filter((u) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.handle.toLowerCase().includes(q);
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-xs select-none pointer-events-auto">
      <div className="relative w-full max-w-[480px] h-[86vh] sm:h-[88vh] bg-white text-zinc-900 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300">
        
        {/* Header Bar with Back Button in Top-Left Corner (User request: ব্যাক বাটন থাকবে উপরে কোনে বামে) */}
        <div className="px-4 py-3.5 border-b border-zinc-100 flex items-center justify-between bg-white">
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-700 transition-colors cursor-pointer"
            title="Back"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
          </button>

          <div className="text-center">
            <h3 className="font-extrabold text-sm sm:text-base text-zinc-900 tracking-tight flex items-center justify-center gap-1.5">
              {mode === 'profile_views' && <Eye className="w-4 h-4 text-cyan-600" />}
              {mode === 'liked_by' && <Heart className="w-4 h-4 fill-[#fe2c55] text-[#fe2c55]" />}
              {mode === 'likes_overview' && <Flame className="w-4 h-4 text-[#fe2c55]" />}
              <span>
                {mode === 'profile_views'
                  ? (language === 'bn' ? 'প্রোফাইল ভিউয়ার্স (১৬ জন)' : 'Profile Views (16)')
                  : mode === 'followers'
                  ? (language === 'bn' ? 'অনুসরণকারীগণ' : 'Followers')
                  : mode === 'following'
                  ? (language === 'bn' ? 'ফলোয়িং' : 'Following')
                  : targetName || 'Users'}
              </span>
            </h3>
            {mode === 'profile_views' && (
              <span className="text-[10px] text-zinc-400 font-semibold block">
                {language === 'bn' ? 'গত ৭ দিনে প্রোফাইল ভিজিট করেছে' : 'Viewed your profile in past 7 days'}
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-zinc-100 flex items-center justify-center text-zinc-400 hover:text-black transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="px-4 py-2.5 bg-zinc-50 border-b border-zinc-100">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'bn' ? 'নাম বা ইউজারনেম দিয়ে খুঁজুন...' : 'Search users...'}
              className="w-full pl-9 pr-3 py-2 bg-white rounded-xl text-xs font-semibold border border-zinc-200 outline-none placeholder:text-zinc-400 focus:border-zinc-400"
            />
          </div>
        </div>

        {/* User List Rows Line by Line */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1 divide-y divide-zinc-50 no-scrollbar">
          {filteredUsers.map((u) => (
            <div
              key={u.id}
              onClick={() => handleUserClick(u)}
              className="py-2.5 px-2 hover:bg-zinc-50 rounded-2xl flex items-center justify-between gap-3 cursor-pointer transition-colors group"
            >
              {/* Left: Avatar & Info */}
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className="relative w-11 h-11 rounded-full flex items-center justify-center p-[1.5px] shrink-0">
                  {/* Thin rotating color ring: প্রোফাইলের চার পাশ দিয়ে চিকন রঙ কালার ঘুরবে */}
                  <div className="absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#fe2c55,#25f4ee,#f59e0b,#8b5cf6,#fe2c55)] animate-spin-slow shadow-xs" />
                  <img src={u.avatar} alt={u.name} className="relative z-1 w-full h-full rounded-full object-cover border border-white" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-black text-zinc-900 truncate">
                      {u.name}
                    </span>
                    {u.verified && (
                      <CheckCircle2 className="w-3.5 h-3.5 fill-cyan-400 text-white shrink-0" />
                    )}
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono block truncate">
                    @{u.handle}
                  </span>
                  {u.subtitle && (
                    <span className="text-[10px] text-zinc-500 line-clamp-1 mt-0.5">
                      {u.subtitle}
                    </span>
                  )}
                </div>
              </div>

              {/* Right: Time Ago & Follow Button */}
              <div className="shrink-0 flex items-center gap-2">
                {u.timeAgo && (
                  <span className="text-[10px] text-zinc-400 font-mono hidden sm:inline-block">
                    {u.timeAgo}
                  </span>
                )}
                <button
                  type="button"
                  onClick={(e) => handleToggleUserFollow(e, u.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 flex items-center gap-1 cursor-pointer ${
                    u.isFollowed
                      ? 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200 border border-zinc-200'
                      : 'bg-[#fe2c55] hover:bg-[#e0264b] text-white'
                  }`}
                >
                  {u.isFollowed ? (
                    <>
                      <UserCheck className="w-3 h-3 text-emerald-600" />
                      <span>Following</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3 h-3" />
                      <span>Follow</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
