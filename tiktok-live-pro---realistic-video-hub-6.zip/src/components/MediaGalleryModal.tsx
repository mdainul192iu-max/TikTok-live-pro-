import React, { useState, useRef } from 'react';
import { 
  X, 
  Image, 
  Video, 
  Upload, 
  Sparkles, 
  Check, 
  Plus, 
  Play, 
  Camera
} from 'lucide-react';
import { AppLanguage, Creator } from '../types';

interface MediaGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  creator: Creator;
  onSelectProfilePhoto?: (url: string) => void;
  onSelectProfileVideo?: (videoUrl: string) => void;
  onAddToStory?: (mediaUrl: string, caption?: string) => void;
  onPublishReel?: (mediaUrl: string, title?: string, isVideo?: boolean) => void;
  onToast?: (msg: string) => void;
}

const GALLERY_PRESETS = [
  {
    id: 'gal-1',
    type: 'photo' as const,
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80',
    title: 'Casual Portrait',
  },
  {
    id: 'gal-2',
    type: 'photo' as const,
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80',
    title: 'Aesthetic Neon',
  },
  {
    id: 'gal-3',
    type: 'video' as const,
    url: 'https://assets.mixkit.co/videos/preview/mixkit-girl-dancing-on-the-street-at-sunset-40760-large.mp4',
    poster: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=600&auto=format&fit=crop&q=80',
    title: 'Street Dance Reel',
  },
  {
    id: 'gal-4',
    type: 'video' as const,
    url: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-vlogger-recording-video-for-social-networks-42173-large.mp4',
    poster: 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=600&auto=format&fit=crop&q=80',
    title: 'Vlog Moment',
  },
  {
    id: 'gal-5',
    type: 'photo' as const,
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&auto=format&fit=crop&q=80',
    title: 'Biker Style',
  },
  {
    id: 'gal-6',
    type: 'video' as const,
    url: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-smartphone-scrolling-social-media-42175-large.mp4',
    poster: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80',
    title: 'Phone Scrolling',
  },
];

export const MediaGalleryModal: React.FC<MediaGalleryModalProps> = ({
  isOpen,
  onClose,
  language,
  creator,
  onSelectProfilePhoto,
  onAddToStory,
  onPublishReel,
  onToast,
}) => {
  const [tab, setTab] = useState<'all' | 'photos' | 'videos'>('all');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleCustomUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      onSelectProfilePhoto?.(url);
      onToast?.(language === 'bn' ? '✓ প্রোফাইল ছবি সফলভাবে আপডেট হয়েছে!' : '✓ Profile photo updated!');
      onClose();
    }
  };

  const filtered = GALLERY_PRESETS.filter((item) => {
    if (tab === 'photos') return item.type === 'photo';
    if (tab === 'videos') return item.type === 'video';
    return true;
  });

  return (
    <div className="fixed inset-0 z-60 flex items-end justify-center bg-black/75 backdrop-blur-xs select-none pointer-events-auto">
      <div className="relative w-full max-w-[480px] h-[80vh] bg-zinc-950 text-white rounded-t-3xl border-t border-zinc-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-[#fe2c55]" />
            <h4 className="font-extrabold text-sm sm:text-base">
              {language === 'bn' ? 'গ্যালারি ও মিডিয়া' : 'Media Gallery'}
            </h4>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs & Device Upload Button */}
        <div className="p-3 bg-zinc-900 flex items-center justify-between gap-2 border-b border-zinc-800">
          <div className="flex gap-1.5">
            <button
              onClick={() => setTab('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                tab === 'all' ? 'bg-white text-black' : 'bg-zinc-800 text-zinc-300'
              }`}
            >
              সব
            </button>
            <button
              onClick={() => setTab('photos')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                tab === 'photos' ? 'bg-white text-black' : 'bg-zinc-800 text-zinc-300'
              }`}
            >
              ছবি
            </button>
            <button
              onClick={() => setTab('videos')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                tab === 'videos' ? 'bg-white text-black' : 'bg-zinc-800 text-zinc-300'
              }`}
            >
              ভিডিও
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleCustomUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#fe2c55] hover:bg-[#e0264b] text-white text-xs font-black shadow-md active:scale-95 transition-all cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>ফোন থেকে বাছুন</span>
          </button>
        </div>

        {/* Media Grid */}
        <div className="flex-1 overflow-y-auto p-3 grid grid-cols-3 gap-2 no-scrollbar">
          {filtered.map((item) => (
            <div
              key={item.id}
              onClick={() => {
                if (item.type === 'photo') {
                  onSelectProfilePhoto?.(item.url);
                  onToast?.(language === 'bn' ? '✓ প্রোফাইল ছবি আপডেট হয়েছে' : '✓ Photo selected');
                } else {
                  onAddToStory?.(item.url, item.title);
                  onToast?.(language === 'bn' ? '✓ স্টোরিতে যোগ করা হয়েছে' : '✓ Added to story');
                }
                onClose();
              }}
              className="relative aspect-square rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 cursor-pointer group hover:scale-102 transition-transform"
            >
              <img src={item.poster || item.url} alt="" className="w-full h-full object-cover" />
              {item.type === 'video' && (
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <Play className="w-6 h-6 fill-white text-white drop-shadow-md" />
                </div>
              )}
              <div className="absolute bottom-1 inset-x-1 text-center">
                <span className="text-[9px] font-bold bg-black/60 px-1.5 py-0.5 rounded-md text-white backdrop-blur-xs">
                  {item.title}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
