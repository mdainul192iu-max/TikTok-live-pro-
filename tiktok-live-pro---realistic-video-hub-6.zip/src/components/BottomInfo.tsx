import React from 'react';
import { Music, MapPin, CheckCircle2 } from 'lucide-react';
import { VideoReel, AppLanguage } from '../types';

interface BottomInfoProps {
  reel: VideoReel;
  onOpenCreator: () => void;
  onOpenSound: () => void;
  onOpenAlgorithmInsights?: () => void;
  language: AppLanguage;
}

export const BottomInfo: React.FC<BottomInfoProps> = ({
  reel,
  onOpenCreator,
  onOpenSound,
  onOpenAlgorithmInsights,
  language,
}) => {
  return (
    <div className="absolute left-3 right-18 bottom-16 z-20 text-white select-none pointer-events-auto">
      {/* Creator Name & Handle */}
      <div 
        onClick={onOpenCreator}
        className="flex items-center gap-1.5 cursor-pointer hover:opacity-90 transition-opacity w-fit"
      >
        <span className="font-black text-sm sm:text-base drop-shadow-md">
          @{reel.creator.handle}
        </span>
        {reel.creator.verified && (
          <CheckCircle2 className="w-4 h-4 fill-cyan-400 text-black shrink-0" />
        )}
      </div>

      {/* Caption & Hashtags */}
      <p className="text-xs sm:text-sm text-white/95 mt-1 line-clamp-2 drop-shadow-md font-medium leading-tight">
        {language === 'bn' && reel.captionBn ? reel.captionBn : reel.caption}
      </p>

      {/* Location tag if available */}
      {reel.location && (
        <div className="flex items-center gap-1 text-[11px] text-zinc-300 font-semibold mt-1">
          <MapPin className="w-3 h-3 text-[#25f4ee]" />
          <span>{reel.location}</span>
        </div>
      )}

      {/* TikTok Algorithm Reach & Viral Progression Pill */}
      {reel.algorithmTier && (
        <button
          type="button"
          onClick={onOpenAlgorithmInsights}
          className={`mt-1.5 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black border backdrop-blur-md shadow-md cursor-pointer transition-all active:scale-95 ${
            reel.algorithmTier === 'tier_50'
              ? 'bg-amber-950/80 text-amber-300 border-amber-500/40 hover:bg-amber-900/90'
              : reel.algorithmTier === 'tier_1000'
              ? 'bg-sky-950/80 text-sky-300 border-sky-500/40 hover:bg-sky-900/90'
              : 'bg-rose-950/85 text-rose-300 border-rose-500/50 hover:bg-rose-900/90 animate-pulse'
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
          <span>
            {reel.algorithmTier === 'tier_50' && (language === 'bn' ? '⚡ অ্যালগরিদম: ৫০ জন অডিয়েন্স টেস্ট' : '⚡ 50 Users Test (Tier 1)')}
            {reel.algorithmTier === 'tier_1000' && (language === 'bn' ? '🚀 ১,০০০ জনের কাছে সম্প্রসারিত' : '🚀 1,000 Users Reach (Tier 2)')}
            {(reel.algorithmTier === 'tier_10000' || reel.algorithmTier === 'tier_viral') && (language === 'bn' ? '🔥 ১০,০০০+ ভাইরাল FYP' : '🔥 10,000+ Viral FYP')}
          </span>
          <span className="text-[9px] opacity-75 underline ml-1">
            {language === 'bn' ? 'রিপোর্ট' : 'Insights'}
          </span>
        </button>
      )}

      {/* Audio Track Tag with scrolling ticker animation (Clicking triggers Reuse Audio) */}
      <div 
        onClick={onOpenSound}
        className="flex items-center gap-2 mt-2 w-full max-w-[240px] bg-black/45 hover:bg-black/65 px-2.5 py-1 rounded-full border border-white/15 backdrop-blur-md cursor-pointer active:scale-95 transition-all overflow-hidden"
        title="এই সাউন্ড ব্যবহার করুন (Reuse Audio)"
      >
        <Music className="w-3.5 h-3.5 text-[#25f4ee] animate-pulse shrink-0" />
        
        {/* Continuous Marquee Ticker */}
        <div className="overflow-hidden whitespace-nowrap flex-1">
          <div className="animate-marquee flex gap-6 text-[11px] font-bold text-zinc-200">
            <span>
              {reel.audioTitle || reel.music.title} - {reel.creator.name} (Original Sound)
            </span>
            <span>
              {reel.audioTitle || reel.music.title} - {reel.creator.name} (Original Sound)
            </span>
          </div>
        </div>

        <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded-full shrink-0 ${
          (reel.audioSource || reel.music.source) === 'spotify' 
            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30' 
            : 'bg-red-950 text-red-400 border border-red-500/30'
        }`}>
          {(reel.audioSource || reel.music.source) === 'spotify' ? 'Spotify' : 'YouTube'}
        </span>
      </div>
    </div>
  );
};
