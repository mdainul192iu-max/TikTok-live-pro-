import React, { useState, useMemo, useEffect } from 'react';
import { 
  ArrowLeft, 
  Globe, 
  Shield, 
  Lock, 
  Download, 
  HardDrive, 
  Sliders, 
  Bell, 
  Clock, 
  HelpCircle, 
  FileText, 
  LogOut, 
  ChevronRight, 
  Wifi, 
  Moon, 
  Sun,
  Eye, 
  EyeOff,
  Sparkles,
  MapPin,
  Search,
  Check,
  Globe2,
  UserPlus,
  Users,
  User,
  Film,
  Radio,
  Share2,
  UserX,
  MessageCircle,
  AtSign,
  Send,
  Repeat,
  DownloadCloud,
  ListFilter,
  Heart,
  PlaySquare,
  Trash2,
  QrCode,
  RefreshCw,
  AlertTriangle,
  Smartphone,
  ShieldCheck,
  SlidersHorizontal,
  X,
  Copy,
  ExternalLink,
  Pin,
  CheckCircle2,
  Rocket,
  Zap,
  Flame,
  CreditCard,
  TrendingUp,
  DollarSign,
  Calculator,
  AlertOctagon,
  Activity,
  Layers,
  CheckCheck,
  Crown,
  Gift,
  Coins,
  Wallet,
  AlertCircle
} from 'lucide-react';
import { AppLanguage, ThemeMode, AccessibilitySettings, Creator, VideoReel, BoostCampaign, BannedUserInfo, VipCapCutPurchase } from '../types';
import { videoCacheManager } from '../services/videoCacheManager';
import { referralWalletService, UserWallet } from '../services/referralWalletService';
import { 
  walletEarningsService, 
  WithdrawalRequest, 
  MobileRechargeRequest, 
  WithdrawalMethod,
  UserWalletState 
} from '../services/walletEarningsService';
import { securityArchitectureService, SecurityIntegrityReport } from '../services/securityArchitectureService';
import { admobService, OFFICIAL_ADMOB_CONFIG } from '../services/admobService';
import { RewardedInterstitialModal } from './RewardedInterstitialModal';
import { COUNTRIES_200, getOperatorsForCountry, CountryLanguageItem } from '../data/languages200';
import {
  getAllAppUsers,
  banUser,
  unbanUser,
  fetchBannedUsers,
  isUserBanned,
  fetchBoostCampaigns,
  saveBoostCampaign,
  updateBoostCampaign,
  fetchVipPurchases,
  updateVipPurchase,
  getFireLiveMetrics,
  AppDirectoryUser
} from '../services/firebaseService';

export interface CountryItem {
  name: string;
  code: string;
  flag: string;
  iso: string;
  language: AppLanguage;
  nativeLang: string;
}

export const ALL_COUNTRIES: CountryItem[] = [
  { name: 'Bangladesh', code: '+880', flag: '🇧🇩', iso: 'BD', language: 'bn', nativeLang: 'বাংলা' },
  { name: 'United States', code: '+1', flag: '🇺🇸', iso: 'US', language: 'en', nativeLang: 'English' },
  { name: 'India', code: '+91', flag: '🇮🇳', iso: 'IN', language: 'hi', nativeLang: 'हिन्दी / English' },
  { name: 'Pakistan', code: '+92', flag: '🇵🇰', iso: 'PK', language: 'ur', nativeLang: 'اردو / English' },
  { name: 'United Kingdom', code: '+44', flag: '🇬🇧', iso: 'GB', language: 'en', nativeLang: 'English' },
  { name: 'Saudi Arabia', code: '+966', flag: '🇸🇦', iso: 'SA', language: 'ar', nativeLang: 'العربية' },
  { name: 'United Arab Emirates', code: '+971', flag: '🇦🇪', iso: 'AE', language: 'ar', nativeLang: 'العربية / English' },
  { name: 'Malaysia', code: '+60', flag: '🇲🇾', iso: 'MY', language: 'en', nativeLang: 'Bahasa Melayu' },
  { name: 'Canada', code: '+1', flag: '🇨🇦', iso: 'CA', language: 'en', nativeLang: 'English / Français' },
  { name: 'Australia', code: '+61', flag: '🇦🇺', iso: 'AU', language: 'en', nativeLang: 'English' },
  { name: 'Germany', code: '+49', flag: '🇩🇪', iso: 'DE', language: 'en', nativeLang: 'Deutsch' },
  { name: 'France', code: '+33', flag: '🇫🇷', iso: 'FR', language: 'en', nativeLang: 'Français' },
  { name: 'Italy', code: '+39', flag: '🇮🇹', iso: 'IT', language: 'en', nativeLang: 'Italiano' },
  { name: 'Brazil', code: '+55', flag: '🇧🇷', iso: 'BR', language: 'pt', nativeLang: 'Português' },
  { name: 'Singapore', code: '+65', flag: '🇸🇬', iso: 'SG', language: 'en', nativeLang: 'English' },
  { name: 'Qatar', code: '+974', flag: '🇶🇦', iso: 'QA', language: 'ar', nativeLang: 'العربية' },
  { name: 'Kuwait', code: '+965', flag: '🇰🇼', iso: 'KW', language: 'ar', nativeLang: 'العربية' },
  { name: 'Oman', code: '+968', flag: '🇴🇲', iso: 'OM', language: 'ar', nativeLang: 'العربية' },
  { name: 'Indonesia', code: '+62', flag: '🇮🇩', iso: 'ID', language: 'id', nativeLang: 'Bahasa Indonesia' },
  { name: 'Turkey', code: '+90', flag: '🇹🇷', iso: 'TR', language: 'en', nativeLang: 'Türkçe' },
];

export const detectSystemCountry = (): CountryItem => {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (tz.includes('Dhaka')) return ALL_COUNTRIES[0];
    if (tz.includes('New_York') || tz.includes('Los_Angeles') || tz.includes('Chicago')) return ALL_COUNTRIES[1];
    if (tz.includes('Kolkata') || tz.includes('Calcutta')) return ALL_COUNTRIES[2];
    if (tz.includes('Karachi')) return ALL_COUNTRIES[3];
    if (tz.includes('London')) return ALL_COUNTRIES[4];
    if (tz.includes('Riyadh')) return ALL_COUNTRIES[5];
    if (tz.includes('Dubai')) return ALL_COUNTRIES[6];
    if (tz.includes('Kuala_Lumpur')) return ALL_COUNTRIES[7];
    if (tz.includes('Toronto') || tz.includes('Vancouver')) return ALL_COUNTRIES[8];
    if (tz.includes('Sydney') || tz.includes('Melbourne')) return ALL_COUNTRIES[9];
    if (tz.includes('Berlin')) return ALL_COUNTRIES[10];
    if (tz.includes('Paris')) return ALL_COUNTRIES[11];
    if (tz.includes('Rome')) return ALL_COUNTRIES[12];
    if (tz.includes('Sao_Paulo')) return ALL_COUNTRIES[13];
    if (tz.includes('Singapore')) return ALL_COUNTRIES[14];
    if (tz.includes('Jakarta')) return ALL_COUNTRIES[18];
    const nav = navigator.language || '';
    if (nav.includes('BD') || nav.includes('bn')) return ALL_COUNTRIES[0];
    if (nav.includes('US')) return ALL_COUNTRIES[1];
    if (nav.includes('IN') || nav.includes('hi')) return ALL_COUNTRIES[2];
    if (nav.includes('GB')) return ALL_COUNTRIES[4];
  } catch {}
  return ALL_COUNTRIES[0];
};

export type SettingsSubView =
  | null
  // New Admin, Boost & Fire Live features
  | 'admin_gate'
  | 'admin_panel'
  | 'tiktok_boost'
  | 'refer_and_earn'
  | 'wallet_and_earnings'
  | 'fire_live_connect'
  // Box 1
  | 'manage_post'
  | 'content_preferences'
  | 'live'
  | 'notification'
  | 'time_wellbeing'
  | 'family_pairing'
  // Box 2
  | 'account'
  | 'security_permission'
  | 'share_profile'
  // Box 3
  | 'private_account'
  | 'blocked_account'
  // Box 4
  | 'comment'
  | 'mention'
  | 'direct_message'
  | 'reuse_content'
  | 'download'
  | 'following_list'
  | 'liked_videos'
  | 'viewers'
  | 'audience_control'
  | 'playback'
  | 'display'
  | 'language'
  | 'accessibility'
  | 'contact_location'
  // Box 5
  | 'offline_video'
  | 'free_space'
  | 'data_saver'
  | 'help_center'
  | 'privacy_center'
  | 'terms_policies'
  // Special
  | 'countries'
  | 'switch_account';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  themeMode: ThemeMode;
  onToggleTheme: () => void;
  accessibility: AccessibilitySettings;
  onUpdateAccessibility: (settings: Partial<AccessibilitySettings>) => void;
  onLogout?: () => void;
  onToast?: (msg: string) => void;
  onOpenAuthForCountry?: (country: CountryItem) => void;
  currentUser?: Creator | null;
  reels?: VideoReel[];
  onDeleteReel?: (reelId: string) => void;
  onOpenLive?: () => void;
  onOpenAuth?: () => void;
  onActivateBoost?: (campaign: BoostCampaign) => void;
  onOpenGeminiAssistant?: () => void;
  isFloatingGeminiEnabled?: boolean;
  onToggleFloatingGemini?: (enabled: boolean) => void;
  initialSubView?: SettingsSubView;
  onOpenRewardedAds?: () => void;
}

// Sleek iOS-style Toggle Switch
const ToggleSwitch: React.FC<{
  checked: boolean;
  onChange: (val: boolean) => void;
  disabled?: boolean;
}> = ({ checked, onChange, disabled }) => (
  <button
    type="button"
    disabled={disabled}
    onClick={(e) => {
      e.stopPropagation();
      onChange(!checked);
    }}
    className={`w-11 h-6 flex items-center rounded-full p-0.5 transition-colors cursor-pointer ${
      checked ? 'bg-[#22c55e]' : 'bg-zinc-300 dark:bg-zinc-700'
    } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
  >
    <div
      className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${
        checked ? 'translate-x-5' : 'translate-x-0'
      }`}
    />
  </button>
);

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  themeMode,
  onToggleTheme,
  accessibility,
  onUpdateAccessibility,
  onLogout,
  onToast,
  onOpenAuthForCountry,
  currentUser,
  reels = [],
  onDeleteReel,
  onOpenLive,
  onOpenAuth,
  onActivateBoost,
  onOpenGeminiAssistant,
  isFloatingGeminiEnabled = true,
  onToggleFloatingGemini,
  initialSubView = null,
  onOpenRewardedAds,
}) => {
  const [activeSubView, setActiveSubView] = useState<SettingsSubView>(initialSubView);

  useEffect(() => {
    if (isOpen && initialSubView !== undefined) {
      setActiveSubView(initialSubView);
    }
  }, [isOpen, initialSubView]);

  const [countrySearch, setCountrySearch] = useState('');
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // ADMIN STATE: User Search, Ban & Unban + Boosts + CapCut VIP Purchases + Withdrawals & Recharges + AdMob & Security
  const [adminSearch, setAdminSearch] = useState('');
  const [adminActiveTab, setAdminActiveTab] = useState<'users' | 'boosts' | 'vip_purchases' | 'withdrawals' | 'recharges' | 'admob_security'>('users');
  const [adminUserFilter, setAdminUserFilter] = useState<'all' | 'active' | 'banned'>('all');
  const [allUsers, setAllUsers] = useState<AppDirectoryUser[]>(() => getAllAppUsers());
  const [bannedList, setBannedList] = useState<BannedUserInfo[]>(() => fetchBannedUsers());
  const [vipPurchases, setVipPurchases] = useState<VipCapCutPurchase[]>(() => fetchVipPurchases());

  // ADMOB SERVICE STATE (Official IDs, dynamic frequency, metrics)
  const [admobConfig, setAdmobConfig] = useState(() => admobService.getConfig());
  const [admobStats, setAdmobStats] = useState(() => admobService.getStats());
  const [showHighPayingInterstitial, setShowHighPayingInterstitial] = useState<boolean>(false);
  const [pendingWithdrawalPayload, setPendingWithdrawalPayload] = useState<any>(null);

  // MY WALLET & EARNINGS STATE (Coins, Currency Conversion, Daily Earnings, Withdraw & Recharge)
  const [earningsWallet, setEarningsWallet] = useState<UserWalletState>(() => walletEarningsService.getWallet());
  const [walletWithdrawals, setWalletWithdrawals] = useState<WithdrawalRequest[]>(() => walletEarningsService.getWithdrawals());
  const [walletRecharges, setWalletRecharges] = useState<MobileRechargeRequest[]>(() => walletEarningsService.getRecharges());
  const [securityReport, setSecurityReport] = useState<SecurityIntegrityReport>(() => securityArchitectureService.getAuditReport());
  
  // Withdrawal Form Modal States
  const [showWithdrawModal, setShowWithdrawModal] = useState<boolean>(false);
  const [withdrawMethodChoice, setWithdrawMethodChoice] = useState<WithdrawalMethod>('bkash');
  const [withdrawAccountInput, setWithdrawAccountInput] = useState<string>('');
  const [withdrawBankName, setWithdrawBankName] = useState<string>('');
  const [withdrawCoinAmount, setWithdrawCoinAmount] = useState<number>(10000);
  
  // Worldwide Mobile Recharge Form Modal States
  const [showRechargeModal, setShowRechargeModal] = useState<boolean>(false);
  const [rechargeRecipientPhone, setRechargeRecipientPhone] = useState<string>('');
  const [rechargeCountryCode, setRechargeCountryCode] = useState<string>('BD');
  const [rechargeOperator, setRechargeOperator] = useState<string>('Grameenphone (GP)');
  const [rechargeFiatAmount, setRechargeFiatAmount] = useState<number>(50);

  // 200+ Language Search State
  const [languageSearchQuery, setLanguageSearchQuery] = useState<string>('');

  // Subscribe to wallet and admob state updates
  useEffect(() => {
    const unsubWallet = walletEarningsService.subscribe(() => {
      setEarningsWallet(walletEarningsService.getWallet());
      setWalletWithdrawals(walletEarningsService.getWithdrawals());
      setWalletRecharges(walletEarningsService.getRecharges());
    });
    const unsubAdmob = admobService.subscribe(() => {
      setAdmobConfig(admobService.getConfig());
      setAdmobStats(admobService.getStats());
    });
    return () => {
      unsubWallet();
      unsubAdmob();
    };
  }, []);

  // HIGH SECURITY ADMIN GATE (User Requirement: Device zenx 1 & typing token 10051979)
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [adminDevice, setAdminDevice] = useState<string>('zenx 1');
  const [adminTokenInput, setAdminTokenInput] = useState<string>(''); // NEVER PRE-FILLED, MUST BE TYPED
  const [showAdminToken, setShowAdminToken] = useState<boolean>(false);
  const [adminSecurityError, setAdminSecurityError] = useState<string>('');

  // BOOST STUDIO STATE: Video Boost & Pricing Calculator
  const [boostViews, setBoostViews] = useState<number>(5000);
  const [boostLikes, setBoostLikes] = useState<number>(1000);
  const [boostVideoUrl, setBoostVideoUrl] = useState<string>('');
  const [boostDescription, setBoostDescription] = useState<string>('');
  const [boostPaymentMethod, setBoostPaymentMethod] = useState<'bkash' | 'nagad' | 'wallet' | 'mastercard' | 'binance' | 'bank'>('bkash');
  const [boostTrxId, setBoostTrxId] = useState<string>('');
  const [boostSenderPhone, setBoostSenderPhone] = useState<string>('');
  const [boostCampaigns, setBoostCampaigns] = useState<BoostCampaign[]>(() => fetchBoostCampaigns());
  const [selectedReelForBoost, setSelectedReelForBoost] = useState<VideoReel | null>(reels[0] || null);

  // REFERRAL & WALLET STATE (User Requirement: সেটিংসে রেফারেন্স আইডি ও রেফার অপশন, ৪৯৯ টাকা আনলক ও ৬০০ টাকা উইথড্র নোটিশ)
  const [userWallet, setUserWallet] = useState<UserWallet>(() => referralWalletService.getWallet((currentUser as any)?.uid || currentUser?.id));
  const [friendRefCodeInput, setFriendRefCodeInput] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState<'bkash' | 'nagad'>('bkash');
  const [withdrawPhone, setWithdrawPhone] = useState('');

  // Custom International Bank Account Form
  const [showAddCustomBank, setShowAddCustomBank] = useState<boolean>(false);
  const [customBankDetails, setCustomBankDetails] = useState({
    bankName: '',
    accountNumber: '',
    accountHolder: '',
    swiftCode: '',
    country: '',
  });

  // App Settings States with localStorage Persistence
  const [isPrivateAccount, setIsPrivateAccount] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_private_account') === 'true';
    } catch {
      return false;
    }
  });

  const [allowDownloads, setAllowDownloads] = useState<boolean>(() => {
    try {
      const v = localStorage.getItem('tiktok_allow_downloads');
      return v !== null ? v === 'true' : true;
    } catch {
      return true;
    }
  });

  const [isDataSaver, setIsDataSaver] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_data_saver') === 'true';
    } catch {
      return false;
    }
  });

  const [isAutoScroll, setIsAutoScroll] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_auto_scroll') === 'true';
    } catch {
      return false;
    }
  });

  const [isMuteOnOpen, setIsMuteOnOpen] = useState<boolean>(() => {
    try {
      return localStorage.getItem('tiktok_mute_on_open') === 'true';
    } catch {
      return false;
    }
  });

  // Privacy filters
  const [commentPrivacy, setCommentPrivacy] = useState<'everyone' | 'followers' | 'none'>('everyone');
  const [mentionPrivacy, setMentionPrivacy] = useState<'everyone' | 'followers' | 'none'>('everyone');
  const [dmPrivacy, setDmPrivacy] = useState<'everyone' | 'friends' | 'none'>('everyone');
  const [duetPrivacy, setDuetPrivacy] = useState<'everyone' | 'friends' | 'only_me'>('everyone');
  const [followingListPrivacy, setFollowingListPrivacy] = useState<'everyone' | 'only_me'>('everyone');
  const [likedVideosPrivacy, setLikedVideosPrivacy] = useState<'everyone' | 'only_me'>('only_me');
  
  // Viewers history
  const [profileViewHistory, setProfileViewHistory] = useState<boolean>(true);
  const [postViewHistory, setPostViewHistory] = useState<boolean>(true);

  // Audience control
  const [is18PlusRestricted, setIs18PlusRestricted] = useState<boolean>(false);

  // Content preferences
  const [restrictedMode, setRestrictedMode] = useState<boolean>(false);
  const [blockedKeywords, setBlockedKeywords] = useState<string[]>(['spam', 'violence', 'harassment']);
  const [newKeywordInput, setNewKeywordInput] = useState('');

  // Notifications
  const [notifications, setNotifications] = useState({
    push: true,
    likes: true,
    comments: true,
    mentions: true,
    dms: true,
    live: true,
  });

  // Screen time & well-being
  const [screenTimeLimit, setScreenTimeLimit] = useState<number>(60); // 60 mins
  const [breakReminder, setBreakReminder] = useState<boolean>(true);

  // Blocked accounts
  const [blockedUsers, setBlockedUsers] = useState<string[]>([
    '@spambot_99',
    '@troll_account101',
    '@advertising_fake',
  ]);
  const [blockHandleInput, setBlockHandleInput] = useState('');

  // Pinned post IDs
  const [pinnedPostIds, setPinnedPostIds] = useState<string[]>([]);

  // Selected Country
  const [selectedCountry, setSelectedCountry] = useState<CountryItem>(() => {
    try {
      const saved = localStorage.getItem('tiktok_selected_country');
      if (saved) {
        const found = ALL_COUNTRIES.find((c) => c.iso === saved || c.code === saved);
        if (found) return found;
      }
    } catch {}
    return detectSystemCountry();
  });

  const detectedCountry = useMemo(() => detectSystemCountry(), []);

  // Refresh users directory when opening admin panel
  useEffect(() => {
    if (activeSubView === 'admin_panel') {
      setAllUsers(getAllAppUsers());
      setBannedList(fetchBannedUsers());
      setBoostCampaigns(fetchBoostCampaigns());
    }
  }, [activeSubView]);

  const filteredCountries = useMemo(() => {
    if (!countrySearch.trim()) return ALL_COUNTRIES;
    const query = countrySearch.toLowerCase();
    return ALL_COUNTRIES.filter(
      (c) =>
        c.name.toLowerCase().includes(query) ||
        c.code.includes(query) ||
        c.iso.toLowerCase().includes(query) ||
        c.nativeLang.toLowerCase().includes(query)
    );
  }, [countrySearch]);

  const cacheStats = useMemo(() => videoCacheManager.getCacheStats(), [activeSubView]);

  // LIVE CALCULATOR: 1k views = $0.40, 1k likes = $1.00
  const boostViewsCost = (boostViews / 1000) * 0.40;
  const boostLikesCost = (boostLikes / 1000) * 1.00;
  const boostTotalCost = Number((boostViewsCost + boostLikesCost).toFixed(2));
  const boostBdtEquivalent = Math.round(boostTotalCost * 122); // 1 USD ≈ 122 BDT

  // Admin filter users by UID or Name/Handle
  const filteredAdminUsers = useMemo(() => {
    return allUsers.filter((u) => {
      const matchesSearch =
        !adminSearch.trim() ||
        u.name.toLowerCase().includes(adminSearch.toLowerCase()) ||
        u.handle.toLowerCase().includes(adminSearch.toLowerCase()) ||
        u.uid.toLowerCase().includes(adminSearch.toLowerCase());

      if (!matchesSearch) return false;
      if (adminUserFilter === 'active') return !u.isBanned;
      if (adminUserFilter === 'banned') return u.isBanned;
      return true;
    });
  }, [allUsers, adminSearch, adminUserFilter]);

  if (!isOpen) return null;

  const LANGUAGES: { code: AppLanguage; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English (US)' },
    { code: 'bn', label: 'Bengali', native: 'বাংলা (বাংলাদেশ)' },
    { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
    { code: 'ar', label: 'Arabic', native: 'العربية' },
    { code: 'es', label: 'Spanish', native: 'Español' },
    { code: 'pt', label: 'Portuguese', native: 'Português (Brasil)' },
    { code: 'ur', label: 'Urdu', native: 'اردو' },
    { code: 'id', label: 'Indonesian', native: 'Bahasa Indonesia' },
  ];

  // Helper to format title of active subview
  const getSubViewTitle = () => {
    switch (activeSubView) {
      // New Core Features
      case 'admin_gate': return 'Admin Security Verification (zenx 1)';
      case 'admin_panel': return 'Admin: User Ban/Unban & Boosts';
      case 'tiktok_boost': return 'TikTok Boost Studio';
      case 'refer_and_earn': return language === 'bn' ? 'রেফার ও আর্ন (৳৪৯৯ বোনাস)' : 'Refer & Earn (৳499 Bonus)';
      case 'wallet_and_earnings': return 'My Wallet & Earnings';
      case 'fire_live_connect': return 'Fire Live Real-Time Connect';
      // Box 1
      case 'manage_post': return 'Manage Post';
      case 'content_preferences': return 'Content preferences';
      case 'live': return 'LIVE';
      case 'notification': return 'Notification';
      case 'time_wellbeing': return 'Time and well-being';
      case 'family_pairing': return 'Family pairing';
      // Box 2
      case 'account': return 'Account';
      case 'security_permission': return 'Security and permission';
      case 'share_profile': return 'Share profile';
      // Box 3
      case 'private_account': return 'Private account';
      case 'blocked_account': return 'Blocked account';
      // Box 4
      case 'comment': return 'Comment';
      case 'mention': return 'Mention';
      case 'direct_message': return 'Direct message';
      case 'reuse_content': return 'Reuse of content';
      case 'download': return 'Download';
      case 'following_list': return 'Following list';
      case 'liked_videos': return 'Like videos';
      case 'viewers': return 'Viewers';
      case 'audience_control': return 'Audience control';
      case 'playback': return 'Play back';
      case 'display': return 'Display';
      case 'language': return 'Language';
      case 'accessibility': return 'Accessibility';
      case 'contact_location': return 'Contact and location';
      // Box 5
      case 'offline_video': return 'Offline video';
      case 'free_space': return 'Free up space';
      case 'data_saver': return 'Data saver';
      case 'help_center': return 'Help center';
      case 'privacy_center': return 'Privacy center';
      case 'terms_policies': return 'Terms and policies';
      // Special
      case 'countries': return 'All Countries & Region';
      case 'switch_account': return 'Switch account';
      default: return 'Settings and privacy';
    }
  };

  // VERIFY HIGH SECURITY ADMIN ACCESS (zenx 1 phone + 10051979 token)
  const handleVerifyAdminAccess = () => {
    setAdminSecurityError('');
    if (adminDevice !== 'zenx 1') {
      const err = 'Security Mismatch: Only authorized hardware device "zenx 1" can access the Master Admin Authority.';
      setAdminSecurityError(err);
      onToast?.('⛔ ' + err);
      return;
    }
    if (adminTokenInput.trim() !== '10051979') {
      const err = 'Invalid Admin Token! Entry denied. Please enter the valid 8-digit token (10051979).';
      setAdminSecurityError(err);
      onToast?.('⛔ ' + err);
      return;
    }
    // Success
    setIsAdminAuthenticated(true);
    setAdminSecurityError('');
    setActiveSubView('admin_panel');
    onToast?.('🛡️ Access Granted: Master Admin Panel Unlocked on zenx 1');
  };

  const handleLockAdminPanel = () => {
    setIsAdminAuthenticated(false);
    setAdminTokenInput('');
    setActiveSubView(null);
    onToast?.('🔒 Admin Authority Locked.');
  };

  // BAN & UNBAN HANDLERS
  const handleBanAccount = (user: AppDirectoryUser) => {
    banUser(user, 'Violation of community guidelines and policy');
    setAllUsers(getAllAppUsers());
    setBannedList(fetchBannedUsers());
    onToast?.(`⛔ Account @${user.handle} (UID: ${user.uid}) has been BANNED.`);
  };

  const handleUnbanAccount = (user: AppDirectoryUser) => {
    unbanUser(user.id);
    unbanUser(user.handle);
    unbanUser(user.uid);
    setAllUsers(getAllAppUsers());
    setBannedList(fetchBannedUsers());
    onToast?.(`✅ Account @${user.handle} (UID: ${user.uid}) has been UNBANNED.`);
  };

  // SUBMIT BOOST ORDER
  const handleSubmitBoostOrder = () => {
    const targetUrl = boostVideoUrl.trim() || selectedReelForBoost?.videoUrl || (reels[0]?.videoUrl ?? '');
    const targetCaption = selectedReelForBoost?.caption || boostDescription || 'Promoted TikTok Campaign';

    // DIRECT BOOST VIA REFERRAL WALLET BALANCE (৳499)
    if (boostPaymentMethod === 'wallet') {
      const spendRes = referralWalletService.spendBalanceForBoost(
        Math.min(userWallet.balanceBDT, boostBdtEquivalent || 499),
        targetCaption
      );
      if (!spendRes.success) {
        onToast?.(spendRes.message);
        return;
      }
      setUserWallet(spendRes.wallet);

      const walletCampaign: BoostCampaign = {
        id: `boost-${Date.now()}`,
        userId: currentUser?.id || 'usr-self',
        userUid: (currentUser as any)?.uid || '7192849204',
        userName: currentUser?.name || 'TikTok Creator',
        userHandle: currentUser?.handle || 'user',
        userAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        videoUrl: targetUrl,
        videoCaption: targetCaption,
        targetViews: boostViews,
        targetLikes: boostLikes,
        totalCostDollar: boostTotalCost,
        paymentMethod: 'bkash', // internally mapped
        transactionId: `WALLET-REF-${Date.now()}`,
        senderPhone: '01875328569',
        description: boostDescription.trim() || 'Paid with Referral Wallet Balance ৳499',
        createdAt: Date.now(),
        status: 'active',
        deliveredViews: 0,
        deliveredLikes: 0,
        paymentVerified: true,
      };

      saveBoostCampaign(walletCampaign);
      setBoostCampaigns(fetchBoostCampaigns());
      onActivateBoost?.(walletCampaign);
      onToast?.('🎉 ৪৯৯ টাকা রেফারেল ব্যালেন্স দিয়ে ভিডিও সফলভাবে বুস্ট করা হয়েছে! ভিডিওটি সবার ফর ইউ পেজের ১ম সারিতে পাঠানো হয়েছে।');
      return;
    }

    if (!boostTrxId.trim()) {
      onToast?.('⚠️ Please enter the Transaction ID (TrxID) after sending money!');
      return;
    }
    const newCampaign: BoostCampaign = {
      id: `boost-${Date.now()}`,
      userId: currentUser?.id || 'usr-self',
      userUid: (currentUser as any)?.uid || '7192849204',
      userName: currentUser?.name || 'TikTok Creator',
      userHandle: currentUser?.handle || 'user',
      userAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      videoUrl: targetUrl,
      videoCaption: selectedReelForBoost?.caption || boostDescription || 'Promoted TikTok Campaign',
      targetViews: boostViews,
      targetLikes: boostLikes,
      totalCostDollar: boostTotalCost,
      paymentMethod: boostPaymentMethod,
      transactionId: boostTrxId.trim(),
      senderPhone: boostSenderPhone.trim() || '01875328569',
      description: boostDescription.trim(),
      createdAt: Date.now(),
      status: 'pending',
      deliveredViews: 0,
      deliveredLikes: 0,
      paymentVerified: true,
    };

    saveBoostCampaign(newCampaign);
    setBoostCampaigns(fetchBoostCampaigns());
    setBoostTrxId('');
    setBoostSenderPhone('');
    if (isAdminAuthenticated) {
      onToast?.(`🎉 Boost order submitted! (TrxID: ${newCampaign.transactionId})`);
      setActiveSubView('admin_panel');
      setAdminActiveTab('boosts');
    } else {
      onToast?.(`🎉 টাকা পরিশোধ সফল! এডমিনের কাছে বুস্ট অর্ডার মেসেজ পাঠানো হয়েছে (TrxID: ${newCampaign.transactionId})। এডমিন zenx 1 ফোনে কনফার্ম করলেই ভিডিও সবার ফর ইউ পেজে যাবে।`);
    }
  };

  // ADMIN ACTIVATE BOOST ("বুস্ট করুন")
  const handleAdminActivateBoost = (campaign: BoostCampaign) => {
    const deliveredV = Math.max(120, Math.floor(campaign.targetViews * 0.4));
    const deliveredL = Math.max(25, Math.floor(campaign.targetLikes * 0.4));
    updateBoostCampaign(campaign.id, {
      status: 'active',
      deliveredViews: deliveredV,
      deliveredLikes: deliveredL,
    });
    setBoostCampaigns(fetchBoostCampaigns());
    onActivateBoost?.(campaign);
    onToast?.(`🚀 Video Boost ACTIVATED! Delivering ${campaign.targetViews.toLocaleString()} views & ${campaign.targetLikes.toLocaleString()} likes on For You feed.`);
  };

  // ADMIN COMPLETE BOOST TARGET ("টার্গেট পূরণ সম্পন্ন")
  const handleAdminCompleteBoost = (campaign: BoostCampaign) => {
    updateBoostCampaign(campaign.id, {
      status: 'completed',
      deliveredViews: campaign.targetViews,
      deliveredLikes: campaign.targetLikes,
    });
    setBoostCampaigns(fetchBoostCampaigns());
    onToast?.(`✓ Target reached! Campaign completed for @${campaign.userHandle}. Video will now play as normal organic video.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md select-none pointer-events-auto">
      <div className="relative w-full max-w-[490px] h-full sm:h-[94vh] bg-zinc-100 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-4 py-3.5 flex items-center justify-between border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shrink-0">
          <button
            onClick={() => {
              if (activeSubView) setActiveSubView(null);
              else onClose();
            }}
            className="w-8 h-8 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center text-zinc-800 dark:text-zinc-200 cursor-pointer transition-colors active:scale-90"
            title="Back"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.4]" />
          </button>
          
          <h3 className="font-extrabold text-sm sm:text-base text-zinc-900 dark:text-zinc-100 tracking-tight text-center truncate max-w-[280px]">
            {getSubViewTitle()}
          </h3>

          <div className="w-8 flex items-center justify-center">
            {activeSubView && (
              <button
                onClick={() => setActiveSubView(null)}
                className="text-xs font-bold text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
              >
                Done
              </button>
            )}
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SUB-VIEWS SECTION                                             */}
        {/* ------------------------------------------------------------- */}
        {activeSubView !== null ? (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar bg-zinc-50 dark:bg-zinc-950">

            {/* ========================================================= */}
            {/* SUB-VIEW: ADMIN HIGH SECURITY GATE (zenx 1 & 10051979)     */}
            {/* ========================================================= */}
            {activeSubView === 'admin_gate' && (
              <div className="space-y-4">
                {/* Security Shield Banner */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-zinc-900 via-zinc-800 to-rose-950 text-white shadow-xl border border-rose-500/30 relative overflow-hidden">
                  <div className="relative z-10">
                    <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-[#fe2c55] border border-rose-500/40 flex items-center justify-center mb-2.5">
                      <ShieldCheck className="w-7 h-7 stroke-[2.4]" />
                    </div>
                    <span className="text-[10px] font-mono font-black text-rose-400 uppercase tracking-widest block">
                      Restricted Access • Level 4 Security Clearance
                    </span>
                    <h3 className="text-base font-black text-white mt-0.5">
                      Master Administrator Authority Gate
                    </h3>
                    <p className="text-xs text-zinc-300 mt-1 leading-relaxed">
                      Only authorized hardware phone <strong className="text-rose-400 font-mono">zenx 1</strong> with valid Security Token can access user ban/unban controls and boost approvals.
                    </p>
                  </div>
                </div>

                {/* Step 1: Device Verification Check */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4.5 h-4.5 text-[#fe2c55]" />
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Step 1: Authorized Phone Device Check
                      </h4>
                    </div>
                    {adminDevice === 'zenx 1' ? (
                      <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                        MATCHED (zenx 1) ✅
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-500/30">
                        UNAUTHORIZED ⛔
                      </span>
                    )}
                  </div>

                  {/* Device selector / simulation for testing security */}
                  <div>
                    <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                      Active Device Signature:
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setAdminDevice('zenx 1');
                          setAdminSecurityError('');
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          adminDevice === 'zenx 1'
                            ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-300 ring-1 ring-emerald-500/30'
                            : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black">zenx 1</span>
                          {adminDevice === 'zenx 1' && <Check className="w-3.5 h-3.5 text-emerald-500 stroke-[3]" />}
                        </div>
                        <span className="text-[9px] text-zinc-400 block mt-0.5">Admin Hardware (Authorized)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setAdminDevice('Other Mobile');
                          setAdminSecurityError('Access Denied: Only zenx 1 phone can unlock the admin panel.');
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          adminDevice !== 'zenx 1'
                            ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-300 ring-1 ring-rose-500/30'
                            : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black">Other Phone</span>
                          {adminDevice !== 'zenx 1' && <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />}
                        </div>
                        <span className="text-[9px] text-zinc-400 block mt-0.5">Generic Device (Unauthorized)</span>
                      </button>
                    </div>
                  </div>

                  {adminDevice !== 'zenx 1' && (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-[11px] text-rose-700 dark:text-rose-300 font-medium">
                      ⛔ Access blocked: Only the administrator's designated <strong>zenx 1</strong> hardware device can proceed to the token verification stage.
                    </div>
                  )}
                </div>

                {/* Step 2: Token Verification (MUST BE MANUALLY TYPED: 10051979) */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4.5 h-4.5 text-[#fe2c55]" />
                    <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                      Step 2: Enter Master Admin Token
                    </h4>
                  </div>

                  <p className="text-[11px] text-zinc-500">
                    Type your 8-digit secret security token manually to authenticate. This token is never pre-filled for maximum security.
                  </p>

                  <div className="relative">
                    <input
                      type={showAdminToken ? 'text' : 'password'}
                      value={adminTokenInput}
                      onChange={(e) => {
                        setAdminTokenInput(e.target.value);
                        setAdminSecurityError('');
                      }}
                      placeholder="Type 8-digit token (e.g. 10051979)..."
                      className="w-full px-3.5 py-3 pr-10 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm font-mono font-black text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-[#fe2c55] tracking-widest placeholder:tracking-normal placeholder:font-sans placeholder:font-normal placeholder:text-zinc-400"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminToken(!showAdminToken)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                    >
                      {showAdminToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {adminSecurityError && (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-600 dark:text-rose-400 font-bold flex items-center gap-2">
                      <AlertOctagon className="w-4 h-4 shrink-0" />
                      <span>{adminSecurityError}</span>
                    </div>
                  )}

                  {/* Unlock Button */}
                  <button
                    type="button"
                    onClick={handleVerifyAdminAccess}
                    disabled={!adminTokenInput.trim()}
                    className={`w-full py-3 rounded-xl font-black text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      adminTokenInput.trim()
                        ? 'bg-[#fe2c55] hover:bg-[#e0264a] text-white active:scale-95'
                        : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Verify Device & Unlock Admin Panel</span>
                  </button>
                </div>

                {/* Security Note */}
                <div className="p-3 bg-zinc-100 dark:bg-zinc-800/40 rounded-xl text-center text-[10px] text-zinc-400 space-y-0.5">
                  <p>Authorized Admin Line: 01875328569</p>
                  <p>Required Token: 10051979 • Hardware: zenx 1</p>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* SUB-VIEW: TIKTOK BOOST STUDIO (ভিডিও বুস্ট ও ক্যালকুলেটর) */}
            {/* ========================================================= */}
            {activeSubView === 'tiktok_boost' && (
              <div className="space-y-4">
                {/* Hero Banner */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-500 via-[#fe2c55] to-amber-500 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10">
                    <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-rose-100 mb-1">
                      <Rocket className="w-3.5 h-3.5 fill-current" />
                      <span>TikTok Promote & For You Boost</span>
                    </div>
                    <h4 className="text-base font-black">Boost Video to Millions</h4>
                    <p className="text-xs text-rose-100 mt-0.5">
                      Promote personal videos or business advertisements directly into the TikTok For You feed.
                    </p>
                  </div>
                  <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none" />
                </div>

                {/* Rate Card Rules: 1k views = $0.40, 1k likes = $1.00 */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="p-3 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Views Pricing</span>
                    <span className="text-sm font-black text-[#fe2c55] block mt-0.5">1k Views = $0.40</span>
                    <span className="text-[10px] text-zinc-500">≈ ৳49 BDT per 1,000 views</span>
                  </div>
                  <div className="p-3 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Likes Pricing</span>
                    <span className="text-sm font-black text-rose-600 block mt-0.5">1k Likes = $1.00</span>
                    <span className="text-[10px] text-zinc-500">≈ ৳122 BDT per 1,000 likes</span>
                  </div>
                </div>

                {/* Interactive Live Calculator */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                  <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                    <div className="flex items-center gap-2">
                      <Calculator className="w-4 h-4 text-[#fe2c55]" />
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Boost Cost Calculator
                      </h4>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-full">
                      Auto Updated
                    </span>
                  </div>

                  {/* Views Control with Custom Typing */}
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                      <span className="text-zinc-800 dark:text-zinc-200">Target Views Count:</span>
                      <span className="text-[#fe2c55] font-black">{boostViews.toLocaleString()} Views (${boostViewsCost.toFixed(2)})</span>
                    </div>

                    {/* Direct typing input box for views */}
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex-1">
                        <label className="text-[10px] font-bold text-zinc-500 block mb-1">
                          Type Custom Views (e.g. 1000, 50000, 10000000 for ১ কোটি):
                        </label>
                        <input
                          type="number"
                          min={1000}
                          step={1000}
                          value={boostViews}
                          onChange={(e) => setBoostViews(Math.max(1000, Number(e.target.value) || 1000))}
                          className="w-full px-3 py-1.5 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono font-bold text-[#fe2c55] focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                        />
                      </div>
                      <div className="pt-4 text-right shrink-0">
                        <span className="text-xs font-mono font-black text-[#fe2c55] block">
                          ${boostViewsCost.toFixed(2)} USD
                        </span>
                        <span className="text-[9px] text-zinc-400">
                          ≈ ৳{Math.round(boostViewsCost * 122)} BDT
                        </span>
                      </div>
                    </div>

                    <input
                      type="range"
                      min={1000}
                      max={1000000}
                      step={1000}
                      value={Math.min(1000000, boostViews)}
                      onChange={(e) => setBoostViews(Number(e.target.value))}
                      className="w-full accent-[#fe2c55] cursor-pointer"
                    />
                    <div className="flex gap-1.5 mt-2 overflow-x-auto no-scrollbar py-0.5">
                      {[1000, 5000, 10000, 50000, 100000, 1000000, 10000000].map((v) => (
                        <button
                          key={v}
                          type="button"
                          onClick={() => setBoostViews(v)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-black shrink-0 transition-colors cursor-pointer ${
                            boostViews === v
                              ? 'bg-[#fe2c55] text-white'
                              : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
                          }`}
                        >
                          {v >= 10000000 ? '10M (১ কোটি)' : v >= 1000000 ? '1M (১০ লাখ)' : `${v / 1000}K`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Likes Control with Custom Typing */}
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                      <span className="text-zinc-800 dark:text-zinc-200">Target Likes Count:</span>
                      <span className="text-rose-600 font-black">{boostLikes.toLocaleString()} Likes (${boostLikesCost.toFixed(2)})</span>
                    </div>

                    {/* Direct typing input box for likes */}
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex-1">
                        <label className="text-[10px] font-bold text-zinc-500 block mb-1">
                          Type Custom Likes (e.g. 500, 2500, 50000):
                        </label>
                        <input
                          type="number"
                          min={0}
                          step={100}
                          value={boostLikes}
                          onChange={(e) => setBoostLikes(Math.max(0, Number(e.target.value) || 0))}
                          className="w-full px-3 py-1.5 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono font-bold text-rose-600 focus:outline-none focus:ring-1 focus:ring-rose-500"
                        />
                      </div>
                      <div className="pt-4 text-right shrink-0">
                        <span className="text-xs font-mono font-black text-rose-600 block">
                          ${boostLikesCost.toFixed(2)} USD
                        </span>
                        <span className="text-[9px] text-zinc-400">
                          ≈ ৳{Math.round(boostLikesCost * 122)} BDT
                        </span>
                      </div>
                    </div>

                    <input
                      type="range"
                      min={0}
                      max={50000}
                      step={500}
                      value={Math.min(50000, boostLikes)}
                      onChange={(e) => setBoostLikes(Number(e.target.value))}
                      className="w-full accent-rose-500 cursor-pointer"
                    />
                    <div className="flex gap-1.5 mt-2 overflow-x-auto no-scrollbar py-0.5">
                      {[0, 500, 1000, 2500, 5000, 10000, 50000].map((l) => (
                        <button
                          key={l}
                          type="button"
                          onClick={() => setBoostLikes(l)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-black shrink-0 transition-colors cursor-pointer ${
                            boostLikes === l
                              ? 'bg-rose-500 text-white'
                              : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
                          }`}
                        >
                          {l === 0 ? '0 Likes' : `${l >= 1000 ? `${l / 1000}K` : l} Likes`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Total Calculated Banner */}
                  <div className="p-3 bg-rose-50/80 dark:bg-rose-950/30 rounded-xl border border-rose-200 dark:border-rose-900 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider block">Total Estimated Amount</span>
                      <span className="text-xl font-black text-[#fe2c55] font-mono">${boostTotalCost.toFixed(2)} USD</span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 font-mono">≈ ৳{boostBdtEquivalent} BDT</span>
                      <span className="text-[10px] text-zinc-400 block">Rate: $1 = 122 BDT</span>
                    </div>
                  </div>
                </div>

                {/* Target Video Link & Description */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                    Target Video & Campaign Details
                  </h4>

                  {/* Pick from current reels */}
                  {reels.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-zinc-500 block mb-1.5">Select from your uploaded reels:</span>
                      <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
                        {reels.map((reel) => {
                          const isSelected = selectedReelForBoost?.id === reel.id;
                          return (
                            <div
                              key={reel.id}
                              onClick={() => {
                                setSelectedReelForBoost(reel);
                                setBoostVideoUrl(reel.videoUrl);
                              }}
                              className={`w-18 h-24 rounded-xl overflow-hidden shrink-0 border-2 cursor-pointer relative transition-all ${
                                isSelected ? 'border-[#fe2c55] ring-2 ring-[#fe2c55]/30' : 'border-zinc-200 dark:border-zinc-700 opacity-80'
                              }`}
                            >
                              <img
                                src={reel.thumbnailUrl || reel.posterUrl || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=200'}
                                alt=""
                                className="w-full h-full object-cover"
                              />
                              {isSelected && (
                                <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#fe2c55] text-white flex items-center justify-center">
                                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400">
                        ভিডিও লিংক (Paste Copied Video Link):
                      </label>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const text = await navigator.clipboard.readText();
                            if (text) {
                              setBoostVideoUrl(text);
                              onToast?.('📋 লিংক পেস্ট করা হয়েছে!');
                            }
                          } catch {
                            // Fallback if permission blocked
                            if (reels[0]?.videoUrl) {
                              setBoostVideoUrl(reels[0].videoUrl);
                              onToast?.('📋 প্রথম ভিডিওর লিংক পেস্ট করা হয়েছে!');
                            }
                          }
                        }}
                        className="text-[10px] font-bold text-[#fe2c55] hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3 h-3" />
                        <span>পেস্ট করুন (Paste)</span>
                      </button>
                    </div>
                    <input
                      type="text"
                      value={boostVideoUrl}
                      onChange={(e) => setBoostVideoUrl(e.target.value)}
                      placeholder="কপি লিংক এখানে পেস্ট করুন (e.g. https://tiktok.app/video/reel-12345)"
                      className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                      Campaign Description / Business Goal:
                    </label>
                    <textarea
                      rows={2}
                      value={boostDescription}
                      onChange={(e) => setBoostDescription(e.target.value)}
                      placeholder="e.g. Promote new fashion boutique / reach 10K music fans on For You page"
                      className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55] resize-none"
                    />
                  </div>
                </div>

                {/* Payment Methods: bKash, Nagad, Mastercard, Binance, Bank */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                    Select Payment Method
                  </h4>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'wallet', name: 'রেফারেল ওয়ালেট (৳499)', badge: '⚡ ইনস্ট্যান্ট ফ্রি বুস্ট', isFrozen: false },
                      { id: 'bkash', name: 'bKash (বিকাশ)', badge: 'সক্রিয় (Active)', isFrozen: false },
                      { id: 'nagad', name: 'Nagad (নগদ)', badge: 'সক্রিয় (Active)', isFrozen: false },
                      { id: 'mastercard', name: 'Mastercard / Visa', badge: '❄️ ফ্রিজ (Frozen)', isFrozen: true },
                      { id: 'binance', name: 'Binance Pay', badge: '❄️ ফ্রিজ (Frozen)', isFrozen: true },
                      { id: 'bank', name: 'Local Bank Wire', badge: '❄️ ফ্রিজ (Frozen)', isFrozen: true },
                    ].map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          if (m.isFrozen) {
                            onToast?.('❄️ এই পেমেন্ট মেথডটি সাময়িকভাবে ফ্রিজ রয়েছে। অনুগ্রহ করে বিকাশ (bKash) বা নগদ (Nagad) ব্যবহার করুন।');
                            return;
                          }
                          setBoostPaymentMethod(m.id as any);
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          m.isFrozen
                            ? 'border-zinc-200 dark:border-zinc-800 bg-zinc-100/60 dark:bg-zinc-800/40 text-zinc-400 opacity-60'
                            : boostPaymentMethod === m.id
                            ? 'border-[#fe2c55] bg-rose-50/50 dark:bg-rose-950/20 text-[#fe2c55] ring-1 ring-[#fe2c55]/30'
                            : 'border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
                        }`}
                      >
                        <span className={`text-[9px] font-black uppercase block ${m.isFrozen ? 'text-sky-400' : 'text-emerald-500'}`}>
                          {m.badge}
                        </span>
                        <span className="text-xs font-black block mt-0.5">{m.name}</span>
                      </button>
                    ))}
                  </div>

                  {/* Wallet payment instructions */}
                  {boostPaymentMethod === 'wallet' && (
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-500/40 space-y-1.5 animate-in fade-in">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-emerald-700 dark:text-emerald-300">
                          রেফারেল ওয়ালেট ব্যালেন্স: ৳{userWallet.balanceBDT}.00
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500 text-white">
                          ৳৪৯৯ আনলকড
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-600 dark:text-zinc-300 leading-relaxed">
                        কোনো TrxID প্রয়োজন নেই! নিচের 'কনফার্ম ও বুস্ট চালু করুন' বাটনে ক্লিক করলেই আপনার রেফারেল ব্যালেন্স থেকে সরাসরি ভিডিও বুস্ট হয়ে সবার ফর ইউ পেজে ৪-টিয়ার অ্যালগরিদমে পৌঁছে যাবে।
                      </p>
                    </div>
                  )}

                  {/* Admin Payment Instructions with user's number: 01875328569 */}
                  <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-xl border border-zinc-200 dark:border-zinc-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                        Admin Payment Details ({boostPaymentMethod.toUpperCase()})
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        Verified Receiver
                      </span>
                    </div>

                    {(boostPaymentMethod === 'bkash' || boostPaymentMethod === 'nagad') && (
                      <div className="p-2.5 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-700 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-zinc-400 block">Send Money Personal Number:</span>
                          <span className="text-sm font-mono font-black text-[#fe2c55]">01875328569</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            try {
                              navigator.clipboard?.writeText('01875328569');
                              onToast?.('✓ Copied: 01875328569');
                            } catch {}
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-zinc-200"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </button>
                      </div>
                    )}

                    {boostPaymentMethod === 'binance' && (
                      <div className="p-2.5 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-700">
                        <span className="text-[10px] text-zinc-400 block">Binance Pay ID (USDT):</span>
                        <span className="text-sm font-mono font-black text-amber-500">875328569</span>
                      </div>
                    )}

                    {boostPaymentMethod === 'bank' && (
                      <div className="space-y-2">
                        <div className="p-2.5 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-700 text-xs space-y-0.5">
                          <span className="text-[10px] text-zinc-400 block font-bold uppercase">Official TikTok Bank Account:</span>
                          <p className="font-bold text-zinc-800 dark:text-zinc-200">Standard Chartered / City Bank</p>
                          <p className="font-mono text-zinc-500">A/C: 2109875328569 (Swift: SCBLBDDX)</p>
                        </div>

                        {/* International Bank Options for Other Countries */}
                        <div className="p-2.5 bg-zinc-100 dark:bg-zinc-800/80 rounded-lg border border-zinc-200 dark:border-zinc-700 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-zinc-700 dark:text-zinc-300">
                              অন্যান্য দেশের জন্য নিজস্ব ব্যাংক যুক্ত করার অপশন:
                            </span>
                            <button
                              type="button"
                              onClick={() => setShowAddCustomBank(!showAddCustomBank)}
                              className="text-[10px] font-black text-[#fe2c55] hover:underline cursor-pointer"
                            >
                              {showAddCustomBank ? 'Cancel' : '+ Add Bank Account'}
                            </button>
                          </div>

                          {showAddCustomBank && (
                            <div className="mt-2 pt-2 border-t border-zinc-200 dark:border-zinc-700 space-y-1.5">
                              <div>
                                <label className="text-[9px] text-zinc-500 block">Bank Name & Country:</label>
                                <input
                                  type="text"
                                  value={customBankDetails.bankName}
                                  onChange={(e) => setCustomBankDetails({ ...customBankDetails, bankName: e.target.value })}
                                  placeholder="e.g. Chase Bank, USA or HDFC, India"
                                  className="w-full px-2 py-1 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-md text-[11px] text-zinc-900 dark:text-zinc-100"
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-1.5">
                                <div>
                                  <label className="text-[9px] text-zinc-500 block">Account Number:</label>
                                  <input
                                    type="text"
                                    value={customBankDetails.accountNumber}
                                    onChange={(e) => setCustomBankDetails({ ...customBankDetails, accountNumber: e.target.value })}
                                    placeholder="Account Number"
                                    className="w-full px-2 py-1 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-md text-[11px] text-zinc-900 dark:text-zinc-100"
                                  />
                                </div>
                                <div>
                                  <label className="text-[9px] text-zinc-500 block">SWIFT / Routing / IBAN:</label>
                                  <input
                                    type="text"
                                    value={customBankDetails.swiftCode}
                                    onChange={(e) => setCustomBankDetails({ ...customBankDetails, swiftCode: e.target.value })}
                                    placeholder="SWIFT / Routing"
                                    className="w-full px-2 py-1 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-md text-[11px] text-zinc-900 dark:text-zinc-100"
                                  />
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  if (customBankDetails.bankName && customBankDetails.accountNumber) {
                                    onToast?.(`✓ Custom bank for ${customBankDetails.bankName} saved!`);
                                    setShowAddCustomBank(false);
                                  } else {
                                    onToast?.('⚠️ Please enter Bank Name and Account Number');
                                  }
                                }}
                                className="w-full py-1.5 rounded-lg bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 font-bold text-[10px] cursor-pointer mt-1"
                              >
                                Connect International Bank
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {boostPaymentMethod === 'mastercard' && (
                      <div className="p-2.5 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-700 text-xs">
                        <span className="text-[10px] text-zinc-400 block">Card Payment Gateway:</span>
                        <p className="font-bold text-zinc-800 dark:text-zinc-200">Visa / Mastercard 3D Secure active</p>
                      </div>
                    )}

                    <p className="text-[10px] text-zinc-500 italic">
                      Step: Send money ৳{boostBdtEquivalent} (${boostTotalCost}) to 01875328569, then enter the Transaction ID (TrxID) below.
                    </p>
                  </div>

                  {/* Transaction ID input field */}
                  <div className="space-y-2 pt-1">
                    <div>
                      <label className="text-[11px] font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                        Transaction ID (TrxID) from Payment Provider *
                      </label>
                      <input
                        type="text"
                        value={boostTrxId}
                        onChange={(e) => setBoostTrxId(e.target.value)}
                        placeholder="e.g. 9K7X8P2L or TRX-9823412"
                        className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono font-bold text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                        Your Sender Phone Number / Account:
                      </label>
                      <input
                        type="text"
                        value={boostSenderPhone}
                        onChange={(e) => setBoostSenderPhone(e.target.value)}
                        placeholder="e.g. 01700123456"
                        className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                      />
                    </div>
                  </div>

                  {/* Submit Order Button */}
                  <button
                    type="button"
                    onClick={handleSubmitBoostOrder}
                    className="w-full py-3 rounded-xl bg-[#fe2c55] hover:bg-[#e0264a] text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                  >
                    <Rocket className="w-4 h-4" />
                    <span>
                      {boostPaymentMethod === 'wallet'
                        ? `রেফারেল ব্যালেন্স দিয়ে বুস্ট করুন (৳${Math.min(userWallet.balanceBDT, boostBdtEquivalent || 499)} কাটা হবে)`
                        : `Submit Boost Order (${boostTotalCost} USD / ৳${boostBdtEquivalent})`}
                    </span>
                  </button>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* SUB-VIEW: REFER & EARN ৳499 (User Requirement)           */}
            {/* ========================================================= */}
            {activeSubView === 'refer_and_earn' && (
              <div className="space-y-4">
                {/* 1. Wallet Balance Hero Banner */}
                <div className="p-4 rounded-3xl bg-gradient-to-br from-amber-500 via-rose-600 to-indigo-700 text-white shadow-xl relative overflow-hidden">
                  <div className="relative z-10">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/30 backdrop-blur-md text-[10px] font-black uppercase tracking-wider text-amber-200">
                        <Coins className="w-3.5 h-3.5 text-amber-300" />
                        <span>Referral & Rewards</span>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-400 text-black text-[10px] font-black uppercase">
                        {userWallet.hasClaimedWelcomeBonus ? '৳৪৯৯ আনলকড ✓' : 'আনলক করুন'}
                      </span>
                    </div>

                    <div className="mt-3">
                      <span className="text-[11px] text-zinc-200 block">বর্তমান রেফারেল ওয়ালেট ব্যালেন্স:</span>
                      <div className="flex items-baseline gap-2 mt-0.5">
                        <span className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white drop-shadow-md">
                          ৳{userWallet.balanceBDT}.00
                        </span>
                        <span className="text-xs text-amber-200 font-bold">BDT (টাকা)</span>
                      </div>
                    </div>

                    <p className="text-xs text-zinc-100 mt-2 leading-relaxed">
                      {language === 'bn' 
                        ? 'আপনার রেফারেল লিংক শেয়ার করে প্রতি রেফারে ৪৯৯ টাকা পর্যন্ত বোনাস আয় করুন।' 
                        : 'Share your personal referral link and unlock ৳499 bonus per referral.'}
                    </p>
                  </div>
                  <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/15 rounded-full blur-2xl pointer-events-none" />
                </div>

                {/* 2. CRITICAL USER REQUIREMENTS NOTICE BANNER */}
                {/* (User Request: এই টাকা যখন আনলক হবে তখন নিচে লেখা আসবে 600 টাকা উইথড্র করতে পারবেন হলে এবং এই টাকা দিয়ে ভিডিও বুস্ট করতে পারবে) */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-cyan-500/15 border-2 border-amber-500/40 dark:border-amber-500/30 shadow-md space-y-2.5">
                  <div className="flex items-start gap-2.5">
                    <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                        {language === 'bn' ? 'উইথড্র ও ভিডিও বুস্ট নীতিমালা:' : 'Withdrawal & Video Boost Terms:'}
                      </h4>
                      <p className="text-xs text-zinc-700 dark:text-zinc-300 font-medium leading-relaxed">
                        <strong className="text-amber-600 dark:text-amber-400">⚠️ ন্যূনতম ৬০০ টাকা (৳৬০০) ব্যালেন্স</strong> হলে আপনি নগদ বা বিকাশ একাউন্টে টাকা উইথড্র করতে পারবেন (বাকি ১০১ টাকা রেফার করে পূরণ করুন)।
                      </p>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Rocket className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span className="text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
                        {language === 'bn' 
                          ? '🚀 এই সম্পূর্ণ ৪৯৯ টাকা দিয়ে এখনই সরাসরি ভিডিও বুস্ট করতে পারবেন!' 
                          : '🚀 You can use this full ৳499 to Boost any video right now!'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setBoostPaymentMethod('wallet');
                        setActiveSubView('tiktok_boost');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-black text-xs shadow-md shrink-0 cursor-pointer active:scale-95 transition-all"
                    >
                      {language === 'bn' ? 'বুস্ট করুন' : 'Boost Now'}
                    </button>
                  </div>
                </div>

                {/* 3. Referral Link & Code Box */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
                    <Gift className="w-4 h-4 text-[#fe2c55]" />
                    <span>{language === 'bn' ? 'আপনার রেফারেল আইডি ও লিংক' : 'Your Referral ID & Link'}</span>
                  </h4>

                  {/* Code */}
                  <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-zinc-400 block font-medium">রেফারেল কোড (Referral Code):</span>
                      <span className="text-sm font-mono font-black text-zinc-900 dark:text-white">
                        {userWallet.referralCode}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(userWallet.referralCode);
                        onToast?.(`✓ রেফারেল কোড কপি হয়েছে: ${userWallet.referralCode}`);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-zinc-300"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </button>
                  </div>

                  {/* Link */}
                  <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between">
                    <div className="truncate mr-2">
                      <span className="text-[10px] text-zinc-400 block font-medium">রেফারেল লিংক (Referral Link):</span>
                      <span className="text-xs font-mono text-[#fe2c55] font-bold truncate block">
                        {userWallet.referralLink}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard?.writeText(userWallet.referralLink);
                          onToast?.('✓ রেফারেল লিংক কপি হয়েছে! বন্ধুদের মাঝে শেয়ার করুন');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#fe2c55] text-white text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-[#e0264a]"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Link</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (navigator.share) {
                            navigator.share({
                              title: 'TikTok Live Pro',
                              text: `আমার রেফারেল লিংকে ক্লিক করে একাউন্ট খুললেই পাবেন ৪৯৯ টাকা ফ্রি ভিডিও বুস্ট বোনাস! কোড: ${userWallet.referralCode}`,
                              url: userWallet.referralLink,
                            }).catch(() => {});
                          } else {
                            navigator.clipboard?.writeText(userWallet.referralLink);
                            onToast?.('✓ লিংক কপি হয়েছে!');
                          }
                        }}
                        className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-800 dark:text-zinc-200 cursor-pointer hover:bg-zinc-300"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* 4. Withdraw Section (Bkash / Nagad) */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
                      <Wallet className="w-4 h-4 text-emerald-500" />
                      <span>{language === 'bn' ? 'নগদ / বিকাশ উইথড্র' : 'Withdrawal to bKash / Nagad'}</span>
                    </h4>
                    <span className="text-[10px] font-bold text-zinc-400">ন্যূনতম: ৳৬০০</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setWithdrawMethod('bkash')}
                      className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        withdrawMethod === 'bkash'
                          ? 'border-[#fe2c55] bg-rose-50/50 dark:bg-rose-950/20 text-[#fe2c55] ring-1 ring-[#fe2c55]'
                          : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                      }`}
                    >
                      bKash (বিকাশ)
                    </button>
                    <button
                      type="button"
                      onClick={() => setWithdrawMethod('nagad')}
                      className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        withdrawMethod === 'nagad'
                          ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 text-amber-600 ring-1 ring-amber-500'
                          : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                      }`}
                    >
                      Nagad (নগদ)
                    </button>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-zinc-500 block mb-1">
                      আপনার {withdrawMethod === 'bkash' ? 'বিকাশ' : 'নগদ'} পার্সোনাল মোবাইল নম্বর:
                    </label>
                    <input
                      type="text"
                      value={withdrawPhone}
                      onChange={(e) => setWithdrawPhone(e.target.value)}
                      placeholder="e.g. 017XXXXXXXX"
                      className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (!withdrawPhone.trim()) {
                        onToast?.('⚠️ অনুগ্রহ করে উইথড্রর জন্য মোবাইল নম্বর দিন!');
                        return;
                      }
                      const res = referralWalletService.requestWithdrawal(600, withdrawMethod, withdrawPhone.trim());
                      setUserWallet(res.wallet);
                      onToast?.(res.message);
                    }}
                    className="w-full py-2.5 rounded-xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 font-extrabold text-xs shadow-md cursor-pointer hover:opacity-90 active:scale-95 transition-all"
                  >
                    {language === 'bn' ? 'উইথড্র রিকোয়েস্ট পাঠান (ন্যূনতম ৳৬০০)' : 'Submit Withdrawal Request (Min ৳600)'}
                  </button>
                </div>

                {/* 5. Claim with Referral Code */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-2">
                  <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
                    বন্ধুর রেফারেল কোড দিন (Enter Friend's Referral Code):
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={friendRefCodeInput}
                      onChange={(e) => setFriendRefCodeInput(e.target.value)}
                      placeholder="e.g. TK-7192849204"
                      className="flex-1 px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!friendRefCodeInput.trim()) return;
                        const res = referralWalletService.claimReferralBonus(friendRefCodeInput.trim());
                        setUserWallet(res.wallet);
                        onToast?.(res.message);
                        setFriendRefCodeInput('');
                      }}
                      className="px-4 py-2 rounded-xl bg-[#fe2c55] text-white font-black text-xs cursor-pointer hover:bg-[#e0264a]"
                    >
                      ক্লেইম করুন
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* SUB-VIEW: MY WALLET & EARNINGS (USER REQUIREMENT)         */}
            {/* ========================================================= */}
            {activeSubView === 'wallet_and_earnings' && (
              <div className="space-y-4">
                {/* 1. Golden Digital Card (কয়েন ও টাকা ভিউ - সোনালী রঙের ডিজিটাল কার্ড) */}
                <div className="p-5 rounded-3xl bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 text-zinc-950 shadow-2xl relative overflow-hidden border border-yellow-200/60">
                  {/* Subtle Metallic Circuit Lines & Gloss Sheen */}
                  <div className="absolute top-0 right-0 w-44 h-44 bg-white/25 rounded-full blur-2xl -mr-12 -mt-12 pointer-events-none" />
                  <div className="absolute bottom-0 left-0 w-36 h-36 bg-amber-700/20 rounded-full blur-xl -ml-8 -mb-8 pointer-events-none" />
                  
                  <div className="relative z-10 flex flex-col justify-between h-full space-y-4">
                    {/* Card Top Row: Brand & EMV Chip */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-7 rounded-md bg-gradient-to-br from-amber-200 to-amber-500 border border-amber-600/60 shadow-xs flex items-center justify-center">
                          {/* EMV Microchip lines */}
                          <div className="w-5 h-4 border border-amber-800/40 rounded-xs grid grid-cols-2 gap-0.5 p-0.5">
                            <div className="bg-amber-900/30 rounded-xs" />
                            <div className="bg-amber-900/30 rounded-xs" />
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-[11px] font-black uppercase tracking-wider text-amber-950">
                          <Crown className="w-3.5 h-3.5 fill-current" />
                          <span>TikTok Gold Rewards</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded-full bg-zinc-950/15 text-zinc-950 border border-zinc-950/20 uppercase tracking-widest">
                          ZERO-TRUST HMAC
                        </span>
                      </div>
                    </div>

                    {/* Card Middle: TOTAL WALLET COINS IN LARGE BOLD TYPOGRAPHY */}
                    <div className="pt-1">
                      <span className="text-[11px] font-bold text-amber-950/80 uppercase tracking-wider block">
                        Total Wallet Balance
                      </span>
                      <div className="flex items-baseline gap-2 mt-0.5">
                        <h2 className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-zinc-950 drop-shadow-xs">
                          {earningsWallet.totalCoins.toLocaleString()}
                        </h2>
                        <span className="text-sm font-black uppercase tracking-wider text-amber-950">
                          COINS
                        </span>
                      </div>
                      
                      {/* 1,000 Coins = 20% Return Rule (ইউজার রিকোয়ারমেন্ট: প্রতি ১০০০ কয়েন থেকে ২০ পারসেন্ট টাকা পাবে) */}
                      <div className="mt-1.5 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-950/20 text-zinc-950 border border-zinc-950/25 text-[10px] font-black">
                        <Coins className="w-3.5 h-3.5 text-amber-950 fill-current" />
                        <span>Ad Revenue Share: 1,000 Coins = 20% Cash Return (২০% রির্টান)</span>
                      </div>
                    </div>

                    {/* Card Bottom Row: Security Badge & Quick Sync */}
                    <div className="flex items-center justify-between pt-1 border-t border-amber-900/15 text-[11px] font-bold text-amber-950/90">
                      <div className="flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-800 fill-current" />
                        <span>Military-Grade Anti-Fraud Guard Active</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSecurityReport(securityArchitectureService.runIntegrityAudit());
                          onToast?.('✓ HMAC-SHA256 ephemeral integrity verified. Wallet in sync.');
                        }}
                        className="p-1 rounded-full bg-zinc-950/10 hover:bg-zinc-950/20 transition-colors cursor-pointer"
                        title="Verify Signature"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-zinc-950" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. Live Local Currency Converter (ঠিক নিচেই ছোট করে সবুজ রঙে তার দেশের টাকায় লাইভ ভিউ) */}
                <div className="bg-emerald-500/10 dark:bg-emerald-950/40 border border-emerald-500/30 rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      <span className="text-[11px] font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                        Live Local Currency Value
                      </span>
                    </div>
                    <div className="flex items-baseline gap-1.5 mt-0.5">
                      <span className="text-xl sm:text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                        {walletEarningsService.convertCoinsToFiat(earningsWallet.totalCoins, earningsWallet.selectedCurrencyCode).formatted}
                      </span>
                    </div>
                    <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block mt-0.5">
                      Real-time live exchange rate • 100 Coins = ৳1.00 BDT or $0.009 USD
                    </span>
                  </div>

                  {/* Currency Selector Pill */}
                  <div className="flex flex-col items-end gap-1">
                    <span className="text-[9px] font-bold text-zinc-400 uppercase">Change Currency:</span>
                    <select
                      value={earningsWallet.selectedCurrencyCode}
                      onChange={(e) => {
                        walletEarningsService.setCurrency(e.target.value);
                        onToast?.(`Currency switched to ${e.target.value}`);
                      }}
                      className="px-2.5 py-1.5 bg-white dark:bg-zinc-800 border border-emerald-500/40 rounded-xl text-xs font-black font-mono text-emerald-700 dark:text-emerald-300 focus:outline-none cursor-pointer shadow-xs"
                    >
                      <option value="BDT">🇧🇩 BDT (৳)</option>
                      <option value="USD">🇺🇸 USD ($)</option>
                      <option value="INR">🇮🇳 INR (₹)</option>
                      <option value="EUR">🇪🇺 EUR (€)</option>
                      <option value="SAR">🇸🇦 SAR (SR)</option>
                      <option value="AED">🇦🇪 AED</option>
                      <option value="GBP">🇬🇧 GBP (£)</option>
                      <option value="PKR">🇵🇰 PKR (₨)</option>
                      <option value="MYR">🇲🇾 MYR (RM)</option>
                      <option value="SGD">🇸🇬 SGD (S$)</option>
                    </select>
                  </div>
                </div>

                {/* 3. Action Buttons: Withdraw & Mobile Recharge */}
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setShowWithdrawModal(true)}
                    className="p-3.5 rounded-2xl bg-[#fe2c55] hover:bg-[#e0264a] text-white shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 group"
                  >
                    <CreditCard className="w-4 h-4 stroke-[2.5]" />
                    <div className="text-left">
                      <span className="text-xs font-black block leading-tight">
                        Withdraw Funds
                      </span>
                      <span className="text-[10px] text-rose-100 opacity-90 block">
                        Binance, bKash, Bank
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowRechargeModal(true)}
                    className="p-3.5 rounded-2xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 group"
                  >
                    <Smartphone className="w-4 h-4 stroke-[2.5]" />
                    <div className="text-left">
                      <span className="text-xs font-black block leading-tight">
                        Mobile Recharge
                      </span>
                      <span className="text-[10px] text-zinc-400 dark:text-zinc-600 block">
                        Worldwide Operators
                      </span>
                    </div>
                  </button>
                </div>

                {/* 4. Daily Earnings Breakdown (আজ সারাদিনে কোন কাজ করে কত আয় করেছে) */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-[#fe2c55]" />
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Today's Work & Activity Breakdown
                      </h4>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-zinc-400">
                      Live 24h Summary
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {/* Item 0: Steem Unlimited Rewarded Video Ads (User Requirement: স্টিম পেজ আনলিমিটেড এড এবং প্রতি এডে ৫ কয়েন) */}
                    <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-indigo-500/10 border border-amber-500/30 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                          <Coins className="w-4.5 h-4.5 fill-current" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                              • Steem Rewarded Ads
                            </span>
                            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold">
                              +5 Coins Each
                            </span>
                          </div>
                          <span className="text-[9px] text-zinc-500 dark:text-zinc-400 font-mono block">
                            ID: {OFFICIAL_ADMOB_CONFIG.unlimitedRewardedAdId}
                          </span>
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {admobStats.rewardedAdsWatched} Ads Watched ({admobStats.rewardedAdsWatched * 5} Coins)
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <div>
                          <span className="text-xs font-mono font-black text-amber-500 block">
                            +{(admobStats.rewardedAdsWatched * 5).toLocaleString()} Coins
                          </span>
                          <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            ≈ {walletEarningsService.convertCoinsToFiat(admobStats.rewardedAdsWatched * 5, earningsWallet.selectedCurrencyCode).formatted}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (onOpenRewardedAds) {
                              onOpenRewardedAds();
                            } else {
                              onToast?.('Opening Steem Unlimited Rewarded Ad Player...');
                            }
                          }}
                          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-rose-500 text-white text-[10px] font-black cursor-pointer shadow-md hover:opacity-90 active:scale-95 transition-all shrink-0 flex items-center gap-1"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Watch (+5 🪙)</span>
                        </button>
                      </div>
                    </div>

                    {/* Item 1: Video Ads Earned */}
                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-[#fe2c55] flex items-center justify-center shrink-0">
                          <Film className="w-4.5 h-4.5" />
                        </div>
                        <div>
                          <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                            • Video Ads Earned
                          </span>
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {earningsWallet.dailyEarnings.videoAdsCount} Ads Viewed Today
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <div>
                          <span className="text-xs font-mono font-black text-amber-500 block">
                            +{earningsWallet.dailyEarnings.videoAdsCoins.toLocaleString()} Coins
                          </span>
                          <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            ≈ {walletEarningsService.convertCoinsToFiat(earningsWallet.dailyEarnings.videoAdsCoins, earningsWallet.selectedCurrencyCode).formatted}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            const res = await walletEarningsService.addCoinsWithSignature('video_ad', 200);
                            if (res.success) {
                              onToast?.('🎉 +200 Coins Earned from Video Ad! HMAC Signed & Verified.');
                            } else {
                              onToast?.(`⚠️ Error: ${res.error}`);
                            }
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-[#fe2c55]/10 hover:bg-[#fe2c55]/20 text-[#fe2c55] text-[10px] font-black cursor-pointer transition-colors shrink-0"
                        >
                          +200 Watch
                        </button>
                      </div>
                    </div>

                    {/* Item 2: Direct Banner Earned */}
                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center shrink-0">
                          <SlidersHorizontal className="w-4.5 h-4.5" />
                        </div>
                        <div>
                          <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                            • Direct Banner Earned
                          </span>
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {earningsWallet.dailyEarnings.bannerAdsCount} Banner Displays Today
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <div>
                          <span className="text-xs font-mono font-black text-amber-500 block">
                            +{earningsWallet.dailyEarnings.bannerAdsCoins.toLocaleString()} Coins
                          </span>
                          <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            ≈ {walletEarningsService.convertCoinsToFiat(earningsWallet.dailyEarnings.bannerAdsCoins, earningsWallet.selectedCurrencyCode).formatted}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            const res = await walletEarningsService.addCoinsWithSignature('banner_ad', 150);
                            if (res.success) {
                              onToast?.('🎉 +150 Coins Claimed from Direct Banner Ad!');
                            }
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 text-[10px] font-black cursor-pointer transition-colors shrink-0"
                        >
                          +150 Claim
                        </button>
                      </div>
                    </div>

                    {/* Item 3: Referral Bonus */}
                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
                          <Gift className="w-4.5 h-4.5" />
                        </div>
                        <div>
                          <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                            • Referral Bonus
                          </span>
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {earningsWallet.dailyEarnings.referralCount} Friends Invited (৳499 each)
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <div>
                          <span className="text-xs font-mono font-black text-amber-500 block">
                            +{earningsWallet.dailyEarnings.referralCoins.toLocaleString()} Coins
                          </span>
                          <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            ≈ {walletEarningsService.convertCoinsToFiat(earningsWallet.dailyEarnings.referralCoins, earningsWallet.selectedCurrencyCode).formatted}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const refLink = `${window.location.origin}/?ref=${currentUser?.id || 'usr-719284'}`;
                            navigator.clipboard.writeText(refLink);
                            onToast?.('✓ Referral link copied! ৳499 will unlock for invited friends.');
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 text-[10px] font-black cursor-pointer transition-colors shrink-0"
                        >
                          Invite
                        </button>
                      </div>
                    </div>

                    {/* Item 4: Watch & Earn Stream */}
                    <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
                          <Sparkles className="w-4.5 h-4.5" />
                        </div>
                        <div>
                          <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                            • Watch & Earn Scrolling
                          </span>
                          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                            {earningsWallet.dailyEarnings.watchEarnCount} Videos Scrolled Today
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <div>
                          <span className="text-xs font-mono font-black text-amber-500 block">
                            +{earningsWallet.dailyEarnings.watchEarnCoins.toLocaleString()} Coins
                          </span>
                          <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            ≈ {walletEarningsService.convertCoinsToFiat(earningsWallet.dailyEarnings.watchEarnCoins, earningsWallet.selectedCurrencyCode).formatted}
                          </span>
                        </div>
                        <span className="px-2 py-1 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 text-[10px] font-bold">
                          Active
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 5. Zero-Trust Military-Grade Security Architecture Card */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-zinc-900 via-zinc-850 to-zinc-950 border border-zinc-800 text-zinc-100 space-y-2.5 shadow-md">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <h5 className="text-xs font-black uppercase tracking-wider text-white">
                        Zero-Trust Security & Anti-Fraud Architecture
                      </h5>
                    </div>
                    <span className="text-[9px] font-mono font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      MILITARY GRADE
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                    <div className="p-2 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                      <span className="text-zinc-400 block text-[9px]">Binary SHA-256 Checksum:</span>
                      <span className="text-emerald-400 font-bold truncate block">
                        {securityReport.checksumMatched ? 'Verified Match ✅' : 'Tampered ❌'}
                      </span>
                    </div>
                    <div className="p-2 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                      <span className="text-zinc-400 block text-[9px]">Root & Jailbreak:</span>
                      <span className="text-emerald-400 font-bold block">
                        {securityReport.rootJailbreakDetected ? 'Detected 🚫' : 'Clean & Protected ✅'}
                      </span>
                    </div>
                    <div className="p-2 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                      <span className="text-zinc-400 block text-[9px]">Frida & Xposed Hooks:</span>
                      <span className="text-emerald-400 font-bold block">
                        {securityReport.fridaXposedDetected ? 'Hook Injected 🚫' : '0 Injections Active ✅'}
                      </span>
                    </div>
                    <div className="p-2 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                      <span className="text-zinc-400 block text-[9px]">Dynamic Ephemeral Signer:</span>
                      <span className="text-emerald-400 font-bold block">
                        HMAC-SHA256 Active ✅
                      </span>
                    </div>
                  </div>
                </div>

                {/* 6. Recent Requests & Status Tracking (পেনডিং ও কমপ্লিট হিস্টোরি) */}
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-[#fe2c55]" />
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Withdrawal & Recharge Requests
                      </h4>
                    </div>
                    <span className="text-[10px] font-mono text-zinc-400">
                      Live Admin Sync
                    </span>
                  </div>

                  <div className="space-y-2">
                    {/* Withdrawals List */}
                    {walletWithdrawals.slice(0, 5).map((w) => (
                      <div
                        key={w.id}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/40 space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-rose-500/10 text-[#fe2c55]">
                              {w.method}
                            </span>
                            <span className="text-xs font-mono font-bold text-zinc-700 dark:text-zinc-300">
                              {w.transferId}
                            </span>
                          </div>
                          <div>
                            {w.status === 'pending' ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px] font-black border border-amber-500/30 flex items-center gap-1 animate-pulse">
                                ⏳ Pending Admin Approval (পেনডিং)
                              </span>
                            ) : w.status === 'completed' ? (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-black border border-emerald-500/30 flex items-center gap-1">
                                ✓ Completed & Transferred (কমপ্লিট)
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-600 text-[10px] font-black">
                                ✕ Rejected & Refunded
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-zinc-500">
                          <span>Account: {w.accountNumber}</span>
                          <span className="font-mono font-bold text-zinc-900 dark:text-zinc-100">
                            {w.amountCoins.toLocaleString()} Coins ({w.currencySymbol} {w.amountFiat})
                          </span>
                        </div>
                      </div>
                    ))}

                    {/* Recharges List */}
                    {walletRecharges.slice(0, 5).map((r) => (
                      <div
                        key={r.id}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/40 space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-500/10 text-emerald-600">
                              📱 {r.operatorName}
                            </span>
                            <span className="text-xs font-mono font-bold text-zinc-700 dark:text-zinc-300">
                              {r.recipientPhone}
                            </span>
                          </div>
                          <div>
                            {r.status === 'pending' ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px] font-black border border-amber-500/30 flex items-center gap-1 animate-pulse">
                                ⏳ Pending Admin Dispatch (পেনডিং)
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-black border border-emerald-500/30 flex items-center gap-1">
                                ✓ Recharged & Completed (কমপ্লিট)
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-zinc-500">
                          <span>Country: {r.countryName} ({r.countryCode})</span>
                          <span className="font-mono font-bold text-zinc-900 dark:text-zinc-100">
                            {r.currencySymbol} {r.amountFiat} ({r.amountCoins.toLocaleString()} Coins)
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* MODAL: WITHDRAW DIALOG */}
                {showWithdrawModal && (
                  <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 w-full max-w-sm border border-zinc-200 dark:border-zinc-800 shadow-2xl space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-5 h-5 text-[#fe2c55]" />
                          <h4 className="text-sm font-black text-zinc-900 dark:text-zinc-100">
                            Withdraw Local Currency
                          </h4>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowWithdrawModal(false)}
                          className="p-1 rounded-full text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Method Selector */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1.5">
                          Select Withdrawal Gateway:
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { id: 'bkash', name: 'bKash (বিকাশ)', icon: '📱' },
                            { id: 'nagad', name: 'Nagad (নগদ)', icon: '📱' },
                            { id: 'binance', name: 'Binance Pay / USDT', icon: '🟡' },
                            { id: 'bank', name: 'Bank Transfer', icon: '🏦' },
                          ].map((m) => (
                            <button
                              key={m.id}
                              type="button"
                              onClick={() => setWithdrawMethodChoice(m.id as any)}
                              className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                                withdrawMethodChoice === m.id
                                  ? 'border-[#fe2c55] bg-rose-50/50 dark:bg-rose-950/20 text-[#fe2c55] ring-1 ring-[#fe2c55]/30'
                                  : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/40 text-zinc-700 dark:text-zinc-300'
                              }`}
                            >
                              <span className="text-xs font-black block">{m.icon} {m.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Account Number / Binance Pay ID */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                          {withdrawMethodChoice === 'binance'
                            ? 'Enter Binance Pay ID or USDT (BEP-20) Address:'
                            : withdrawMethodChoice === 'bank'
                            ? 'Enter Bank Account Number & Holder Name:'
                            : 'Enter Personal / Agent Phone Number:'}
                        </label>
                        <input
                          type="text"
                          value={withdrawAccountInput}
                          onChange={(e) => setWithdrawAccountInput(e.target.value)}
                          placeholder={
                            withdrawMethodChoice === 'binance'
                              ? 'e.g. Binance Pay ID: 84920184'
                              : withdrawMethodChoice === 'bank'
                              ? 'e.g. DBBL 120-105-998822 (Tanvir)'
                              : 'e.g. 01875328569'
                          }
                          className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono font-bold text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-[#fe2c55]"
                        />
                      </div>

                      {/* Coin Amount Select */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1.5">
                          Select Coin Amount to Withdraw:
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { coins: 10000, label: '10k Coins' },
                            { coins: 25000, label: '25k Coins' },
                            { coins: 50000, label: '50k Coins' },
                          ].map((amt) => (
                            <button
                              key={amt.coins}
                              type="button"
                              onClick={() => setWithdrawCoinAmount(amt.coins)}
                              className={`p-2 rounded-xl border text-center cursor-pointer text-xs font-mono font-bold transition-all ${
                                withdrawCoinAmount === amt.coins
                                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-600'
                                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                              }`}
                            >
                              {amt.label}
                            </button>
                          ))}
                        </div>
                        <div className="mt-2 text-right">
                          <span className="text-xs font-mono font-black text-emerald-600">
                            ≈ {walletEarningsService.convertCoinsToFiat(withdrawCoinAmount, earningsWallet.selectedCurrencyCode).formatted}
                          </span>
                        </div>
                      </div>

                      {/* Submit Button (Triggers High-Paying Rewarded Interstitial Ad with Loading Transition Spinner) */}
                      <button
                        type="button"
                        onClick={() => {
                          if (!withdrawAccountInput.trim()) {
                            onToast?.('⚠️ Please enter your phone number, Binance Pay ID or bank details!');
                            return;
                          }
                          const payload = {
                            userId: currentUser?.id || 'usr-self',
                            userName: currentUser?.name || 'TikTok Creator',
                            userHandle: currentUser?.handle || 'creator',
                            userAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
                            method: withdrawMethodChoice,
                            accountNumber: withdrawAccountInput.trim(),
                            amountCoins: withdrawCoinAmount,
                            currencyCode: earningsWallet.selectedCurrencyCode,
                          };
                          setPendingWithdrawalPayload(payload);
                          setShowWithdrawModal(false);
                          setShowHighPayingInterstitial(true);
                        }}
                        className="w-full py-3 rounded-xl bg-[#fe2c55] hover:bg-[#e0264a] text-white font-black text-xs shadow-md transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-2"
                      >
                        <Sparkles className="w-4 h-4 text-amber-200" />
                        <span>Confirm Withdraw (উইথড্র নিশ্চিত করুন)</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* MODAL: WORLDWIDE MOBILE OPERATOR RECHARGE DIALOG */}
                {showRechargeModal && (
                  <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 w-full max-w-sm border border-zinc-200 dark:border-zinc-800 shadow-2xl space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Smartphone className="w-5 h-5 text-emerald-500" />
                          <h4 className="text-sm font-black text-zinc-900 dark:text-zinc-100">
                            Worldwide Mobile Recharge
                          </h4>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowRechargeModal(false)}
                          className="p-1 rounded-full text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Select Country from 200+ list */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                          Select Country (200+ Countries):
                        </label>
                        <select
                          value={rechargeCountryCode}
                          onChange={(e) => {
                            const code = e.target.value;
                            setRechargeCountryCode(code);
                            const ops = getOperatorsForCountry(code);
                            if (ops && ops.length > 0) {
                              setRechargeOperator(ops[0]);
                            }
                          }}
                          className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-bold text-zinc-900 dark:text-zinc-100 focus:outline-none"
                        >
                          {COUNTRIES_200.map((c) => (
                            <option key={c.code} value={c.code}>
                              {c.flag} {c.name} ({c.dialCode}) - {c.currencyCode}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Select Operator for the selected Country */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                          Select Mobile Operator:
                        </label>
                        <select
                          value={rechargeOperator}
                          onChange={(e) => setRechargeOperator(e.target.value)}
                          className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-bold text-zinc-900 dark:text-zinc-100 focus:outline-none"
                        >
                          {getOperatorsForCountry(rechargeCountryCode).map((op) => (
                            <option key={op} value={op}>
                              {op}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Recipient Phone Number */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1">
                          Recipient Mobile Number:
                        </label>
                        <input
                          type="tel"
                          value={rechargeRecipientPhone}
                          onChange={(e) => setRechargeRecipientPhone(e.target.value)}
                          placeholder="e.g. 01875328569 or +8801875328569"
                          className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-mono font-bold text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>

                      {/* Recharge Amount */}
                      <div>
                        <label className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1.5">
                          Select Recharge Amount:
                        </label>
                        <div className="grid grid-cols-4 gap-1.5">
                          {[20, 50, 100, 200].map((amt) => (
                            <button
                              key={amt}
                              type="button"
                              onClick={() => setRechargeFiatAmount(amt)}
                              className={`py-2 rounded-xl border text-center text-xs font-mono font-bold cursor-pointer transition-all ${
                                rechargeFiatAmount === amt
                                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-600'
                                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                              }`}
                            >
                              {amt}
                            </button>
                          ))}
                        </div>
                        <div className="mt-1.5 text-right text-[10px] text-zinc-400 font-mono">
                          Coins required: {walletEarningsService.convertFiatToCoins(rechargeFiatAmount, earningsWallet.selectedCurrencyCode).toLocaleString()} Coins
                        </div>
                      </div>

                      {/* Submit Recharge */}
                      <button
                        type="button"
                        onClick={async () => {
                          if (!rechargeRecipientPhone.trim()) {
                            onToast?.('⚠️ Please enter the recipient mobile number!');
                            return;
                          }
                          const country = COUNTRIES_200.find(c => c.code === rechargeCountryCode) || COUNTRIES_200[0];
                          const res = await walletEarningsService.submitMobileRecharge({
                            userId: currentUser?.id || 'usr-self',
                            userName: currentUser?.name || 'TikTok Creator',
                            userHandle: currentUser?.handle || 'creator',
                            userAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
                            recipientPhone: rechargeRecipientPhone.trim(),
                            countryCode: rechargeCountryCode,
                            countryName: country.name,
                            operatorName: rechargeOperator,
                            amountFiat: rechargeFiatAmount,
                            currencyCode: earningsWallet.selectedCurrencyCode,
                          });

                          if (res.success && res.request) {
                            setShowRechargeModal(false);
                            setRechargeRecipientPhone('');
                            onToast?.(`🎉 Recharge request submitted! Status: Pending. Admin will send mobile recharge to ${res.request.recipientPhone}.`);
                          } else {
                            onToast?.(`⚠️ ${res.error || 'Failed to submit recharge'}`);
                          }
                        }}
                        className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition-all cursor-pointer active:scale-95"
                      >
                        Submit Mobile Recharge (মোবাইল রিচার্জ পাঠান)
                      </button>
                    </div>
                  </div>
                )}

                {/* HIGH-PAYING REWARDED INTERSTITIAL AD MODAL ON WITHDRAW (User Requirement: ca-app-pub-3964151806897298/5450308150) */}
                <RewardedInterstitialModal
                  isOpen={showHighPayingInterstitial}
                  onClose={() => {
                    setShowHighPayingInterstitial(false);
                    setPendingWithdrawalPayload(null);
                  }}
                  amountFiat={
                    pendingWithdrawalPayload
                      ? walletEarningsService.convertCoinsToFiat(pendingWithdrawalPayload.amountCoins, pendingWithdrawalPayload.currencyCode).amount
                      : 0
                  }
                  currencyCode={earningsWallet.selectedCurrencyCode}
                  onAdCompleted={async () => {
                    if (!pendingWithdrawalPayload) return;
                    const res = await walletEarningsService.submitWithdrawal(pendingWithdrawalPayload);
                    setShowHighPayingInterstitial(false);
                    if (res.success && res.request) {
                      setWithdrawAccountInput('');
                      setPendingWithdrawalPayload(null);
                      onToast?.(
                        `🎉 Ad Completed! Withdrawal of ${res.request.currencySymbol}${res.request.amountFiat} submitted as PENDING to Admin Panel (TrxID: ${res.request.transferId}).`
                      );
                    } else {
                      onToast?.(`⚠️ ${res.error || 'Failed to submit withdrawal'}`);
                    }
                  }}
                />
              </div>
            )}

            {/* ========================================================= */}
            {/* SUB-VIEW: ADMIN PANEL (ID SEARCH, BAN & UNBAN + BOOSTS)   */}
            {/* ========================================================= */}
            {activeSubView === 'admin_panel' && (
              <div className="space-y-4">
                {/* Admin Mode Badge */}
                <div className="p-3 bg-gradient-to-r from-zinc-900 via-zinc-850 to-zinc-900 text-white rounded-2xl flex items-center justify-between border border-zinc-700 shadow-lg">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="text-xs font-black">TikTok Central Admin Authority</h4>
                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          zenx 1
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-300">
                        Admin: <span className="font-mono text-emerald-400 font-bold">01875328569</span> • Device: <span className="font-mono text-cyan-300 font-bold">zenx 1 (Verified)</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleLockAdminPanel}
                      className="px-2.5 py-1 rounded-xl bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 text-[10px] font-black cursor-pointer transition-colors flex items-center gap-1"
                      title="Lock Admin Panel"
                    >
                      <Lock className="w-3 h-3" />
                      <span>Lock</span>
                    </button>
                  </div>
                </div>

                {/* Tabs: Users vs Boosts vs CapCut VIP vs Withdrawals vs Recharges */}
                <div className="grid grid-cols-6 gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setAdminActiveTab('users')}
                    className={`py-2 px-1 rounded-lg text-[10px] font-black transition-all cursor-pointer truncate ${
                      adminActiveTab === 'users'
                        ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    Users ({allUsers.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdminActiveTab('boosts')}
                    className={`py-2 px-1 rounded-lg text-[10px] font-black transition-all cursor-pointer truncate ${
                      adminActiveTab === 'boosts'
                        ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    Boosts ({boostCampaigns.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAdminActiveTab('vip_purchases');
                      setVipPurchases(fetchVipPurchases());
                    }}
                    className={`py-2 px-1 rounded-lg text-[10px] font-black transition-all cursor-pointer truncate ${
                      adminActiveTab === 'vip_purchases'
                        ? 'bg-gradient-to-r from-amber-500/20 to-amber-400/20 text-amber-500 dark:text-amber-400 font-black shadow-xs border border-amber-500/30'
                        : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    VIP ({vipPurchases.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdminActiveTab('withdrawals')}
                    className={`py-2 px-1 rounded-lg text-[10px] font-black transition-all cursor-pointer truncate relative ${
                      adminActiveTab === 'withdrawals'
                        ? 'bg-rose-500 text-white shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    Withdraw ({walletWithdrawals.filter((w) => w.status === 'pending').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdminActiveTab('recharges')}
                    className={`py-2 px-1 rounded-lg text-[10px] font-black transition-all cursor-pointer truncate relative ${
                      adminActiveTab === 'recharges'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    Recharge ({walletRecharges.filter((r) => r.status === 'pending').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdminActiveTab('admob_security')}
                    className={`py-2 px-1 rounded-lg text-[10px] font-black transition-all cursor-pointer truncate relative ${
                      adminActiveTab === 'admob_security'
                        ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-800'
                    }`}
                  >
                    AdMob & Security
                  </button>
                </div>

                {/* TAB 1: USERS DIRECTORY, SEARCH, BAN & UNBAN */}
                {adminActiveTab === 'users' && (
                  <div className="space-y-3">
                    {/* Search Bar */}
                    <div className="relative">
                      <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={adminSearch}
                        onChange={(e) => setAdminSearch(e.target.value)}
                        placeholder="Search by UID (e.g. 7192849) or Name/Handle..."
                        className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-[#fe2c55]"
                      />
                    </div>

                    {/* Filter Pills */}
                    <div className="flex gap-1.5 text-xs font-bold">
                      <button
                        type="button"
                        onClick={() => setAdminUserFilter('all')}
                        className={`px-3 py-1 rounded-full text-[11px] font-black cursor-pointer ${
                          adminUserFilter === 'all'
                            ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                            : 'bg-zinc-200/70 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        All Accounts ({allUsers.length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setAdminUserFilter('active')}
                        className={`px-3 py-1 rounded-full text-[11px] font-black cursor-pointer ${
                          adminUserFilter === 'active'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-zinc-200/70 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        Active ({allUsers.filter((u) => !u.isBanned).length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setAdminUserFilter('banned')}
                        className={`px-3 py-1 rounded-full text-[11px] font-black cursor-pointer ${
                          adminUserFilter === 'banned'
                            ? 'bg-rose-600 text-white'
                            : 'bg-zinc-200/70 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        Banned ({allUsers.filter((u) => u.isBanned).length})
                      </button>
                    </div>

                    {/* User Cards List */}
                    <div className="space-y-2.5">
                      {filteredAdminUsers.map((user) => (
                        <div
                          key={user.id}
                          className={`p-3 rounded-2xl border transition-all ${
                            user.isBanned
                              ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-300 dark:border-rose-900'
                              : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 shadow-xs'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-zinc-200 dark:border-zinc-700">
                                <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 truncate block">
                                    {user.name}
                                  </span>
                                  {user.verified && (
                                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-500 fill-current shrink-0" />
                                  )}
                                </div>
                                <div className="flex items-center gap-2 text-[10px] text-zinc-400 font-mono">
                                  <span>@{user.handle}</span>
                                  <span>• UID: {user.uid}</span>
                                </div>
                              </div>
                            </div>

                            {/* Status Badge */}
                            <div>
                              {user.isBanned ? (
                                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black">
                                  BANNED 🚫
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-black border border-emerald-200 dark:border-emerald-800">
                                  Active ✅
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Action Row */}
                          <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-zinc-100 dark:border-zinc-800 text-xs">
                            <span className="text-[10px] text-zinc-400">
                              {user.followers.toLocaleString()} followers • {user.country || 'Global'}
                            </span>

                            {user.isBanned ? (
                              <button
                                type="button"
                                onClick={() => handleUnbanAccount(user)}
                                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs cursor-pointer shadow-xs active:scale-95 transition-transform"
                              >
                                Unban Account ✅
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleBanAccount(user)}
                                className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 font-black text-xs cursor-pointer active:scale-95 transition-transform"
                              >
                                Ban Account 🚫
                              </button>
                            )}
                          </div>
                        </div>
                      ))}

                      {filteredAdminUsers.length === 0 && (
                        <div className="text-center py-8 text-zinc-400 text-xs">
                          No users found matching "{adminSearch}"
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* TAB 2: BOOST ORDERS & PROMOTED ADS QUEUE */}
                {adminActiveTab === 'boosts' && (
                  <div className="space-y-3">
                    <p className="text-xs text-zinc-500">
                      Review submitted boost payments, verify TrxID, and activate viral distribution onto the For You feed.
                    </p>

                    {boostCampaigns.map((camp) => (
                      <div
                        key={camp.id}
                        className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3"
                      >
                        {/* User Header */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <img src={camp.userAvatar} alt="" className="w-8 h-8 rounded-full object-cover border" />
                            <div>
                              <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                                {camp.userName} (@{camp.userHandle})
                              </span>
                              <span className="text-[10px] font-mono text-zinc-400">UID: {camp.userUid}</span>
                            </div>
                          </div>

                          {/* Payment Success badge as requested by user */}
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-black border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                            <CheckCheck className="w-3 h-3 text-emerald-600 stroke-[3]" />
                            <span>টাকা সফল (Payment Success)</span>
                          </span>
                        </div>

                        {/* Package Details */}
                        <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-xl border border-zinc-200 dark:border-zinc-700 grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-[10px] text-zinc-400 block">Package Ordered:</span>
                            <span className="font-black text-[#fe2c55]">
                              {camp.targetViews.toLocaleString()} Views + {camp.targetLikes.toLocaleString()} Likes
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">Amount Paid:</span>
                            <span className="font-mono font-black text-zinc-900 dark:text-zinc-100">
                              ${camp.totalCostDollar.toFixed(2)} USD (≈ ৳{Math.round(camp.totalCostDollar * 122)})
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">Payment Method:</span>
                            <span className="font-bold uppercase text-zinc-700 dark:text-zinc-300">
                              {camp.paymentMethod} • {camp.senderPhone || '01875328569'}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">Transaction ID:</span>
                            <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                              {camp.transactionId}
                            </span>
                          </div>
                        </div>

                        {/* Video Link & Description */}
                        <div className="text-xs">
                          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-0.5">
                            Target Video URL:
                          </span>
                          <span className="font-mono text-[11px] text-sky-600 dark:text-sky-400 block truncate">
                            {camp.videoUrl}
                          </span>
                          {camp.description && (
                            <p className="text-[11px] text-zinc-500 mt-1 italic">
                              "{camp.description}"
                            </p>
                          )}
                        </div>

                        {/* Progress Bar if active */}
                        {camp.status === 'active' && (
                          <div>
                            <div className="flex items-center justify-between text-[10px] font-bold mb-1">
                              <span className="text-zinc-500">Delivered Views:</span>
                              <span className="text-[#fe2c55] font-mono">
                                {camp.deliveredViews.toLocaleString()} / {camp.targetViews.toLocaleString()} (
                                {Math.round((camp.deliveredViews / camp.targetViews) * 100)}%)
                              </span>
                            </div>
                            <div className="w-full h-2 bg-zinc-200 dark:bg-zinc-700 rounded-full overflow-hidden">
                              <div
                                style={{ width: `${Math.min(100, Math.round((camp.deliveredViews / camp.targetViews) * 100))}%` }}
                                className="h-full bg-gradient-to-r from-rose-500 to-amber-500 rounded-full transition-all"
                              />
                            </div>
                          </div>
                        )}

                        {/* Action: "বুস্ট" (Boost Now) - Only Admin can click */}
                        <div className="flex items-center justify-end gap-2 pt-1 border-t border-zinc-100 dark:border-zinc-800">
                          {camp.status === 'pending' && (
                            <button
                              type="button"
                              onClick={() => handleAdminActivateBoost(camp)}
                              className="px-4 py-2 rounded-xl bg-[#fe2c55] hover:bg-[#e0264a] text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                            >
                              <Rocket className="w-3.5 h-3.5" />
                              <span>বুস্ট করুন (Boost Now)</span>
                            </button>
                          )}

                          {camp.status === 'active' && (
                            <button
                              type="button"
                              onClick={() => handleAdminCompleteBoost(camp)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-xs transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>টার্গেট সম্পন্ন (Finish)</span>
                            </button>
                          )}

                          {camp.status === 'completed' && (
                            <span className="text-xs font-black text-emerald-600 flex items-center gap-1">
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Completed • Video Playing Normally</span>
                            </span>
                          )}
                        </div>
                      </div>
                    ))}

                    {boostCampaigns.length === 0 && (
                      <div className="text-center py-8 text-zinc-400 text-xs">
                        No boost orders submitted yet.
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 3: CAPCUT VIP IN-APP PURCHASES & ORDERS */}
                {adminActiveTab === 'vip_purchases' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-zinc-500">
                        ক্যাপকাট ভিআইপি ফিচার ক্রয়ের পেমেন্ট ট্রানজেকশন (TrxID) ও ইউজার আইডি তালিকা:
                      </p>
                      <button
                        type="button"
                        onClick={() => setVipPurchases(fetchVipPurchases())}
                        className="text-[10px] text-[#fe2c55] font-bold hover:underline cursor-pointer"
                      >
                        রিফ্রেশ
                      </button>
                    </div>

                    {vipPurchases.map((vip) => (
                      <div
                        key={vip.id}
                        className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3"
                      >
                        {/* Header: User info */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <img src={vip.userAvatar} alt="" className="w-8 h-8 rounded-full object-cover border" />
                            <div>
                              <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block">
                                {vip.userName} (@{vip.userHandle})
                              </span>
                              <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                                ক্রেতার UID: {vip.userUid}
                              </span>
                            </div>
                          </div>

                          {vip.status === 'verified' ? (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-black border border-emerald-500/30 flex items-center gap-1">
                              <CheckCheck className="w-3 h-3 text-emerald-500 stroke-[3]" />
                              <span>ভেরিফাইড ও সক্রিয়</span>
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-[10px] font-black border border-amber-500/30 flex items-center gap-1">
                              <Crown className="w-3 h-3 text-amber-500 fill-amber-500" />
                              <span>নতুন পারচেজ অর্ডার</span>
                            </span>
                          )}
                        </div>

                        {/* Order & Payment Specs */}
                        <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-xl border border-zinc-200 dark:border-zinc-700 grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-[10px] text-zinc-400 block">কেনা ভিআইপি ফিচার:</span>
                            <span className="font-black text-amber-600 dark:text-amber-400 block truncate">
                              {vip.featureTitle}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">পরিশোধিত মূল্য:</span>
                            <span className="font-mono font-black text-zinc-900 dark:text-zinc-100">
                              ৳{vip.amountBDT} BDT (${vip.amountUSD} USD)
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">পেমেন্ট মেথড ও প্রেরক:</span>
                            <span className="font-bold uppercase text-zinc-700 dark:text-zinc-300 block truncate">
                              {vip.paymentMethod} • {vip.senderPhone}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">ট্রানজেকশন আইডি (TrxID):</span>
                            <span className="font-mono font-black text-[#fe2c55] block truncate">
                              {vip.transactionId}
                            </span>
                          </div>
                        </div>

                        {/* Admin Action Button */}
                        <div className="flex items-center justify-between pt-1 border-t border-zinc-100 dark:border-zinc-800 text-[11px]">
                          <span className="text-zinc-400 font-mono text-[10px]">
                            এডমিন মার্চেন্ট: {vip.adminPhoneContact || '01875328569'}
                          </span>

                          {vip.status === 'pending' ? (
                            <button
                              type="button"
                              onClick={() => {
                                updateVipPurchase(vip.id, { status: 'verified' });
                                setVipPurchases(fetchVipPurchases());
                                onToast?.(`✓ UID ${vip.userUid} এর জন্য "${vip.featureTitle}" নিশ্চিত ও আনলক করা হয়েছে।`);
                              }}
                              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-[#fe2c55] text-black font-black text-xs shadow-md transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                            >
                              <ShieldCheck className="w-3.5 h-3.5" />
                              <span>ভেরিফাই ও নিশ্চিত করুন</span>
                            </button>
                          ) : (
                            <span className="text-emerald-600 font-black flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>কনফার্মড</span>
                            </span>
                          )}
                        </div>
                      </div>
                    ))}

                    {vipPurchases.length === 0 && (
                      <div className="text-center py-8 text-zinc-400 text-xs">
                        এখনও কোনো ক্যাপকাট ভিআইপি অর্ডার আসেনি।
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 4: WITHDRAWAL REQUESTS (উইথড্র রিকোয়েস্ট ও এপ্রোভাল) */}
                {adminActiveTab === 'withdrawals' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Pending Withdrawal Requests ({walletWithdrawals.filter((w) => w.status === 'pending').length})
                      </h4>
                      <span className="text-[10px] text-zinc-400">
                        Total {walletWithdrawals.length} orders
                      </span>
                    </div>

                    {walletWithdrawals.map((w) => (
                      <div
                        key={w.id}
                        className={`p-3.5 rounded-2xl border transition-all space-y-2.5 ${
                          w.status === 'pending'
                            ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800 shadow-xs'
                            : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 shadow-xs opacity-85'
                        }`}
                      >
                        {/* User Profile Header */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-zinc-200 dark:border-zinc-700 shadow-xs">
                              <img src={w.userAvatar} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                                  {w.userName}
                                </span>
                                <span className="text-[10px] font-mono text-zinc-400">
                                  @{w.userHandle}
                                </span>
                              </div>
                              <span className="text-[10px] font-mono text-zinc-500 block">
                                User ID: {w.userId} • {new Date(w.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>

                          <div>
                            {w.status === 'pending' ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-400 text-[10px] font-black border border-amber-500/30 animate-pulse">
                                ⏳ PENDING
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-[10px] font-black border border-emerald-500/30">
                                ✓ APPROVED
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Transfer Details Card */}
                        <div className="grid grid-cols-2 gap-2 p-2.5 bg-white dark:bg-zinc-800/60 rounded-xl border border-zinc-200/80 dark:border-zinc-700 text-xs">
                          <div>
                            <span className="text-[10px] text-zinc-400 block">উইথড্র মেথড ও অ্যাকাউন্ট:</span>
                            <span className="font-bold text-zinc-900 dark:text-zinc-100 uppercase block truncate">
                              {w.method} • {w.accountNumber}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">টাকা ট্রান্সফার আইডি (TrxID):</span>
                            <span className="font-mono font-black text-[#fe2c55] block truncate">
                              {w.transferId}
                            </span>
                          </div>
                          <div className="col-span-2 pt-1 border-t border-zinc-100 dark:border-zinc-700/60 flex items-center justify-between">
                            <span className="text-[10px] text-zinc-400">উইথড্রর পরিমাণ:</span>
                            <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 text-sm">
                              {w.currencySymbol} {w.amountFiat} ({w.amountCoins.toLocaleString()} Coins)
                            </span>
                          </div>
                        </div>

                        {/* Admin Action Buttons (এপ্রোভ বা রিজেক্ট) */}
                        <div className="flex items-center justify-between pt-1 border-t border-zinc-100 dark:border-zinc-800 text-[11px]">
                          <span className="text-zinc-400 font-mono text-[10px]">
                            {w.status === 'pending' ? 'Review transfer ID and approve' : `Approved at: ${new Date(w.approvedAt || Date.now()).toLocaleTimeString()}`}
                          </span>

                          {w.status === 'pending' ? (
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  walletEarningsService.rejectWithdrawal(w.id);
                                  onToast?.(`Withdrawal request for ${w.userName} rejected and coins refunded.`);
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-bold text-xs cursor-pointer hover:bg-zinc-300"
                              >
                                Reject
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  walletEarningsService.approveWithdrawal(w.id);
                                  onToast?.(`🎉 Withdrawal APPROVED! ${w.currencySymbol}${w.amountFiat} transferred to ${w.accountNumber} (${w.userName}).`);
                                }}
                                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>এপ্রোভ করুন (Approve)</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-emerald-600 font-black flex items-center gap-1 text-xs">
                              <CheckCircle2 className="w-4 h-4" />
                              <span>কমপ্লিট সম্পন্ন (Transferred)</span>
                            </span>
                          )}
                        </div>
                      </div>
                    ))}

                    {walletWithdrawals.length === 0 && (
                      <div className="text-center py-8 text-zinc-400 text-xs">
                        এখনও কোনো উইথড্র রিকোয়েস্ট আসেনি।
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 5: MOBILE RECHARGE REQUESTS (মোবাইল রিচার্জ রিকোয়েস্ট ও এপ্রোভাল) */}
                {adminActiveTab === 'recharges' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Pending Worldwide Mobile Recharges ({walletRecharges.filter((r) => r.status === 'pending').length})
                      </h4>
                      <span className="text-[10px] text-zinc-400">
                        Total {walletRecharges.length} recharges
                      </span>
                    </div>

                    {walletRecharges.map((r) => (
                      <div
                        key={r.id}
                        className={`p-3.5 rounded-2xl border transition-all space-y-2.5 ${
                          r.status === 'pending'
                            ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800 shadow-xs'
                            : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 shadow-xs opacity-85'
                        }`}
                      >
                        {/* User Profile Header */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-zinc-200 dark:border-zinc-700 shadow-xs">
                              <img src={r.userAvatar} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                                  {r.userName}
                                </span>
                                <span className="text-[10px] font-mono text-zinc-400">
                                  @{r.userHandle}
                                </span>
                              </div>
                              <span className="text-[10px] font-mono text-zinc-500 block">
                                Requested at: {new Date(r.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>

                          <div>
                            {r.status === 'pending' ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-400 text-[10px] font-black border border-amber-500/30 animate-pulse">
                                ⏳ PENDING RECHARGE
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-[10px] font-black border border-emerald-500/30">
                                ✓ RECHARGED
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Mobile & Operator Details Card */}
                        <div className="grid grid-cols-2 gap-2 p-2.5 bg-white dark:bg-zinc-800/60 rounded-xl border border-zinc-200/80 dark:border-zinc-700 text-xs">
                          <div>
                            <span className="text-[10px] text-zinc-400 block">গ্রাহকের মোবাইল নম্বর:</span>
                            <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 text-sm block">
                              📱 {r.recipientPhone}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] text-zinc-400 block">দেশ ও মোবাইল অপারেটর:</span>
                            <span className="font-bold text-zinc-900 dark:text-zinc-100 block truncate">
                              {r.countryName} • {r.operatorName}
                            </span>
                          </div>
                          <div className="col-span-2 pt-1 border-t border-zinc-100 dark:border-zinc-700/60 flex items-center justify-between">
                            <span className="text-[10px] text-zinc-400">রিচার্জের পরিমাণ:</span>
                            <span className="font-mono font-black text-zinc-900 dark:text-zinc-100 text-sm">
                              {r.currencySymbol} {r.amountFiat} ({r.amountCoins.toLocaleString()} Coins)
                            </span>
                          </div>
                        </div>

                        {/* Admin Action Buttons (এপ্রোভ রিচার্জ) */}
                        <div className="flex items-center justify-between pt-1 border-t border-zinc-100 dark:border-zinc-800 text-[11px]">
                          <span className="text-zinc-400 font-mono text-[10px]">
                            {r.status === 'pending' ? 'Dispatch recharge to phone and click approve' : `Dispatched at: ${new Date(r.approvedAt || Date.now()).toLocaleTimeString()}`}
                          </span>

                          {r.status === 'pending' ? (
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  walletEarningsService.rejectRecharge(r.id);
                                  onToast?.(`Recharge request for ${r.recipientPhone} rejected and coins refunded.`);
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-bold text-xs cursor-pointer hover:bg-zinc-300"
                              >
                                Reject
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  walletEarningsService.approveRecharge(r.id);
                                  onToast?.(`🎉 Mobile recharge APPROVED & SENT to ${r.recipientPhone} (${r.operatorName})! Status marked as Completed.`);
                                }}
                                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>এপ্রোভ ও রিচার্জ করুন (Approve)</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-emerald-600 font-black flex items-center gap-1 text-xs">
                              <CheckCircle2 className="w-4 h-4" />
                              <span>রিচার্জ সম্পন্ন (Completed)</span>
                            </span>
                          )}
                        </div>
                      </div>
                    ))}

                    {walletRecharges.length === 0 && (
                      <div className="text-center py-8 text-zinc-400 text-xs">
                        এখনও কোনো মোবাইল রিচার্জ রিকোয়েস্ট আসেনি।
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 6: ADMOB SDK CONTROL & WORLD-CLASS SECURITY AUTO-BAN MONITOR */}
                {adminActiveTab === 'admob_security' && (
                  <div className="space-y-4">
                    {/* Header Banner */}
                    <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-600 via-rose-600 to-indigo-700 text-white shadow-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-5 h-5 text-amber-200 fill-amber-200" />
                          <h4 className="text-xs font-black uppercase tracking-wider">
                            Official Google AdMob & World-Class Security
                          </h4>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-400 text-black text-[9px] font-black uppercase tracking-wider">
                          LIVE & MONITORED
                        </span>
                      </div>
                      <p className="text-[11px] text-white/90 leading-relaxed">
                        Control native feed ad frequency, monitor real-time impressions & gold coin rewards, and inspect auto-banned fraudulent bots.
                      </p>
                    </div>

                    {/* 1. NATIVE AD FREQUENCY CONTROLLER (User Requirement: কয়টা ভিডিও পর পর এড হবে এডমিন প্যানেল থেকে চেন্জ করা যাবে) */}
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                        <div>
                          <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
                            <Sliders className="w-4 h-4 text-[#fe2c55]" />
                            <span>Feed Ad Frequency Control (ভিডিও পর পর এড সেটিংস)</span>
                          </h4>
                          <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block mt-0.5">
                            How many videos appear between each Native Advanced Ad in For You feed
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="px-2.5 py-1 rounded-xl bg-[#fe2c55]/10 text-[#fe2c55] font-black text-xs font-mono">
                            Every {admobConfig.videosPerNativeAd} Videos
                          </span>
                        </div>
                      </div>

                      {/* Quick Select Buttons */}
                      <div>
                        <span className="text-[10px] font-bold text-zinc-600 dark:text-zinc-400 block mb-1.5">
                          Select Frequency Preset:
                        </span>
                        <div className="grid grid-cols-6 gap-1.5">
                          {[2, 3, 4, 5, 6, 8].map((count) => (
                            <button
                              key={count}
                              type="button"
                              onClick={() => {
                                admobService.setVideosPerNativeAd(count);
                                onToast?.(`✓ Native Ad frequency set to every ${count} videos!`);
                              }}
                              className={`py-2 rounded-xl text-xs font-black font-mono transition-all cursor-pointer ${
                                admobConfig.videosPerNativeAd === count
                                  ? 'bg-[#fe2c55] text-white shadow-md scale-102 ring-2 ring-[#fe2c55]/30'
                                  : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                              }`}
                            >
                              {count} {count === 4 ? '★' : 'vids'}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700 text-[11px] text-zinc-600 dark:text-zinc-400 flex items-center justify-between">
                        <span>Active Feed Rule:</span>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          1 Native Ad injected every {admobConfig.videosPerNativeAd} reels (+5 Coins / 80% view)
                        </span>
                      </div>
                    </div>

                    {/* 2. OFFICIAL ADMOB CONFIGURATION CARDS */}
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          <span>Official Production Google Ad Unit IDs</span>
                        </h4>
                        <span className="text-[10px] text-zinc-400 font-mono">
                          Verified App ID
                        </span>
                      </div>

                      <div className="space-y-2">
                        {/* App ID */}
                        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
                          <div className="truncate mr-2">
                            <span className="text-[10px] text-zinc-400 block font-bold">1. Google AdMob App ID:</span>
                            <span className="font-mono font-bold text-zinc-900 dark:text-zinc-100 text-[11px] truncate block">
                              {admobConfig.appId}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(admobConfig.appId);
                              onToast?.('✓ Copied AdMob App ID');
                            }}
                            className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300 shrink-0 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Native Advanced */}
                        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
                          <div className="truncate mr-2">
                            <span className="text-[10px] text-zinc-400 block font-bold">2. Home Page (For You) - Native Advanced Ad ID:</span>
                            <span className="font-mono font-bold text-sky-600 dark:text-sky-400 text-[11px] truncate block">
                              {admobConfig.nativeAdvancedAdId}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(admobConfig.nativeAdvancedAdId);
                              onToast?.('✓ Copied Native Ad ID');
                            }}
                            className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300 shrink-0 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Steem Rewarded */}
                        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
                          <div className="truncate mr-2">
                            <span className="text-[10px] text-zinc-400 block font-bold">3. Steem Page - Unlimited Rewarded Ad ID:</span>
                            <span className="font-mono font-bold text-amber-600 dark:text-amber-400 text-[11px] truncate block">
                              {admobConfig.unlimitedRewardedAdId}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(admobConfig.unlimitedRewardedAdId);
                              onToast?.('✓ Copied Rewarded Ad ID');
                            }}
                            className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300 shrink-0 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Withdraw Interstitial */}
                        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
                          <div className="truncate mr-2">
                            <span className="text-[10px] text-zinc-400 block font-bold">4. Withdraw Page - High-Paying Rewarded Interstitial ID:</span>
                            <span className="font-mono font-black text-rose-600 dark:text-rose-400 text-[11px] truncate block">
                              {admobConfig.rewardedInterstitialAdId}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(admobConfig.rewardedInterstitialAdId);
                              onToast?.('✓ Copied Rewarded Interstitial Ad ID');
                            }}
                            className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300 shrink-0 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* 3. LIVE PERFORMANCE & COINS METRICS */}
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
                        <Activity className="w-4 h-4 text-emerald-500" />
                        <span>Live Ad Impressions & Wallet Rewards</span>
                      </h4>

                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700">
                          <span className="text-[10px] text-zinc-400 block font-bold">Native Ads Served:</span>
                          <span className="text-lg font-black font-mono text-zinc-900 dark:text-white">
                            {admobStats.nativeAdsServed}
                          </span>
                        </div>
                        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700">
                          <span className="text-[10px] text-zinc-400 block font-bold">Rewarded Ads Completed:</span>
                          <span className="text-lg font-black font-mono text-amber-500">
                            {admobStats.rewardedAdsWatched}
                          </span>
                        </div>
                        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700">
                          <span className="text-[10px] text-zinc-400 block font-bold">Interstitials Played:</span>
                          <span className="text-lg font-black font-mono text-rose-500">
                            {admobStats.interstitialsCompleted}
                          </span>
                        </div>
                        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700">
                          <span className="text-[10px] text-zinc-400 block font-bold">Gold Coins Distributed:</span>
                          <span className="text-lg font-black font-mono text-emerald-600 dark:text-emerald-400">
                            {admobStats.totalCoinsAwarded.toLocaleString()} 🪙
                          </span>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 text-[11px] text-amber-900 dark:text-amber-200 flex items-center justify-between">
                        <span>Ad Revenue Cashback Return Rate:</span>
                        <span className="font-bold">1,000 Coins = 20% Money Return</span>
                      </div>
                    </div>

                    {/* 4. WORLD-CLASS ZERO-TOLERANCE SECURITY & AUTO-BAN WATCHDOG */}
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-wider flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-emerald-500" />
                          <span>World-Class Security & Auto-Ban Watchdog</span>
                        </h4>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 font-mono text-[10px] font-bold">
                          ACTIVE
                        </span>
                      </div>

                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                        Automatic Zero-Fraud Defense Engine: Any bot, dynamic instrumentation (Frida/Xposed), memory hook, or ultra-fast click spamming automatically triggers instant account ban and logs to this panel.
                      </p>

                      <div className="space-y-1.5">
                        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
                          <span className="font-bold text-zinc-700 dark:text-zinc-300">Bot / Malicious Fraud Blocks:</span>
                          <span className="font-mono font-bold text-rose-500">
                            {admobStats.blockedBotAttempts} Attempts Auto-Intercepted
                          </span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
                          <span className="font-bold text-zinc-700 dark:text-zinc-300">Total Banned Accounts:</span>
                          <span className="font-mono font-bold text-zinc-900 dark:text-white">
                            {bannedList.length} Accounts Restricted
                          </span>
                        </div>
                      </div>

                      {/* Banned Users Table / Quick Unban */}
                      {bannedList.length > 0 && (
                        <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 space-y-2">
                          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">
                            Recent Banned & Auto-Restricted Users:
                          </span>
                          <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                            {bannedList.map((b) => (
                              <div
                                key={b.uid}
                                className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-800/40 flex items-center justify-between text-xs"
                              >
                                <div className="truncate mr-2">
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-mono font-bold text-rose-600 dark:text-rose-400 text-[11px]">
                                      UID: {b.uid}
                                    </span>
                                    <span className="text-[10px] text-zinc-500">
                                      @{b.handle}
                                    </span>
                                  </div>
                                  <span className="text-[10px] text-zinc-400 truncate block">
                                    Reason: {b.reason || 'Security integrity violation'}
                                  </span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    unbanUser(b.uid);
                                    setBannedList(fetchBannedUsers());
                                    onToast?.(`✓ User ${b.uid} unbanned successfully.`);
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-white dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-[10px] font-bold hover:bg-zinc-100 dark:hover:bg-zinc-700 cursor-pointer shrink-0 shadow-xs"
                                >
                                  Unban
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ========================================================= */}
            {/* SUB-VIEW: FIRE LIVE CONNECT REAL-TIME DASHBOARD           */}
            {/* ========================================================= */}
            {activeSubView === 'fire_live_connect' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-5 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 text-[#fe2c55] flex items-center justify-center font-bold">
                    <Flame className="w-6 h-6 fill-current animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-zinc-900 dark:text-zinc-100">
                      Fire Live Connect System
                    </h4>
                    <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      Live Real-Time Sync Connected
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-xl border border-zinc-200 dark:border-zinc-700 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">Node Edge Server:</span>
                    <span className="font-mono font-bold text-zinc-900 dark:text-zinc-100">asia-southeast1 (Dhaka)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">Latency:</span>
                    <span className="font-mono font-black text-emerald-600">24 ms (Ultra Fast)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">Active Live Viewers:</span>
                    <span className="font-mono font-bold text-[#fe2c55]">12,480 viewers online</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">Real-Time Sync:</span>
                    <span className="font-bold text-zinc-800 dark:text-zinc-200">Reels, Hearts, Gifts & Calls</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onToast?.('✓ Fire Live Real-Time connection refreshed!')}
                  className="w-full py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 text-zinc-800 dark:text-zinc-200 font-extrabold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Test Fire Live Latency Ping</span>
                </button>
              </div>
            )}

            {/* 1. MANAGE POST */}
            {activeSubView === 'manage_post' && (
              <div className="space-y-4">
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Film className="w-5 h-5 text-[#fe2c55]" />
                      <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                        Your Posts ({reels.length})
                      </h4>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-50 text-[#fe2c55]">
                      Active
                    </span>
                  </div>
                  <p className="text-xs text-zinc-500 mb-4">
                    Manage your videos and photo carousels. Pin highlights to top or remove unwanted posts.
                  </p>

                  <div className="space-y-2.5">
                    {reels.map((reel) => {
                      const isPinned = pinnedPostIds.includes(reel.id);
                      return (
                        <div
                          key={reel.id}
                          className="flex items-center justify-between p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50/70 dark:bg-zinc-800/50 hover:bg-zinc-100/70 transition-colors"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-12 h-14 rounded-lg bg-zinc-800 overflow-hidden shrink-0 border border-zinc-200 dark:border-zinc-700">
                              <img
                                src={reel.thumbnailUrl || reel.posterUrl || reel.images?.[0] || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=200'}
                                alt=""
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 truncate block">
                                  {reel.caption || 'Untitled Post'}
                                </span>
                                {isPinned && (
                                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 flex items-center gap-0.5">
                                    <Pin className="w-2.5 h-2.5" /> Pinned
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-zinc-400 block mt-0.5">
                                ❤️ {reel.likesCount || 0} likes • 💬 {reel.commentsCount || 0} comments
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 ml-2">
                            <button
                              onClick={() => {
                                setPinnedPostIds((prev) =>
                                  isPinned ? prev.filter((id) => id !== reel.id) : [reel.id, ...prev]
                                );
                                onToast?.(isPinned ? 'Post unpinned' : '✓ Post pinned to top of profile');
                              }}
                              className={`p-1.5 rounded-lg border text-xs cursor-pointer ${
                                isPinned
                                  ? 'bg-amber-500 text-white border-amber-600'
                                  : 'bg-white dark:bg-zinc-700 text-zinc-700 dark:text-zinc-200 border-zinc-200 dark:border-zinc-600'
                              }`}
                              title={isPinned ? 'Unpin' : 'Pin to top'}
                            >
                              <Pin className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={() => {
                                if (onDeleteReel) {
                                  onDeleteReel(reel.id);
                                } else {
                                  onToast?.('✓ Post deleted successfully');
                                }
                              }}
                              className="p-1.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100 transition-colors cursor-pointer"
                              title="Delete post"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* 2. CONTENT PREFERENCES */}
            {activeSubView === 'content_preferences' && (
              <div className="space-y-4">
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                        Restricted Mode
                      </h4>
                      <p className="text-xs text-zinc-500 mt-0.5">
                        Limits videos that might not be suitable for everybody.
                      </p>
                    </div>
                    <ToggleSwitch
                      checked={restrictedMode}
                      onChange={(val) => {
                        setRestrictedMode(val);
                        onToast?.(val ? '✓ Restricted Mode ON' : 'Restricted Mode OFF');
                      }}
                    />
                  </div>

                  <hr className="border-zinc-100 dark:border-zinc-800" />

                  <div>
                    <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                      Filter Video Keywords
                    </h4>
                    <p className="text-xs text-zinc-500 mb-3">
                      Videos containing these hashtags or descriptions won't appear in For You or Following feeds.
                    </p>

                    <div className="flex gap-2 mb-3">
                      <input
                        type="text"
                        value={newKeywordInput}
                        onChange={(e) => setNewKeywordInput(e.target.value)}
                        placeholder="Add keyword (e.g. spoiler)"
                        className="flex-1 px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-[#fe2c55]"
                      />
                      <button
                        onClick={() => {
                          if (newKeywordInput.trim()) {
                            setBlockedKeywords((prev) => [...prev, newKeywordInput.trim().toLowerCase()]);
                            setNewKeywordInput('');
                            onToast?.('✓ Keyword filter added');
                          }
                        }}
                        className="px-3.5 py-2 bg-[#fe2c55] text-white font-bold text-xs rounded-xl cursor-pointer"
                      >
                        Add
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {blockedKeywords.map((kw) => (
                        <span
                          key={kw}
                          className="px-2.5 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold flex items-center gap-1.5 border border-zinc-200 dark:border-zinc-700"
                        >
                          #{kw}
                          <button
                            onClick={() => setBlockedKeywords((prev) => prev.filter((k) => k !== kw))}
                            className="text-zinc-400 hover:text-rose-500"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>

                  <hr className="border-zinc-100 dark:border-zinc-800" />

                  <button
                    onClick={() => onToast?.('✓ For You feed recommendation model refreshed!')}
                    className="w-full py-2.5 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 text-zinc-800 dark:text-zinc-200 font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh Your For You Feed</span>
                  </button>
                </div>
              </div>
            )}

            {/* 3. LIVE */}
            {activeSubView === 'live' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <Radio className="w-5 h-5 text-[#fe2c55] animate-pulse" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    LIVE Creator Studio
                  </h4>
                </div>
                <p className="text-xs text-zinc-500">
                  Broadcast live video to your followers and interact with real-time comments and gifts.
                </p>

                <div className="p-3 bg-rose-50/70 dark:bg-rose-950/30 rounded-xl border border-rose-100 dark:border-rose-900">
                  <div className="flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200">
                    <span>LIVE Eligibility:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-black">✓ Eligible (Pro)</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-zinc-500 mt-1">
                    <span>Gifts & Virtual items:</span>
                    <span className="text-zinc-700 dark:text-zinc-300 font-bold">Enabled</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (onOpenLive) {
                      onClose();
                      onOpenLive();
                    } else {
                      onToast?.('🔴 Going LIVE broadcast now!');
                    }
                  }}
                  className="w-full py-3 rounded-xl bg-[#fe2c55] text-white font-extrabold text-xs shadow-md hover:bg-[#e0264a] transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Radio className="w-4 h-4" />
                  <span>Start LIVE Broadcast Now</span>
                </button>
              </div>
            )}

            {/* 4. NOTIFICATION */}
            {activeSubView === 'notification' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="flex items-center justify-between pb-2">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Push Notifications</span>
                    <span className="text-[10px] text-zinc-400">Receive alerts when app is in background</span>
                  </div>
                  <ToggleSwitch
                    checked={notifications.push}
                    onChange={(v) => {
                      setNotifications((p) => ({ ...p, push: v }));
                      onToast?.(v ? 'Push alerts ON' : 'Push alerts OFF');
                    }}
                  />
                </div>

                <div className="flex items-center justify-between pt-3 pb-2">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Likes & Favorites</span>
                    <span className="text-[10px] text-zinc-400">When someone likes your videos or photos</span>
                  </div>
                  <ToggleSwitch
                    checked={notifications.likes}
                    onChange={(v) => setNotifications((p) => ({ ...p, likes: v }))}
                  />
                </div>

                <div className="flex items-center justify-between pt-3 pb-2">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Comments & Replies</span>
                    <span className="text-[10px] text-zinc-400">When someone comments on your post</span>
                  </div>
                  <ToggleSwitch
                    checked={notifications.comments}
                    onChange={(v) => setNotifications((p) => ({ ...p, comments: v }))}
                  />
                </div>

                <div className="flex items-center justify-between pt-3 pb-2">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Mentions & Tags</span>
                    <span className="text-[10px] text-zinc-400">When someone tags you in a video or comment</span>
                  </div>
                  <ToggleSwitch
                    checked={notifications.mentions}
                    onChange={(v) => setNotifications((p) => ({ ...p, mentions: v }))}
                  />
                </div>

                <div className="flex items-center justify-between pt-3">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Direct Messages</span>
                    <span className="text-[10px] text-zinc-400">When a friend sends you a private chat</span>
                  </div>
                  <ToggleSwitch
                    checked={notifications.dms}
                    onChange={(v) => setNotifications((p) => ({ ...p, dms: v }))}
                  />
                </div>
              </div>
            )}

            {/* 5. TIME AND WELL-BEING */}
            {activeSubView === 'time_wellbeing' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-indigo-500" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    Screen Time Management
                  </h4>
                </div>
                <p className="text-xs text-zinc-500">
                  Set daily screen time limits and break reminders to support digital balance.
                </p>

                <div className="space-y-2 pt-2">
                  <span className="text-xs font-black text-zinc-800 dark:text-zinc-200 block">Daily Limit</span>
                  <div className="grid grid-cols-4 gap-2">
                    {[40, 60, 90, 120].map((mins) => (
                      <button
                        key={mins}
                        onClick={() => {
                          setScreenTimeLimit(mins);
                          onToast?.(`✓ Daily limit set to ${mins} minutes`);
                        }}
                        className={`py-2 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                          screenTimeLimit === mins
                            ? 'bg-[#fe2c55] text-white border-[#fe2c55]'
                            : 'bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300'
                        }`}
                      >
                        {mins}m
                      </button>
                    ))}
                  </div>
                </div>

                <hr className="border-zinc-100 dark:border-zinc-800" />

                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Screen Time Breaks</span>
                    <span className="text-[10px] text-zinc-400">Remind every 30 minutes of continuous watch</span>
                  </div>
                  <ToggleSwitch
                    checked={breakReminder}
                    onChange={(v) => {
                      setBreakReminder(v);
                      onToast?.(v ? 'Break reminders enabled' : 'Break reminders off');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 6. FAMILY PAIRING */}
            {activeSubView === 'family_pairing' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-sky-500" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    Family Pairing
                  </h4>
                </div>
                <p className="text-xs text-zinc-500">
                  Link your TikTok account with your teen's account to customize safety settings, manage screen time, and filter content.
                </p>

                <div className="space-y-2 pt-2">
                  <button
                    onClick={() => onToast?.('✓ Parent mode pairing code generated!')}
                    className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/60 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-between text-xs font-bold text-zinc-900 dark:text-zinc-100 cursor-pointer"
                  >
                    <span>I am a Parent / Guardian</span>
                    <ChevronRight className="w-4 h-4 text-zinc-400" />
                  </button>

                  <button
                    onClick={() => onToast?.('✓ Teen scan mode ready to scan parent QR code')}
                    className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/60 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-between text-xs font-bold text-zinc-900 dark:text-zinc-100 cursor-pointer"
                  >
                    <span>I am a Teenager</span>
                    <ChevronRight className="w-4 h-4 text-zinc-400" />
                  </button>
                </div>
              </div>
            )}

            {/* 7. ACCOUNT */}
            {activeSubView === 'account' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="pb-2">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">User ID (UID)</span>
                  <span className="text-xs font-mono font-bold text-zinc-900 dark:text-zinc-100">
                    {(currentUser as any)?.uid || '7192849204820194'}
                  </span>
                </div>

                <div className="pt-3 pb-2">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Username</span>
                  <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                    @{currentUser?.handle || 'tiktok_user'}
                  </span>
                </div>

                <div className="pt-3 pb-2">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Phone Number</span>
                  <span className="text-xs font-mono font-bold text-zinc-900 dark:text-zinc-100">
                    {selectedCountry.code} 01875328569
                  </span>
                </div>

                <div className="pt-3 pb-2">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Country / Region</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-base">{selectedCountry.flag}</span>
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">{selectedCountry.name}</span>
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    onClick={() => onToast?.('✓ Switched to Pro / Creator Account!')}
                    className="w-full py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 font-extrabold text-xs text-zinc-800 dark:text-zinc-200 transition-colors cursor-pointer"
                  >
                    Switch to Business / Pro Account
                  </button>
                </div>
              </div>
            )}

            {/* 8. SECURITY AND PERMISSION */}
            {activeSubView === 'security_permission' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="flex items-center justify-between pb-2">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">2-Step Verification</span>
                    <span className="text-[10px] text-zinc-400">Protects account with SMS and Authenticator code</span>
                  </div>
                  <ToggleSwitch
                    checked={true}
                    onChange={(v) => onToast?.(v ? '2-Step Verification enabled' : '2-Step Verification disabled')}
                  />
                </div>

                <div className="pt-3 pb-2">
                  <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block mb-1">
                    Security Alerts & Devices
                  </span>
                  <p className="text-[10px] text-zinc-400 mb-2">No suspicious logins detected in the last 30 days.</p>
                  <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Your account security is in good standing.</span>
                  </div>
                </div>

                <div className="pt-3">
                  <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block mb-2">
                    App Permissions
                  </span>
                  <div className="space-y-1.5 text-xs text-zinc-700 dark:text-zinc-300">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-50 dark:bg-zinc-800">
                      <span>Camera</span>
                      <span className="text-emerald-600 font-black">Allowed</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-50 dark:bg-zinc-800">
                      <span>Microphone</span>
                      <span className="text-emerald-600 font-black">Allowed</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-50 dark:bg-zinc-800">
                      <span>Photos & Videos</span>
                      <span className="text-emerald-600 font-black">Allowed</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 9. SHARE PROFILE */}
            {activeSubView === 'share_profile' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-5 border border-zinc-200 dark:border-zinc-800 shadow-xs flex flex-col items-center text-center space-y-4">
                <div className="w-16 h-16 rounded-full border-2 border-[#fe2c55] overflow-hidden p-0.5 shadow-md">
                  <img
                    src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'}
                    alt=""
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    {currentUser?.name || 'TikTok Creator'}
                  </h4>
                  <p className="text-xs text-zinc-500 font-semibold">@{currentUser?.handle || 'user'}</p>
                </div>

                <div className="w-40 h-40 bg-zinc-900 rounded-2xl p-3 flex items-center justify-center border-4 border-[#25f4ee]/40 shadow-lg">
                  <QrCode className="w-28 h-28 text-white" />
                </div>

                <div className="w-full space-y-2 pt-2">
                  <button
                    onClick={() => {
                      try {
                        navigator.clipboard?.writeText(window.location.origin + '/@' + (currentUser?.handle || 'user'));
                        onToast?.('✓ Profile link copied to clipboard!');
                      } catch {
                        onToast?.('✓ Profile link copied!');
                      }
                    }}
                    className="w-full py-2.5 rounded-xl bg-[#fe2c55] text-white font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Copy Profile Link</span>
                  </button>

                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <button
                      onClick={() => onToast?.('✓ Sharing to WhatsApp')}
                      className="py-2 rounded-xl bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-200 cursor-pointer"
                    >
                      WhatsApp
                    </button>
                    <button
                      onClick={() => onToast?.('✓ Sharing to Facebook')}
                      className="py-2 rounded-xl bg-blue-50 text-blue-700 font-bold text-xs border border-blue-200 cursor-pointer"
                    >
                      Facebook
                    </button>
                    <button
                      onClick={() => onToast?.('✓ Sharing to Messages')}
                      className="py-2 rounded-xl bg-purple-50 text-purple-700 font-bold text-xs border border-purple-200 cursor-pointer"
                    >
                      Messages
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 10. PRIVATE ACCOUNT */}
            {activeSubView === 'private_account' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="pr-3">
                    <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                      Private Account
                    </h4>
                    <p className="text-xs text-zinc-500 mt-1">
                      With a private account, only users you approve can follow you and watch your videos. Your existing followers won't be affected.
                    </p>
                  </div>
                  <ToggleSwitch
                    checked={isPrivateAccount}
                    onChange={(val) => {
                      setIsPrivateAccount(val);
                      try {
                        localStorage.setItem('tiktok_private_account', String(val));
                      } catch {}
                      onToast?.(val ? '🔒 Account is now Private' : '🌐 Account is now Public');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 11. BLOCKED ACCOUNT */}
            {activeSubView === 'blocked_account' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Blocked Accounts ({blockedUsers.length})
                  </h4>
                  <p className="text-xs text-zinc-500">
                    Blocked users cannot view your videos, send you messages, or find your profile.
                  </p>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={blockHandleInput}
                    onChange={(e) => setBlockHandleInput(e.target.value)}
                    placeholder="Block handle (e.g. @spammer)"
                    className="flex-1 px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      if (blockHandleInput.trim()) {
                        setBlockedUsers((p) => [...p, blockHandleInput.trim()]);
                        setBlockHandleInput('');
                        onToast?.('✓ Account added to block list');
                      }
                    }}
                    className="px-3 py-2 bg-zinc-900 dark:bg-zinc-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    Block
                  </button>
                </div>

                <div className="space-y-2 pt-2">
                  {blockedUsers.map((user) => (
                    <div
                      key={user}
                      className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between"
                    >
                      <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">{user}</span>
                      <button
                        onClick={() => {
                          setBlockedUsers((p) => p.filter((u) => u !== user));
                          onToast?.(`✓ Unblocked ${user}`);
                        }}
                        className="px-3 py-1 bg-white dark:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-600 rounded-lg text-xs font-bold hover:bg-zinc-100 cursor-pointer"
                      >
                        Unblock
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 12. COMMENT */}
            {activeSubView === 'comment' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Who can comment on your videos
                  </h4>
                  <p className="text-xs text-zinc-500 mb-3">Choose who is allowed to comment on your posts.</p>

                  <div className="space-y-2">
                    {[
                      { id: 'everyone', label: 'Everyone' },
                      { id: 'followers', label: 'Followers that you follow back' },
                      { id: 'none', label: 'No one' },
                    ].map((opt) => (
                      <div
                        key={opt.id}
                        onClick={() => {
                          setCommentPrivacy(opt.id as any);
                          onToast?.(`Comment privacy updated: ${opt.label}`);
                        }}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                      >
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{opt.label}</span>
                        {commentPrivacy === opt.id && <Check className="w-4 h-4 text-[#fe2c55] stroke-[3]" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 13. MENTION */}
            {activeSubView === 'mention' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Who can mention and tag you
                  </h4>
                  <p className="text-xs text-zinc-500 mb-3">Control who can mention your handle in videos and comments.</p>

                  <div className="space-y-2">
                    {[
                      { id: 'everyone', label: 'Everyone' },
                      { id: 'followers', label: 'People you follow' },
                      { id: 'none', label: 'No one' },
                    ].map((opt) => (
                      <div
                        key={opt.id}
                        onClick={() => {
                          setMentionPrivacy(opt.id as any);
                          onToast?.(`Mentions updated: ${opt.label}`);
                        }}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                      >
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{opt.label}</span>
                        {mentionPrivacy === opt.id && <Check className="w-4 h-4 text-[#fe2c55] stroke-[3]" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 14. DIRECT MESSAGE */}
            {activeSubView === 'direct_message' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Direct Messages
                  </h4>
                  <p className="text-xs text-zinc-500 mb-3">Choose who can send you direct chat messages.</p>

                  <div className="space-y-2">
                    {[
                      { id: 'everyone', label: 'Everyone' },
                      { id: 'friends', label: 'Friends (Followers you follow back)' },
                      { id: 'none', label: 'No one' },
                    ].map((opt) => (
                      <div
                        key={opt.id}
                        onClick={() => {
                          setDmPrivacy(opt.id as any);
                          onToast?.(`Direct messages set to: ${opt.label}`);
                        }}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                      >
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{opt.label}</span>
                        {dmPrivacy === opt.id && <Check className="w-4 h-4 text-[#fe2c55] stroke-[3]" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 15. REUSE OF CONTENT (DUET / STITCH) */}
            {activeSubView === 'reuse_content' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Duet & Stitch (Reuse of Content)
                  </h4>
                  <p className="text-xs text-zinc-500 mb-3">Allow other creators to Duet or Stitch with your public videos.</p>

                  <div className="space-y-2">
                    {[
                      { id: 'everyone', label: 'Everyone' },
                      { id: 'friends', label: 'Friends only' },
                      { id: 'only_me', label: 'Only Me (Disabled)' },
                    ].map((opt) => (
                      <div
                        key={opt.id}
                        onClick={() => {
                          setDuetPrivacy(opt.id as any);
                          onToast?.(`Duet & Stitch permission: ${opt.label}`);
                        }}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                      >
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{opt.label}</span>
                        {duetPrivacy === opt.id && <Check className="w-4 h-4 text-[#fe2c55] stroke-[3]" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 16. DOWNLOAD */}
            {activeSubView === 'download' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="pr-3">
                    <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                      Video Downloads
                    </h4>
                    <p className="text-xs text-zinc-500 mt-1">
                      Allow other users to download your videos and share them to other platforms. When turned off, viewers can only share a link.
                    </p>
                  </div>
                  <ToggleSwitch
                    checked={allowDownloads}
                    onChange={(val) => {
                      setAllowDownloads(val);
                      try {
                        localStorage.setItem('tiktok_allow_downloads', String(val));
                      } catch {}
                      onToast?.(val ? '✓ Video downloads allowed' : 'Video downloads disabled');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 17. FOLLOWING LIST */}
            {activeSubView === 'following_list' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Who can see your following list
                  </h4>
                  <div className="space-y-2 mt-3">
                    {[
                      { id: 'everyone', label: 'Everyone' },
                      { id: 'only_me', label: 'Only Me' },
                    ].map((opt) => (
                      <div
                        key={opt.id}
                        onClick={() => {
                          setFollowingListPrivacy(opt.id as any);
                          onToast?.(`Following list visibility: ${opt.label}`);
                        }}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                      >
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{opt.label}</span>
                        {followingListPrivacy === opt.id && <Check className="w-4 h-4 text-[#fe2c55] stroke-[3]" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 18. LIKE VIDEOS */}
            {activeSubView === 'liked_videos' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Who can see your liked videos
                  </h4>
                  <div className="space-y-2 mt-3">
                    {[
                      { id: 'everyone', label: 'Everyone' },
                      { id: 'only_me', label: 'Only Me' },
                    ].map((opt) => (
                      <div
                        key={opt.id}
                        onClick={() => {
                          setLikedVideosPrivacy(opt.id as any);
                          onToast?.(`Liked videos visibility: ${opt.label}`);
                        }}
                        className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/50 flex items-center justify-between cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                      >
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{opt.label}</span>
                        {likedVideosPrivacy === opt.id && <Check className="w-4 h-4 text-[#fe2c55] stroke-[3]" />}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 19. VIEWERS */}
            {activeSubView === 'viewers' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="flex items-center justify-between pb-2">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Profile View History</span>
                    <span className="text-[10px] text-zinc-400">See who viewed your profile in the past 30 days</span>
                  </div>
                  <ToggleSwitch
                    checked={profileViewHistory}
                    onChange={(v) => {
                      setProfileViewHistory(v);
                      onToast?.(v ? 'Profile view history ON' : 'Profile view history OFF');
                    }}
                  />
                </div>

                <div className="flex items-center justify-between pt-3">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Post View History</span>
                    <span className="text-[10px] text-zinc-400">Allow followers to see that you viewed their posts</span>
                  </div>
                  <ToggleSwitch
                    checked={postViewHistory}
                    onChange={(v) => {
                      setPostViewHistory(v);
                      onToast?.(v ? 'Post view history ON' : 'Post view history OFF');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 20. AUDIENCE CONTROL */}
            {activeSubView === 'audience_control' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="pr-3">
                    <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                      Restrict to 18+ Viewers
                    </h4>
                    <p className="text-xs text-zinc-500 mt-1">
                      Restrict your videos to viewers aged 18 and older. This ensures mature content is only delivered to adult audiences.
                    </p>
                  </div>
                  <ToggleSwitch
                    checked={is18PlusRestricted}
                    onChange={(v) => {
                      setIs18PlusRestricted(v);
                      onToast?.(v ? '18+ restriction active' : '18+ restriction disabled');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 21. PLAY BACK */}
            {activeSubView === 'playback' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="flex items-center justify-between pb-2">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Auto-Scroll</span>
                    <span className="text-[10px] text-zinc-400">Automatically scroll to the next video when finished</span>
                  </div>
                  <ToggleSwitch
                    checked={isAutoScroll}
                    onChange={(v) => {
                      setIsAutoScroll(v);
                      try {
                        localStorage.setItem('tiktok_auto_scroll', String(v));
                      } catch {}
                      onToast?.(v ? 'Auto-scroll enabled' : 'Auto-scroll disabled');
                    }}
                  />
                </div>

                <div className="flex items-center justify-between pt-3">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Open TikTok on Mute</span>
                    <span className="text-[10px] text-zinc-400">Always start playback muted to avoid sudden loud sounds</span>
                  </div>
                  <ToggleSwitch
                    checked={isMuteOnOpen}
                    onChange={(v) => {
                      setIsMuteOnOpen(v);
                      try {
                        localStorage.setItem('tiktok_mute_on_open', String(v));
                      } catch {}
                      onToast?.(v ? 'Mute on open active' : 'Mute on open disabled');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 22. DISPLAY */}
            {activeSubView === 'display' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Theme Appearance
                  </h4>
                  <p className="text-xs text-zinc-500 mb-3">Choose light or dark visual theme for TikTok.</p>

                  <div className="grid grid-cols-2 gap-3">
                    <div
                      onClick={() => {
                        if (themeMode === 'dark') onToggleTheme();
                        onToast?.('Light theme applied');
                      }}
                      className={`p-3 rounded-2xl border-2 flex flex-col items-center gap-2 cursor-pointer transition-all ${
                        themeMode === 'light'
                          ? 'border-[#fe2c55] bg-rose-50/40 dark:bg-zinc-800'
                          : 'border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/40'
                      }`}
                    >
                      <Sun className="w-6 h-6 text-amber-500" />
                      <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100">Light Mode</span>
                    </div>

                    <div
                      onClick={() => {
                        if (themeMode === 'light') onToggleTheme();
                        onToast?.('Dark theme applied');
                      }}
                      className={`p-3 rounded-2xl border-2 flex flex-col items-center gap-2 cursor-pointer transition-all ${
                        themeMode === 'dark'
                          ? 'border-[#fe2c55] bg-rose-50/40 dark:bg-zinc-800'
                          : 'border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/40'
                      }`}
                    >
                      <Moon className="w-6 h-6 text-indigo-400" />
                      <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100">Dark Mode</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 23. LANGUAGE: 200+ WORLD COUNTRIES & REGIONAL DIALECTS */}
            {activeSubView === 'language' && (
              <div className="space-y-3">
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-3 border border-zinc-200 dark:border-zinc-800 shadow-xs">
                  <div className="relative">
                    <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={languageSearchQuery}
                      onChange={(e) => setLanguageSearchQuery(e.target.value)}
                      placeholder="Search 200+ country languages (e.g. Bangladesh, Arabic, Spanish)..."
                      className="w-full pl-9 pr-4 py-2 bg-zinc-50 dark:bg-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-[#fe2c55]"
                    />
                  </div>
                  <span className="text-[10px] text-zinc-400 block mt-2 text-right">
                    Showing {COUNTRIES_200.filter(c => 
                      !languageSearchQuery || 
                      c.name.toLowerCase().includes(languageSearchQuery.toLowerCase()) ||
                      c.nativeName.toLowerCase().includes(languageSearchQuery.toLowerCase()) ||
                      c.languageName.toLowerCase().includes(languageSearchQuery.toLowerCase()) ||
                      c.nativeLanguageName.toLowerCase().includes(languageSearchQuery.toLowerCase())
                    ).length} of {COUNTRIES_200.length} world languages
                  </span>
                </div>

                <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 max-h-[60vh] overflow-y-auto no-scrollbar">
                  {COUNTRIES_200.filter((c) =>
                    !languageSearchQuery ||
                    c.name.toLowerCase().includes(languageSearchQuery.toLowerCase()) ||
                    c.nativeName.toLowerCase().includes(languageSearchQuery.toLowerCase()) ||
                    c.languageName.toLowerCase().includes(languageSearchQuery.toLowerCase()) ||
                    c.nativeLanguageName.toLowerCase().includes(languageSearchQuery.toLowerCase())
                  ).map((item) => (
                    <div
                      key={item.code}
                      onClick={() => {
                        onLanguageChange(item.language as any);
                        walletEarningsService.setCurrency(item.currencyCode);
                        setActiveSubView(null);
                        onToast?.(`✓ Language set to: ${item.nativeLanguageName} • ${item.name} (${item.flag})`);
                      }}
                      className="py-3 px-3 flex items-center justify-between cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl shrink-0">{item.flag}</span>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                              {item.nativeLanguageName}
                            </span>
                            <span className="text-[10px] text-zinc-400 font-mono">
                              ({item.name})
                            </span>
                          </div>
                          <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block">
                            {item.languageName} • {item.currencyCode} ({item.currencySymbol})
                          </span>
                        </div>
                      </div>

                      {language === item.language && (
                        <span className="text-xs font-black text-[#fe2c55] flex items-center gap-1 shrink-0">
                          <Check className="w-4 h-4 stroke-[3]" /> Active
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 24. ACCESSIBILITY */}
            {activeSubView === 'accessibility' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="flex items-center justify-between pb-2">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Always Show Captions</span>
                    <span className="text-[10px] text-zinc-400">Generate real-time subtitles for spoken video audio</span>
                  </div>
                  <ToggleSwitch
                    checked={true}
                    onChange={(v) => onToast?.(v ? 'Captions enabled' : 'Captions disabled')}
                  />
                </div>

                <div className="flex items-center justify-between pt-3">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Animated Thumbnails</span>
                    <span className="text-[10px] text-zinc-400">Play animated previews on video covers</span>
                  </div>
                  <ToggleSwitch
                    checked={true}
                    onChange={(v) => onToast?.(v ? 'Animated thumbnails ON' : 'Animated thumbnails OFF')}
                  />
                </div>
              </div>
            )}

            {/* 25. CONTACT AND LOCATION */}
            {activeSubView === 'contact_location' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-3">
                <div className="flex items-center justify-between pb-2">
                  <div className="pr-3">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Sync Phone Contacts</span>
                    <span className="text-[10px] text-zinc-400">Find your friends who are on TikTok</span>
                  </div>
                  <ToggleSwitch
                    checked={true}
                    onChange={(v) => onToast?.(v ? 'Contacts sync active' : 'Contacts sync disabled')}
                  />
                </div>

                <div className="pt-3 pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Location Permission</span>
                      <span className="text-[10px] text-zinc-400">GPS location for local feeds and sounds</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-600">Active</span>
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    onClick={() => setActiveSubView('countries')}
                    className="w-full py-2.5 px-3 rounded-xl bg-sky-50 dark:bg-sky-950/40 text-sky-800 dark:text-sky-300 font-extrabold text-xs flex items-center justify-between cursor-pointer border border-sky-100 dark:border-sky-900"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{selectedCountry.flag}</span>
                      <span>Selected Country: {selectedCountry.name} ({selectedCountry.code})</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-sky-500" />
                  </button>
                </div>
              </div>
            )}

            {/* 26. OFFLINE VIDEO */}
            {activeSubView === 'offline_video' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <Download className="w-5 h-5 text-cyan-500" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    Offline Videos
                  </h4>
                </div>
                <p className="text-xs text-zinc-500">
                  Download 50 to 200 videos while connected to Wi-Fi so you can watch TikTok completely offline anywhere without mobile data.
                </p>

                <div className="p-3 bg-cyan-50 dark:bg-cyan-950/30 rounded-xl border border-cyan-100 dark:border-cyan-900 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100 block">Current Status</span>
                    <span className="text-[10px] text-zinc-500">30 videos downloaded (75 MB cached)</span>
                  </div>
                  <span className="text-xs font-black text-cyan-600 dark:text-cyan-400">Ready</span>
                </div>

                <div className="space-y-2 pt-1">
                  {[
                    { count: 50, size: '120 MB' },
                    { count: 100, size: '250 MB' },
                    { count: 200, size: '500 MB' },
                  ].map((pkg) => (
                    <button
                      key={pkg.count}
                      onClick={() => onToast?.(`✓ Downloading ${pkg.count} offline videos (${pkg.size})...`)}
                      className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 flex items-center justify-between text-xs font-bold cursor-pointer hover:bg-zinc-100 transition-colors"
                    >
                      <span>Download {pkg.count} Videos</span>
                      <span className="text-zinc-400 font-mono">{pkg.size}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 27. FREE UP SPACE */}
            {activeSubView === 'free_space' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs divide-y divide-zinc-100 dark:divide-zinc-800 space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Free up space & Cache
                  </h4>
                  <p className="text-xs text-zinc-500">
                    Free up storage space by clearing temporary cache and offline draft files.
                  </p>
                </div>

                <div className="pt-3 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Cache</span>
                    <span className="text-[10px] text-zinc-400">
                      Auto-purge: 3 days | Cap: 100 files ({cacheStats.count} cached)
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-zinc-600 dark:text-zinc-300">
                      {cacheStats.sizeMb} MB
                    </span>
                    <button
                      onClick={async () => {
                        await videoCacheManager.clearAllCache();
                        onToast?.('✓ Video cache cleared successfully! (3-day auto-purge policy active)');
                        setActiveSubView(null);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-rose-50 text-[#fe2c55] border border-rose-200 font-bold text-xs hover:bg-rose-100 cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                <div className="pt-3 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100 block">Downloads</span>
                    <span className="text-[10px] text-zinc-400">Stickers, filters and offline drafts</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-zinc-600 dark:text-zinc-300">0.0 MB</span>
                    <button
                      onClick={() => onToast?.('✓ Downloads cleared')}
                      className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 font-bold text-xs hover:bg-zinc-200 cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 28. DATA SAVER */}
            {activeSubView === 'data_saver' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="pr-3">
                    <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                      Data Saver
                    </h4>
                    <p className="text-xs text-zinc-500 mt-1">
                      Reduce your data usage when using cellular mobile data. Videos might be at a lower resolution or take longer to load. This will not apply when on Wi-Fi.
                    </p>
                  </div>
                  <ToggleSwitch
                    checked={isDataSaver}
                    onChange={(val) => {
                      setIsDataSaver(val);
                      try {
                        localStorage.setItem('tiktok_data_saver', String(val));
                      } catch {}
                      onToast?.(val ? '✓ Data saver mode active' : 'Data saver disabled');
                    }}
                  />
                </div>
              </div>
            )}

            {/* 29. HELP CENTER */}
            {activeSubView === 'help_center' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-indigo-500" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    TikTok Help Center
                  </h4>
                </div>
                <p className="text-xs text-zinc-500">Find answers and get 24/7 support.</p>

                <div className="space-y-2 pt-2">
                  {[
                    'Account and Login Issues',
                    'Privacy, Safety and Security',
                    'Creator Rewards & Monetization',
                    'Report a Problem or Inappropriate Content',
                  ].map((topic) => (
                    <div
                      key={topic}
                      onClick={() => onToast?.(`✓ Help topic opened: ${topic}`)}
                      className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800 flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
                    >
                      <span>{topic}</span>
                      <ChevronRight className="w-4 h-4 text-zinc-400" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 30. PRIVACY CENTER */}
            {activeSubView === 'privacy_center' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-500" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    TikTok Privacy Center
                  </h4>
                </div>
                <p className="text-xs text-zinc-500">
                  Learn about how we protect your information and exercise your privacy rights.
                </p>

                <div className="space-y-2 pt-2">
                  <button
                    onClick={() => onToast?.('✓ Your TikTok data export file (.json) requested')}
                    className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 flex items-center justify-between text-xs font-bold text-zinc-900 dark:text-zinc-100 cursor-pointer"
                  >
                    <span>Download Your TikTok Data (JSON)</span>
                    <Download className="w-4 h-4 text-zinc-400" />
                  </button>
                  <button
                    onClick={() => onToast?.('✓ Privacy policy summary opened')}
                    className="w-full p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 flex items-center justify-between text-xs font-bold text-zinc-900 dark:text-zinc-100 cursor-pointer"
                  >
                    <span>Our Data Privacy Principles</span>
                    <ExternalLink className="w-4 h-4 text-zinc-400" />
                  </button>
                </div>
              </div>
            )}

            {/* 31. TERMS AND POLICIES */}
            {activeSubView === 'terms_policies' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-zinc-600" />
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100">
                    Terms and Policies
                  </h4>
                </div>
                <div className="space-y-2 pt-2">
                  {[
                    'Terms of Service',
                    'Privacy Policy',
                    'Community Guidelines',
                    'Intellectual Property Policy',
                    'Open Source Licenses',
                  ].map((doc) => (
                    <div
                      key={doc}
                      onClick={() => onToast?.(`✓ ${doc} viewed`)}
                      className="p-3 rounded-xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800 flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
                    >
                      <span>{doc}</span>
                      <ChevronRight className="w-4 h-4 text-zinc-400" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 32. ALL COUNTRIES & REGION SUB-VIEW */}
            {activeSubView === 'countries' && (
              <div className="space-y-3">
                {/* Auto-detected Country Banner */}
                <div className="p-3 bg-gradient-to-r from-sky-50 to-indigo-50 dark:from-sky-950/40 dark:to-indigo-950/40 border border-sky-100 dark:border-sky-900 rounded-2xl">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-sky-800 dark:text-sky-300 uppercase tracking-wider flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-sky-600" />
                      Auto-Detected from Device
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-200 dark:bg-sky-900 text-sky-900 dark:text-sky-200">
                      {detectedCountry.code}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-xl">{detectedCountry.flag}</span>
                    <div>
                      <h4 className="text-xs font-black text-zinc-900 dark:text-zinc-100">{detectedCountry.name}</h4>
                      <p className="text-[10px] text-zinc-600 dark:text-zinc-400">
                        App automatically sets country location & mobile OTP format
                      </p>
                    </div>
                  </div>
                </div>

                {/* Search Input */}
                <div className="relative">
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={countrySearch}
                    onChange={(e) => setCountrySearch(e.target.value)}
                    placeholder="Search all countries or dial code..."
                    className="w-full pl-9 pr-4 py-2 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-[#fe2c55]"
                  />
                </div>

                {/* Countries List */}
                <div className="space-y-2 pb-3">
                  {filteredCountries.map((c) => {
                    const isSelected = selectedCountry.iso === c.iso;
                    return (
                      <div
                        key={c.iso}
                        className={`p-3 rounded-2xl border transition-all ${
                          isSelected
                            ? 'bg-white dark:bg-zinc-900 border-[#fe2c55] shadow-md ring-1 ring-[#fe2c55]/30'
                            : 'bg-white dark:bg-zinc-900 border-zinc-200/80 dark:border-zinc-800 hover:border-zinc-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <span className="text-2xl">{c.flag}</span>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">{c.name}</span>
                                <span className="text-[10px] font-mono font-bold text-zinc-500">({c.code})</span>
                              </div>
                              <span className="text-[10px] text-zinc-500">{c.nativeLang}</span>
                            </div>
                          </div>

                          {isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950 text-[#fe2c55] text-[10px] font-black border border-rose-200 dark:border-rose-900 flex items-center gap-1">
                              <Check className="w-3 h-3 stroke-[3]" />
                              <span>Selected</span>
                            </span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 mt-2.5 pt-2 border-t border-zinc-100 dark:border-zinc-800">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedCountry(c);
                              try {
                                localStorage.setItem('tiktok_selected_country', c.iso);
                              } catch {}
                              onLanguageChange(c.language);
                              onToast?.(`✓ ${c.name} selected! Language & mobile OTP updated`);
                            }}
                            className="flex-1 py-1.5 px-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 active:scale-95 text-zinc-800 dark:text-zinc-200 text-[10px] font-extrabold transition-all cursor-pointer"
                          >
                            Set Country & Language
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setSelectedCountry(c);
                              try {
                                localStorage.setItem('tiktok_selected_country', c.iso);
                              } catch {}
                              if (onOpenAuthForCountry) {
                                onOpenAuthForCountry(c);
                                onClose();
                              } else {
                                onToast?.(`✓ Opening account for ${c.name}`);
                              }
                            }}
                            className="py-1.5 px-3 rounded-xl bg-[#fe2c55] hover:bg-[#e0264a] active:scale-95 text-white text-[10px] font-black shadow-xs transition-all cursor-pointer flex items-center gap-1"
                          >
                            <UserPlus className="w-3 h-3" />
                            <span>Create ID</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 33. SWITCH ACCOUNT */}
            {activeSubView === 'switch_account' && (
              <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
                <div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                    Switch Account
                  </h4>
                  <p className="text-xs text-zinc-500">
                    Easily switch between multiple TikTok profiles on this device.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="p-3 rounded-xl border-2 border-[#fe2c55] bg-rose-50/30 dark:bg-rose-950/20 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-full overflow-hidden border border-[#fe2c55]">
                        <img
                          src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100 block">
                          {currentUser?.name || 'Active Account'}
                        </span>
                        <span className="text-[10px] text-zinc-400">@{currentUser?.handle || 'user'}</span>
                      </div>
                    </div>
                    <span className="text-xs font-black text-[#fe2c55]">Active</span>
                  </div>

                  <button
                    onClick={() => {
                      if (onOpenAuth) {
                        onClose();
                        onOpenAuth();
                      } else {
                        onToast?.('✓ Open Add Account modal');
                      }
                    }}
                    className="w-full py-3 rounded-xl border border-dashed border-zinc-300 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-xs font-bold text-zinc-700 dark:text-zinc-300 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <UserPlus className="w-4 h-4 text-[#fe2c55]" />
                    <span>Add New Account</span>
                  </button>
                </div>
              </div>
            )}

          </div>
        ) : (
          /* ------------------------------------------------------------- */
          /* MAIN SETTINGS SCREEN                                          */
          /* ------------------------------------------------------------- */
          <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar bg-zinc-100 dark:bg-zinc-950">
            
            {/* Top Quick Banner: ALL COUNTRIES & REGION SELECTOR */}
            <div
              onClick={() => setActiveSubView('countries')}
              className="p-3 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 shadow-xs flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-850 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                  <Globe2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-extrabold text-zinc-900 dark:text-zinc-100">
                      All Countries & Region
                    </span>
                    <span className="text-base">{selectedCountry.flag}</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 block font-medium">
                    {selectedCountry.name} ({selectedCountry.code}) • {selectedCountry.nativeLang}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs text-[#fe2c55] font-bold">
                <span>Change</span>
                <ChevronRight className="w-4 h-4 text-zinc-400" />
              </div>
            </div>

            {/* ========================================================= */}
            {/* PROMOTED FEATURES BOX: TIKTOK BOOST & ADMIN SYSTEM        */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Promotion & Admin Control
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 0. Gemini AI Assistant (User Request: সেটিংসে ক্লিক করলে ভাসমান একটি জিমিনি এআই এসিস্ট্যান্ট থাকবে যাকে ইচ্ছে মতো নোরা চারা করা যাবে...) */}
                <div
                  className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition-colors bg-gradient-to-r from-cyan-50/60 via-indigo-50/40 to-purple-50/50 dark:from-cyan-950/30 dark:via-indigo-950/30 dark:to-purple-950/30"
                >
                  <div 
                    onClick={() => {
                      onToggleFloatingGemini?.(true);
                      onOpenGeminiAssistant?.();
                      onClose();
                    }}
                    className="flex items-center gap-3 cursor-pointer flex-1"
                  >
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-fuchsia-500 text-white flex items-center justify-center shadow-md shrink-0">
                      <Sparkles className="w-5 h-5 text-[#25f4ee] animate-pulse" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                          {language === 'bn' ? 'জিমিনি সুপার এআই (Gemini World #1 AI)' : 'Gemini Super AI Assistant'}
                        </span>
                        <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-600 text-white text-[9px] font-black uppercase">
                          World #1
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-medium block">
                        {language === 'bn' 
                          ? 'স্ক্রিনে ভাসমান নাড়াচাড়া • গুগল সার্চ বার • বহুভাষিক ভয়েস ও স্বয়ংক্রিয় অ্যাপ নেভিগেশন' 
                          : 'Floating draggable • Google-style search bar • Any language voice & navigation'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        const next = !isFloatingGeminiEnabled;
                        onToggleFloatingGemini?.(next);
                        onToast?.(
                          next 
                            ? (language === 'bn' ? '✨ ভাসমান জিমিনি এআই চালু! স্ক্রিনের যেকোনো জায়গায় টেনে রাখুন' : '✨ Floating Gemini AI active! Drag anywhere on screen')
                            : (language === 'bn' ? 'ভাসমান এআই সহকারী বন্ধ করা হয়েছে' : 'Floating AI disabled')
                        );
                      }}
                      className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-full border transition-all cursor-pointer shadow-xs active:scale-95 ${
                        isFloatingGeminiEnabled
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white border-emerald-400'
                          : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-500 border-zinc-300 dark:border-zinc-700'
                      }`}
                      title="ভাসমান বাটন টগল"
                    >
                      {isFloatingGeminiEnabled 
                        ? (language === 'bn' ? '✓ ভাসমান চালু' : '✓ Floating ON') 
                        : (language === 'bn' ? 'ভাসমান বন্ধ' : 'Floating OFF')}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onToggleFloatingGemini?.(true);
                        onOpenGeminiAssistant?.();
                        onClose();
                      }}
                      className="px-2.5 py-1 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-600 text-white text-[10px] font-bold shadow-xs flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
                    >
                      <span>{language === 'bn' ? 'ওপেন' : 'Open'}</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* 0. My Wallet & Earnings (User Requirement: My Wallet & Earnings সেটিংস এর ভিতর থাকবে সুন্দর করে ছোট করে অন্য লেখার মতো) */}
                <div
                  onClick={() => setActiveSubView('wallet_and_earnings')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors bg-gradient-to-r from-amber-50/80 via-yellow-50/50 to-emerald-50/60 dark:from-amber-950/20 dark:via-yellow-950/20 dark:to-emerald-950/20"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-emerald-500 text-zinc-950 flex items-center justify-center shadow-xs">
                      <Wallet className="w-4.5 h-4.5 text-zinc-950 stroke-[2.4]" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                          My Wallet & Earnings
                        </span>
                        <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-emerald-500 text-zinc-950 text-[9px] font-black uppercase">
                          GOLD
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-medium block">
                        Coins View • Live Currency Converter • Daily Breakdown • Withdraw & Recharge
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold">
                    <div className="text-right">
                      <span className="font-mono font-black text-amber-500 block leading-none">
                        {earningsWallet.totalCoins.toLocaleString()}
                      </span>
                      <span className="text-[10px] font-mono font-black text-emerald-500 block leading-none mt-0.5">
                        {walletEarningsService.convertCoinsToFiat(earningsWallet.totalCoins, earningsWallet.selectedCurrencyCode).symbol} {walletEarningsService.convertCoinsToFiat(earningsWallet.totalCoins, earningsWallet.selectedCurrencyCode).amount}
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-zinc-400 shrink-0" />
                  </div>
                </div>

                {/* 1. TikTok Boost & Promote */}
                <div
                  onClick={() => setActiveSubView('tiktok_boost')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors bg-gradient-to-r from-rose-50/40 via-transparent to-amber-50/30 dark:from-rose-950/20 dark:to-transparent"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-xs">
                      <Rocket className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                          TikTok Boost & Promote
                        </span>
                        <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[9px] font-black uppercase">
                          Viral Ads
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-medium block">
                        1k views = $0.40 • 1k likes = $1.00 (Wallet / bKash / Nagad)
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Refer & Earn ৳499 (User Request: সেটিংসে রেফারেন্স আইডি এই এপসের এবং রেফার অপশন থাকবে যার ভিতর লিংক এই আইডির এবং 499 টাকা আর্ন থাকবে...) */}
                <div
                  onClick={() => setActiveSubView('refer_and_earn')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors bg-gradient-to-r from-amber-50/70 via-rose-50/40 to-indigo-50/50 dark:from-amber-950/25 dark:via-rose-950/20 dark:to-indigo-950/20"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 via-rose-500 to-indigo-600 text-white flex items-center justify-center shadow-xs">
                      <Coins className="w-4.5 h-4.5 text-amber-200" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                          {language === 'bn' ? 'রেফার ও আর্ন (৳৪৯৯ বোনাস)' : 'Refer & Earn (৳499 Bonus)'}
                        </span>
                        <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-rose-600 text-white text-[9px] font-black uppercase">
                          ৳499 FREE
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-500 dark:text-zinc-400 font-medium block">
                        {language === 'bn' 
                          ? 'রেফারেল লিংক শেয়ার • ৪৯৯ টাকা আনলক • ৬০০ টাকা উইথড্র বা সরাসরি ভিডিও বুস্ট' 
                          : 'Share referral link • ৳499 unlocked • ৳600 withdraw or instant video boost'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-[#fe2c55] font-bold">
                    <span className="font-mono font-black text-amber-500">৳{userWallet.balanceBDT}</span>
                    <ChevronRight className="w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                {/* 2. Admin: User Search, Ban & Unban + Boost Approvals */}
                <div
                  onClick={() => {
                    if (isAdminAuthenticated) {
                      setActiveSubView('admin_panel');
                    } else {
                      setActiveSubView('admin_gate');
                    }
                  }}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-zinc-900 dark:bg-zinc-800 text-emerald-400 flex items-center justify-center">
                      <ShieldCheck className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                          Admin: Search, Ban/Unban & Boosts
                        </span>
                        <span className="px-1.5 py-0.2 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-[9px] font-black font-mono">
                          ADMIN
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-400 font-medium block">
                        Search UID/Name to Ban/Unban • Approve and deliver video boosts
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 3. Fire Live Connect Real-Time Node */}
                <div
                  onClick={() => setActiveSubView('fire_live_connect')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-[#fe2c55] flex items-center justify-center">
                      <Flame className="w-4.5 h-4.5 fill-current animate-pulse" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-zinc-900 dark:text-zinc-100">
                          Fire Live Connect System
                        </span>
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      </div>
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block">
                        Real-time live sync active • 24ms latency • Asia-SE1
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </div>
            </div>

            {/* ========================================================= */}
            {/* BOX 1: Manage Post - Content preferences - LIVE -         */}
            {/* Notification - Time and well-being - Family pairing       */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Content & Activity
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 1. Manage Post */}
                <div
                  onClick={() => setActiveSubView('manage_post')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Film className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Manage Post
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Content preferences */}
                <div
                  onClick={() => setActiveSubView('content_preferences')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <SlidersHorizontal className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Content preferences
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 3. LIVE */}
                <div
                  onClick={() => setActiveSubView('live')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Radio className="w-4.5 h-4.5 text-[#fe2c55] stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      LIVE
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 4. Notification */}
                <div
                  onClick={() => setActiveSubView('notification')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Bell className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Notification
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 5. Time and well-being */}
                <div
                  onClick={() => setActiveSubView('time_wellbeing')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Clock className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Time and well-being
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 6. Family pairing */}
                <div
                  onClick={() => setActiveSubView('family_pairing')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Users className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Family pairing
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </div>
            </div>

            {/* ========================================================= */}
            {/* BOX 2: Account - Security and permission - Share profile  */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Account
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 1. Account */}
                <div
                  onClick={() => setActiveSubView('account')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <User className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Account
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Security and permission */}
                <div
                  onClick={() => setActiveSubView('security_permission')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Security and permission
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 3. Share profile */}
                <div
                  onClick={() => setActiveSubView('share_profile')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Share2 className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Share profile
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </div>
            </div>

            {/* ========================================================= */}
            {/* BOX 3: Private account - Blocked account                  */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Privacy
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 1. Private account */}
                <div
                  onClick={() => setActiveSubView('private_account')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Lock className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Private account
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ToggleSwitch
                      checked={isPrivateAccount}
                      onChange={(val) => {
                        setIsPrivateAccount(val);
                        try {
                          localStorage.setItem('tiktok_private_account', String(val));
                        } catch {}
                        onToast?.(val ? '🔒 Account is now Private' : '🌐 Account is now Public');
                      }}
                    />
                  </div>
                </div>

                {/* 2. Blocked account */}
                <div
                  onClick={() => setActiveSubView('blocked_account')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <UserX className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Blocked account
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </div>
            </div>

            {/* ========================================================= */}
            {/* BOX 4: Interactions, Preferences & Device                 */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Interactions & Preferences
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 1. Comment */}
                <div
                  onClick={() => setActiveSubView('comment')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <MessageCircle className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Comment
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Mention */}
                <div
                  onClick={() => setActiveSubView('mention')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <AtSign className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Mention
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 3. Direct massage (Direct message) */}
                <div
                  onClick={() => setActiveSubView('direct_message')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Send className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Direct massage
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 4. Reuse of content */}
                <div
                  onClick={() => setActiveSubView('reuse_content')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Repeat className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Reuse of content
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 5. Download */}
                <div
                  onClick={() => setActiveSubView('download')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <DownloadCloud className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Download
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ToggleSwitch
                      checked={allowDownloads}
                      onChange={(val) => {
                        setAllowDownloads(val);
                        try {
                          localStorage.setItem('tiktok_allow_downloads', String(val));
                        } catch {}
                        onToast?.(val ? '✓ Downloads allowed' : 'Downloads disabled');
                      }}
                    />
                  </div>
                </div>

                {/* 6. Following list */}
                <div
                  onClick={() => setActiveSubView('following_list')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Users className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Following list
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 7. Like videos */}
                <div
                  onClick={() => setActiveSubView('liked_videos')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Heart className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Like videos
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 8. Viewers */}
                <div
                  onClick={() => setActiveSubView('viewers')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Eye className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Viewers
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 9. Audience control */}
                <div
                  onClick={() => setActiveSubView('audience_control')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Audience control
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 10. Play back */}
                <div
                  onClick={() => setActiveSubView('playback')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <PlaySquare className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Play back
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 11. Display */}
                <div
                  onClick={() => setActiveSubView('display')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Moon className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Display
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 12. Language */}
                <div
                  onClick={() => setActiveSubView('language')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Globe className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Language
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-zinc-400 font-bold">
                    <span>{language === 'en' ? 'English (US)' : language === 'bn' ? 'বাংলা' : language.toUpperCase()}</span>
                    <ChevronRight className="w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                {/* 13. Accessibility */}
                <div
                  onClick={() => setActiveSubView('accessibility')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <EyeOff className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Accessibility
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 14. Contact and location */}
                <div
                  onClick={() => setActiveSubView('contact_location')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Contact and location
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </div>
            </div>

            {/* ========================================================= */}
            {/* BOX 5: Cache, Cellular & Policies                         */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Cache & Cellular
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 1. Offline video */}
                <div
                  onClick={() => setActiveSubView('offline_video')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Download className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Offline video
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Free up space */}
                <div
                  onClick={() => setActiveSubView('free_space')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <HardDrive className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Free up space
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-mono font-bold text-zinc-400">
                      {cacheStats.sizeMb} MB
                    </span>
                    <ChevronRight className="w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                {/* 3. Data saver */}
                <div
                  onClick={() => setActiveSubView('data_saver')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Wifi className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Data saver
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ToggleSwitch
                      checked={isDataSaver}
                      onChange={(val) => {
                        setIsDataSaver(val);
                        try {
                          localStorage.setItem('tiktok_data_saver', String(val));
                        } catch {}
                        onToast?.(val ? '✓ Data saver mode active' : 'Data saver disabled');
                      }}
                    />
                  </div>
                </div>

                {/* 4. Help center */}
                <div
                  onClick={() => setActiveSubView('help_center')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Help center
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 5. Privacy center */}
                <div
                  onClick={() => setActiveSubView('privacy_center')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Shield className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Privacy center
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 6. Terms and policeic */}
                <div
                  onClick={() => setActiveSubView('terms_policies')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Terms and policeic
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </div>
            </div>

            {/* ========================================================= */}
            {/* BOX 6: Switch account - Log out                           */}
            {/* ========================================================= */}
            <div>
              <h5 className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider px-3 mb-1.5">
                Login & Session
              </h5>
              <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-xs border border-zinc-200/80 dark:border-zinc-800/80 overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800/60">
                {/* 1. Switch account */}
                <div
                  onClick={() => setActiveSubView('switch_account')}
                  className="p-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/40 active:bg-zinc-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <RefreshCw className="w-4.5 h-4.5 text-zinc-600 dark:text-zinc-300 stroke-[2.2]" />
                    <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                      Switch account
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>

                {/* 2. Log out */}
                <div
                  onClick={() => setShowLogoutConfirm(true)}
                  className="p-3.5 flex items-center justify-between hover:bg-rose-50/50 dark:hover:bg-rose-950/20 active:bg-rose-100 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <LogOut className="w-4.5 h-4.5 text-rose-500 stroke-[2.2]" />
                    <span className="text-xs font-extrabold text-rose-500">
                      Log out
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-rose-300" />
                </div>
              </div>
            </div>

          </div>
        )}

        {/* LOGOUT CONFIRMATION DIALOG */}
        {showLogoutConfirm && (
          <div className="absolute inset-0 z-60 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="w-full max-w-xs bg-white dark:bg-zinc-900 rounded-3xl p-5 shadow-2xl border border-zinc-200 dark:border-zinc-800 text-center animate-in zoom-in-95 duration-150">
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950/50 text-[#fe2c55] flex items-center justify-center mx-auto mb-3">
                <LogOut className="w-6 h-6 stroke-[2.2]" />
              </div>
              <h4 className="font-black text-sm text-zinc-900 dark:text-zinc-100 mb-1">
                Log out of TikTok?
              </h4>
              <p className="text-xs text-zinc-500 mb-5">
                You can always log back in at any time.
              </p>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowLogoutConfirm(false);
                    onLogout?.();
                    onClose();
                  }}
                  className="w-full py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-extrabold text-xs transition-colors cursor-pointer"
                >
                  Log out
                </button>
                <button
                  type="button"
                  onClick={() => setShowLogoutConfirm(false)}
                  className="w-full py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-bold text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
